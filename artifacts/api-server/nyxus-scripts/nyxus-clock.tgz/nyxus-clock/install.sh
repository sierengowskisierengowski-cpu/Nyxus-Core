#!/usr/bin/env bash
# NYXUS Clock — installer (called by nyxus_clock_install.sh)
# (c) 2026 Joseph Sierengowski - NYX-J5W-2026-SIERENGOWSKI-LOCKED
set -euo pipefail

B=$'\e[1m'; R=$'\e[0m'; CYAN=$'\e[38;5;51m'; PINK=$'\e[38;5;201m'
PURPLE=$'\e[38;5;177m'; DIM=$'\e[2m'
step() { printf "\n${PURPLE}▌${R} ${B}%s${R}\n" "$*"; }
ok()   { printf "  ${CYAN}✓${R}  %s\n" "$*"; }
fail() { printf "  ${PINK}✗${R}  %s\n" "$*" >&2; }

# Self-elevate
if [[ $EUID -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    exec sudo -E bash "$0" "$@"
  fi
  fail "must be run as root"; exit 1
fi

# Resolve the real user (we install user-readable bin + system .desktop)
TARGET_USER="${SUDO_USER:-${USER:-nyx}}"
TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
[[ -z "$TARGET_HOME" ]] && TARGET_HOME="/home/$TARGET_USER"

SLUG="nyxus-clock"
SLUG_SHORT="clock"
APP_ID="io.nyxus.${SLUG_SHORT}"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)/${SLUG}"

step "install python deps"
PKGS=(gtk4 python-gobject python-cairo python-pillow)

if command -v pacman >/dev/null; then
  pacman -S --needed --noconfirm "${PKGS[@]}" 2>/dev/null || \
    fail "(non-fatal) pacman could not install one of: ${PKGS[*]}"
fi
ok "deps checked"

step "copy app files to /opt/${SLUG}"
mkdir -p "/opt/${SLUG}"
cp -f "$SRC_DIR"/*.py "/opt/${SLUG}/"
chmod 755 "/opt/${SLUG}"
chmod 644 "/opt/${SLUG}"/*.py
ok "/opt/${SLUG}/ populated"

step "install launcher /usr/local/bin/${SLUG}"
cat > "/usr/local/bin/${SLUG}" <<EOF
#!/usr/bin/env bash
exec python3 /opt/${SLUG}/main.py "\$@"
EOF
chmod 755 "/usr/local/bin/${SLUG}"
ok "launcher installed"

step "install desktop entry"
cat > "/usr/share/applications/${APP_ID}.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=NYXUS Clock
GenericName=Clock
Comment=System clock with day/date — local time, real
Exec=/usr/local/bin/${SLUG}
Icon=${APP_ID}
Terminal=false
Categories=Utility;Clock;
StartupWMClass=${APP_ID}
Keywords=clock;time;date;
EOF
ok ".desktop installed"

step "install icon"
ICON_DIR="/usr/share/icons/hicolor/scalable/apps"
mkdir -p "$ICON_DIR"
cp -f "$SRC_DIR/icon.svg" "$ICON_DIR/${APP_ID}.svg"
# Also drop a 256px PNG location if the source has one
PNG_DIR="/usr/share/icons/hicolor/256x256/apps"
mkdir -p "$PNG_DIR"
if [[ -f "$SRC_DIR/icon.png" ]]; then
  cp -f "$SRC_DIR/icon.png" "$PNG_DIR/${APP_ID}.png"
fi
gtk-update-icon-cache -t -f /usr/share/icons/hicolor 2>/dev/null || true
update-desktop-database /usr/share/applications 2>/dev/null || true
ok "icons installed"

cat <<EOF

──────────────────────────────────────────────────────────────────────
${B}NYXUS Clock install complete.${R}
Launch:  ${CYAN}${SLUG}${R}    or pick "NYXUS Clock" from Rofi.
──────────────────────────────────────────────────────────────────────
EOF
