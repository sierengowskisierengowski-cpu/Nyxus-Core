"""
NYXUS SAGE — hand-drawn UI primitives.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Premium hand-drawn / wobbly button, icon, header, panel — same visual
language as the rest of the NYXUS suite. Built on GTK4 + Cairo.

Color tokens are intentionally muted/neutral here — brand colors will
be applied separately.
"""
from __future__ import annotations

import math
import random
from typing import Callable

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk     # noqa: E402


# ────────────────────────────────────────────────────────────────────────────
# palette  (placeholder — brand colors come in a later pass)
# ────────────────────────────────────────────────────────────────────────────

NYX = {
    "bg":         (0.039, 0.039, 0.071),
    "panel":      (0.071, 0.063, 0.106),
    "panel_h":    (0.094, 0.082, 0.137),
    "ink":        (0.94,  0.92,  0.97),
    "ink_dim":    (0.62,  0.58,  0.70),
    "ink_faint":  (0.36,  0.34,  0.42),
    # severity tokens — neutral hues, not brand
    "critical":   (0.92,  0.36,  0.42),
    "high":       (0.92,  0.66,  0.34),
    "medium":     (0.78,  0.74,  0.42),
    "low":        (0.50,  0.74,  0.82),
    "info":       (0.55,  0.58,  0.72),
    "ok":         (0.50,  0.78,  0.58),
    # gentle accent (for active state) — neutral lavender
    "accent":     (0.66,  0.58,  0.84),
}


# ────────────────────────────────────────────────────────────────────────────
# global CSS — handwritten font everywhere, dark base
# ────────────────────────────────────────────────────────────────────────────

GLOBAL_CSS = b"""
* { font-family: "Caveat", "Patrick Hand", "Comic Neue", sans-serif; }
window { background-color: transparent; color: #efefee; }
.sage-shell { background-color: transparent; }
.sage-sidebar { background-color: rgba(8,6,18,0.62); border-right: 1px solid rgba(168,154,202,0.25); padding: 10px 6px; border-radius: 0 8px 8px 0; }
.sage-content { background-color: transparent; padding: 14px 16px; }
.sage-panel { background-color: rgba(10,10,20,0.62); border-radius: 8px; padding: 10px; border: 1px solid rgba(168,154,202,0.18); }
.sage-statusbar { background-color: rgba(5,4,12,0.78); padding: 5px 12px; border-top: 1px solid rgba(168,154,202,0.25); color: #c8b2db; font-size: 16px; }
.sage-doc-title { color: #c8b2db; font-size: 18px; }
.sage-faint { color: #b9a4cc; font-size: 16px; }
.sage-muted { color: #8c8aa0; font-size: 15px; }
.sage-h1 { font-size: 32px; color: #ffd700; text-shadow: 0 0 10px rgba(255,215,0,0.45); }
.sage-h2 { font-size: 24px; color: #ff3ea5; text-shadow: 0 0 8px rgba(255,62,165,0.40); }
.sage-h3 { font-size: 20px; color: #c4607a; }
.sage-mono { font-family: "JetBrainsMono Nerd Font", "Fira Code", "DejaVu Sans Mono", monospace; font-size: 14px; }
.sage-issue { background-color: rgba(20,20,32,0.62); border-radius: 6px; padding: 8px 10px; border: 1px solid rgba(255,62,165,0.20); }
.sage-issue:hover { background-color: rgba(255,62,165,0.18); border-color: rgba(255,62,165,0.55); box-shadow: 0 0 10px rgba(255,62,165,0.30); }
entry, spinbutton {
  background-color: rgba(20,9,28,0.62); color: #efefee; border: 1px solid rgba(255,62,165,0.45);
  border-radius: 8px; padding: 6px 12px; font-size: 18px;
}
entry:focus, spinbutton:focus { border-color: rgba(0,220,255,0.85); box-shadow: 0 0 12px rgba(0,220,255,0.45); }
button { font-size: 18px; }
scrollbar { background: transparent; }
scrollbar slider { background: rgba(255,62,165,0.55); border-radius: 4px; min-width: 8px; min-height: 8px; }
scrollbar slider:hover { background: rgba(0,220,255,0.85); box-shadow: 0 0 8px rgba(0,220,255,0.55); }
"""


def install_global_css(display) -> None:
    prov = Gtk.CssProvider()
    prov.load_from_data(GLOBAL_CSS)
    Gtk.StyleContext.add_provider_for_display(
        display, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )


# ────────────────────────────────────────────────────────────────────────────
# sketch helpers
# ────────────────────────────────────────────────────────────────────────────

def jitter(seed: int, amp: float = 1.6) -> Callable[[float], float]:
    rng = random.Random(seed)
    return lambda s=1.0: rng.uniform(-amp * s, amp * s)


def _sketch_path(cr, x, y, w, h, j_amp: float, seed: int) -> None:
    j = jitter(seed, j_amp)
    cr.move_to(x + j(.4), y + j(.4))
    cr.curve_to(x + w * .33 + j(), y + j(),
                x + w * .67 + j(), y + j(),
                x + w + j(.4), y + j(.4))
    cr.curve_to(x + w + j(), y + h * .33 + j(),
                x + w + j(), y + h * .67 + j(),
                x + w + j(.4), y + h + j(.4))
    cr.curve_to(x + w * .67 + j(), y + h + j(),
                x + w * .33 + j(), y + h + j(),
                x + j(.4), y + h + j(.4))
    cr.curve_to(x + j(), y + h * .67 + j(),
                x + j(), y + h * .33 + j(),
                x + j(.4), y + j(.4))
    cr.close_path()


def sketch_rect(cr, x, y, w, h, rgba, thick=2.4, seed=None, *,
                shadow: bool = True, double_stroke: bool = True):
    s = seed if seed is not None else int(x * 7 + y * 13 + w * 3 + h * 5)
    cr.set_line_cap(1); cr.set_line_join(1)
    if shadow:
        cr.save()
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.45)
        cr.set_line_width(thick + 1.6)
        _sketch_path(cr, x + 1.2, y + 1.6, w, h, 1.0, s ^ 0xA5A5)
        cr.stroke()
        cr.restore()
    cr.set_source_rgba(*rgba if len(rgba) == 4 else (*rgba, 0.95))
    cr.set_line_width(thick)
    _sketch_path(cr, x, y, w, h, 1.1, s)
    cr.stroke()
    if double_stroke:
        col = rgba
        cr.set_source_rgba(col[0], col[1], col[2],
                           (col[3] if len(col) == 4 else 0.95) * 0.45)
        cr.set_line_width(max(1.0, thick * 0.55))
        _sketch_path(cr, x + 0.6, y + 0.4, w - 0.2, h - 0.2, 1.4, s ^ 0x5A5A)
        cr.stroke()


def sketch_rect_fill(cr, x, y, w, h, rgba, thick=2.0, seed=None):
    s = seed if seed is not None else int(x * 7 + y * 13 + w * 3 + h * 5)
    a = rgba[3] if len(rgba) == 4 else 1.0
    cr.save()
    cr.set_source_rgba(rgba[0], rgba[1], rgba[2], a)
    cr.rectangle(x + 1, y + 1, w - 2, h - 2); cr.fill()
    cr.set_source_rgba(0.0, 0.0, 0.0, 0.28)
    cr.set_line_width(1.2)
    cr.rectangle(x + 2.5, y + 2.5, w - 5, h - 5); cr.stroke()
    cr.restore()
    sketch_rect(cr, x, y, w, h,
                (rgba[0], rgba[1], rgba[2], 0.95),
                thick, s, shadow=True, double_stroke=True)


# ────────────────────────────────────────────────────────────────────────────
# hand-drawn icons
# ────────────────────────────────────────────────────────────────────────────

def _stroke(cr, color, thick: float = 2.0):
    cr.set_source_rgba(*color if len(color) == 4 else (*color, 0.95))
    cr.set_line_width(thick)
    cr.set_line_cap(1); cr.set_line_join(1)


def sketch_icon(cr, name: str, x: float, y: float, size: float = 18,
                color=NYX["ink"], thick: float = 1.8) -> None:
    cx, cy = x + size / 2, y + size / 2
    r = size * 0.42
    j = jitter(hash(name) & 0xFFFF, 0.6)

    if name == "search":
        _stroke(cr, color, thick)
        cr.arc(cx - size * 0.10, cy - size * 0.10, r * 0.70, 0, math.pi * 2); cr.stroke()
        cr.move_to(cx + size * 0.18 + j(), cy + size * 0.18 + j())
        cr.line_to(x + size * 0.92 + j(), y + size * 0.92 + j()); cr.stroke()
    elif name == "plus":
        _stroke(cr, color, thick)
        cr.move_to(cx + j(), y + size * .15 + j())
        cr.line_to(cx + j(), y + size * .85 + j()); cr.stroke()
        cr.move_to(x + size * .15 + j(), cy + j())
        cr.line_to(x + size * .85 + j(), cy + j()); cr.stroke()
    elif name == "x":
        _stroke(cr, color, thick)
        cr.move_to(x + size * .2 + j(), y + size * .2 + j())
        cr.line_to(x + size * .8 + j(), y + size * .8 + j()); cr.stroke()
        cr.move_to(x + size * .8 + j(), y + size * .2 + j())
        cr.line_to(x + size * .2 + j(), y + size * .8 + j()); cr.stroke()
    elif name == "check":
        _stroke(cr, color, thick)
        cr.move_to(x + size * .15 + j(), cy + j())
        cr.line_to(x + size * .42 + j(), y + size * .80 + j())
        cr.line_to(x + size * .85 + j(), y + size * .20 + j()); cr.stroke()
    elif name == "folder":
        _stroke(cr, color, thick)
        cr.move_to(x + j(), y + size * .35 + j())
        cr.line_to(x + size * .35 + j(), y + size * .35 + j())
        cr.line_to(x + size * .45 + j(), y + size * .22 + j())
        cr.line_to(x + size * .95 + j(), y + size * .22 + j())
        cr.line_to(x + size * .95 + j(), y + size * .82 + j())
        cr.line_to(x + j(), y + size * .82 + j()); cr.close_path(); cr.stroke()
    elif name == "book":
        _stroke(cr, color, thick)
        cr.move_to(x + size * .15, y + size * .15)
        cr.line_to(x + size * .15, y + size * .85)
        cr.line_to(x + size * .85, y + size * .85)
        cr.line_to(x + size * .85, y + size * .15)
        cr.close_path(); cr.stroke()
        cr.move_to(cx + j(), y + size * .15 + j()); cr.line_to(cx + j(), y + size * .85 + j()); cr.stroke()
    elif name == "brain":
        _stroke(cr, color, thick)
        cr.arc(cx, cy, r * 0.85, 0, math.pi * 2); cr.stroke()
        for ang in (math.pi * 0.25, math.pi * 0.75, math.pi * 1.25, math.pi * 1.75):
            cr.move_to(cx, cy)
            cr.line_to(cx + math.cos(ang) * r * 0.65 + j(),
                       cy + math.sin(ang) * r * 0.65 + j())
            cr.stroke()
    elif name == "eye":
        _stroke(cr, color, thick)
        cr.move_to(x + j(), cy + j())
        cr.curve_to(x + size * .25, cy - r * .9 + j(),
                    x + size * .75, cy - r * .9 + j(),
                    x + size + j(), cy + j())
        cr.curve_to(x + size * .75, cy + r * .9 + j(),
                    x + size * .25, cy + r * .9 + j(),
                    x + j(), cy + j()); cr.stroke()
        cr.arc(cx, cy, r * .35, 0, math.pi * 2); cr.stroke()
    elif name == "gear":
        _stroke(cr, color, thick)
        for k in range(8):
            ang = k * math.pi / 4
            x1 = cx + math.cos(ang) * r * .65
            y1 = cy + math.sin(ang) * r * .65
            x2 = cx + math.cos(ang) * r * 1.05
            y2 = cy + math.sin(ang) * r * 1.05
            cr.move_to(x1, y1); cr.line_to(x2, y2); cr.stroke()
        cr.arc(cx, cy, r * .55, 0, math.pi * 2); cr.stroke()
    elif name == "scan":
        # magnifier over a document
        _stroke(cr, color, thick)
        sketch_rect(cr, x + size * .12, y + size * .12,
                    size * .55, size * .76, color, thick * 0.9,
                    seed=hash("scan-doc") & 0xFFFF,
                    shadow=False, double_stroke=False)
        cr.arc(x + size * .68, y + size * .58, size * .22, 0, math.pi * 2); cr.stroke()
        cr.move_to(x + size * .85 + j(), y + size * .75 + j())
        cr.line_to(x + size * .96 + j(), y + size * .92 + j()); cr.stroke()
    else:
        cr.set_source_rgba(*color if len(color) == 4 else (*color, 0.95))
        cr.arc(cx, cy, r * .55, 0, math.pi * 2); cr.fill()


# ────────────────────────────────────────────────────────────────────────────
# buttons
# ────────────────────────────────────────────────────────────────────────────

class SketchButton(Gtk.Button):
    """Hand-drawn rectangular button. Toggleable optional."""

    def __init__(self, label: str, color=None, *,
                 toggleable: bool = False,
                 width: int = -1, height: int = 38,
                 font_size: int = 19,
                 on_click: Callable[[], None] | None = None):
        super().__init__()
        self.set_has_frame(False)
        self.label = label
        self.color = color or NYX["ink"]
        self.toggleable = toggleable
        self.toggled = False
        self._font = font_size
        self.set_size_request(width, height)
        area = Gtk.DrawingArea()
        area.set_draw_func(self._draw)
        self.area = area
        self.set_child(area)
        self.connect("clicked", self._on_clicked)
        if on_click:
            self._user_click = on_click
        else:
            self._user_click = None

    def _on_clicked(self, _b):
        if self.toggleable:
            self.toggled = not self.toggled
            self.area.queue_draw()
        if self._user_click:
            self._user_click()

    def set_toggled(self, on: bool) -> None:
        self.toggled = bool(on)
        self.area.queue_draw()

    def set_label_text(self, t: str) -> None:
        self.label = t
        self.area.queue_draw()

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        col = self.color
        seed = hash(self.label) & 0xFFFF
        if self.toggled:
            bg = (col[0] * 0.30, col[1] * 0.30, col[2] * 0.30, 0.65)
            sketch_rect_fill(cr, 4, 4, w - 8, h - 8, bg, 1.8, seed=seed)
        sketch_rect(cr, 4, 4, w - 8, h - 8,
                    (col[0], col[1], col[2], 0.96), 2.4, seed=seed)
        cr.select_font_face("Caveat", 0, 1)
        cr.set_font_size(self._font)
        ext = cr.text_extents(self.label)
        tx = (w - ext.width) / 2 - ext.x_bearing
        ty = (h + ext.height) / 2 - 2
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.move_to(tx + 0.8, ty + 1.0); cr.show_text(self.label)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.move_to(tx, ty); cr.show_text(self.label)
        if self.toggled:
            j = jitter(seed ^ 0xCAFE, 0.5)
            cr.set_source_rgba(col[0], col[1], col[2], 0.85)
            cr.set_line_width(1.6); cr.set_line_cap(1)
            ux1 = tx + j(); uy = ty + 3 + j(); ux2 = tx + ext.width + j()
            cr.move_to(ux1, uy)
            cr.curve_to((ux1 * 2 + ux2) / 3 + j(), uy + j(),
                        (ux1 + ux2 * 2) / 3 + j(), uy + j(),
                        ux2, uy + j())
            cr.stroke()


class SidebarItem(Gtk.Button):
    """Sidebar nav row — hand-drawn icon + label, sketched container when active."""

    def __init__(self, key: str, label: str, icon: str,
                 color=None, *, on_click: Callable[[str], None]):
        super().__init__()
        self.set_has_frame(False)
        self.key = key
        self.label = label
        self.icon = icon
        self.color = color or NYX["accent"]
        self.toggled = False
        self._cb = on_click
        self.set_size_request(-1, 52)
        area = Gtk.DrawingArea()
        area.set_draw_func(self._draw)
        self.area = area
        self.set_child(area)
        self.connect("clicked", lambda *_: self._cb(self.key))

    def set_toggled(self, on: bool) -> None:
        self.toggled = bool(on)
        self.area.queue_draw()

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        seed = hash(self.key) & 0xFFFF
        col = self.color if self.toggled else NYX["ink_dim"]
        if self.toggled:
            bg = (col[0] * 0.30, col[1] * 0.30, col[2] * 0.30, 0.55)
            sketch_rect_fill(cr, 4, 4, w - 8, h - 8, bg, 1.6, seed=seed)
            sketch_rect(cr, 4, 4, w - 8, h - 8, (*col, 0.96), 2.0, seed=seed)
        # icon
        sketch_icon(cr, self.icon, 14, (h - 22) / 2, 22, color=col, thick=1.8)
        # label
        cr.select_font_face("Caveat", 0, 1)
        cr.set_font_size(20)
        ext = cr.text_extents(self.label)
        ty = (h + ext.height) / 2 - 2
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.move_to(45, ty + 1); cr.show_text(self.label)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0 if self.toggled else 0.78)
        cr.move_to(44, ty); cr.show_text(self.label)


# ────────────────────────────────────────────────────────────────────────────
# headers
# ────────────────────────────────────────────────────────────────────────────

class TiltedHeader(Gtk.DrawingArea):
    """Slightly-tilted hand-drawn header strip."""

    def __init__(self, text: str, color=None, *,
                 height: int = 56, tilt: float = -0.018):
        super().__init__()
        self.text = text
        self.color = color or NYX["ink"]
        self.tilt = tilt
        self.set_size_request(-1, height)
        self.set_draw_func(self._draw)

    def set_text(self, t: str) -> None:
        self.text = t
        self.queue_draw()

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        cr.save()
        cr.translate(w / 2, h / 2); cr.rotate(self.tilt); cr.translate(-w / 2, -h / 2)
        c = self.color
        seed = hash(self.text) & 0xFFFF
        sketch_rect_fill(cr, 4, 4, w - 8, h - 8,
                         (c[0] * 0.20, c[1] * 0.20, c[2] * 0.20, 0.92), 2.0, seed=seed)
        sketch_rect(cr, 4, 4, w - 8, h - 8, (*c, 1.0), 2.6, seed=seed)
        cr.select_font_face("Caveat", 0, 1)
        cr.set_font_size(26)
        ext = cr.text_extents(self.text)
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.move_to(15, h / 2 + ext.height / 2 - 2); cr.show_text(self.text)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.move_to(14, h / 2 + ext.height / 2 - 3); cr.show_text(self.text)
        cr.restore()


class SeverityChip(Gtk.DrawingArea):
    """Small hand-drawn severity badge — colored by severity token."""

    def __init__(self, severity: str):
        super().__init__()
        self.severity = severity
        self.set_size_request(96, 28)
        self.set_draw_func(self._draw)

    @staticmethod
    def color_for(severity: str) -> tuple[float, float, float]:
        return NYX.get(severity.lower(), NYX["info"])

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        c = self.color_for(self.severity)
        seed = hash(self.severity) & 0xFFFF
        sketch_rect_fill(cr, 2, 2, w - 4, h - 4,
                         (c[0] * 0.45, c[1] * 0.45, c[2] * 0.45, 0.92), 1.5, seed=seed)
        sketch_rect(cr, 2, 2, w - 4, h - 4, (*c, 0.95), 1.8, seed=seed,
                    shadow=False, double_stroke=False)
        cr.select_font_face("Caveat", 0, 1)
        cr.set_font_size(16)
        ext = cr.text_extents(self.severity)
        tx = (w - ext.width) / 2 - ext.x_bearing
        ty = (h + ext.height) / 2 - 2
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.move_to(tx + 0.6, ty + 0.8); cr.show_text(self.severity)
        cr.set_source_rgba(0.99, 0.97, 1.0, 1.0)
        cr.move_to(tx, ty); cr.show_text(self.severity)
