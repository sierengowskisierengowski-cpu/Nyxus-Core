"""
NYXUS SAGE — audit engine.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Walks a file or folder, applies every applicable rule, and produces
an Issue list grouped by severity. Pure stdlib — no GTK dependency.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from pathlib import Path

from .rules import Rule, SEVERITY_RANK, applicable, detect_language, starter_pack


# files we never read — binary, lockfiles, build artifacts
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv",
             ".cache", "build", "dist", ".pytest_cache", ".mypy_cache",
             "target", ".tox"}
SKIP_SUFFIXES = {".pyc", ".pyo", ".so", ".o", ".a", ".dylib", ".dll",
                 ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
                 ".mp3", ".mp4", ".wav", ".webm", ".mov", ".avi",
                 ".tar", ".tgz", ".gz", ".zip", ".7z", ".rar",
                 ".pdf", ".woff", ".woff2", ".ttf", ".otf"}
MAX_FILE_BYTES = 1_000_000   # skip huge files


@dataclass(order=True)
class Issue:
    """A single rule violation in a single file/line."""
    severity_rank: int = field(init=False, repr=False)
    severity: str
    rule_id: str
    rule_name: str
    file: str
    line: int
    snippet: str
    why: str
    fix: str
    auto_fix: bool = False
    category: str = ""

    def __post_init__(self):
        self.severity_rank = SEVERITY_RANK.get(self.severity, 99)


@dataclass
class Report:
    target: str
    files_scanned: int
    duration: float
    issues: list[Issue]

    def by_severity(self) -> dict[str, list[Issue]]:
        out: dict[str, list[Issue]] = {}
        for i in self.issues:
            out.setdefault(i.severity, []).append(i)
        return out

    def auto_fixable_count(self) -> int:
        return sum(1 for i in self.issues if i.auto_fix)

    def passes(self) -> bool:
        return not any(i.severity == "CRITICAL" for i in self.issues)

    def summary_lines(self) -> list[str]:
        sev = self.by_severity()
        out = [
            "NYXUS SAGE AUDIT REPORT",
            "=" * 24,
            f"Target: {self.target}",
            f"Files scanned: {self.files_scanned}",
            f"Total issues: {len(self.issues)}",
            f"Scan time: {self.duration:.2f}s",
            "",
        ]
        for s in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
            items = sev.get(s, [])
            if not items:
                continue
            out.append(f"{s} ({len(items)}):")
            for it in items[:50]:
                out.append(f"  {it.file}:{it.line} — {it.rule_name}")
                out.append(f"    {it.snippet[:120]}")
                out.append(f"    fix: {it.fix}")
                out.append(f"    rule: {it.rule_id}")
                out.append("")
            if len(items) > 50:
                out.append(f"  ... and {len(items) - 50} more {s} issues")
                out.append("")
        af = self.auto_fixable_count()
        if af:
            out.append(f"AUTO-FIXABLE ({af} issues):")
            out.append("  Run with --fix to auto-correct (where supported)")
            out.append("")
        verdict = "PASS" if self.passes() else "FAIL — fix CRITICAL issues before shipping"
        out.append(f"VERDICT: {verdict}")
        return out


# ────────────────────────────────────────────────────────────────────────────

class Engine:
    """Stateless audit engine. Construct once, audit() many targets."""

    def __init__(self, rules: list[Rule] | None = None):
        self.rules: list[Rule] = rules if rules is not None else starter_pack()

    def add_rule(self, rule: Rule) -> None:
        self.rules.append(rule)

    def _iter_files(self, target: Path):
        if target.is_file():
            yield target
            return
        for root, dirs, files in os.walk(target):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for f in files:
                p = Path(root) / f
                if p.suffix.lower() in SKIP_SUFFIXES:
                    continue
                try:
                    if p.stat().st_size > MAX_FILE_BYTES:
                        continue
                except OSError:
                    continue
                yield p

    def _read_text(self, p: Path) -> str | None:
        try:
            with p.open("rb") as fb:
                # quick null-byte sniff: binary files of unknown extension
                # would otherwise produce a wall of false-positive matches
                head = fb.read(4096)
                if b"\x00" in head:
                    return None
                rest = fb.read()
            return (head + rest).decode("utf-8", errors="replace")
        except OSError:
            return None

    def audit(self, target: str | Path,
              progress_cb=None) -> Report:
        """Run every applicable rule against every file in `target`."""
        t0 = time.time()
        target_path = Path(target).expanduser().resolve()
        issues: list[Issue] = []
        n_files = 0
        files = list(self._iter_files(target_path))
        total = len(files)
        for idx, p in enumerate(files):
            n_files += 1
            text = self._read_text(p)
            if text is None:
                continue
            lang = detect_language(str(p))
            for rule in self.rules:
                if not applicable(rule, lang):
                    continue
                try:
                    matches = list(rule.matches(text))
                except Exception:
                    continue
                for line_no, snippet in matches:
                    issues.append(Issue(
                        severity=rule.severity,
                        rule_id=rule.rid,
                        rule_name=rule.name,
                        file=str(p),
                        line=line_no,
                        snippet=snippet,
                        why=rule.why,
                        fix=rule.fix,
                        auto_fix=rule.auto_fix,
                        category=rule.category,
                    ))
            if progress_cb is not None:
                try:
                    progress_cb(idx + 1, total, str(p))
                except Exception:
                    pass
        issues.sort()  # by severity_rank
        return Report(
            target=str(target_path),
            files_scanned=n_files,
            duration=time.time() - t0,
            issues=issues,
        )
