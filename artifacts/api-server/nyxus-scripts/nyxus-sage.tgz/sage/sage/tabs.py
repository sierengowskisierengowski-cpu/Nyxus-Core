"""
NYXUS SAGE — tab pages.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Five tabs: Audit, Knowledge Base, Learning, Watcher, Settings.
Audit + Knowledge Base are fully wired in Phase 1. The remaining three
ship with informative placeholder content describing the Phase 2 work.
"""
from __future__ import annotations

import threading
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import GLib, Gtk, Gio   # noqa: E402

from . import ui
from .audit import Engine, Issue, Report
from .knowledge import COLLECTIONS, KnowledgeBase


SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")


# ────────────────────────────────────────────────────────────────────────────
# AUDIT TAB
# ────────────────────────────────────────────────────────────────────────────

class AuditTab(Gtk.Box):
    def __init__(self, app):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.app = app
        self.engine = Engine()
        self._target: Path | None = None
        self._report: Report | None = None
        self._severity_filter: set[str] = set(SEVERITIES)

        self.append(ui.TiltedHeader("audit  ·  scan any file or folder",
                                    color=ui.NYX["accent"]))

        # ── target picker row ────────────────────────────────────────────
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.target_label = Gtk.Label(label="no target selected", xalign=0.0,
                                      hexpand=True)
        self.target_label.add_css_class("sage-faint")
        row.append(self.target_label)
        row.append(ui.SketchButton("pick file", color=ui.NYX["info"],
                                   width=110, height=38,
                                   on_click=self._pick_file))
        row.append(ui.SketchButton("pick folder", color=ui.NYX["info"],
                                   width=130, height=38,
                                   on_click=self._pick_folder))
        self.run_btn = ui.SketchButton("audit now", color=ui.NYX["accent"],
                                       width=130, height=38,
                                       on_click=self._run_audit)
        row.append(self.run_btn)
        self.append(row)

        # ── severity filter row ──────────────────────────────────────────
        sev_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        sev_row.append(Gtk.Label(label="show:", xalign=0.0))
        self._sev_buttons: dict[str, ui.SketchButton] = {}
        for s in SEVERITIES:
            color = ui.SeverityChip.color_for(s)
            b = ui.SketchButton(s, color=color, toggleable=True,
                                width=110, height=34, font_size=17)
            b.set_toggled(True)

            def on_toggle(_b, _s=s):
                # called after the toggle; sync set with widget state
                if _b.toggled:
                    self._severity_filter.add(_s)
                else:
                    self._severity_filter.discard(_s)
                self._refresh_results()

            b.connect("clicked", on_toggle)
            self._sev_buttons[s] = b
            sev_row.append(b)
        self.append(sev_row)

        # ── progress ─────────────────────────────────────────────────────
        self.progress = Gtk.ProgressBar(); self.progress.set_visible(False)
        self.append(self.progress)

        # ── summary ──────────────────────────────────────────────────────
        self.summary = Gtk.Label(label="", xalign=0.0, wrap=True)
        self.summary.add_css_class("sage-faint")
        self.append(self.summary)

        # ── results scroll ───────────────────────────────────────────────
        scroll = Gtk.ScrolledWindow(); scroll.set_vexpand(True); scroll.set_hexpand(True)
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        self.results_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        scroll.set_child(self.results_box)
        self.append(scroll)

        # initial empty state
        self._show_empty("drop a file or pick a target above, then hit  ‘audit now’")

    # ── helpers ─────────────────────────────────────────────────────────

    def _show_empty(self, text: str):
        for c in list(self._iter_children(self.results_box)):
            self.results_box.remove(c)
        msg = Gtk.Label(label=text, xalign=0.0, wrap=True,
                        margin_top=18)
        msg.add_css_class("sage-muted")
        self.results_box.append(msg)

    @staticmethod
    def _iter_children(box: Gtk.Box):
        c = box.get_first_child()
        while c is not None:
            n = c.get_next_sibling()
            yield c
            c = n

    def set_target(self, p: Path):
        self._target = p
        self.target_label.set_text(str(p))
        self.app.set_status(f"target · {p}")

    # ── pickers ─────────────────────────────────────────────────────────

    def _pick_file(self):
        dlg = Gtk.FileDialog(title="select a file to audit")
        def cb(_d, res):
            try:
                f = dlg.open_finish(res)
                if f is not None:
                    self.set_target(Path(f.get_path()))
            except Exception:
                pass
        dlg.open(self.app.win, None, cb)

    def _pick_folder(self):
        dlg = Gtk.FileDialog(title="select a folder to audit")
        def cb(_d, res):
            try:
                f = dlg.select_folder_finish(res)
                if f is not None:
                    self.set_target(Path(f.get_path()))
            except Exception:
                pass
        dlg.select_folder(self.app.win, None, cb)

    # ── audit run ───────────────────────────────────────────────────────

    def _run_audit(self):
        if self._target is None:
            self.app.set_status("no target — pick a file or folder first")
            return
        self.run_btn.set_label_text("auditing…")
        self.progress.set_visible(True)
        self.progress.set_fraction(0.0)
        self._show_empty("scanning…")

        target = self._target

        def progress_cb(idx: int, total: int, current: str):
            frac = (idx / total) if total else 1.0
            GLib.idle_add(self.progress.set_fraction, frac)
            GLib.idle_add(self.progress.set_text, f"{idx}/{total}  {Path(current).name}")
            GLib.idle_add(self.progress.set_show_text, True)

        def worker():
            try:
                report = self.engine.audit(target, progress_cb=progress_cb)
            except Exception as exc:
                GLib.idle_add(self._on_error, str(exc))
                return
            GLib.idle_add(self._on_done, report)

        threading.Thread(target=worker, daemon=True).start()

    def _on_error(self, msg: str):
        self.run_btn.set_label_text("audit now")
        self.progress.set_visible(False)
        self._show_empty(f"audit failed: {msg}")
        self.app.set_status(f"audit failed: {msg}")

    def _on_done(self, report: Report):
        self._report = report
        self.run_btn.set_label_text("audit now")
        self.progress.set_visible(False)
        self._refresh_results()

    def _refresh_results(self):
        report = self._report
        if report is None:
            return
        self.summary.set_text(
            f"target {report.target} · {report.files_scanned} files · "
            f"{len(report.issues)} issues · {report.duration:.2f}s · "
            f"verdict {'PASS' if report.passes() else 'FAIL'}"
        )
        for c in list(self._iter_children(self.results_box)):
            self.results_box.remove(c)
        visible = [i for i in report.issues if i.severity in self._severity_filter]
        if not visible:
            self._show_empty("no issues match the current severity filter — try toggling more on.")
            return
        for issue in visible[:200]:
            self.results_box.append(self._issue_card(issue))
        if len(visible) > 200:
            more = Gtk.Label(label=f"… and {len(visible) - 200} more (use --report to dump all)",
                             xalign=0.0)
            more.add_css_class("sage-muted")
            self.results_box.append(more)

    @staticmethod
    def _issue_card(issue: Issue) -> Gtk.Widget:
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        card.add_css_class("sage-issue")
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        chip = ui.SeverityChip(issue.severity); chip.set_size_request(96, 26)
        head.append(chip)
        title = Gtk.Label(label=f"{issue.rule_name}",
                          xalign=0.0, hexpand=True)
        title.add_css_class("sage-h3")
        head.append(title)
        rid = Gtk.Label(label=issue.rule_id, xalign=1.0)
        rid.add_css_class("sage-muted")
        head.append(rid)
        card.append(head)

        loc = Gtk.Label(label=f"{issue.file}:{issue.line}", xalign=0.0,
                        wrap=True, selectable=True)
        loc.add_css_class("sage-faint")
        card.append(loc)

        snip = Gtk.Label(label=issue.snippet[:240], xalign=0.0,
                         wrap=True, selectable=True)
        snip.add_css_class("sage-mono")
        card.append(snip)

        why = Gtk.Label(label=f"why: {issue.why}", xalign=0.0, wrap=True)
        why.add_css_class("sage-faint")
        card.append(why)

        fix = Gtk.Label(label=f"fix: {issue.fix}", xalign=0.0, wrap=True)
        fix.add_css_class("sage-faint")
        card.append(fix)
        return card


# ────────────────────────────────────────────────────────────────────────────
# KNOWLEDGE BASE TAB
# ────────────────────────────────────────────────────────────────────────────

class KnowledgeTab(Gtk.Box):
    def __init__(self, app):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.app = app
        self.kb = KnowledgeBase()
        self.kb.seed_starter_rules()
        self._current_collection = COLLECTIONS[0]
        self._current_rid: str | None = None

        self.append(ui.TiltedHeader(
            f"knowledge base  ·  {self.kb.backend_name}  ·  {self.kb.root}",
            color=ui.NYX["accent"]))

        # search row
        srow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.search_entry = Gtk.Entry()
        self.search_entry.set_placeholder_text("search rules and patterns…")
        self.search_entry.set_hexpand(True)
        self.search_entry.connect("activate", lambda *_: self._do_search())
        srow.append(self.search_entry)
        srow.append(ui.SketchButton("search", color=ui.NYX["info"],
                                    width=100, height=38,
                                    on_click=self._do_search))
        srow.append(ui.SketchButton("clear", color=ui.NYX["ink_dim"],
                                    width=80, height=38,
                                    on_click=self._clear_search))
        self.append(srow)

        # body: collections | list | detail
        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12,
                       hexpand=True, vexpand=True)

        # collections
        col_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        col_box.set_size_request(220, -1)
        col_box.add_css_class("sage-panel")
        col_box.append(self._small_header("collections"))
        self._col_buttons: dict[str, ui.SketchButton] = {}
        stats = self.kb.stats()
        for c in COLLECTIONS:
            label = f"{c}  ({stats.get(c, 0)})"
            b = ui.SketchButton(label, color=ui.NYX["accent"],
                                toggleable=True, height=36, font_size=17,
                                on_click=lambda _c=c: self._switch_collection(_c))
            self._col_buttons[c] = b
            col_box.append(b)
        self._col_buttons[self._current_collection].set_toggled(True)
        body.append(col_box)

        # list
        list_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        list_outer.set_size_request(360, -1)
        list_outer.add_css_class("sage-panel")
        list_outer.append(self._small_header("rules"))
        list_scroll = Gtk.ScrolledWindow(); list_scroll.set_vexpand(True)
        self.list_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        list_scroll.set_child(self.list_box)
        list_outer.append(list_scroll)
        body.append(list_outer)

        # detail
        detail_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6,
                               hexpand=True)
        detail_outer.add_css_class("sage-panel")
        detail_outer.append(self._small_header("detail"))
        detail_scroll = Gtk.ScrolledWindow(); detail_scroll.set_vexpand(True)
        self.detail_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        detail_scroll.set_child(self.detail_box)
        detail_outer.append(detail_scroll)
        body.append(detail_outer)

        self.append(body)
        self._refresh_list()
        self._render_detail(None)

    @staticmethod
    def _iter_children(box: Gtk.Box):
        c = box.get_first_child()
        while c is not None:
            n = c.get_next_sibling()
            yield c
            c = n

    def _small_header(self, text: str) -> Gtk.Widget:
        h = Gtk.Label(label=text, xalign=0.0)
        h.add_css_class("sage-h3")
        return h

    def _switch_collection(self, c: str):
        self._current_collection = c
        for k, b in self._col_buttons.items():
            b.set_toggled(k == c)
        self._refresh_list()
        self._render_detail(None)

    def _refresh_list(self, entries: list[dict] | None = None):
        if entries is None:
            entries = self.kb.list_collection(self._current_collection)
        for c in list(self._iter_children(self.list_box)):
            self.list_box.remove(c)
        if not entries:
            empty = Gtk.Label(label="(no entries in this collection yet)",
                              xalign=0.0)
            empty.add_css_class("sage-muted")
            self.list_box.append(empty)
            return
        for e in entries:
            row = self._list_row(e)
            self.list_box.append(row)

    def _list_row(self, entry: dict) -> Gtk.Widget:
        meta = entry.get("metadata", {}) or {}
        rid = entry["rid"]
        sev = meta.get("severity", "INFO")
        name = meta.get("name") or entry["doc"][:60]
        btn = Gtk.Button()
        btn.set_has_frame(False)
        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        chip = ui.SeverityChip(sev); chip.set_size_request(96, 26)
        inner.append(chip)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2,
                      hexpand=True)
        l1 = Gtk.Label(label=name, xalign=0.0, wrap=True)
        l1.add_css_class("sage-h3")
        col.append(l1)
        l2 = Gtk.Label(label=rid, xalign=0.0)
        l2.add_css_class("sage-muted")
        col.append(l2)
        inner.append(col)
        btn.set_child(inner)
        btn.connect("clicked", lambda *_: self._render_detail(entry))
        return btn

    def _render_detail(self, entry: dict | None):
        for c in list(self._iter_children(self.detail_box)):
            self.detail_box.remove(c)
        if entry is None:
            empty = Gtk.Label(label="select a rule on the left to see its details",
                              xalign=0.0)
            empty.add_css_class("sage-muted")
            self.detail_box.append(empty)
            return
        meta = entry.get("metadata", {}) or {}
        # title
        title = Gtk.Label(label=meta.get("name") or entry["rid"],
                          xalign=0.0, wrap=True)
        title.add_css_class("sage-h2")
        self.detail_box.append(title)
        # severity + id
        meta_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        chip = ui.SeverityChip(meta.get("severity", "INFO"))
        chip.set_size_request(96, 28)
        meta_row.append(chip)
        meta_row.append(self._kv("id",       entry["rid"]))
        meta_row.append(self._kv("category", entry["collection"]))
        meta_row.append(self._kv("languages", meta.get("languages", "any")))
        self.detail_box.append(meta_row)
        # fields
        self.detail_box.append(self._field("what to look for", entry["doc"]))
        self.detail_box.append(self._field("why it matters", meta.get("why", "")))
        self.detail_box.append(self._field("suggested fix", meta.get("fix", "")))
        if meta.get("pattern"):
            self.detail_box.append(self._field("detection pattern (regex)",
                                               meta["pattern"], mono=True))

    @staticmethod
    def _kv(k: str, v: str) -> Gtk.Widget:
        b = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        kl = Gtk.Label(label=f"{k}:"); kl.add_css_class("sage-muted")
        vl = Gtk.Label(label=str(v), selectable=True); vl.add_css_class("sage-faint")
        b.append(kl); b.append(vl)
        return b

    @staticmethod
    def _field(label: str, value: str, *, mono: bool = False) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2,
                      margin_top=8)
        l = Gtk.Label(label=label, xalign=0.0); l.add_css_class("sage-h3")
        box.append(l)
        v = Gtk.Label(label=value or "—", xalign=0.0, wrap=True, selectable=True)
        v.add_css_class("sage-mono" if mono else "sage-faint")
        box.append(v)
        return box

    def _do_search(self):
        q = (self.search_entry.get_text() or "").strip()
        if not q:
            self._refresh_list()
            return
        results = self.kb.query(q, collection=self._current_collection, limit=50)
        self._refresh_list(results)

    def _clear_search(self):
        self.search_entry.set_text("")
        self._refresh_list()


# ────────────────────────────────────────────────────────────────────────────
# LEARNING TAB (Phase 2 placeholder with real status)
# ────────────────────────────────────────────────────────────────────────────

class LearningTab(Gtk.Box):
    def __init__(self, app):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.append(ui.TiltedHeader("learning  ·  passive pattern discovery",
                                    color=ui.NYX["accent"]))
        kb = KnowledgeBase()
        learned = kb.stats().get("learned_patterns", 0)
        self.append(self._stat("learned patterns this session", str(learned)))
        self.append(self._stat("knowledge backend", kb.backend_name))
        body = Gtk.Label(
            label=(
                "Phase 1 (current): the audit engine + knowledge base are live.\n"
                "Anything you audit feeds anonymized pattern fingerprints into the\n"
                "‘learned_patterns’ collection so SAGE notices what you fix often.\n\n"
                "Phase 2 (next): the systemd terminal-watcher service ships and starts\n"
                "feeding this tab with —\n"
                "  • commands run\n"
                "  • errors observed and the fixes that followed\n"
                "  • new tools and dependencies added\n"
                "  • weekly summaries of what was learned\n\n"
                "Privacy is local-only by default. Nothing leaves your machine."
            ),
            xalign=0.0, wrap=True)
        body.add_css_class("sage-faint")
        self.append(body)

    @staticmethod
    def _stat(k: str, v: str) -> Gtk.Widget:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        kl = Gtk.Label(label=k, xalign=0.0); kl.add_css_class("sage-faint")
        vl = Gtk.Label(label=v, xalign=1.0); vl.add_css_class("sage-h3")
        kl.set_hexpand(True)
        row.append(kl); row.append(vl)
        return row


# ────────────────────────────────────────────────────────────────────────────
# WATCHER TAB
# ────────────────────────────────────────────────────────────────────────────

class WatcherTab(Gtk.Box):
    def __init__(self, app):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.append(ui.TiltedHeader("terminal watcher  ·  background service",
                                    color=ui.NYX["accent"]))
        status = self._systemd_status_text()
        self.append(self._kv_row("systemd unit", "nyxus-sage-watcher.service"))
        self.append(self._kv_row("status", status))
        self.append(self._kv_row("cpu cap", "0.3% (enforced via nice + ionice)"))
        info = Gtk.Label(label=(
            "Phase 2 will install nyxus-sage-watcher.service. It will silently\n"
            "watch your shell history, file modifications, and error/fix patterns,\n"
            "then promote high-confidence patterns into the rule set automatically.\n\n"
            "Until then, this tab shows you what the unit will do and where it\n"
            "would log to (~/.cache/nyxus-sage/watcher.log)."
        ), xalign=0.0, wrap=True)
        info.add_css_class("sage-faint")
        self.append(info)

    @staticmethod
    def _kv_row(k: str, v: str) -> Gtk.Widget:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        kl = Gtk.Label(label=k, xalign=0.0); kl.add_css_class("sage-faint")
        vl = Gtk.Label(label=v, xalign=1.0, selectable=True); vl.add_css_class("sage-h3")
        kl.set_hexpand(True)
        row.append(kl); row.append(vl)
        return row

    @staticmethod
    def _systemd_status_text() -> str:
        import shutil, subprocess
        if not shutil.which("systemctl"):
            return "systemctl not found — watcher requires systemd"
        try:
            r = subprocess.run(
                ["systemctl", "is-active", "nyxus-sage-watcher.service"],
                capture_output=True, text=True, timeout=2)
            out = r.stdout.strip() or r.stderr.strip()
            return out or "unknown"
        except Exception:
            return "could not query systemctl"


# ────────────────────────────────────────────────────────────────────────────
# SETTINGS TAB
# ────────────────────────────────────────────────────────────────────────────

class SettingsTab(Gtk.Box):
    def __init__(self, app):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.append(ui.TiltedHeader("settings", color=ui.NYX["accent"]))
        kb = KnowledgeBase()
        self.append(self._kv_row("knowledge base path", str(kb.root)))
        self.append(self._kv_row("backend", kb.backend_name))
        for c, n in kb.stats().items():
            self.append(self._kv_row(c, str(n)))
        self.append(self._kv_row("version", _ver()))
        self.append(self._kv_row("copyright",
                                 "© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED"))

    @staticmethod
    def _kv_row(k: str, v: str) -> Gtk.Widget:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        kl = Gtk.Label(label=k, xalign=0.0); kl.add_css_class("sage-faint")
        vl = Gtk.Label(label=v, xalign=1.0, selectable=True); vl.add_css_class("sage-h3")
        kl.set_hexpand(True)
        row.append(kl); row.append(vl)
        return row


def _ver() -> str:
    try:
        from . import __version__
        return __version__
    except Exception:
        return "?"
