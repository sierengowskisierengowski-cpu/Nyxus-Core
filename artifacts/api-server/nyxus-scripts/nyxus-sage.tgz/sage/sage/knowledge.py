"""
NYXUS SAGE — knowledge base.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Stores rules, learned patterns, and user-added knowledge.

Storage strategy:
  • If `chromadb` is installed → use it (vector + metadata, persistent).
  • Otherwise → fall back to SQLite + FTS5 (always available, smaller dep).

Both backends expose the same API: `add()`, `query()`, `list_collection()`,
`get()`, `delete()`, `collections()`.
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path

from .rules import Rule, starter_pack


# canonical collection names from the SAGE spec
COLLECTIONS = (
    "linux_docs",
    "security_docs",
    "python_docs",
    "gtk4_docs",
    "bash_docs",
    "nyxus_rules",
    "learned_patterns",
    "user_rules",
    "codebase_index",
)


def kb_root() -> Path:
    """Default knowledge-base root: ~/.config/nyxus-sage/knowledge/"""
    return Path(os.path.expanduser("~/.config/nyxus-sage/knowledge"))


# ────────────────────────────────────────────────────────────────────────────

class KnowledgeBase:
    """Backend-agnostic facade. Picks Chroma if available, SQLite otherwise."""

    def __init__(self, root: Path | None = None):
        self.root = (root or kb_root()).expanduser()
        self.root.mkdir(parents=True, exist_ok=True)
        self._backend = self._make_backend()

    @property
    def backend_name(self) -> str:
        return self._backend.name

    def _make_backend(self):
        try:
            import chromadb  # noqa: F401
            return _ChromaBackend(self.root)
        except Exception:
            return _SQLiteBackend(self.root)

    # ── public API ─────────────────────────────────────────────────────
    def collections(self) -> list[str]:
        return list(COLLECTIONS)

    def add(self, collection: str, rid: str, doc: str,
            metadata: dict | None = None) -> None:
        self._backend.add(collection, rid, doc, metadata or {})

    def add_rule(self, rule: Rule) -> None:
        meta = {
            "name": rule.name,
            "severity": rule.severity,
            "languages": ",".join(rule.languages),
            "pattern": rule.pattern,
            "why": rule.why,
            "fix": rule.fix,
            "auto_fix": "1" if rule.auto_fix else "0",
        }
        self._backend.add(rule.category, rule.rid, rule.description, meta)

    def list_collection(self, collection: str) -> list[dict]:
        return self._backend.list_collection(collection)

    def get(self, collection: str, rid: str) -> dict | None:
        return self._backend.get(collection, rid)

    def delete(self, collection: str, rid: str) -> None:
        self._backend.delete(collection, rid)

    def query(self, text: str, collection: str | None = None,
              limit: int = 20) -> list[dict]:
        return self._backend.query(text, collection, limit)

    def stats(self) -> dict[str, int]:
        return {c: self._backend.count(c) for c in COLLECTIONS}

    def seed_starter_rules(self) -> int:
        """Idempotently load the starter rule pack. Returns the number added."""
        added = 0
        for rule in starter_pack():
            existing = self._backend.get(rule.category, rule.rid)
            if existing is None:
                self.add_rule(rule)
                added += 1
        return added


# ────────────────────────────────────────────────────────────────────────────
# SQLite + FTS5 backend (default)
# ────────────────────────────────────────────────────────────────────────────

class _SQLiteBackend:
    name = "sqlite"

    def __init__(self, root: Path):
        self.db_path = root / "sage.sqlite"
        self.con = sqlite3.connect(str(self.db_path))
        self.con.row_factory = sqlite3.Row
        self.con.execute("""
            CREATE TABLE IF NOT EXISTS entries (
                collection TEXT NOT NULL,
                rid        TEXT NOT NULL,
                doc        TEXT NOT NULL,
                meta_json  TEXT NOT NULL,
                ts         INTEGER NOT NULL,
                PRIMARY KEY (collection, rid)
            )
        """)
        # Optional FTS index — graceful if FTS5 isn't compiled in.
        # We deliberately do NOT use external-content mode: the index is small
        # and the column names of `entries` (`meta_json`) wouldn't match the
        # tokenized field we want (`meta_text`). Manual sync via _refresh_fts_row.
        try:
            self.con.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS entries_fts
                USING fts5(collection UNINDEXED, rid UNINDEXED, doc, meta_text)
            """)
            self._has_fts = True
        except sqlite3.OperationalError:
            self._has_fts = False
        self.con.commit()

    def _refresh_fts_row(self, collection: str, rid: str, doc: str, meta: dict) -> None:
        if not self._has_fts:
            return
        meta_text = " ".join(f"{k}:{v}" for k, v in meta.items())
        self.con.execute(
            "DELETE FROM entries_fts WHERE collection = ? AND rid = ?",
            (collection, rid))
        self.con.execute(
            "INSERT INTO entries_fts (collection, rid, doc, meta_text) VALUES (?, ?, ?, ?)",
            (collection, rid, doc, meta_text))

    def add(self, collection: str, rid: str, doc: str, meta: dict) -> None:
        self.con.execute(
            "INSERT OR REPLACE INTO entries(collection, rid, doc, meta_json, ts) "
            "VALUES (?, ?, ?, ?, ?)",
            (collection, rid, doc, json.dumps(meta), int(time.time())))
        self._refresh_fts_row(collection, rid, doc, meta)
        self.con.commit()

    def list_collection(self, collection: str) -> list[dict]:
        rows = self.con.execute(
            "SELECT rid, doc, meta_json FROM entries WHERE collection = ? ORDER BY rid",
            (collection,)).fetchall()
        return [self._row_to_dict(collection, r) for r in rows]

    def get(self, collection: str, rid: str) -> dict | None:
        row = self.con.execute(
            "SELECT rid, doc, meta_json FROM entries WHERE collection = ? AND rid = ?",
            (collection, rid)).fetchone()
        return self._row_to_dict(collection, row) if row else None

    def delete(self, collection: str, rid: str) -> None:
        self.con.execute(
            "DELETE FROM entries WHERE collection = ? AND rid = ?",
            (collection, rid))
        if self._has_fts:
            self.con.execute(
                "DELETE FROM entries_fts WHERE collection = ? AND rid = ?",
                (collection, rid))
        self.con.commit()

    def query(self, text: str, collection: str | None, limit: int) -> list[dict]:
        text = (text or "").strip()
        if not text:
            return []
        # try FTS5 first; fall back to LIKE.
        # FTS5 MATCH syntax has many special chars (:, ", *, AND, OR, NEAR…).
        # Wrap user input in a quoted phrase to treat it as a literal token list.
        if self._has_fts:
            safe = '"' + text.replace('"', '""') + '"'
            try:
                if collection:
                    rows = self.con.execute(
                        "SELECT entries_fts.collection AS collection, "
                        "       entries_fts.rid AS rid, "
                        "       entries_fts.doc AS doc, "
                        "       entries.meta_json AS meta_json "
                        "FROM entries_fts "
                        "JOIN entries ON entries.collection = entries_fts.collection "
                        "             AND entries.rid = entries_fts.rid "
                        "WHERE entries_fts MATCH ? AND entries_fts.collection = ? LIMIT ?",
                        (safe, collection, limit)).fetchall()
                else:
                    rows = self.con.execute(
                        "SELECT entries_fts.collection AS collection, "
                        "       entries_fts.rid AS rid, "
                        "       entries_fts.doc AS doc, "
                        "       entries.meta_json AS meta_json "
                        "FROM entries_fts "
                        "JOIN entries ON entries.collection = entries_fts.collection "
                        "             AND entries.rid = entries_fts.rid "
                        "WHERE entries_fts MATCH ? LIMIT ?",
                        (safe, limit)).fetchall()
                return [self._row_to_dict(r["collection"], r) for r in rows]
            except sqlite3.OperationalError:
                pass
        # LIKE fallback
        like = f"%{text}%"
        if collection:
            rows = self.con.execute(
                "SELECT rid, doc, meta_json FROM entries "
                "WHERE collection = ? AND (doc LIKE ? OR meta_json LIKE ?) LIMIT ?",
                (collection, like, like, limit)).fetchall()
            return [self._row_to_dict(collection, r) for r in rows]
        rows = self.con.execute(
            "SELECT collection, rid, doc, meta_json FROM entries "
            "WHERE doc LIKE ? OR meta_json LIKE ? LIMIT ?",
            (like, like, limit)).fetchall()
        return [self._row_to_dict(r["collection"], r) for r in rows]

    def count(self, collection: str) -> int:
        row = self.con.execute(
            "SELECT COUNT(*) AS n FROM entries WHERE collection = ?",
            (collection,)).fetchone()
        return row["n"] if row else 0

    @staticmethod
    def _row_to_dict(collection: str, row) -> dict:
        meta = json.loads(row["meta_json"]) if row["meta_json"] else {}
        return {
            "collection": collection,
            "rid": row["rid"],
            "doc": row["doc"],
            "metadata": meta,
        }


# ────────────────────────────────────────────────────────────────────────────
# ChromaDB backend (used if chromadb is installed)
# ────────────────────────────────────────────────────────────────────────────

class _ChromaBackend:
    name = "chromadb"

    def __init__(self, root: Path):
        import chromadb
        from chromadb.config import Settings
        self.client = chromadb.PersistentClient(
            path=str(root / "chroma"),
            settings=Settings(anonymized_telemetry=False))
        self._cols: dict[str, object] = {}
        for c in COLLECTIONS:
            self._cols[c] = self.client.get_or_create_collection(c)

    def _col(self, name: str):
        if name not in self._cols:
            self._cols[name] = self.client.get_or_create_collection(name)
        return self._cols[name]

    def add(self, collection: str, rid: str, doc: str, meta: dict) -> None:
        # Chroma requires all metadata values to be primitives
        clean_meta = {k: (v if isinstance(v, (str, int, float, bool)) else str(v))
                      for k, v in meta.items()}
        try:
            self._col(collection).upsert(ids=[rid], documents=[doc], metadatas=[clean_meta])
        except Exception:
            try:
                self._col(collection).delete(ids=[rid])
            except Exception:
                pass
            self._col(collection).add(ids=[rid], documents=[doc], metadatas=[clean_meta])

    def list_collection(self, collection: str) -> list[dict]:
        try:
            res = self._col(collection).get()
        except Exception:
            return []
        out = []
        for rid, doc, meta in zip(res.get("ids", []),
                                  res.get("documents", []),
                                  res.get("metadatas", [])):
            out.append({"collection": collection, "rid": rid, "doc": doc,
                        "metadata": meta or {}})
        out.sort(key=lambda d: d["rid"])
        return out

    def get(self, collection: str, rid: str) -> dict | None:
        try:
            res = self._col(collection).get(ids=[rid])
        except Exception:
            return None
        if not res.get("ids"):
            return None
        return {"collection": collection, "rid": res["ids"][0],
                "doc": (res["documents"] or [""])[0],
                "metadata": (res["metadatas"] or [{}])[0]}

    def delete(self, collection: str, rid: str) -> None:
        try:
            self._col(collection).delete(ids=[rid])
        except Exception:
            pass

    def query(self, text: str, collection: str | None, limit: int) -> list[dict]:
        text = (text or "").strip()
        if not text:
            return []
        targets = [collection] if collection else list(COLLECTIONS)
        out: list[dict] = []
        for c in targets:
            try:
                res = self._col(c).query(query_texts=[text], n_results=limit)
            except Exception:
                continue
            ids   = (res.get("ids") or [[]])[0]
            docs  = (res.get("documents") or [[]])[0]
            metas = (res.get("metadatas") or [[]])[0]
            for rid, doc, meta in zip(ids, docs, metas):
                out.append({"collection": c, "rid": rid, "doc": doc,
                            "metadata": meta or {}})
            if len(out) >= limit:
                break
        return out[:limit]

    def count(self, collection: str) -> int:
        try:
            return self._col(collection).count()
        except Exception:
            return 0
