"""
NYXUS SAGE — `nyxus-audit` command-line entry point.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Usage:
    nyxus-audit <path>            run a full audit on a file or folder
    nyxus-audit <path> --report   write the textual report to stdout (default)
    nyxus-audit --rules           list every active rule (id, severity, name)
    nyxus-audit --kb-stats        show how many entries each KB collection has

Exit codes:
    0 — clean (no CRITICAL issues)
    1 — CRITICAL issues found
    2 — invalid usage / I/O error
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .audit import Engine
from .knowledge import KnowledgeBase

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



# ANSI colors (fall back to plain text when not a tty)
def _color(name: str, text: str) -> str:
    if not sys.stdout.isatty():
        return text
    codes = {
        "bold":   "\033[1m",
        "dim":    "\033[2m",
        "red":    "\033[38;5;203m",
        "yellow": "\033[38;5;220m",
        "green":  "\033[38;5;120m",
        "pink":   "\033[38;5;213m",
        "purple": "\033[38;5;177m",
        "cyan":   "\033[38;5;51m",
        "reset":  "\033[0m",
    }
    return f"{codes.get(name, '')}{text}{codes['reset']}"


def cmd_audit(args) -> int:
    target = Path(args.path).expanduser()
    if not target.exists():
        print(_color("red", f"path not found: {target}"), file=sys.stderr)
        return 2
    eng = Engine()
    print(_color("dim", f"scanning {target} with {len(eng.rules)} rules…"),
          file=sys.stderr)
    report = eng.audit(target)
    for line in report.summary_lines():
        # color severity headers
        if line.startswith("CRITICAL"):
            print(_color("red", _color("bold", line)))
        elif line.startswith("HIGH"):
            print(_color("yellow", _color("bold", line)))
        elif line.startswith("MEDIUM"):
            print(_color("purple", line))
        elif line.startswith("LOW") or line.startswith("INFO"):
            print(_color("cyan", line))
        elif line.startswith("VERDICT: PASS"):
            print(_color("green", _color("bold", line)))
        elif line.startswith("VERDICT: FAIL"):
            print(_color("red", _color("bold", line)))
        else:
            print(line)
    return 0 if report.passes() else 1


def cmd_rules(args) -> int:
    eng = Engine()
    by_sev: dict[str, list] = {}
    for r in eng.rules:
        by_sev.setdefault(r.severity, []).append(r)
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        rules = by_sev.get(sev, [])
        if not rules:
            continue
        color = {"CRITICAL": "red", "HIGH": "yellow",
                 "MEDIUM": "purple", "LOW": "cyan", "INFO": "dim"}.get(sev, "")
        print(_color(color, _color("bold", f"\n{sev} ({len(rules)})")))
        for r in rules:
            langs = ",".join(r.languages)
            print(f"  {r.rid:<22} [{langs:<14}] {r.name}")
    print(_color("dim", f"\ntotal rules: {len(eng.rules)}"))
    return 0


def cmd_kb_stats(args) -> int:
    kb = KnowledgeBase()
    seeded = kb.seed_starter_rules()
    if seeded:
        print(_color("dim", f"seeded {seeded} starter rules into the knowledge base"))
    print(_color("bold", f"\nknowledge base ({kb.backend_name}) at {kb.root}"))
    for col, n in kb.stats().items():
        print(f"  {col:<22} {n:>4} entries")
    return 0


def cmd_kb_search(args) -> int:
    kb = KnowledgeBase()
    kb.seed_starter_rules()
    results = kb.query(args.query, collection=args.collection, limit=args.limit)
    if not results:
        print(_color("dim", "no matches"))
        return 0
    for r in results:
        meta = r.get("metadata", {}) or {}
        print(_color("bold", f"\n{r['rid']}  ({r['collection']}, {meta.get('severity', '?')})"))
        print(f"  {meta.get('name', r['doc'][:80])}")
        print(_color("dim", f"  {r['doc']}"))
        if meta.get("fix"):
            print(_color("cyan", f"  fix: {meta['fix']}"))
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="nyxus-audit",
                                description="NYXUS SAGE — code auditor")
    sub = p.add_subparsers(dest="cmd")

    # default subcommand: audit
    pa = sub.add_parser("audit", help="audit a file or folder")
    pa.add_argument("path")
    pa.set_defaults(func=cmd_audit)

    pr = sub.add_parser("rules", help="list active rules")
    pr.set_defaults(func=cmd_rules)

    pk = sub.add_parser("kb-stats", help="show knowledge base entry counts")
    pk.set_defaults(func=cmd_kb_stats)

    ps = sub.add_parser("kb-search", help="search the knowledge base")
    ps.add_argument("query")
    ps.add_argument("--collection", "-c", default=None)
    ps.add_argument("--limit", "-n", type=int, default=10)
    ps.set_defaults(func=cmd_kb_search)

    # legacy / convenience: bare `nyxus-audit <path>` runs audit
    if argv is None:
        argv = sys.argv[1:]
    if argv and argv[0] not in {"audit", "rules", "kb-stats", "kb-search",
                                "-h", "--help"}:
        argv = ["audit", *argv]

    args = p.parse_args(argv)
    if not getattr(args, "func", None):
        p.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
