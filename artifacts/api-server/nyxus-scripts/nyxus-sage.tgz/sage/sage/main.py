#!/usr/bin/env python3
"""
NYXUS SAGE — main GTK4 app.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Sidebar with five tabs (Audit, Knowledge Base, Learning, Watcher, Settings),
all backed by the real engine + knowledge base.
"""
from __future__ import annotations

import os
import sys
import traceback
from datetime import datetime
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk   # noqa: E402

# init libadwaita early so its built-in CSS resource bundle is registered
Adw.init()

# bootstrap import path so `sage.*` resolves whether we're run from
# /opt/nyxus-sage or out of a checkout
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from sage import ui, tabs as tabs_mod    # noqa: E402

APP_ID = "io.nyxus.sage"


# ────────────────────────────────────────────────────────────────────────
# bulletproof crash logging
# ────────────────────────────────────────────────────────────────────────

def _crash(prefix: str) -> None:
    tb = traceback.format_exc()
    msg = f"\n\033[1;31m▌ NYXUS SAGE · {prefix}\033[0m\n{tb}\n"
    try:
        sys.stderr.write(msg); sys.stderr.flush()
    except Exception:
        pass
    try:
        log = Path(os.path.expanduser("~/.cache/nyxus-sage.log"))
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open("a") as f:
            f.write(f"\n=== {datetime.now().isoformat()} · {prefix} ===\n{tb}\n")
        sys.stderr.write(f"  (full traceback also written to {log})\n")
        sys.stderr.flush()
    except Exception:
        pass


# ────────────────────────────────────────────────────────────────────────
# main window
# ────────────────────────────────────────────────────────────────────────

TABS = [
    ("audit",     "audit",     "scan",   tabs_mod.AuditTab),
    ("knowledge", "knowledge", "book",   tabs_mod.KnowledgeTab),
    ("learning",  "learning",  "brain",  tabs_mod.LearningTab),
    ("watcher",   "watcher",   "eye",    tabs_mod.WatcherTab),
    ("settings",  "settings",  "gear",   tabs_mod.SettingsTab),
]


class SageWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="NYXUS SAGE")
        self.set_default_size(1320, 880)
        ui.install_global_css(Gdk.Display.get_default())
        self.app = app

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.add_css_class("sage-shell")
        self.set_content(root)

        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0,
                       hexpand=True, vexpand=True)
        root.append(body)

        # sidebar
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        sidebar.set_size_request(220, -1)
        sidebar.add_css_class("sage-sidebar")
        body.append(sidebar)

        # title strip in sidebar
        title = Gtk.Label(label="NYXUS  SAGE", xalign=0.0)
        title.set_margin_start(10); title.set_margin_top(4); title.set_margin_bottom(8)
        title.add_css_class("sage-h2")
        sidebar.append(title)
        subtitle = Gtk.Label(label="audit · learn · know", xalign=0.0)
        subtitle.set_margin_start(10); subtitle.set_margin_bottom(12)
        subtitle.add_css_class("sage-muted")
        sidebar.append(subtitle)

        # sidebar nav
        self._nav: dict[str, ui.SidebarItem] = {}
        for key, label, icon, _cls in TABS:
            item = ui.SidebarItem(key, label, icon, on_click=self._switch_to)
            self._nav[key] = item
            sidebar.append(item)

        # content area
        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0,
                               hexpand=True, vexpand=True)
        self.content.add_css_class("sage-content")
        body.append(self.content)

        # status bar
        self.status = Gtk.Label(label="ready  ·  audit", xalign=0.0)
        self.status.add_css_class("sage-statusbar")
        root.append(self.status)

        # cache built tabs
        self._tabs: dict[str, Gtk.Widget] = {}
        self._switch_to("audit")

    def _switch_to(self, key: str):
        # untoggle siblings
        for k, n in self._nav.items():
            n.set_toggled(k == key)
        # remove old content child
        c = self.content.get_first_child()
        while c is not None:
            n = c.get_next_sibling(); self.content.remove(c); c = n
        # build/get tab
        if key not in self._tabs:
            try:
                cls = next(t[3] for t in TABS if t[0] == key)
                self._tabs[key] = cls(self)
            except Exception:
                _crash(f"tab '{key}' failed to build")
                err = Gtk.Label(label=f"tab failed to load — see ~/.cache/nyxus-sage.log",
                                xalign=0.0, wrap=True)
                err.add_css_class("sage-faint")
                self._tabs[key] = err
        self.content.append(self._tabs[key])
        self.set_status(f"ready  ·  {key}")

    def set_status(self, text: str) -> None:
        self.status.set_text(text)


# ────────────────────────────────────────────────────────────────────────
# application
# ────────────────────────────────────────────────────────────────────────

class SageApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.HANDLES_OPEN)
        self.win: SageWindow | None = None
        self.connect("activate", self._activate)

    def _activate(self, _a):
        try:
            self.win = SageWindow(self)
            self.win.present()
        except Exception:
            _crash("SageWindow init failed")
            raise


def main() -> int:
    try:
        return SageApp().run(None)
    except Exception:
        _crash("main() crashed")
        return 1



# ─────────────────────────── NYXUS CHROME (auto-injected) ───────────────────
# Unifies look across every NYXUS GTK4 app: graffiti background, Caveat
# font, neon palette. Monkey-patches ApplicationWindow.present so the
# canonical install_chrome() runs once per top-level window without
# touching the app's own window-construction code. nyxus-panel is
# intentionally excluded (LayerShell incompatibility with Gtk.Overlay).
# nyxus_chrome.py is shipped to ~/.nyxus by nyxus_install.sh.
try:
    import os as _nyx_os, sys as _nyx_sys
    _nyx_chrome_dir = _nyx_os.path.expanduser("~/.nyxus")
    if _nyx_chrome_dir not in _nyx_sys.path:
        _nyx_sys.path.insert(0, _nyx_chrome_dir)
    try:
        from nyxus_chrome import install_chrome as _nyx_install_chrome
    except ImportError:
        _nyx_install_chrome = lambda *a, **kw: None  # silent no-op
    import gi as _nyx_gi
    _nyx_gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk as _NyxGtk
    _NYX_PAGE_KEY = "_sage"
    if not getattr(_NyxGtk.ApplicationWindow, "_nyx_chrome_hooked", False):
        _orig_present = _NyxGtk.ApplicationWindow.present
        def _nyx_present(self):
            try: _nyx_install_chrome(self, page_key=_NYX_PAGE_KEY)
            except Exception: pass
            return _orig_present(self)
        _NyxGtk.ApplicationWindow.present = _nyx_present
        _NyxGtk.ApplicationWindow._nyx_chrome_hooked = True
except Exception as _nyx_e:
    import sys as _nyx_sys
    print("nyxus-chrome bootstrap skipped: %s" % _nyx_e, file=_nyx_sys.stderr)
# ────────────────────────── /NYXUS CHROME ───────────────────────────────────

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except BaseException:
        _crash("uncaught at top level")
        raise SystemExit(1)
