"""
NYXUS SAGE — rule definitions.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

A Rule is a declarative pattern + metadata. The audit engine matches
each rule's regex against files of the matching language and emits
issues.  This file is the *Phase 1 starter pack*; user-added rules
and learned patterns live in the knowledge base.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable, Pattern

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")
SEVERITY_RANK = {s: i for i, s in enumerate(SEVERITIES)}


@dataclass
class Rule:
    rid: str                            # e.g. "GTK4-ACTION-001"
    name: str                           # short human title
    category: str                       # collection: gtk4_docs, python_docs ...
    severity: str                       # one of SEVERITIES
    languages: tuple[str, ...]          # ("python",) or ("bash",) or ("any",)
    pattern: str                        # regex (multiline) — None means structural check
    description: str                    # what to look for
    why: str                            # why it matters
    fix: str                            # suggested fix (plain text)
    auto_fix: bool = False
    # populated lazily
    _compiled: Pattern | None = field(default=None, repr=False, compare=False)

    def matches(self, text: str) -> Iterable[tuple[int, str]]:
        """Yield (line_number, snippet) for each match in `text`."""
        if not self.pattern:
            return
        if self._compiled is None:
            self._compiled = re.compile(self.pattern, re.MULTILINE)
        for m in self._compiled.finditer(text):
            line_no = text.count("\n", 0, m.start()) + 1
            line = text.splitlines()[line_no - 1] if line_no - 1 < len(text.splitlines()) else m.group(0)
            yield line_no, line.strip()


# ────────────────────────────────────────────────────────────────────────────
# starter rule pack — ~35 real, actionable rules
# ────────────────────────────────────────────────────────────────────────────

STARTER_RULES: list[Rule] = [

    # ── GTK4 ──────────────────────────────────────────────────────────────
    Rule("GTK4-ACTION-001", "GMenu action name has invalid chars",
         "gtk4_docs", "CRITICAL", ("python",),
         r"""\.append\s*\(\s*['"][^'"]*['"]\s*,\s*['"](?:app|win|menu)\.[a-zA-Z0-9_\-\.]*[\s()·\[\]·!@#$%^&*+={}|\\;:,<>?][a-zA-Z0-9_\-\.\s()·\[\]·!@#$%^&*+={}|\\;:,<>?]*['"]\s*\)""",
         "GMenu detailed-action names must match [a-zA-Z0-9-]+ — anything else (spaces, parens, dots, ·) makes GMenu try to parse the rest as a GVariant target and abort.",
         "Causes the menu to fail silently or the app to crash on activation.",
         "Sanitize action ids: re.sub(r'[^a-zA-Z0-9]+', '_', label).strip('_')"),

    Rule("GTK4-RES-001", "Importing /org/gnome/adwaita/gtk-dark.css",
         "gtk4_docs", "MEDIUM", ("css",),
         r"""@import\s+url\s*\(\s*['"]?resource:///org/gnome/adwaita/gtk-dark\.css['"]?\s*\)""",
         "User CSS imports a resource path that no longer exists in libadwaita.",
         "Spams stderr at every GTK init; can mask real errors.",
         "Remove the @import. libadwaita auto-applies its theme via Adw.init() — use GTK_THEME=Adwaita:dark to force dark."),

    Rule("GTK4-THREAD-001", "Tight polling loop without sleep",
         "gtk4_docs", "HIGH", ("python",),
         r"""while\s+(True|self\.[a-zA-Z_]+)\s*:\s*(?:\n\s+(?!time\.sleep|GLib\.timeout|asyncio\.sleep|await\s).*)+""",
         "Background loop with no time.sleep() or async wait — burns 100% CPU.",
         "Causes UI freezes, fan spin-up, battery drain.",
         "Add time.sleep(2) (minimum) inside the loop, or use GLib.timeout_add()."),

    Rule("GTK4-THREAD-002", "GTK widget modified from a non-main thread",
         "gtk4_docs", "HIGH", ("python",),
         r"""threading\.Thread\([^)]*\)[^\n]*\n(?:[^\n]*\n){0,30}?[^\n]*\.(set_text|set_label|set_value|queue_draw|append|remove)\s*\(""",
         "Direct widget mutation inside a thread body — GTK is not thread-safe.",
         "Causes random crashes, redraw artifacts, segfaults.",
         "Wrap UI updates in GLib.idle_add(lambda: widget.set_text(...))."),

    Rule("GTK4-CSS-001", "load_from_data passed a str instead of bytes",
         "gtk4_docs", "MEDIUM", ("python",),
         r"""\.load_from_data\s*\(\s*['"][^'"]*['"]""",
         "GTK4 CssProvider.load_from_data() requires bytes, not str.",
         "Raises a TypeError on app start in newer GTK4 builds.",
         "Pass b\"...\" or .encode() the string."),

    # ── Python ────────────────────────────────────────────────────────────
    Rule("PY-EXC-001", "Bare except clause",
         "python_docs", "MEDIUM", ("python",),
         r"""^\s*except\s*:\s*$""",
         "`except:` swallows every exception including KeyboardInterrupt and SystemExit.",
         "Hides real bugs and makes Ctrl+C impossible.",
         "Use `except Exception:` or catch specific exception types."),

    Rule("PY-EXC-002", "except: pass swallows all errors silently",
         "python_docs", "HIGH", ("python",),
         r"""^\s*except[^:]*:\s*\n\s*pass\s*$""",
         "Silently discarding exceptions makes failures invisible.",
         "Causes mysterious bugs and wastes hours of debugging.",
         "Either log the exception, raise it, or document why it's safe to ignore."),

    Rule("PY-SEC-001", "Hardcoded password / API key / secret",
         "python_docs", "CRITICAL", ("python", "any"),
         r"""(?i)(?:password|api[_\-]?key|secret|token|access[_\-]?key)\s*=\s*['"][A-Za-z0-9_\-]{12,}['"]""",
         "Credentials embedded in source code.",
         "Anyone with repo access can use them; leaks via git history are permanent.",
         "Read from environment variable or a 0600-permissioned config file."),

    Rule("PY-SEC-002", "subprocess call with shell=True and dynamic input",
         "python_docs", "CRITICAL", ("python",),
         r"""subprocess\.\w+\([^)]*shell\s*=\s*True[^)]*\+|subprocess\.\w+\([^)]*shell\s*=\s*True[^)]*f['"]""",
         "Shell command built from user input enables command injection.",
         "Attacker can run arbitrary commands as your user.",
         "Use shell=False and pass args as a list: subprocess.run(['ls', path])."),

    Rule("PY-SEC-003", "eval() or exec() on dynamic content",
         "python_docs", "CRITICAL", ("python",),
         r"""\b(eval|exec)\s*\(\s*[a-zA-Z_][a-zA-Z0-9_]*""",
         "eval/exec on a variable lets any value run as Python code.",
         "Trivial remote code execution.",
         "Use ast.literal_eval() for data, or refactor to avoid dynamic code."),

    Rule("PY-CRYPTO-001", "Weak hash (md5/sha1) used for password",
         "python_docs", "HIGH", ("python",),
         r"""(?i)hashlib\.(md5|sha1)\s*\([^)]*(password|passwd|pwd|secret)""",
         "MD5 and SHA1 are broken for password hashing.",
         "Rainbow tables crack these in seconds.",
         "Use bcrypt, argon2, or hashlib.scrypt() with a salt."),

    Rule("PY-IMPORT-001", "Wildcard import",
         "python_docs", "LOW", ("python",),
         r"""^from\s+\S+\s+import\s+\*""",
         "`from x import *` pollutes the namespace and hides what's used.",
         "Makes refactoring harder; can shadow built-ins.",
         "List the names you need explicitly."),

    Rule("PY-FILE-001", "open() without context manager",
         "python_docs", "LOW", ("python",),
         r"""=\s*open\s*\([^)]+\)(?![^\n]*\.(?:read|write))""",
         "File opened but not in a `with` block — risk of leaving fds open.",
         "Resource leaks; on Windows can lock files unexpectedly.",
         "Use `with open(path) as f:`."),

    Rule("PY-MUT-DEFAULT", "Mutable default argument",
         "python_docs", "MEDIUM", ("python",),
         r"""def\s+\w+\s*\([^)]*=\s*(\[\]|\{\}|set\(\))""",
         "Mutable default arguments are shared across all calls.",
         "Causes confusing bugs where state leaks between invocations.",
         "Use None as default and create the mutable inside: `if x is None: x = []`."),

    # ── Bash / Zsh ────────────────────────────────────────────────────────
    Rule("BASH-VAR-001", "Unquoted variable expansion",
         "bash_docs", "HIGH", ("bash",),
         r"""(?<![\w'"])\$[a-zA-Z_][a-zA-Z0-9_]*(?![\w'"}])""",
         "`$var` (unquoted) word-splits and globs — breaks on spaces and special chars.",
         "Causes silent bugs when paths contain spaces or wildcards.",
         "Always quote: \"$var\" or \"${var}\"."),

    Rule("BASH-EXIT-001", "Missing set -euo pipefail",
         "bash_docs", "MEDIUM", ("bash",),
         r"""\A(?!.*set\s+-[a-z]*[eu])""",
         "Script doesn't enable strict mode — failures are ignored silently.",
         "Half-finished operations leave the system in inconsistent state.",
         "Add `set -euo pipefail` near the top of the script."),

    Rule("BASH-LS-001", "Parsing ls output",
         "bash_docs", "MEDIUM", ("bash",),
         r"""(?:for|while)\s+\w+\s+in\s+\$?\(\s*ls\b|\$\(\s*ls\s+[^)]*\s*\)""",
         "Parsing `ls` output is unsafe with filenames containing spaces or newlines.",
         "Loops break on common filenames; can cause data loss if combined with rm.",
         "Use a glob: `for f in *.txt; do ...` or `find ... -print0 | xargs -0 ...`."),

    Rule("BASH-BACKTICK-001", "Backtick command substitution",
         "bash_docs", "LOW", ("bash",),
         r"""`[^`]+`""",
         "Backticks don't nest and are harder to read than $(...).",
         "Maintenance burden; portability issues with nested commands.",
         "Use `$(command)` instead of `command`."),

    Rule("BASH-TEST-001", "Single bracket [ ] in bash conditional",
         "bash_docs", "LOW", ("bash",),
         r"""^\s*if\s+\[\s+[^\[]""",
         "`[ ]` is the POSIX test command; `[[ ]]` is bash's safer keyword.",
         "Lacks pattern matching, &&/||, no word splitting.",
         "Use `[[ ... ]]` in bash scripts."),

    # ── NYXUS Layer 4 ─────────────────────────────────────────────────────
    Rule("NYX-LIC-001", "Missing NYXUS copyright header",
         "nyxus_rules", "MEDIUM", ("python",),
         r"""\A(?!(?:.|\n){0,2000}Joseph Sierengowski)""",
         "File missing the © 2026 Joseph Sierengowski header.",
         "Violates the per-file copyright requirement (Layer 4).",
         "Add the standard header: `© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED`."),

    Rule("NYX-CONFIG-001", "Config not at ~/.config/nyxus-*",
         "nyxus_rules", "MEDIUM", ("python",),
         r"""(?i)Path\.home\(\)\s*/\s*['"]\.(?!config/nyxus-)""",
         "NYXUS apps must store config under ~/.config/nyxus-<appname>/.",
         "Conventions break — apps stomp on each other's settings.",
         "Use `Path.home() / '.config' / 'nyxus-<appname>' / ...`."),

    Rule("NYX-CLIP-001", "xclip / xdg-clipboard used instead of wl-copy",
         "nyxus_rules", "HIGH", ("python", "bash"),
         r"""\b(xclip|xdg-clipboard|xsel)\b""",
         "NYXUS targets Wayland — xclip/xsel only work on X11.",
         "Clipboard silently fails on the user's Hyprland session.",
         "Use `wl-copy` and `wl-paste` from wl-clipboard."),

    Rule("NYX-PYVER-001", "AI module on Python ≥ 3.13",
         "nyxus_rules", "HIGH", ("python",),
         r"""(?i)import\s+(torch|tensorflow|onnxruntime|chromadb|whisper|demucs)""",
         "Heavy ML libs lack wheels for Python 3.13+ — must pin to 3.12.",
         "pip install fails or builds from source for 30+ minutes.",
         "Create a venv with `python3.12 -m venv` for AI features."),

    Rule("NYX-PLACEHOLDER-001", "Placeholder lambda on a button",
         "nyxus_rules", "MEDIUM", ("python",),
         r"""\.connect\s*\(\s*['"]clicked['"]\s*,\s*lambda[^:]*:\s*(?:print|pass|None|\.\.\.)\b""",
         "Button connected to a no-op or print() — placeholder left in shipped code.",
         "Users click it, nothing happens, app feels broken.",
         "Wire the button to a real handler or remove it."),

    Rule("NYX-CHMOD-001", "World-writable permission in install script",
         "nyxus_rules", "HIGH", ("bash",),
         r"""chmod\s+(?:[0-7]?[0-7]?[27])\s|chmod\s+a\+w""",
         "Install script grants 0666 / 0777 / a+w on a deployed file.",
         "Anyone on the box can replace your binary or config.",
         "Use 0644 for files, 0755 for dirs/executables, 0600 for secrets."),

    Rule("NYX-ABSPATH-001", "Hardcoded absolute home path",
         "nyxus_rules", "MEDIUM", ("python", "bash"),
         r"""['"]/home/[a-zA-Z0-9_\-]+/""",
         "Hardcoded /home/<user>/ path — only works on one machine.",
         "Breaks for any other user; install script silently writes to nowhere.",
         "Use Path.home(), $HOME, or $TARGET_HOME (in elevated installers)."),

    Rule("NYX-TRAY-001", "GTK app close handler skips tray check",
         "nyxus_rules", "LOW", ("python",),
         r"""def\s+(?:do_close_request|on_close|_on_close)[^)]*\)[^:]*:\s*\n\s+(?:return\s+False|self\.close\(\))""",
         "NYXUS apps must minimize to system tray on close, not exit.",
         "User loses background daemon; has to restart to re-arm watchers.",
         "If a tray icon is configured, hide the window and return True."),

    # ── Security ──────────────────────────────────────────────────────────
    Rule("SEC-INJ-001", "User input concatenated into shell command",
         "security_docs", "CRITICAL", ("python", "bash"),
         r"""os\.system\s*\([^)]*[+f]['"]|os\.popen\s*\([^)]*[+f]['"]""",
         "User-controlled string flows into a shell command.",
         "Trivial command injection — RCE.",
         "Use subprocess.run(['cmd', arg]) with shell=False."),

    Rule("SEC-PATH-001", "Path traversal via untrusted join",
         "security_docs", "HIGH", ("python",),
         r"""(?i)open\s*\([^)]*\+\s*(?:request\.|args\.|user_|untrusted)""",
         "User-supplied filename joined into a path opened on disk.",
         "Reading arbitrary files via `../../etc/passwd` style paths.",
         "Sanitize with os.path.basename() and verify the resolved path stays under a base dir."),

    Rule("SEC-RANDOM-001", "random module used for security tokens",
         "security_docs", "HIGH", ("python",),
         r"""(?i)random\.(?:random|randint|choice|choices)\s*\([^)]*\)\s*(?:\n|;)?[^\n]*(?:token|password|secret|salt|nonce)""",
         "`random` is a Mersenne-Twister PRNG — predictable.",
         "Tokens generated this way can be brute-forced.",
         "Use `secrets.token_hex()` / `secrets.token_urlsafe()` instead."),

    Rule("SEC-PICKLE-001", "pickle.loads on untrusted data",
         "security_docs", "CRITICAL", ("python",),
         r"""pickle\.loads?\s*\(""",
         "pickle deserialization runs arbitrary code if the source is untrusted.",
         "Trivial RCE if the payload comes from network / user input.",
         "Use json.loads for data interchange. If you must use pickle, sign the payload."),

    Rule("SEC-YAML-001", "yaml.load without SafeLoader",
         "security_docs", "HIGH", ("python",),
         r"""yaml\.load\s*\((?![^)]*Loader\s*=\s*yaml\.Safe)""",
         "yaml.load() without a safe loader executes arbitrary Python on parse.",
         "RCE via crafted YAML.",
         "Use yaml.safe_load() or pass Loader=yaml.SafeLoader."),

    # ── Linux / system ────────────────────────────────────────────────────
    Rule("LIN-PERM-001", "chmod 777 in script",
         "linux_docs", "HIGH", ("bash", "python"),
         r"""chmod\s+0?777\b""",
         "World-writable + executable on a real file.",
         "Anyone on the system can replace it with malicious code.",
         "Use 0755 (executable) or 0644 (data); 0700/0600 for personal files."),

    Rule("LIN-SSH-001", "SSH PasswordAuthentication enabled",
         "linux_docs", "HIGH", ("any",),
         r"""(?i)^\s*PasswordAuthentication\s+yes""",
         "SSH allows password login — vulnerable to brute force.",
         "Box ends up in botnets; key-only is the standard.",
         "Set PasswordAuthentication no and use SSH keys."),

    Rule("LIN-SYSTEMD-001", "systemd unit missing [Install]",
         "linux_docs", "MEDIUM", ("any",),
         r"""\A(?:.|\n)*\[Service\](?:.|\n)*\Z(?<!\[Install\][^\[]*)""",
         "Service unit has [Service] but no [Install] — `systemctl enable` will fail.",
         "Service won't start at boot; user has to manually `systemctl start` every time.",
         "Add `[Install]\\nWantedBy=multi-user.target` (or a more specific target)."),

    Rule("LIN-SUDOERS-001", "NOPASSWD on a shell-capable command",
         "linux_docs", "CRITICAL", ("any",),
         r"""(?i)NOPASSWD:\s*ALL|NOPASSWD:\s*/bin/(bash|sh|zsh)""",
         "Sudoers grants no-password access to a shell — equivalent to root for that user.",
         "Trivial privilege escalation if the user account is compromised.",
         "Restrict NOPASSWD to specific narrow commands only (e.g. `/usr/bin/systemctl restart myservice`)."),
]


def starter_pack() -> list[Rule]:
    """Return a fresh list of the starter rules (callable so tests get a clean slate)."""
    return list(STARTER_RULES)


def by_category() -> dict[str, list[Rule]]:
    """Group starter rules by category."""
    out: dict[str, list[Rule]] = {}
    for r in STARTER_RULES:
        out.setdefault(r.category, []).append(r)
    return out


# language detection — rough but practical
_EXT_TO_LANG = {
    ".py": "python",   ".pyw": "python",
    ".sh": "bash",     ".bash": "bash",   ".zsh": "bash",
    ".css": "css",
    ".yml": "yaml",    ".yaml": "yaml",
    ".toml": "toml",
    ".json": "json",
    ".md": "markdown",
    ".service": "systemd",
    ".conf": "config",
}


def detect_language(path: str) -> str:
    from pathlib import Path as _P
    p = _P(path)
    ext = p.suffix.lower()
    if ext in _EXT_TO_LANG:
        return _EXT_TO_LANG[ext]
    # shebang sniffing
    try:
        with p.open("rb") as f:
            first = f.read(80)
        if first.startswith(b"#!"):
            head = first.decode("utf-8", "ignore")
            if "python" in head: return "python"
            if "bash" in head or "/sh" in head or "zsh" in head: return "bash"
    except Exception:
        pass
    return "any"


def applicable(rule: Rule, lang: str) -> bool:
    return "any" in rule.languages or lang in rule.languages
