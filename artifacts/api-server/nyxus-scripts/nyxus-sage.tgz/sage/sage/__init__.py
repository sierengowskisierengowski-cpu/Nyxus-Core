"""NYXUS SAGE — intelligent code auditing & passive learning engine.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
__version__ = "1.0.0"
