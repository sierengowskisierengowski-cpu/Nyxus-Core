#!/usr/bin/env bash
# ============================================================================
#  NYXUS SAGE — installer
#  © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
#
#  Installs:
#    /opt/nyxus-sage/                            ← python package
#    /usr/local/bin/nyxus-sage                   ← GUI launcher
#    /usr/local/bin/nyxus-audit                  ← CLI auditor
#    ~/.local/share/applications/nyxus-sage.desktop
#
#  System packages (Arch):
#    gtk4, libadwaita, python-gobject, python-cairo, ttf-caveat
#  Optional Python (auto-installed via pip --user, falls back to sqlite if missing):
#    chromadb
# ============================================================================
set -uo pipefail

if [[ -t 1 ]]; then
  R="\033[0m"; B="\033[1m"; DIM="\033[2m"
  PINK="\033[38;5;213m"; GREEN="\033[38;5;120m"; GOLD="\033[38;5;220m"
  PURPLE="\033[38;5;177m"; RED="\033[38;5;203m"
else
  R="";B="";DIM="";PINK="";GREEN="";GOLD="";PURPLE="";RED=""
fi
ok()   { printf "  ${GREEN}✓${R}  %s\n" "$*"; }
warn() { printf "  ${GOLD}!${R}  %s\n" "$*"; }
fail() { printf "  ${RED}✗${R}  %s\n" "$*"; }
step() { printf "\n${PURPLE}${B}── %s ──${R}\n" "$*"; }

TARGET_USER="${SUDO_USER:-$USER}"
TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6 || echo "$HOME")"

if [[ $EUID -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    printf "  ${DIM}elevating with sudo (you'll be prompted)…${R}\n\n"
    if [[ -f "$0" && -r "$0" ]]; then
      exec sudo -E bash "$0" "$@"
    else
      fail "must be run as root"; exit 1
    fi
  fi
  fail "must be run as root (sudo not available)"; exit 1
fi

clear 2>/dev/null || true
cat <<EOF
${PINK}${B}
   ███╗   ██╗██╗   ██╗██╗  ██╗██╗   ██╗███████╗
   ████╗  ██║╚██╗ ██╔╝╚██╗██╔╝██║   ██║██╔════╝
   ██╔██╗ ██║ ╚████╔╝  ╚███╔╝ ██║   ██║███████╗
   ██║╚██╗██║  ╚██╔╝   ██╔██╗ ██║   ██║╚════██║
   ██║ ╚████║   ██║   ██╔╝ ██╗╚██████╔╝███████║
   ╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚══════╝
${R}${GOLD}                       S A G E${R}
${DIM}        audit · learn · know — passively, locally${R}

EOF

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
ok "source: $SRC_DIR"

# ── system packages ─────────────────────────────────────────────────────────
step "system packages"
REQUIRED_PKGS=(gtk4 libadwaita python-gobject python-cairo)
OPTIONAL_PKGS=(ttf-caveat)
if command -v pacman >/dev/null 2>&1; then
  REQ_MISSING=()
  for p in "${REQUIRED_PKGS[@]}"; do
    pacman -Qi "$p" >/dev/null 2>&1 || REQ_MISSING+=("$p")
  done
  if (( ${#REQ_MISSING[@]} )); then
    printf "  ${DIM}installing required: ${REQ_MISSING[*]}${R}\n"
    pacman -S --noconfirm --needed "${REQ_MISSING[@]}" || true
  fi
  STILL=()
  for p in "${REQUIRED_PKGS[@]}"; do
    pacman -Qi "$p" >/dev/null 2>&1 || STILL+=("$p")
  done
  if (( ${#STILL[@]} )); then
    fail "required packages failed to install: ${STILL[*]}"; exit 1
  fi
  ok "required system packages installed"
  OPT_MISSING=()
  for p in "${OPTIONAL_PKGS[@]}"; do
    pacman -Qi "$p" >/dev/null 2>&1 || OPT_MISSING+=("$p")
  done
  if (( ${#OPT_MISSING[@]} )); then
    pacman -S --noconfirm --needed "${OPT_MISSING[@]}" >/dev/null 2>&1 \
      || warn "optional skipped (font may fall back): ${OPT_MISSING[*]}"
  fi
else
  warn "pacman not found — install manually: ${REQUIRED_PKGS[*]} ${OPTIONAL_PKGS[*]}"
fi

# ── optional pip — chromadb (knowledge base auto-falls-back to sqlite) ─────
step "optional Python packages"
PIP="$(command -v pip3 || command -v pip || true)"
if [[ -n "$PIP" ]]; then
  if ! sudo -u "$TARGET_USER" python3 -c "import chromadb" >/dev/null 2>&1; then
    printf "  ${DIM}pip install --user chromadb (this can take a minute)…${R}\n"
    sudo -u "$TARGET_USER" "$PIP" install --user --break-system-packages chromadb \
      >/dev/null 2>&1 \
      || sudo -u "$TARGET_USER" "$PIP" install --user chromadb >/dev/null 2>&1 \
      || warn "chromadb not installed — SAGE will use built-in SQLite backend (still fully functional)"
  fi
  ok "python extras attempted"
else
  warn "pip not found — SAGE will use built-in SQLite backend"
fi

# ── deploy ──────────────────────────────────────────────────────────────────
step "deploy"
INSTALL_DIR="/opt/nyxus-sage"
mkdir -p "$INSTALL_DIR"
rm -rf "$INSTALL_DIR/sage"
cp -r "$SRC_DIR/sage" "$INSTALL_DIR/sage"
chmod -R a+rX "$INSTALL_DIR"
ok "installed → $INSTALL_DIR"

# ── GUI launcher ────────────────────────────────────────────────────────────
GUI_LAUNCHER="/usr/local/bin/nyxus-sage"
cat > "$GUI_LAUNCHER" <<'LAUNCH'
#!/usr/bin/env bash
# NYXUS SAGE — GUI launcher
export PYTHONPATH="/opt/nyxus-sage:${PYTHONPATH:-}"
export GTK_THEME="${GTK_THEME:-Adwaita:dark}"
if [[ -z "${NYXUS_DEBUG:-}" ]]; then
  exec python3 -m sage.main "$@" 2> >(grep -vE "Theme parser error|gtk-dark\.css|adwaita.*does not exist" >&2)
else
  exec python3 -m sage.main "$@"
fi
LAUNCH
chmod 0755 "$GUI_LAUNCHER"
ln -sf "$GUI_LAUNCHER" /usr/local/bin/sage  2>/dev/null || true
ok "gui launcher → $GUI_LAUNCHER (alias: sage)"

# ── CLI launcher ────────────────────────────────────────────────────────────
CLI_LAUNCHER="/usr/local/bin/nyxus-audit"
cat > "$CLI_LAUNCHER" <<'LAUNCH'
#!/usr/bin/env bash
# NYXUS SAGE — `nyxus-audit` CLI
export PYTHONPATH="/opt/nyxus-sage:${PYTHONPATH:-}"
exec python3 -m sage.cli "$@"
LAUNCH
chmod 0755 "$CLI_LAUNCHER"
ok "cli launcher → $CLI_LAUNCHER"

# ── desktop file ────────────────────────────────────────────────────────────
DESK_DIR="$TARGET_HOME/.local/share/applications"
sudo -u "$TARGET_USER" mkdir -p "$DESK_DIR"
DESK_PATH="$DESK_DIR/nyxus-sage.desktop"
cat > "$DESK_PATH" <<DESK
[Desktop Entry]
Type=Application
Name=NYXUS SAGE
GenericName=Code Auditor & Knowledge Base
Comment=Audit any code, learn passively, get smarter every day
Exec=nyxus-sage
Icon=text-x-generic
Terminal=false
Categories=Development;Utility;
StartupNotify=true
StartupWMClass=nyxus-sage
DESK
chown "$TARGET_USER":"$(id -gn "$TARGET_USER")" "$DESK_PATH"
chmod 0644 "$DESK_PATH"
ok "desktop entry → $DESK_PATH"

# refresh desktop cache
if command -v update-desktop-database >/dev/null 2>&1; then
  sudo -u "$TARGET_USER" update-desktop-database "$DESK_DIR" >/dev/null 2>&1 || true
fi

# ── seed the knowledge base on the user's behalf so the GUI is instant ─────
step "seed knowledge base"
sudo -u "$TARGET_USER" python3 - <<'PY' 2>/dev/null || true
import sys
sys.path.insert(0, "/opt/nyxus-sage")
from sage.knowledge import KnowledgeBase
kb = KnowledgeBase()
n = kb.seed_starter_rules()
print(f"  seeded {n} starter rules into {kb.backend_name} backend at {kb.root}")
PY

# ── done ────────────────────────────────────────────────────────────────────
step "done"
ok "GUI:  ${B}nyxus-sage${R}     (alias: ${B}sage${R})"
ok "CLI:  ${B}nyxus-audit <path>${R}"
ok "menu: NYXUS SAGE in your application launcher"
printf "\n${DIM}© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED${R}\n"
