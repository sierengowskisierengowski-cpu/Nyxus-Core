"""
NYXUS Phantom — RED-event forensic capture pipeline.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

When Phantom escalates an event to RED severity, this module captures
a complete forensic snapshot of the system state at the time of the
incident, encrypts it with GPG, and writes a sealed bundle the
investigator can replay later.

Bundle contents:
  • metadata.json       — incident metadata + chain-of-custody
  • processes.json      — full process tree at time of event
  • connections.json    — every active TCP/UDP socket
  • files_recent.json   — file changes in last 60 minutes
  • modules.txt         — loaded kernel modules
  • dmesg.txt           — full dmesg ring buffer
  • journal.txt         — journalctl --since "2 hours ago"
  • netstat.txt         — ss -tunap output
  • lsof.txt            — open file handles
  • memory_dumps/       — /proc/<pid>/maps + smaps for offending PID(s)
  • pcap/incident.pcap  — 60s capture if tcpdump available
  • bundle.tar.gz.gpg   — everything above, signed + encrypted
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────


GPG_RECIPIENT = os.environ.get("NYXUS_GPG_RECIPIENT", "")  # set in config


# --------------------------------------------------------------------------- #
# entry point                                                                 #
# --------------------------------------------------------------------------- #
def capture_full(out_dir: Path, ctx: dict, cfg: dict, log) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    log("FX", "RED", f"forensic capture begin → {out_dir}", ctx)

    meta = {
        "ts": time.time(),
        "ts_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "host": os.uname().nodename,
        "kernel": os.uname().release,
        "trigger_ctx": ctx,
        "phantom_pid": os.getpid(),
        "phantom_uid": os.getuid(),
        "tools_present": _detect_tools(),
    }
    (out_dir / "metadata.json").write_text(json.dumps(meta, indent=2))

    _capture_processes(out_dir, log)
    _capture_connections(out_dir, log)
    _capture_recent_files(out_dir, log)
    _capture_modules(out_dir, log)
    _capture_dmesg(out_dir, log)
    _capture_journal(out_dir, log)
    _capture_netstat(out_dir, log)
    _capture_lsof(out_dir, log)
    _capture_memory(out_dir, ctx, log)
    _capture_pcap(out_dir, log)

    # produce hash manifest
    manifest = {}
    for p in out_dir.rglob("*"):
        if p.is_file() and p.name != "manifest.json":
            try:
                manifest[str(p.relative_to(out_dir))] = _sha256(p)
            except Exception:
                continue
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True))

    # tarball + GPG (if configured)
    tar_path = out_dir.parent / f"{out_dir.name}.tar.gz"
    try:
        subprocess.run(["tar", "czf", str(tar_path), "-C", str(out_dir.parent), out_dir.name],
                       check=True, timeout=120, capture_output=True)
        log("FX", "RED", f"tarball → {tar_path} ({tar_path.stat().st_size} bytes)", None)
    except Exception as exc:
        log("FX", "RED", f"tar failed: {exc}", None)
        return

    if GPG_RECIPIENT and shutil.which("gpg"):
        gpg_path = tar_path.with_suffix(tar_path.suffix + ".gpg")
        try:
            subprocess.run(
                ["gpg", "--batch", "--yes", "--trust-model", "always",
                 "--encrypt", "--recipient", GPG_RECIPIENT,
                 "--output", str(gpg_path), str(tar_path)],
                check=True, timeout=60, capture_output=True,
            )
            os.unlink(tar_path)
            log("FX", "RED", f"GPG-sealed → {gpg_path}", None)
        except Exception as exc:
            log("FX", "RED", f"GPG encryption failed: {exc}", None)


# --------------------------------------------------------------------------- #
# capture helpers                                                              #
# --------------------------------------------------------------------------- #
def _capture_processes(out: Path, log) -> None:
    try:
        import psutil
        rows = []
        for p in psutil.process_iter():
            try:
                rows.append({
                    "pid": p.pid, "ppid": p.ppid(), "name": p.name(),
                    "exe": p.exe() if p.is_running() else "",
                    "cmdline": p.cmdline(),
                    "username": p.username(),
                    "create_time": p.create_time(),
                    "cpu_percent": p.cpu_percent(),
                    "memory_rss": p.memory_info().rss,
                    "num_threads": p.num_threads(),
                    "open_files": [str(f.path) for f in p.open_files()][:20],
                    "connections": [{"laddr": str(c.laddr), "raddr": str(c.raddr) if c.raddr else "",
                                     "status": c.status} for c in p.net_connections()][:20],
                })
            except Exception:
                continue
        (out / "processes.json").write_text(json.dumps(rows, indent=2))
    except Exception as exc:
        log("FX", "WHITE", f"processes capture failed: {exc}", None)


def _capture_connections(out: Path, log) -> None:
    try:
        import psutil
        conns = [{"fd": c.fd, "type": c.type, "laddr": str(c.laddr),
                  "raddr": str(c.raddr) if c.raddr else "",
                  "status": c.status, "pid": c.pid}
                 for c in psutil.net_connections(kind="inet")]
        (out / "connections.json").write_text(json.dumps(conns, indent=2))
    except Exception as exc:
        log("FX", "WHITE", f"connections capture failed: {exc}", None)


def _capture_recent_files(out: Path, log) -> None:
    threshold = time.time() - 3600
    rows = []
    for root in ("/etc", "/usr", "/var", "/home", "/tmp", "/opt"):
        if not Path(root).is_dir():
            continue
        try:
            for dirpath, dirnames, filenames in os.walk(root):
                # cap depth a bit so we don't fork-bomb the FS
                if dirpath.count("/") > 8:
                    dirnames.clear()
                    continue
                for fn in filenames:
                    p = Path(dirpath) / fn
                    try:
                        st = p.stat()
                        if st.st_mtime > threshold:
                            rows.append({"path": str(p), "size": st.st_size,
                                         "mtime": st.st_mtime, "uid": st.st_uid,
                                         "mode": oct(st.st_mode)})
                    except OSError:
                        continue
        except Exception:
            continue
    (out / "files_recent.json").write_text(json.dumps(rows[:5000], indent=2))


def _capture_modules(out: Path, log) -> None:
    try:
        (out / "modules.txt").write_text(Path("/proc/modules").read_text())
    except Exception as exc:
        log("FX", "WHITE", f"modules capture failed: {exc}", None)


def _capture_dmesg(out: Path, log) -> None:
    if not shutil.which("dmesg"):
        return
    try:
        r = subprocess.run(["dmesg"], capture_output=True, timeout=10, text=True)
        (out / "dmesg.txt").write_text(r.stdout)
    except Exception as exc:
        log("FX", "WHITE", f"dmesg failed: {exc}", None)


def _capture_journal(out: Path, log) -> None:
    if not shutil.which("journalctl"):
        return
    try:
        r = subprocess.run(["journalctl", "--since", "2 hours ago", "--no-pager"],
                           capture_output=True, timeout=30, text=True)
        (out / "journal.txt").write_text(r.stdout[:10_000_000])
    except Exception as exc:
        log("FX", "WHITE", f"journal failed: {exc}", None)


def _capture_netstat(out: Path, log) -> None:
    if not shutil.which("ss"):
        return
    try:
        r = subprocess.run(["ss", "-tunap"], capture_output=True, timeout=10, text=True)
        (out / "netstat.txt").write_text(r.stdout)
    except Exception as exc:
        log("FX", "WHITE", f"ss failed: {exc}", None)


def _capture_lsof(out: Path, log) -> None:
    if not shutil.which("lsof"):
        return
    try:
        r = subprocess.run(["lsof", "-n", "-P"], capture_output=True, timeout=20, text=True)
        (out / "lsof.txt").write_text(r.stdout[:5_000_000])
    except Exception as exc:
        log("FX", "WHITE", f"lsof failed: {exc}", None)


def _capture_memory(out: Path, ctx: dict, log) -> None:
    pid = ctx.get("pid")
    if not pid:
        return
    try:
        d = out / "memory_dumps" / str(pid)
        d.mkdir(parents=True, exist_ok=True)
        for fn in ("maps", "smaps", "status", "stat", "comm", "cmdline"):
            src = Path(f"/proc/{pid}/{fn}")
            if src.exists():
                try:
                    (d / fn).write_text(src.read_text(errors="replace"))
                except Exception:
                    continue
    except Exception as exc:
        log("FX", "WHITE", f"memory dump failed: {exc}", None)


def _capture_pcap(out: Path, log) -> None:
    if not shutil.which("tcpdump"):
        return
    pcap = out / "pcap" / "incident.pcap"
    pcap.parent.mkdir(exist_ok=True)
    try:
        subprocess.run(["tcpdump", "-i", "any", "-w", str(pcap), "-G", "60", "-W", "1"],
                       timeout=70, check=False, capture_output=True)
        log("FX", "RED", f"pcap captured → {pcap}", None)
    except Exception as exc:
        log("FX", "WHITE", f"tcpdump failed: {exc}", None)


# --------------------------------------------------------------------------- #
# utility                                                                      #
# --------------------------------------------------------------------------- #
def _detect_tools() -> dict[str, bool]:
    return {t: bool(shutil.which(t)) for t in
            ["psutil", "tcpdump", "dmesg", "journalctl", "ss", "lsof",
             "ufw", "gpg", "loginctl", "ionice"]}


def _sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fp:
        for chunk in iter(lambda: fp.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


if __name__ == "__main__":  # quick test harness
    capture_full(Path("/tmp/phantom-test"), {"pid": os.getpid()}, {}, lambda *a: print(a))
