#!/usr/bin/env bash
# ============================================================================
# NYXUS Phantom — installer
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
#
# Run as root on the target Arch + Hyprland system:
#   sudo bash install.sh
# ============================================================================
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: must be run as root" >&2
  exit 1
fi

INSTALL_DIR="/opt/nyxus-phantom"
CONFIG_DIR="/etc/nyxus-phantom"
DATA_DIR="/var/lib/nyxus-phantom"
LOG_DIR="/var/log/nyxus-phantom"
SERVICE_USER="nyxus-phantom"
SERVICE_GROUP="nyxus-phantom"

echo "──────────────────────────────────────────────────────────────"
echo "  NYXUS Phantom · install"
echo "──────────────────────────────────────────────────────────────"

# 1. system packages
echo "[1/7] installing system packages …"
if command -v pacman >/dev/null 2>&1; then
  pacman -Sy --needed --noconfirm \
      python python-pip python-psutil python-cryptography \
      python-gnupg python-paho-mqtt \
      tcpdump lsof ufw libnotify gnupg sudo
elif command -v apt-get >/dev/null 2>&1; then
  apt-get update
  apt-get install -y python3 python3-pip python3-psutil python3-cryptography \
      python3-gnupg python3-paho-mqtt tcpdump lsof ufw libnotify-bin gnupg
fi

# 2. service user
echo "[2/7] creating $SERVICE_USER user …"
if ! id -u "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi
groupadd -f "$SERVICE_GROUP" || true

# 3. directories
echo "[3/7] creating directories …"
mkdir -p "$INSTALL_DIR" "$CONFIG_DIR" "$DATA_DIR" "$LOG_DIR" "$DATA_DIR/.nyxus/phantom"
chown -R "$SERVICE_USER:$SERVICE_GROUP" "$DATA_DIR" "$LOG_DIR"
chmod 750 "$DATA_DIR" "$LOG_DIR"

# 4. Python files
echo "[4/7] copying daemon files …"
HERE="$(cd "$(dirname "$0")" && pwd)"
install -m 0755 "$HERE/phantom.py"            "$INSTALL_DIR/phantom.py"
install -m 0644 "$HERE/phantom_monitor.py"    "$INSTALL_DIR/phantom_monitor.py"
install -m 0644 "$HERE/phantom_response.py"   "$INSTALL_DIR/phantom_response.py"
install -m 0644 "$HERE/phantom_forensics.py"  "$INSTALL_DIR/phantom_forensics.py"
install -m 0644 "$HERE/phantom_threats.py"    "$INSTALL_DIR/phantom_threats.py"

# 5. config (don't clobber existing)
echo "[5/7] installing default config …"
if [[ ! -f "$CONFIG_DIR/config.json" ]]; then
  install -m 0644 "$HERE/config.json" "$CONFIG_DIR/config.json"
fi
chown -R "$SERVICE_USER:$SERVICE_GROUP" "$CONFIG_DIR"

# 6. python deps via pip if distro packages didn't cover it
echo "[6/7] installing extra python deps …"
python3 -m pip install --break-system-packages --quiet \
    inotify_simple paho-mqtt psutil 2>/dev/null || \
python3 -m pip install --quiet inotify_simple paho-mqtt psutil

# 7. systemd unit + polkit rule
echo "[7/7] installing systemd unit …"
install -m 0644 "$HERE/nyxus-phantom.service" /etc/systemd/system/nyxus-phantom.service

# polkit rule: stopping the service requires YubiKey-backed sudo
mkdir -p /etc/polkit-1/rules.d
cat > /etc/polkit-1/rules.d/99-nyxus-phantom.rules <<'POLKIT'
// NYXUS Phantom — only root may stop, via pam-u2f sudo
polkit.addRule(function(action, subject) {
    if (action.id == "org.freedesktop.systemd1.manage-units" &&
        action.lookup("unit") == "nyxus-phantom.service" &&
        ["stop","restart","reload"].indexOf(action.lookup("verb")) >= 0) {
        if (subject.isInGroup("wheel") && subject.local && subject.active) {
            return polkit.Result.AUTH_ADMIN_KEEP;
        }
        return polkit.Result.NO;
    }
});
POLKIT

systemctl daemon-reload
systemctl enable nyxus-phantom.service
systemctl restart nyxus-phantom.service

echo
echo "──────────────────────────────────────────────────────────────"
echo "  Phantom installed and started."
echo "  status:  systemctl status nyxus-phantom"
echo "  logs:    journalctl -fu nyxus-phantom"
echo "  events:  $DATA_DIR/.nyxus/phantom/events.db"
echo "──────────────────────────────────────────────────────────────"
