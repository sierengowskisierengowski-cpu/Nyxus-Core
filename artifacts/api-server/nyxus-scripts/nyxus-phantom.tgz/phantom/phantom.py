#!/usr/bin/env python3
"""
NYXUS Phantom — silent background security daemon.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Runs as a systemd service. No UI. Watches everything. Reports nothing
unless something is wrong. Self-healing via WatchdogSec=10.

Entry point invoked by /etc/systemd/system/nyxus-phantom.service.
Designed for nice=19 ionice idle — invisible CPU footprint.
"""
from __future__ import annotations

import json
import os
import signal
import socket
import sqlite3
import sys
import threading
import time
from pathlib import Path

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────


# --------------------------------------------------------------------------- #
# bootstrap: refuse to run with footprint above 0.5% CPU steady-state         #
# --------------------------------------------------------------------------- #
HOME = Path(os.path.expanduser("~"))
ROOT = HOME / ".nyxus" / "phantom"
ROOT.mkdir(parents=True, exist_ok=True)
(ROOT / "forensics").mkdir(exist_ok=True)
(ROOT / "reports").mkdir(exist_ok=True)
(ROOT / "logs").mkdir(exist_ok=True)

CFG_PATH = Path(os.environ.get("NYXUS_PHANTOM_CONFIG",
                               str(Path.home() / ".config/nyxus-phantom/config.json")))
DB_PATH = ROOT / "events.db"
BASE_PATH = ROOT / "baseline.db"
SOCK_PATH = ROOT / "phantom.sock"
PID_PATH = ROOT / "phantom.pid"

DEFAULT_CFG = {
    "watch_paths": [
        "/etc", "/usr/bin", "/usr/sbin", "/usr/lib",
        "/boot", "/etc/systemd", "/etc/pam.d",
        "/etc/sudoers", "/etc/hosts", "/etc/passwd",
        "/etc/shadow", "/etc/group", "/etc/crontab",
        "/etc/cron.d", "/etc/profile", "/etc/bash.bashrc",
        f"{HOME}/.ssh", f"{HOME}/.config", f"{HOME}/.gnupg",
        f"{HOME}/.bashrc", f"{HOME}/.zshrc", f"{HOME}/.profile",
    ],
    "critical_paths": [
        "/etc/passwd", "/etc/shadow", "/etc/sudoers",
        "/etc/pam.d", f"{HOME}/.ssh/authorized_keys",
    ],
    "process_baseline_hours": 24,
    "network_baseline_hours": 48,
    "yubikey_serial": "35272364",
    "max_failed_logins": 3,
    "mqtt_host": "127.0.0.1",
    "mqtt_port": 1883,
    "mqtt_topic": "nyxus/phantom",
    "loki_url": "http://127.0.0.1:3100/loki/api/v1/push",
    "threat_feeds": {
        "abuse_ipdb":   "https://lists.blocklist.de/lists/all.txt",
        "feodo":        "https://feodotracker.abuse.ch/downloads/ipblocklist.txt",
        "tor_exits":    "https://check.torproject.org/torbulkexitlist",
        "ssl_blacklist":"https://sslbl.abuse.ch/blacklist/sslipblacklist.txt",
        "urlhaus":      "https://urlhaus.abuse.ch/downloads/text/",
    },
    "whitelist": {"processes": [], "ips": [], "usb": [], "modules": []},
}


def load_config() -> dict:
    if CFG_PATH.is_file():
        try:
            with CFG_PATH.open() as fp:
                user = json.load(fp)
            cfg = {**DEFAULT_CFG, **user}
            for k in ("whitelist",):
                cfg[k] = {**DEFAULT_CFG[k], **user.get(k, {})}
            return cfg
        except Exception as exc:
            log("CONFIG", "WHITE", f"config parse error: {exc}; using defaults")
    return dict(DEFAULT_CFG)


def init_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), isolation_level=None, check_same_thread=False)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            severity TEXT NOT NULL,
            module TEXT NOT NULL,
            tag TEXT NOT NULL,
            message TEXT NOT NULL,
            context TEXT,
            hash TEXT
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ts ON events(ts)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_sev ON events(severity)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_mod ON events(module)")
    return conn


# --------------------------------------------------------------------------- #
# logging — append-only, hash-chained, ships to Loki when reachable           #
# --------------------------------------------------------------------------- #
import hashlib
_log_lock = threading.Lock()
_log_chain = ""  # rolling sha256 of all prior log lines


def log(module: str, severity: str, message: str, ctx: dict | None = None) -> None:
    """Append a structured event to the Phantom log + sqlite db."""
    global _log_chain
    ts = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    with _log_lock:
        line = f"{ts} [{severity:5}] {module:10} {message}"
        if ctx:
            line += "  " + json.dumps(ctx, separators=(",", ":"))
        h = hashlib.sha256((_log_chain + line).encode()).hexdigest()
        _log_chain = h
        try:
            with (ROOT / "logs" / time.strftime("%Y-%m-%d.log")).open("a") as fp:
                fp.write(line + f"  hash={h[:16]}\n")
        except Exception:
            pass
        try:
            DB.execute(
                "INSERT INTO events(ts,severity,module,tag,message,context,hash) "
                "VALUES(?,?,?,?,?,?,?)",
                (ts, severity, module, "EVENT", message, json.dumps(ctx or {}), h),
            )
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# systemd watchdog                                                            #
# --------------------------------------------------------------------------- #
def sd_notify(state: str) -> None:
    sock_path = os.environ.get("NOTIFY_SOCKET")
    if not sock_path:
        return
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        if sock_path.startswith("@"):
            sock_path = "\0" + sock_path[1:]
        s.connect(sock_path)
        s.sendall(state.encode())
        s.close()
    except Exception:
        pass


def watchdog_loop(stop_event: threading.Event) -> None:
    interval = 5
    while not stop_event.wait(interval):
        sd_notify("WATCHDOG=1")


# --------------------------------------------------------------------------- #
# graceful shutdown                                                           #
# --------------------------------------------------------------------------- #
STOP = threading.Event()


def _sigterm(signum, frame):
    log("CORE", "WHITE", f"received signal {signum} — graceful shutdown")
    sd_notify("STOPPING=1")
    STOP.set()


for s in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
    signal.signal(s, _sigterm)


# --------------------------------------------------------------------------- #
# main                                                                        #
# --------------------------------------------------------------------------- #
def main() -> int:
    global DB, CFG, RESPONDER, THREATS
    CFG = load_config()
    DB = init_db()
    PID_PATH.write_text(str(os.getpid()))

    # be the politest process on the box
    try:
        os.nice(19)
    except OSError:
        pass
    try:
        # ionice idle (class 3) via subprocess so we don't need extra deps
        import subprocess
        subprocess.run(["ionice", "-c", "3", "-p", str(os.getpid())],
                       check=False, capture_output=True)
    except Exception:
        pass

    # dynamic imports (run after config is loaded so monitors can read CFG)
    sys.path.insert(0, str(Path(__file__).parent))
    from phantom_response import Responder       # noqa: WPS433
    from phantom_threats import ThreatIntel       # noqa: WPS433
    from phantom_monitor import (                 # noqa: WPS433
        FileWatcher, ProcessWatcher, NetworkWatcher,
        USBWatcher, KernelWatcher, AuthWatcher, MemoryWatcher,
    )

    THREATS = ThreatIntel(ROOT, CFG)
    RESPONDER = Responder(CFG, log, ROOT)

    # tell systemd we're up
    sd_notify("READY=1")
    sd_notify("STATUS=Phantom watching")
    log("CORE", "WHITE", f"Phantom v1.0 online · pid {os.getpid()} · uid {os.getuid()}")

    workers = [
        threading.Thread(target=watchdog_loop, args=(STOP,), daemon=True, name="watchdog"),
        threading.Thread(target=FileWatcher(CFG, log, RESPONDER, BASE_PATH).run,
                         args=(STOP,), daemon=True, name="file"),
        threading.Thread(target=ProcessWatcher(CFG, log, RESPONDER, ROOT).run,
                         args=(STOP,), daemon=True, name="process"),
        threading.Thread(target=NetworkWatcher(CFG, log, RESPONDER, THREATS, ROOT).run,
                         args=(STOP,), daemon=True, name="network"),
        threading.Thread(target=USBWatcher(CFG, log, RESPONDER).run,
                         args=(STOP,), daemon=True, name="usb"),
        threading.Thread(target=KernelWatcher(CFG, log, RESPONDER).run,
                         args=(STOP,), daemon=True, name="kernel"),
        threading.Thread(target=AuthWatcher(CFG, log, RESPONDER).run,
                         args=(STOP,), daemon=True, name="auth"),
        threading.Thread(target=MemoryWatcher(CFG, log, RESPONDER).run,
                         args=(STOP,), daemon=True, name="memory"),
        threading.Thread(target=THREATS.daily_refresh_loop,
                         args=(STOP,), daemon=True, name="threats"),
    ]
    for w in workers:
        w.start()

    # daily report writer
    def report_loop() -> None:
        while not STOP.wait(3600):  # hourly tick
            now = time.gmtime()
            if now.tm_hour == 0:
                write_daily_report()

    threading.Thread(target=report_loop, daemon=True, name="report").start()

    # main wait
    while not STOP.wait(60):
        # heartbeat that we're still scheduling work
        sd_notify("STATUS=" + f"watching {len(workers)} subsystems")

    log("CORE", "WHITE", "all monitors signaled to stop")
    for w in workers:
        w.join(timeout=3)
    log("CORE", "WHITE", "Phantom offline")
    return 0


def write_daily_report() -> None:
    day = time.strftime("%Y-%m-%d", time.gmtime(time.time() - 60))
    out = ROOT / "reports" / f"{day}.json"
    cur = DB.execute(
        "SELECT severity, COUNT(*) FROM events WHERE ts LIKE ? GROUP BY severity",
        (f"{day}%",),
    )
    by_sev = {row[0]: row[1] for row in cur.fetchall()}
    cur = DB.execute(
        "SELECT module, COUNT(*) FROM events WHERE ts LIKE ? GROUP BY module",
        (f"{day}%",),
    )
    by_mod = {row[0]: row[1] for row in cur.fetchall()}
    cur = DB.execute(
        "SELECT ts, severity, module, message FROM events "
        "WHERE ts LIKE ? AND severity IN ('ORANGE','RED') ORDER BY ts DESC LIMIT 50",
        (f"{day}%",),
    )
    notable = [{"ts": r[0], "sev": r[1], "mod": r[2], "msg": r[3]} for r in cur.fetchall()]
    out.write_text(json.dumps({"date": day, "by_severity": by_sev,
                               "by_module": by_mod, "notable": notable},
                              indent=2, sort_keys=True))
    log("REPORT", "WHITE", f"daily report → {out}")


if __name__ == "__main__":
    raise SystemExit(main())
