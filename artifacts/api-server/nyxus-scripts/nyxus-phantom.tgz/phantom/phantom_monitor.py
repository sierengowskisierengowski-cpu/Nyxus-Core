"""
NYXUS Phantom — monitoring modules
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

All seven watcher subsystems Phantom runs as background threads:
  • FileWatcher    — inotify + sha256 baseline of critical paths
  • ProcessWatcher — psutil baseline + new process scrutiny
  • NetworkWatcher — netlink + outbound-connection baseline + threat lookup
  • USBWatcher     — udev/sysfs poll, HID anomaly detection, YubiKey watch
  • KernelWatcher  — module load events, /proc/sys params, LD_PRELOAD
  • AuthWatcher    — /var/log/auth.log tail, sudo/SSH events, account changes
  • MemoryWatcher  — /proc/*/maps anomalies, fileless execution heuristics

Every watcher is best-effort: missing binaries or permission errors are
logged at WHITE severity and the watcher carries on. Phantom must NEVER
crash the systemd unit just because one subsystem can't read a node.
"""
from __future__ import annotations

import collections
import hashlib
import json
import os
import re
import sqlite3
import struct
import subprocess
import time
from pathlib import Path
from typing import Callable, Iterable

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────


LogFn = Callable[[str, str, str, dict | None], None]

CRIT_NAMES = {"sshd", "sudo", "su", "systemd", "passwd", "useradd", "usermod",
              "groupadd", "crontab", "init", "polkitd"}
SHELL_NAMES = {"bash", "sh", "zsh", "dash", "fish", "ksh", "tcsh"}
NETWORK_PARENTS = {"sshd", "nginx", "apache2", "httpd", "vsftpd", "postfix",
                   "dovecot", "smtpd", "named", "bind9"}


# --------------------------------------------------------------------------- #
# helper                                                                      #
# --------------------------------------------------------------------------- #
def _sha256_file(path: Path, chunk: int = 65536) -> str | None:
    try:
        h = hashlib.sha256()
        with path.open("rb") as fp:
            for blk in iter(lambda: fp.read(chunk), b""):
                h.update(blk)
        return h.hexdigest()
    except Exception:
        return None


def _walk(paths: Iterable[str], skip_dirs=(".git", "__pycache__", "node_modules")):
    for p in paths:
        root = Path(p)
        if not root.exists():
            continue
        if root.is_file():
            yield root
            continue
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            dirnames[:] = [d for d in dirnames if d not in skip_dirs]
            for fn in filenames:
                f = Path(dirpath) / fn
                try:
                    if f.is_file() and not f.is_symlink():
                        yield f
                except OSError:
                    continue


# =========================================================================== #
# 1. FILE WATCHER                                                             #
# =========================================================================== #
class FileWatcher:
    def __init__(self, cfg, log: LogFn, responder, baseline_path: Path):
        self.cfg = cfg
        self.log = log
        self.responder = responder
        self.bp = baseline_path
        self.crit = set(cfg["critical_paths"])

    def _open_db(self) -> sqlite3.Connection:
        c = sqlite3.connect(str(self.bp), isolation_level=None, check_same_thread=False)
        c.execute("CREATE TABLE IF NOT EXISTS files (path TEXT PRIMARY KEY, sha TEXT, mtime REAL)")
        return c

    def _build_baseline(self, db) -> int:
        n = 0
        for f in _walk(self.cfg["watch_paths"]):
            sha = _sha256_file(f)
            if sha is None:
                continue
            try:
                db.execute("INSERT OR REPLACE INTO files VALUES(?,?,?)",
                           (str(f), sha, f.stat().st_mtime))
                n += 1
            except Exception:
                continue
        return n

    def run(self, stop) -> None:
        db = self._open_db()
        cur = db.execute("SELECT COUNT(*) FROM files").fetchone()
        if not cur or cur[0] == 0:
            self.log("FILE", "WHITE", "building first-run SHA256 baseline …", None)
            n = self._build_baseline(db)
            self.log("FILE", "WHITE", f"baseline complete · {n} files hashed", None)
        else:
            self.log("FILE", "WHITE", f"baseline loaded · {cur[0]} files", None)

        # try inotify path; fall back to periodic walk
        try:
            from inotify_simple import INotify, flags
            inotify = INotify()
            mask = flags.MODIFY | flags.CREATE | flags.DELETE | flags.ATTRIB | flags.MOVED_TO | flags.MOVED_FROM
            wd_to_path: dict[int, str] = {}
            for p in self.cfg["watch_paths"]:
                try:
                    if Path(p).exists():
                        wd = inotify.add_watch(p, mask)
                        wd_to_path[wd] = p
                except Exception as exc:
                    self.log("FILE", "WHITE", f"cannot watch {p}: {exc}", None)
            self.log("FILE", "WHITE", f"inotify online · {len(wd_to_path)} root watches", None)
            while not stop.is_set():
                for ev in inotify.read(timeout=1000):
                    self._handle_event(db, wd_to_path.get(ev.wd, ""), ev.name, ev.mask)
        except Exception as exc:
            self.log("FILE", "WHITE", f"inotify unavailable ({exc}); polling mode", None)
            while not stop.wait(60):
                self._poll_once(db)

    def _handle_event(self, db, root: str, name: str, mask: int) -> None:
        if not name:
            return
        full = str(Path(root) / name)
        is_crit = any(full == c or full.startswith(c + "/") for c in self.crit)
        sev = "RED" if is_crit else "ORANGE"
        # match against baseline
        row = db.execute("SELECT sha FROM files WHERE path=?", (full,)).fetchone()
        new_sha = _sha256_file(Path(full)) if Path(full).is_file() else None
        if row is None and new_sha:
            self.log("FILE", "ORANGE", f"NEW file in protected path: {full}",
                     {"sha256": new_sha})
            self.responder.dispatch("ORANGE", "FILE", "new", {"path": full, "sha": new_sha})
            db.execute("INSERT OR REPLACE INTO files VALUES(?,?,?)",
                       (full, new_sha, time.time()))
        elif row and new_sha and row[0] != new_sha:
            self.log("FILE", sev, f"HASH MISMATCH on {full}",
                     {"old": row[0], "new": new_sha})
            self.responder.dispatch(sev, "FILE", "modified",
                                    {"path": full, "old": row[0], "new": new_sha})
            db.execute("UPDATE files SET sha=?, mtime=? WHERE path=?",
                       (new_sha, time.time(), full))
        elif row and not Path(full).exists():
            self.log("FILE", sev, f"DELETED {full}", {"old": row[0]})
            self.responder.dispatch(sev, "FILE", "deleted", {"path": full})
            db.execute("DELETE FROM files WHERE path=?", (full,))

    def _poll_once(self, db) -> None:
        # cheap O(N) walk with mtime gate
        for f in _walk(self.cfg["watch_paths"]):
            try:
                mt = f.stat().st_mtime
            except OSError:
                continue
            row = db.execute("SELECT sha, mtime FROM files WHERE path=?", (str(f),)).fetchone()
            if row and abs(row[1] - mt) < 0.5:
                continue
            self._handle_event(db, str(f.parent), f.name, 0)


# =========================================================================== #
# 2. PROCESS WATCHER                                                          #
# =========================================================================== #
class ProcessWatcher:
    def __init__(self, cfg, log: LogFn, responder, root: Path):
        self.cfg = cfg
        self.log = log
        self.responder = responder
        self.baseline_path = root / "process_baseline.json"
        self.seen: dict[int, dict] = {}

    def _load_baseline(self) -> set[str]:
        if self.baseline_path.is_file():
            try:
                return set(json.loads(self.baseline_path.read_text()).get("names", []))
            except Exception:
                return set()
        return set()

    def _save_baseline(self, names: set[str]) -> None:
        self.baseline_path.write_text(json.dumps(
            {"names": sorted(names), "saved": time.time()}, indent=2))

    def run(self, stop) -> None:
        try:
            import psutil
        except ImportError:
            self.log("PROC", "WHITE", "psutil missing → process watcher disabled", None)
            stop.wait()
            return

        baseline = self._load_baseline()
        baseline_started = time.time()
        baseline_window = self.cfg["process_baseline_hours"] * 3600
        # seed first sweep
        for proc in psutil.process_iter(["pid", "name", "exe", "cmdline", "ppid", "username"]):
            try:
                self.seen[proc.info["pid"]] = proc.info
                baseline.add(proc.info["name"] or "")
            except Exception:
                continue

        while not stop.wait(3):
            try:
                current_pids = set()
                for proc in psutil.process_iter(["pid", "name", "exe", "cmdline", "ppid", "username", "cpu_percent"]):
                    try:
                        info = proc.info
                    except Exception:
                        continue
                    pid = info["pid"]
                    current_pids.add(pid)
                    if pid in self.seen:
                        # cryptominer heuristic — sustained high CPU
                        cpu = info.get("cpu_percent") or 0
                        if cpu > 80 and (info["name"] or "") not in baseline:
                            self.log("PROC", "ORANGE",
                                     f"sustained high CPU from new process {info['name']} pid={pid}",
                                     {"cpu": cpu, "exe": info.get("exe")})
                            self.responder.dispatch("ORANGE", "PROC", "highcpu", info)
                        continue
                    # NEW process
                    self.seen[pid] = info
                    self._scrutinize(info, baseline, baseline_started + baseline_window)

                # process death
                for dead in set(self.seen) - current_pids:
                    self.seen.pop(dead, None)
            except Exception as exc:
                self.log("PROC", "WHITE", f"watcher iteration error: {exc}", None)

            # periodically commit baseline names so day-2 has knowledge
            if time.time() - baseline_started > 600:
                self._save_baseline(baseline)
                baseline_started = time.time()

    def _scrutinize(self, info: dict, baseline: set[str], baseline_until: float) -> None:
        name = info.get("name") or ""
        exe = info.get("exe") or ""
        cmdline = info.get("cmdline") or []
        cmd_str = " ".join(cmdline) if cmdline else ""

        # name masquerading: similar to a critical name but different exe path
        for crit in CRIT_NAMES:
            if name and name != crit and _similar(name, crit):
                if exe and not exe.startswith(("/usr/", "/sbin/", "/bin/")):
                    self.log("PROC", "RED",
                             f"masquerade suspect: {name} mimics {crit}, exe={exe}", info)
                    self.responder.dispatch("RED", "PROC", "masquerade", info)
                    return

        # reverse shell: shell with network parent
        if name in SHELL_NAMES:
            try:
                import psutil
                parent = psutil.Process(info["ppid"])
                pname = parent.name()
                if pname in NETWORK_PARENTS:
                    self.log("PROC", "RED",
                             f"shell {name} spawned by network service {pname}", info)
                    self.responder.dispatch("RED", "PROC", "reverseshell",
                                            {**info, "parent": pname})
                    return
            except Exception:
                pass

        # exe path outside canonical bins
        if exe and not exe.startswith(("/usr/", "/sbin/", "/bin/", "/opt/", "/snap/")):
            sev = "YELLOW" if time.time() > baseline_until else "WHITE"
            self.log("PROC", sev, f"unusual exe location {exe}", info)
            if sev == "YELLOW":
                self.responder.dispatch("YELLOW", "PROC", "unusual_exe", info)

        # unknown name after baseline window
        if time.time() > baseline_until and name not in baseline:
            self.log("PROC", "BLUE", f"first-seen process: {name}", info)
            baseline.add(name)


def _similar(a: str, b: str) -> bool:
    if not a or not b:
        return False
    if abs(len(a) - len(b)) > 2:
        return False
    diff = sum(1 for x, y in zip(a, b) if x != y)
    return diff <= 2 and a != b


# =========================================================================== #
# 3. NETWORK WATCHER                                                          #
# =========================================================================== #
class NetworkWatcher:
    def __init__(self, cfg, log: LogFn, responder, threats, root: Path):
        self.cfg = cfg
        self.log = log
        self.responder = responder
        self.threats = threats
        self.baseline_path = root / "net_baseline.json"
        self.seen: set[tuple] = set()

    def run(self, stop) -> None:
        try:
            import psutil
        except ImportError:
            self.log("NET", "WHITE", "psutil missing → network watcher disabled", None)
            stop.wait()
            return

        baseline = set()
        if self.baseline_path.is_file():
            try:
                baseline = set(tuple(t) for t in json.loads(self.baseline_path.read_text()))
            except Exception:
                pass
        last_save = time.time()
        baseline_until = time.time() + self.cfg["network_baseline_hours"] * 3600

        while not stop.wait(4):
            try:
                conns = psutil.net_connections(kind="inet")
            except Exception as exc:
                self.log("NET", "WHITE", f"net_connections failed: {exc}", None)
                continue

            for c in conns:
                if c.status != psutil.CONN_ESTABLISHED or not c.raddr:
                    continue
                tup = (c.raddr.ip, c.raddr.port, c.type)
                if tup in self.seen:
                    continue
                self.seen.add(tup)

                # threat lookup
                hit = self.threats.lookup_ip(c.raddr.ip)
                if hit:
                    self.log("NET", "RED",
                             f"connection to KNOWN MALICIOUS {c.raddr.ip}:{c.raddr.port}",
                             {"feed": hit, "pid": c.pid})
                    self.responder.dispatch("RED", "NET", "blacklist",
                                            {"ip": c.raddr.ip, "port": c.raddr.port,
                                             "feed": hit, "pid": c.pid})
                    continue

                # learn first 48h, then alert on never-seen externals
                if tup not in baseline:
                    if time.time() > baseline_until:
                        sev = "YELLOW" if _is_public(c.raddr.ip) else "BLUE"
                        self.log("NET", sev,
                                 f"new outbound to {c.raddr.ip}:{c.raddr.port}",
                                 {"pid": c.pid})
                        if sev == "YELLOW":
                            self.responder.dispatch("YELLOW", "NET", "new_dest",
                                                    {"ip": c.raddr.ip, "port": c.raddr.port})
                    baseline.add(tup)

            if time.time() - last_save > 300:
                try:
                    self.baseline_path.write_text(json.dumps([list(t) for t in baseline]))
                except Exception:
                    pass
                last_save = time.time()


def _is_public(ip: str) -> bool:
    if ":" in ip:  # IPv6 — call most public
        return not (ip.startswith("fe80") or ip.startswith("::1") or ip == "::")
    o = ip.split(".")
    if len(o) != 4:
        return False
    a, b = int(o[0]), int(o[1])
    if a == 10 or a == 127:
        return False
    if a == 172 and 16 <= b <= 31:
        return False
    if a == 192 and b == 168:
        return False
    if a == 169 and b == 254:
        return False
    if a >= 224:
        return False
    return True


# =========================================================================== #
# 4. USB WATCHER                                                              #
# =========================================================================== #
class USBWatcher:
    SYS_USB = Path("/sys/bus/usb/devices")

    def __init__(self, cfg, log: LogFn, responder):
        self.cfg = cfg
        self.log = log
        self.responder = responder
        self.seen: dict[str, dict] = {}

    def _enumerate(self) -> dict[str, dict]:
        out: dict[str, dict] = {}
        if not self.SYS_USB.is_dir():
            return out
        for dev in self.SYS_USB.iterdir():
            if ":" in dev.name:  # skip interface entries
                continue
            try:
                vid = (dev / "idVendor").read_text().strip()
                pid = (dev / "idProduct").read_text().strip()
                serial = ""
                if (dev / "serial").is_file():
                    serial = (dev / "serial").read_text().strip()
                product = ""
                if (dev / "product").is_file():
                    product = (dev / "product").read_text().strip()
                cls = ""
                if (dev / "bDeviceClass").is_file():
                    cls = (dev / "bDeviceClass").read_text().strip()
                out[dev.name] = {"vid": vid, "pid": pid, "serial": serial,
                                 "product": product, "class": cls}
            except Exception:
                continue
        return out

    def run(self, stop) -> None:
        self.seen = self._enumerate()
        self.log("USB", "WHITE", f"USB baseline: {len(self.seen)} devices", None)
        yk_serial = self.cfg.get("yubikey_serial", "")
        had_yk = any(d["serial"] == yk_serial for d in self.seen.values()) if yk_serial else False

        while not stop.wait(2):
            now = self._enumerate()
            new = set(now) - set(self.seen)
            gone = set(self.seen) - set(now)
            for k in new:
                d = now[k]
                meta = {"vid": d["vid"], "pid": d["pid"],
                        "serial": d["serial"], "product": d["product"]}
                # HID class = 03 — keyboard/mouse: alert if vendor unknown
                if d["class"] == "03" and d["vid"] not in self.cfg.get("whitelist", {}).get("usb", []):
                    self.log("USB", "RED",
                             f"new HID device {d['product']} ({d['vid']}:{d['pid']})",
                             meta)
                    self.responder.dispatch("RED", "USB", "hid_unknown", meta)
                else:
                    self.log("USB", "YELLOW",
                             f"new USB device {d['product']} ({d['vid']}:{d['pid']})",
                             meta)
                    self.responder.dispatch("YELLOW", "USB", "new", meta)
            for k in gone:
                d = self.seen[k]
                if yk_serial and d["serial"] == yk_serial:
                    self.log("USB", "ORANGE", "YubiKey removed during active session",
                             {"serial": d["serial"]})
                    self.responder.dispatch("ORANGE", "USB", "yubikey_removed",
                                            {"serial": d["serial"]})
                else:
                    self.log("USB", "BLUE", f"USB removed: {d.get('product','?')}",
                             {"vid": d["vid"], "pid": d["pid"]})
            if yk_serial:
                has_yk = any(d["serial"] == yk_serial for d in now.values())
                if had_yk and not has_yk:
                    pass  # already handled in `gone` above
                had_yk = has_yk
            self.seen = now


# =========================================================================== #
# 5. KERNEL WATCHER                                                           #
# =========================================================================== #
class KernelWatcher:
    def __init__(self, cfg, log: LogFn, responder):
        self.cfg = cfg
        self.log = log
        self.responder = responder

    def run(self, stop) -> None:
        baseline_mods = self._modules()
        self.log("KERN", "WHITE", f"kernel module baseline: {len(baseline_mods)}", None)
        baseline_sysctl = self._sysctl_snapshot()
        last_preload_check = 0.0

        while not stop.wait(10):
            current = self._modules()
            new = current - baseline_mods
            gone = baseline_mods - current
            wl = set(self.cfg.get("whitelist", {}).get("modules", []))
            for m in new:
                sev = "WHITE" if m in wl else "ORANGE"
                self.log("KERN", sev, f"kernel module loaded: {m}", {"module": m})
                if sev == "ORANGE":
                    self.responder.dispatch("ORANGE", "KERN", "module_load", {"module": m})
            for m in gone:
                self.log("KERN", "BLUE", f"kernel module unloaded: {m}", {"module": m})
            baseline_mods = current

            # sysctl drift
            if int(time.time()) % 60 < 10:
                cur_sc = self._sysctl_snapshot()
                for k, v in cur_sc.items():
                    if k in baseline_sysctl and baseline_sysctl[k] != v:
                        self.log("KERN", "ORANGE",
                                 f"sysctl drift {k}: {baseline_sysctl[k]} → {v}",
                                 {"key": k, "old": baseline_sysctl[k], "new": v})
                        self.responder.dispatch("ORANGE", "KERN", "sysctl",
                                                {"key": k, "old": baseline_sysctl[k], "new": v})
                baseline_sysctl = cur_sc

            # LD_PRELOAD presence
            if time.time() - last_preload_check > 300:
                last_preload_check = time.time()
                try:
                    p = Path("/etc/ld.so.preload")
                    if p.is_file() and p.read_text().strip():
                        self.log("KERN", "RED",
                                 f"/etc/ld.so.preload non-empty: {p.read_text().strip()}", None)
                        self.responder.dispatch("RED", "KERN", "ld_preload",
                                                {"content": p.read_text()})
                except Exception:
                    pass

    def _modules(self) -> set[str]:
        try:
            return {l.split()[0] for l in Path("/proc/modules").read_text().splitlines() if l}
        except Exception:
            return set()

    def _sysctl_snapshot(self) -> dict[str, str]:
        keys = ["kernel/randomize_va_space", "net/ipv4/ip_forward",
                "kernel/dmesg_restrict", "kernel/kptr_restrict",
                "net/ipv4/conf/all/accept_redirects",
                "net/ipv4/conf/all/send_redirects",
                "net/ipv4/tcp_syncookies"]
        out = {}
        for k in keys:
            f = Path("/proc/sys") / k
            try:
                out[k] = f.read_text().strip()
            except Exception:
                continue
        return out


# =========================================================================== #
# 6. AUTH WATCHER                                                             #
# =========================================================================== #
class AuthWatcher:
    LOGS = ["/var/log/auth.log", "/var/log/secure"]

    def __init__(self, cfg, log: LogFn, responder):
        self.cfg = cfg
        self.log = log
        self.responder = responder
        self.fail_count: dict[str, int] = collections.Counter()
        self.last_seen_size: dict[str, int] = {}

    def run(self, stop) -> None:
        # also tail journalctl -fu sshd as a fallback
        log_path = next((p for p in self.LOGS if Path(p).is_file()), None)
        if log_path:
            self.log("AUTH", "WHITE", f"tailing {log_path}", None)
            self._tail_file(log_path, stop)
        else:
            self.log("AUTH", "WHITE", "no auth.log; using journalctl", None)
            self._tail_journal(stop)

    def _tail_file(self, path: str, stop) -> None:
        try:
            with open(path, "r", errors="ignore") as fp:
                fp.seek(0, 2)
                while not stop.is_set():
                    line = fp.readline()
                    if not line:
                        time.sleep(0.5)
                        continue
                    self._parse(line.rstrip())
        except Exception as exc:
            self.log("AUTH", "WHITE", f"tail failed: {exc}", None)

    def _tail_journal(self, stop) -> None:
        try:
            proc = subprocess.Popen(
                ["journalctl", "-fu", "sshd", "-fu", "sudo", "-fu", "systemd-logind",
                 "-o", "short-iso", "--no-pager"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
            )
        except Exception as exc:
            self.log("AUTH", "WHITE", f"journalctl unavailable: {exc}", None)
            stop.wait()
            return
        try:
            while not stop.is_set():
                line = proc.stdout.readline() if proc.stdout else ""
                if not line:
                    if proc.poll() is not None:
                        break
                    continue
                self._parse(line.rstrip())
        finally:
            try:
                proc.terminate()
            except Exception:
                pass

    def _parse(self, line: str) -> None:
        if not line:
            return
        # SSH failed
        m = re.search(r"Failed password for(?: invalid user)? (\S+) from (\S+)", line)
        if m:
            user, ip = m.group(1), m.group(2)
            self.fail_count[ip] += 1
            self.log("AUTH", "YELLOW", f"SSH FAIL {user}@{ip} (count={self.fail_count[ip]})",
                     {"user": user, "ip": ip})
            if self.fail_count[ip] >= self.cfg["max_failed_logins"]:
                self.responder.dispatch("ORANGE", "AUTH", "ssh_brute",
                                        {"ip": ip, "fails": self.fail_count[ip]})
                self.fail_count[ip] = 0
            return
        # SSH accepted
        m = re.search(r"Accepted \S+ for (\S+) from (\S+)", line)
        if m:
            user, ip = m.group(1), m.group(2)
            sev = "RED" if user == "root" else "BLUE"
            self.log("AUTH", sev, f"SSH OK {user}@{ip}", {"user": user, "ip": ip})
            if sev == "RED":
                self.responder.dispatch("RED", "AUTH", "root_login", {"user": user, "ip": ip})
            return
        # sudo
        m = re.search(r"sudo:\s+(\S+)\s*:\s*.*COMMAND=(.*)", line)
        if m:
            user, cmd = m.group(1), m.group(2)
            self.log("AUTH", "BLUE", f"SUDO {user} → {cmd}", {"user": user, "cmd": cmd})
            return
        # user/group changes
        if "useradd" in line or "groupadd" in line or "passwd:" in line:
            self.log("AUTH", "ORANGE", line, None)
            self.responder.dispatch("ORANGE", "AUTH", "user_change", {"line": line})


# =========================================================================== #
# 7. MEMORY WATCHER                                                           #
# =========================================================================== #
class MemoryWatcher:
    def __init__(self, cfg, log: LogFn, responder):
        self.cfg = cfg
        self.log = log
        self.responder = responder

    def run(self, stop) -> None:
        try:
            import psutil
        except ImportError:
            self.log("MEM", "WHITE", "psutil missing → memory watcher disabled", None)
            stop.wait()
            return
        while not stop.wait(30):
            try:
                self._scan_once()
            except Exception as exc:
                self.log("MEM", "WHITE", f"scan error: {exc}", None)

    def _scan_once(self) -> None:
        proc_dir = Path("/proc")
        for p in proc_dir.iterdir():
            if not p.name.isdigit():
                continue
            maps = p / "maps"
            if not maps.exists():
                continue
            try:
                txt = maps.read_text()
            except Exception:
                continue
            # heuristic: rwx mapping with no backing file (anon executable heap)
            for line in txt.splitlines():
                parts = line.split()
                if len(parts) < 5:
                    continue
                perms = parts[1]
                pathname = " ".join(parts[5:]) if len(parts) > 5 else ""
                if "rwx" in perms and not pathname:
                    try:
                        comm = (p / "comm").read_text().strip()
                    except Exception:
                        comm = "?"
                    if comm not in {"java", "node", "chromium", "firefox",
                                    "code", "chrome", "electron"}:
                        self.log("MEM", "ORANGE",
                                 f"rwx anon mapping in {comm} pid={p.name}",
                                 {"comm": comm, "pid": p.name, "line": line})
                        self.responder.dispatch("ORANGE", "MEM", "rwx_anon",
                                                {"comm": comm, "pid": p.name})
                        break
