"""
NYXUS Phantom — severity engine + automated defensive responses.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Severity ladder:
   WHITE  — silent log
   BLUE   — log + included in daily report
   YELLOW — desktop notification + log
   ORANGE — automatic defensive action + notification + log
   RED    — full lockdown + forensic snapshot + critical notification

The Responder class is single-instanced per Phantom run. Watchers call
`responder.dispatch(severity, module, tag, ctx)`; everything else
flows from there: notifications, MQTT publish, UFW changes, process
kills, file quarantine, and (for RED) the forensic capture pipeline.
"""
from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable

LogFn = Callable[[str, str, str, dict | None], None]

ICON_FOR_SEV = {"YELLOW": "dialog-warning", "ORANGE": "dialog-error", "RED": "security-high"}


class Responder:
    def __init__(self, cfg: dict, log: LogFn, root: Path):
        self.cfg = cfg
        self.log = log
        self.root = root
        self.q_dir = root / "quarantine"
        self.q_dir.mkdir(exist_ok=True)
        self._mqtt = None
        self._init_mqtt()
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ #
    # MQTT optional                                                       #
    # ------------------------------------------------------------------ #
    def _init_mqtt(self) -> None:
        try:
            import paho.mqtt.client as mqtt
            client = mqtt.Client(client_id=f"phantom-{os.getpid()}")
            client.connect(self.cfg["mqtt_host"], self.cfg["mqtt_port"], 5)
            client.loop_start()
            self._mqtt = client
            self.log("RESP", "WHITE", "MQTT publisher online", None)
        except Exception as exc:
            self.log("RESP", "WHITE", f"MQTT unavailable ({exc})", None)
            self._mqtt = None

    def _publish(self, topic: str, payload: dict) -> None:
        if not self._mqtt:
            return
        try:
            self._mqtt.publish(topic, json.dumps(payload), qos=0, retain=False)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # public API                                                          #
    # ------------------------------------------------------------------ #
    def dispatch(self, severity: str, module: str, tag: str, ctx: dict | None) -> None:
        sev = severity.upper()
        ctx = ctx or {}
        payload = {"ts": time.time(), "severity": sev, "module": module,
                   "tag": tag, **ctx}
        self._publish(f"{self.cfg['mqtt_topic']}/{module.lower()}", payload)

        if sev in ("YELLOW", "ORANGE", "RED"):
            self._notify(sev, module, tag, ctx)

        if sev == "ORANGE":
            self._defensive_orange(module, tag, ctx)
        elif sev == "RED":
            self._defensive_red(module, tag, ctx)

    # ------------------------------------------------------------------ #
    # notifications                                                       #
    # ------------------------------------------------------------------ #
    def _notify(self, sev: str, module: str, tag: str, ctx: dict) -> None:
        msg = ctx.get("msg") or ctx.get("path") or ctx.get("ip") or json.dumps(ctx)[:80]
        title = f"NYXUS Phantom · {sev}"
        body = f"[{module}/{tag}] {msg}"
        # try notify-send first; fall back to wall + write to a tray spool
        for env in ("DISPLAY", "WAYLAND_DISPLAY", "DBUS_SESSION_BUS_ADDRESS"):
            os.environ.setdefault(env, os.environ.get(env, ""))
        try:
            subprocess.run(
                ["notify-send", "-u", "critical" if sev == "RED" else "normal",
                 "-i", ICON_FOR_SEV.get(sev, "dialog-information"),
                 "-a", "nyxus-phantom", title, body],
                check=False, timeout=3, capture_output=True,
            )
        except Exception:
            pass
        # spool for the Shield app to pick up
        spool = self.root / "spool"
        spool.mkdir(exist_ok=True)
        try:
            (spool / f"{int(time.time()*1000)}-{module}-{sev}.json").write_text(
                json.dumps({"sev": sev, "module": module, "tag": tag, "ctx": ctx,
                            "ts": time.time()}, indent=2)
            )
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # ORANGE actions                                                      #
    # ------------------------------------------------------------------ #
    def _defensive_orange(self, module: str, tag: str, ctx: dict) -> None:
        with self._lock:
            if module == "NET" and ctx.get("ip"):
                self._ufw_block(ctx["ip"])
            elif module == "FILE" and ctx.get("path"):
                self._quarantine(ctx["path"])
            elif module == "PROC" and ctx.get("pid"):
                self._kill_process(int(ctx["pid"]))
            elif module == "AUTH" and tag == "ssh_brute" and ctx.get("ip"):
                self._ufw_block(ctx["ip"])
            self._snapshot("orange")

    # ------------------------------------------------------------------ #
    # RED actions — full lockdown                                         #
    # ------------------------------------------------------------------ #
    def _defensive_red(self, module: str, tag: str, ctx: dict) -> None:
        self.log("RESP", "RED", f"LOCKDOWN triggered by {module}/{tag}", ctx)
        threading.Thread(target=self._lockdown_thread,
                         args=(module, tag, ctx), daemon=True, name="lockdown").start()

    def _lockdown_thread(self, module: str, tag: str, ctx: dict) -> None:
        try:
            from phantom_forensics import capture_full   # noqa: WPS433
        except ImportError:
            self.log("RESP", "RED", "forensics module missing!", None)
            return
        # 1. block all new inbound, kill non-whitelisted outbound
        self._ufw_lockdown()
        # 2. lock user session
        self._lock_session()
        # 3. forensic capture
        out_dir = self.root / "forensics" / time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
        try:
            capture_full(out_dir, ctx, self.cfg, self.log)
            self.log("RESP", "RED", f"forensic bundle → {out_dir}", None)
        except Exception as exc:
            self.log("RESP", "RED", f"forensic capture failed: {exc}", None)
        # 4. ship summary to loki
        self._ship_loki({"event": "RED_LOCKDOWN", "module": module, "tag": tag,
                         "ctx": ctx, "forensics": str(out_dir)})

    # ------------------------------------------------------------------ #
    # tools                                                               #
    # ------------------------------------------------------------------ #
    def _ufw_block(self, ip: str) -> None:
        if not shutil.which("ufw"):
            self.log("RESP", "WHITE", f"ufw missing → cannot block {ip}", None)
            return
        try:
            subprocess.run(["ufw", "deny", "from", ip], check=False, timeout=5,
                           capture_output=True)
            self.log("RESP", "ORANGE", f"UFW blocked {ip}", {"ip": ip})
        except Exception as exc:
            self.log("RESP", "WHITE", f"ufw block failed: {exc}", None)

    def _ufw_lockdown(self) -> None:
        if not shutil.which("ufw"):
            return
        try:
            subprocess.run(["ufw", "default", "deny", "incoming"], check=False, timeout=5,
                           capture_output=True)
            subprocess.run(["ufw", "default", "deny", "outgoing"], check=False, timeout=5,
                           capture_output=True)
            for allow in ("53", "123"):  # DNS + NTP
                subprocess.run(["ufw", "allow", "out", allow], check=False, timeout=5,
                               capture_output=True)
            subprocess.run(["ufw", "--force", "enable"], check=False, timeout=5,
                           capture_output=True)
            self.log("RESP", "RED", "UFW LOCKDOWN engaged", None)
        except Exception as exc:
            self.log("RESP", "WHITE", f"ufw lockdown failed: {exc}", None)

    def _lock_session(self) -> None:
        try:
            subprocess.run(["loginctl", "lock-sessions"], check=False, timeout=5,
                           capture_output=True)
        except Exception:
            pass

    def _quarantine(self, path: str) -> None:
        src = Path(path)
        if not src.is_file():
            return
        dst = self.q_dir / f"{int(time.time())}-{src.name}.q"
        try:
            shutil.copy2(src, dst)
            os.chmod(dst, 0o400)
            self.log("RESP", "ORANGE", f"quarantined {path} → {dst}",
                     {"path": path, "dst": str(dst)})
        except Exception as exc:
            self.log("RESP", "WHITE", f"quarantine failed: {exc}", None)

    def _kill_process(self, pid: int) -> None:
        try:
            os.kill(pid, 15)
            self.log("RESP", "ORANGE", f"sent SIGTERM to pid {pid}", {"pid": pid})
        except ProcessLookupError:
            pass
        except PermissionError:
            self.log("RESP", "WHITE", f"no permission to kill pid {pid}", None)
        except Exception as exc:
            self.log("RESP", "WHITE", f"kill failed: {exc}", None)

    def _snapshot(self, prefix: str) -> None:
        out = self.root / "snapshots" / f"{prefix}-{int(time.time())}.json"
        out.parent.mkdir(exist_ok=True)
        try:
            import psutil
            data = {
                "ts": time.time(),
                "load": os.getloadavg(),
                "procs": [
                    {"pid": p.pid, "name": p.name(), "cpu": p.cpu_percent(),
                     "rss": p.memory_info().rss}
                    for p in psutil.process_iter()
                ][:200],
                "net": [
                    {"laddr": str(c.laddr), "raddr": str(c.raddr) if c.raddr else "",
                     "status": c.status, "pid": c.pid}
                    for c in psutil.net_connections(kind="inet")
                ][:200],
            }
            out.write_text(json.dumps(data, indent=2))
        except Exception as exc:
            self.log("RESP", "WHITE", f"snapshot failed: {exc}", None)

    def _ship_loki(self, payload: dict) -> None:
        url = self.cfg.get("loki_url")
        if not url:
            return
        try:
            import requests
            ts_ns = str(int(time.time() * 1e9))
            body = {"streams": [{"stream": {"app": "nyxus-phantom"},
                                 "values": [[ts_ns, json.dumps(payload)]]}]}
            requests.post(url, json=body, timeout=3)
        except Exception:
            pass
