"""
NYXUS Phantom — local threat-intelligence cache + daily refresher.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Maintains a local sqlite database of:
  • known malicious IPs (abuse.ch + emerging-threats + blocklist.de)
  • Tor exit nodes
  • C2 server IPs (Feodo Tracker, SSL Blacklist, URLhaus)

Lookups are O(log n) sqlite indexed. NEVER calls out during monitoring;
the daily refresher is the only network egress this module performs.
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path
from typing import Iterable


class ThreatIntel:
    SCHEMA = """
        CREATE TABLE IF NOT EXISTS ips (
            ip TEXT PRIMARY KEY, feed TEXT NOT NULL, ts REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_feed ON ips(feed);
    """

    def __init__(self, root: Path, cfg: dict):
        self.cfg = cfg
        self.db_path = root / "threats.db"
        self.last_refresh = 0.0
        self._init_db()

    def _init_db(self) -> None:
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False,
                                    isolation_level=None)
        self.conn.executescript(self.SCHEMA)

    # ------------------------------------------------------------------ #
    # public lookup — used in hot path, NEVER touches network             #
    # ------------------------------------------------------------------ #
    def lookup_ip(self, ip: str) -> str | None:
        """Return feed name if `ip` is on any blocklist, else None."""
        try:
            row = self.conn.execute("SELECT feed FROM ips WHERE ip=?", (ip,)).fetchone()
            return row[0] if row else None
        except Exception:
            return None

    def stats(self) -> dict[str, int]:
        try:
            cur = self.conn.execute("SELECT feed, COUNT(*) FROM ips GROUP BY feed")
            return {r[0]: r[1] for r in cur.fetchall()}
        except Exception:
            return {}

    # ------------------------------------------------------------------ #
    # background refresher                                                #
    # ------------------------------------------------------------------ #
    def daily_refresh_loop(self, stop) -> None:
        # initial refresh after 60s of uptime so we don't slam network at boot
        if not stop.wait(60):
            self._refresh_all()
        while not stop.wait(86400):  # 24h
            self._refresh_all()

    def _refresh_all(self) -> None:
        feeds = self.cfg.get("threat_feeds", {})
        try:
            import requests
        except ImportError:
            return
        added = 0
        for name, url in feeds.items():
            try:
                r = requests.get(url, timeout=15,
                                 headers={"User-Agent": "nyxus-phantom/1.0"})
                if r.status_code != 200:
                    continue
                ips = list(self._extract_ips(r.text))
                self._upsert(name, ips)
                added += len(ips)
            except Exception:
                continue
        self.last_refresh = time.time()
        try:
            (self.db_path.parent / "threats_lastrefresh.txt").write_text(
                f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}  +{added}"
            )
        except Exception:
            pass

    def _extract_ips(self, text: str) -> Iterable[str]:
        import re
        # support plain IP-per-line OR CSV (Feodo) — first IPv4-looking column wins
        rx = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        seen: set[str] = set()
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = rx.search(line)
            if not m:
                continue
            ip = m.group(0)
            if ip in seen:
                continue
            seen.add(ip)
            yield ip

    def _upsert(self, feed: str, ips: list[str]) -> None:
        ts = time.time()
        try:
            self.conn.execute("BEGIN")
            self.conn.execute("DELETE FROM ips WHERE feed=?", (feed,))
            self.conn.executemany("INSERT OR REPLACE INTO ips VALUES(?,?,?)",
                                  [(ip, feed, ts) for ip in ips])
            self.conn.execute("COMMIT")
        except Exception:
            try:
                self.conn.execute("ROLLBACK")
            except Exception:
                pass
