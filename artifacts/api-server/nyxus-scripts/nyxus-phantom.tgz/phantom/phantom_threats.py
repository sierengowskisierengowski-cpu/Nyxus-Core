"""
NYXUS Phantom — local threat-intelligence cache + daily refresher.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Maintains a local sqlite database of:
  • known malicious IPs (abuse.ch + emerging-threats + blocklist.de)
  • Tor exit nodes
  • C2 server IPs (Feodo Tracker, SSL Blacklist, URLhaus)

Lookups are O(log n) sqlite indexed. NEVER calls out during monitoring;
the daily refresher is the only network egress this module performs.
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path
from typing import Iterable

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class ThreatIntel:
    SCHEMA = """
        CREATE TABLE IF NOT EXISTS ips (
            ip TEXT PRIMARY KEY, feed TEXT NOT NULL, ts REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_feed ON ips(feed);
    """

    def __init__(self, root: Path, cfg: dict):
        self.cfg = cfg
        self.db_path = root / "threats.db"
        self.last_refresh = 0.0
        self._init_db()

    def _init_db(self) -> None:
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False,
                                    isolation_level=None)
        self.conn.executescript(self.SCHEMA)

    # ------------------------------------------------------------------ #
    # public lookup — used in hot path, NEVER touches network             #
    # ------------------------------------------------------------------ #
    def lookup_ip(self, ip: str) -> str | None:
        """Return feed name if `ip` is on any blocklist, else None."""
        try:
            row = self.conn.execute("SELECT feed FROM ips WHERE ip=?", (ip,)).fetchone()
            return row[0] if row else None
        except Exception:
            return None

    def stats(self) -> dict[str, int]:
        try:
            cur = self.conn.execute("SELECT feed, COUNT(*) FROM ips GROUP BY feed")
            return {r[0]: r[1] for r in cur.fetchall()}
        except Exception:
            return {}

    # ------------------------------------------------------------------ #
    # background refresher                                                #
    # ------------------------------------------------------------------ #
    def daily_refresh_loop(self, stop) -> None:
        # initial refresh after 60s of uptime so we don't slam network at boot
        if not stop.wait(60):
            self._refresh_all()
        while not stop.wait(86400):  # 24h
            self._refresh_all()

    def _refresh_all(self) -> None:
        feeds = self.cfg.get("threat_feeds", {})
        try:
            import requests
        except ImportError:
            return
        added = 0
        for name, url in feeds.items():
            try:
                r = requests.get(url, timeout=15,
                                 headers={"User-Agent": "nyxus-phantom/1.0"})
                if r.status_code != 200:
                    continue
                ips = list(self._extract_ips(r.text))
                self._upsert(name, ips)
                added += len(ips)
            except Exception:
                continue
        self.last_refresh = time.time()
        try:
            (self.db_path.parent / "threats_lastrefresh.txt").write_text(
                f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}  +{added}"
            )
        except Exception:
            pass

    def _extract_ips(self, text: str) -> Iterable[str]:
        import re
        # support plain IP-per-line OR CSV (Feodo) — first IPv4-looking column wins
        rx = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        seen: set[str] = set()
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = rx.search(line)
            if not m:
                continue
            ip = m.group(0)
            if ip in seen:
                continue
            seen.add(ip)
            yield ip

    def _upsert(self, feed: str, ips: list[str]) -> None:
        ts = time.time()
        try:
            self.conn.execute("BEGIN")
            self.conn.execute("DELETE FROM ips WHERE feed=?", (feed,))
            self.conn.executemany("INSERT OR REPLACE INTO ips VALUES(?,?,?)",
                                  [(ip, feed, ts) for ip in ips])
            self.conn.execute("COMMIT")
        except Exception:
            try:
                self.conn.execute("ROLLBACK")
            except Exception:
                pass
