# NYXUS Phantom

> Silent background security daemon for NyX.x.OS.
> © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Phantom is the always-on, invisible layer that watches every critical
sub-system on the MSI Stealth GS77 and reacts before you notice
anything is wrong. There is **no UI**. Phantom only surfaces when
something is wrong — via desktop notifications, MQTT events, and
forensic bundles dropped on disk.

It runs:

- as a **systemd Type=notify** service with a 10-second watchdog
- as its own non-login user `nyxus-phantom` with minimal capabilities
- at **nice 19, ionice idle, CPUQuota=10%** — invisible footprint
- with `protect-system=strict` plus an explicit polkit rule so that
  stopping it requires root **and** a YubiKey-backed sudo prompt

## What Phantom watches

| subsystem      | source                              | notes                           |
| -------------- | ----------------------------------- | ------------------------------- |
| files          | inotify + sha256 baseline           | RED on critical path mismatch   |
| processes      | psutil baseline + scrutiny          | masquerade + reverse-shell + miner detection |
| network        | psutil sockets + threat IP DB       | RED on known-malicious IP       |
| USB            | sysfs poll                          | HID-anomaly RED, YubiKey watch  |
| kernel modules | /proc/modules + /etc/ld.so.preload  | ORANGE on unexpected load       |
| auth           | tail of auth.log + journalctl       | brute-force ban + root-login RED|
| memory         | /proc/*/maps                        | rwx anon mapping detection      |

## Severity ladder

```
WHITE  silent log only
BLUE   logged · counted in daily report
YELLOW desktop notification + log
ORANGE automatic defensive action + notification + log
RED    full lockdown + forensic bundle + critical notification
```

## Files installed

```
/opt/nyxus-phantom/                phantom.py + 4 modules
/etc/nyxus-phantom/config.json     defaults
/etc/systemd/system/nyxus-phantom.service
/var/lib/nyxus-phantom/.nyxus/phantom/
        events.db        — every event Phantom has ever seen
        baseline.db      — sha256 hash baseline for monitored paths
        threats.db       — local copy of threat-intel feeds
        forensics/       — RED-event GPG-sealed bundles
        reports/         — daily JSON summaries
        logs/            — append-only hash-chained log files
        spool/           — pickup queue for the Shield app
```

## Install

```bash
sudo bash install.sh
```

This will:

1. install system packages (`tcpdump`, `lsof`, `ufw`, `libnotify`, `gnupg`)
2. create the `nyxus-phantom` system user
3. copy daemon files to `/opt/nyxus-phantom/`
4. install the systemd unit + polkit rule
5. enable and start the service

## After install

```bash
systemctl status nyxus-phantom         # health
journalctl -fu nyxus-phantom           # live log
sqlite3 ~/.nyxus/phantom/events.db \
        'SELECT ts,severity,module,message FROM events ORDER BY id DESC LIMIT 30'
```

## Integration

- **MQTT** — every event published to `nyxus/phantom/<module>` (topic configurable).
- **Loki** — RED events shipped to the local Loki instance for Grafana.
- **Shield app** — reads `events.db` for friendly dashboard view.
- **GodsApp** — queries Phantom's history when the operator opens the
  forensics module.

## Stopping Phantom

By design Phantom resists casual stops:

```bash
sudo systemctl stop nyxus-phantom    # will trigger polkit YubiKey prompt
```

Without a YubiKey present the prompt fails closed.

## Tuning

Edit `/etc/nyxus-phantom/config.json` then:

```bash
sudo systemctl restart nyxus-phantom
```

The most useful keys to tune:

- `process_baseline_hours` — how long Phantom learns "normal" before alerting
- `network_baseline_hours` — same for outbound connections
- `whitelist.{processes,ips,usb,modules}` — known-good entries
- `threat_feeds.*` — URLs of threat-intel lists to mirror locally

## Architecture

```
                 ┌──────────────┐
                 │ phantom.py   │  systemd Type=notify, sd_notify watchdog
                 └──────┬───────┘
       ┌─────────┬─────┼──────┬──────────┬──────────┐
       │         │     │      │          │          │
   ┌───▼──┐ ┌────▼─┐ ┌─▼──┐ ┌─▼──┐ ┌────▼────┐ ┌───▼───┐
   │ FILE │ │ PROC │ │NET │ │USB │ │ KERNEL  │ │ AUTH  │
   └───┬──┘ └────┬─┘ └─┬──┘ └─┬──┘ └────┬────┘ └───┬───┘
       │         │     │      │         │          │
       └────────┬┴─────┴──────┴─────────┴──────────┘
                │
        ┌───────▼─────────┐
        │ Responder       │  ── notify-send
        │ + Threat lookup │  ── ufw block / lockdown
        │ + Forensics     │  ── tcpdump · journal · /proc dump · GPG seal
        └─────────────────┘
                │
        ┌───────▼─────────┐
        │ events.db       │
        │ MQTT publish    │
        │ Loki ship       │
        │ daily reports   │
        └─────────────────┘
```
