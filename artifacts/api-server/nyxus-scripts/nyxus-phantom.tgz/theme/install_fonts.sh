#!/usr/bin/env bash
# ============================================================================
# NYXUS handwritten font installer — Inter + Inter + JetBrains Mono
# Drops TTF files into ~/.local/share/fonts and refreshes the font cache.
# Safe to run multiple times.
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================================================
set -euo pipefail

FONT_DIR="${HOME}/.local/share/fonts/nyxus"
mkdir -p "${FONT_DIR}"

fetch() {
  local name="$1" url="$2" out="${FONT_DIR}/$3"
  if [[ -s "${out}" ]]; then
    echo "[fonts] ${name} already present → ${out}"
    return 0
  fi
  echo "[fonts] downloading ${name} …"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "${url}" -o "${out}"
  elif command -v wget >/dev/null 2>&1; then
    wget -q "${url}" -O "${out}"
  else
    echo "[fonts] ERROR: need curl or wget" >&2
    exit 1
  fi
}

# Google Fonts mirror (raw GitHub release of the Google Fonts repo)
GF_BASE="https://github.com/google/fonts/raw/main/ofl"

fetch "Inter-Regular"          "${GF_BASE}/caveat/Inter%5Bwght%5D.ttf"            "Inter-Regular.ttf"
fetch "Inter-Regular"     "${GF_BASE}/patrickhand/Inter-Regular.ttf"    "Inter-Regular.ttf"

# JetBrains Mono is shipped on most distros, but install a private copy too
JBM_BASE="https://github.com/JetBrains/JetBrainsMono/raw/master/fonts/ttf"
fetch "JetBrainsMono-Regular"   "${JBM_BASE}/JetBrainsMono-Regular.ttf"             "JetBrainsMono-Regular.ttf"
fetch "JetBrainsMono-Bold"      "${JBM_BASE}/JetBrainsMono-Bold.ttf"                "JetBrainsMono-Bold.ttf"

if command -v fc-cache >/dev/null 2>&1; then
  echo "[fonts] refreshing font cache …"
  fc-cache -f "${FONT_DIR}" >/dev/null 2>&1 || true
fi

echo "[fonts] done — fonts live in ${FONT_DIR}"
