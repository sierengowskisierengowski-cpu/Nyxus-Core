"""
NYXUS shared theme helper for GTK4 apps (Shield + GodsApp).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Provides:
  • COLORS  — hex strings for the NyX palette (DARK MIRROR monochrome)
  • SEV     — severity tokens with color + label
  • apply_theme(display)   — install global CSS provider for a Gdk.Display
  • make_badge(severity, text) — Gtk.Label preconfigured as a badge
  • header(text, level=1)  — Gtk.Label as h1/h2/h3
  • card(child, *, active=False) — Gtk.Frame with .nyx-card class

Usage:
    from nyxus_theme import apply_theme, COLORS, make_badge

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────

    apply_theme(Gdk.Display.get_default())
"""
from __future__ import annotations

import os
from pathlib import Path

# fmt: off
COLORS = {
    "bg_deep":       "#0a0a0a",
    "bg":            "#0a0a0a",
    "bg_card":       "#0f1420",
    "bg_card_hover": "#0f1420",
    "bg_input":      "#0a0a0a",
    "purple":        "#6a6e78",
    "purple_dim":    "#3a3e4a",
    "purple_deep":   "#0f1420",
    "pink":          "#6a6e78",
    "pink_neon":     "#6a6e78",
    "gold":          "#e8edf5",
    "gold_dim":      "#9aa0ad",
    "text":          "#e8edf5",
    "text_dim":      "#9aa0ad",
    "text_faint":    "#6a6e78",
    "safe":          "#c8ccd6",
    "info":          "#c8ccd6",
    "warn":          "#9aa0ad",
    "high":          "#9aa0ad",
    "crit":          "#6a6e78",
}
# fmt: on

SEV = {
    "WHITE":  {"label": "INFO",  "css": "nyx-badge-info"},
    "BLUE":   {"label": "INFO",  "css": "nyx-badge-info"},
    "YELLOW": {"label": "WARN",  "css": "nyx-badge-warn"},
    "ORANGE": {"label": "HIGH",  "css": "nyx-badge-high"},
    "RED":    {"label": "CRIT",  "css": "nyx-badge-crit"},
    "GREEN":  {"label": "SAFE",  "css": "nyx-badge-safe"},
    "SAFE":   {"label": "SAFE",  "css": "nyx-badge-safe"},
    "INFO":   {"label": "INFO",  "css": "nyx-badge-info"},
    "WARN":   {"label": "WARN",  "css": "nyx-badge-warn"},
    "HIGH":   {"label": "HIGH",  "css": "nyx-badge-high"},
    "CRIT":   {"label": "CRIT",  "css": "nyx-badge-crit"},
}


def find_css() -> str:
    """Locate nyxus_theme.css next to this file or in known install paths."""
    here = Path(__file__).resolve().parent
    for cand in (
        here / "nyxus_theme.css",
        Path("/usr/share/nyxus/theme/nyxus_theme.css"),
        Path.home() / ".local/share/nyxus/theme/nyxus_theme.css",
        Path("/etc/nyxus/theme/nyxus_theme.css"),
    ):
        if cand.is_file():
            return str(cand)
    raise FileNotFoundError("nyxus_theme.css not found in any known location")


def apply_theme(display=None) -> None:
    """Install the NYXUS GTK CSS provider globally for the given display."""
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gdk, Gtk  # noqa: WPS433

    if display is None:
        display = Gdk.Display.get_default()

    css_path = find_css()
    provider = Gtk.CssProvider()
    try:
        provider.load_from_path(css_path)
    except Exception as exc:  # pragma: no cover - best effort, never crash app
        print(f"[nyxus_theme] WARN: could not load {css_path}: {exc}")
        return
    Gtk.StyleContext.add_provider_for_display(
        display, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

    # Set dark scheme preference (GTK4 picks darker variants when available).
    try:
        settings = Gtk.Settings.get_default()
        if settings is not None:
            settings.set_property("gtk-application-prefer-dark-theme", True)
    except Exception:
        pass


def make_badge(severity: str, text: str | None = None):
    """Create a Gtk.Label styled as a NyX severity badge."""
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk  # noqa: WPS433

    info = SEV.get(severity.upper(), SEV["INFO"])
    label = Gtk.Label(label=text or info["label"])
    ctx = label.get_style_context()
    ctx.add_class("nyx-badge")
    ctx.add_class(info["css"])
    return label


def header(text: str, level: int = 1):
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk  # noqa: WPS433

    label = Gtk.Label(label=text, xalign=0)
    label.get_style_context().add_class(f"nyx-h{max(1, min(3, level))}")
    return label


def card(child, *, active: bool = False):
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk  # noqa: WPS433

    frame = Gtk.Frame()
    frame.set_child(child)
    ctx = frame.get_style_context()
    ctx.add_class("nyx-card")
    if active:
        ctx.add_class("nyx-card-active")
    return frame


def banner_text(title: str) -> str:
    """Plain-text NyX banner block (handy for terminals / log headers)."""
    bar = "═" * (len(title) + 8)
    return f"╔{bar}╗\n║    {title}    ║\n╚{bar}╝\n"
