"""
NYXUS shared theme helper for GTK4 apps (Shield + GodsApp).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Provides:
  • COLORS  — hex strings for the NyX palette (purple/pink/gold)
  • SEV     — severity tokens with color + label
  • apply_theme(display)   — install global CSS provider for a Gdk.Display
  • make_badge(severity, text) — Gtk.Label preconfigured as a badge
  • header(text, level=1)  — Gtk.Label as h1/h2/h3
  • card(child, *, active=False) — Gtk.Frame with .nyx-card class

Usage:
    from nyxus_theme import apply_theme, COLORS, make_badge
    apply_theme(Gdk.Display.get_default())
"""
from __future__ import annotations

import os
from pathlib import Path

# fmt: off
COLORS = {
    "bg_deep":       "#0a0407",
    "bg":            "#0d0608",
    "bg_card":       "#14091a",
    "bg_card_hover": "#1c0e22",
    "bg_input":      "#0e0710",
    "purple":        "#7B5EA7",
    "purple_dim":    "#4a3066",
    "purple_deep":   "#2D0050",
    "pink":          "#C4607A",
    "pink_neon":     "#FF3EA5",
    "gold":          "#e8edf5",
    "gold_dim":      "#A88800",
    "text":          "#F0E0F0",
    "text_dim":      "#A090A0",
    "text_faint":    "#6a5a6a",
    "safe":          "#50FFA0",
    "info":          "#6EC5FF",
    "warn":          "#FFA040",
    "high":          "#FF7050",
    "crit":          "#FF3E50",
}
# fmt: on

SEV = {
    "WHITE":  {"label": "INFO",  "css": "nyx-badge-info"},
    "BLUE":   {"label": "INFO",  "css": "nyx-badge-info"},
    "YELLOW": {"label": "WARN",  "css": "nyx-badge-warn"},
    "ORANGE": {"label": "HIGH",  "css": "nyx-badge-high"},
    "RED":    {"label": "CRIT",  "css": "nyx-badge-crit"},
    "GREEN":  {"label": "SAFE",  "css": "nyx-badge-safe"},
    "SAFE":   {"label": "SAFE",  "css": "nyx-badge-safe"},
    "INFO":   {"label": "INFO",  "css": "nyx-badge-info"},
    "WARN":   {"label": "WARN",  "css": "nyx-badge-warn"},
    "HIGH":   {"label": "HIGH",  "css": "nyx-badge-high"},
    "CRIT":   {"label": "CRIT",  "css": "nyx-badge-crit"},
}


def find_css() -> str:
    """Locate nyxus_theme.css next to this file or in known install paths."""
    here = Path(__file__).resolve().parent
    for cand in (
        here / "nyxus_theme.css",
        Path("/usr/share/nyxus/theme/nyxus_theme.css"),
        Path.home() / ".local/share/nyxus/theme/nyxus_theme.css",
        Path("/etc/nyxus/theme/nyxus_theme.css"),
    ):
        if cand.is_file():
            return str(cand)
    raise FileNotFoundError("nyxus_theme.css not found in any known location")


def apply_theme(display=None) -> None:
    """Install the NYXUS GTK CSS provider globally for the given display."""
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gdk, Gtk  # noqa: WPS433

    if display is None:
        display = Gdk.Display.get_default()

    css_path = find_css()
    provider = Gtk.CssProvider()
    try:
        provider.load_from_path(css_path)
    except Exception as exc:  # pragma: no cover - best effort, never crash app
        print(f"[nyxus_theme] WARN: could not load {css_path}: {exc}")
        return
    Gtk.StyleContext.add_provider_for_display(
        display, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

    # Set dark scheme preference (GTK4 picks darker variants when available).
    try:
        settings = Gtk.Settings.get_default()
        if settings is not None:
            settings.set_property("gtk-application-prefer-dark-theme", True)
    except Exception:
        pass


def make_badge(severity: str, text: str | None = None):
    """Create a Gtk.Label styled as a NyX severity badge."""
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk  # noqa: WPS433

    info = SEV.get(severity.upper(), SEV["INFO"])
    label = Gtk.Label(label=text or info["label"])
    ctx = label.get_style_context()
    ctx.add_class("nyx-badge")
    ctx.add_class(info["css"])
    return label


def header(text: str, level: int = 1):
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk  # noqa: WPS433

    label = Gtk.Label(label=text, xalign=0)
    label.get_style_context().add_class(f"nyx-h{max(1, min(3, level))}")
    return label


def card(child, *, active: bool = False):
    import gi

    gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk  # noqa: WPS433

    frame = Gtk.Frame()
    frame.set_child(child)
    ctx = frame.get_style_context()
    ctx.add_class("nyx-card")
    if active:
        ctx.add_class("nyx-card-active")
    return frame


def banner_text(title: str) -> str:
    """Plain-text NyX banner block (handy for terminals / log headers)."""
    bar = "═" * (len(title) + 8)
    return f"╔{bar}╗\n║    {title}    ║\n╚{bar}╝\n"
