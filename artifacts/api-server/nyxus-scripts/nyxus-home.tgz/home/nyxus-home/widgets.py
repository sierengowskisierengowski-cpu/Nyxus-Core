# ============================================
# NYXUS Home — widget builders
# © 2026 Joseph Sierengowski
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
Each builder returns a Gtk.Box (the card) that's added to the dashboard
grid. All cards share the same skeleton: header (glyph + title + license
tag) + body + optional footer with a `card-<name>` CSS class for theming.
"""

import datetime
import json
import threading
from urllib.parse import urlencode
from urllib.request import urlopen, Request

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib

from style import HEX
from storage import (
    load_config, save_config,
    load_notepad, save_notepad,
    load_dismissed_notifs, save_dismissed_notifs,
    PasswordStore, generate_password,
)

LICENSE_TAG = "NYX-J5W-2026"


# ── card skeleton ───────────────────────────────────────────────────────
def card_shell(name: str, title: str, glyph: str, footer_text: str = "") -> Gtk.Box:
    """Returns (card, body_box, footer_label) — caller appends to body_box."""
    card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    card.add_css_class(f"card-{name}")
    card.add_css_class("home-card")
    card.set_hexpand(True)
    card.set_vexpand(False)

    # header row: glyph | title | license tag
    header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    g = Gtk.Label(label=glyph)
    g.add_css_class(f"card-{name}-glyph")
    g.set_xalign(0)
    t = Gtk.Label(label=title)
    t.add_css_class(f"card-{name}-title")
    t.set_xalign(0)
    spacer = Gtk.Box()
    spacer.set_hexpand(True)
    tag = Gtk.Label(label=LICENSE_TAG)
    tag.add_css_class(f"card-{name}-footer")
    tag.set_xalign(1)
    header.append(g)
    header.append(t)
    header.append(spacer)
    header.append(tag)
    card.append(header)

    # divider
    sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
    sep.set_opacity(0.2)
    card.append(sep)

    # body
    body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    body.set_vexpand(True)
    card.append(body)

    # footer
    footer = Gtk.Label(label=footer_text)
    footer.add_css_class(f"card-{name}-footer")
    footer.set_xalign(0)
    footer.set_wrap(True)
    if footer_text:
        sep2 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        sep2.set_opacity(0.15)
        card.append(sep2)
        card.append(footer)

    card.body = body              # type: ignore[attr-defined]
    card.footer_label = footer    # type: ignore[attr-defined]
    return card


# ── CLOCK ───────────────────────────────────────────────────────────────
def build_clock_card() -> Gtk.Box:
    import time as _time
    tz = _time.tzname[0] if _time.tzname else "LOCAL"
    card = card_shell("clock", "Clock", "◴", f"SYSTEM TIME · {tz}")

    time_lbl = Gtk.Label(label="--:--")
    time_lbl.add_css_class("clock-time")
    time_lbl.set_xalign(0.5)

    day_lbl = Gtk.Label(label="--")
    day_lbl.add_css_class("clock-day")
    day_lbl.set_xalign(0.5)

    date_lbl = Gtk.Label(label="--")
    date_lbl.add_css_class("clock-date")
    date_lbl.set_xalign(0.5)

    card.body.append(time_lbl)
    card.body.append(day_lbl)
    card.body.append(date_lbl)

    def tick():
        now = datetime.datetime.now()
        sep = ":" if now.second % 2 == 0 else " "
        time_lbl.set_markup(
            f'<span font_family="JetBrains Mono" weight="bold" size="44000">'
            f'{now.hour:02d}<span foreground="{HEX["pink"]}">{sep}</span>{now.minute:02d}'
            f'</span>'
            f'<span foreground="{HEX["dim"]}" size="18000">  {now.second:02d}</span>'
        )
        day_lbl.set_label(now.strftime("%A"))
        date_lbl.set_label(now.strftime("%B %-d, %Y").upper())
        return True

    tick()
    GLib.timeout_add_seconds(1, tick)
    return card


# ── WEATHER ─────────────────────────────────────────────────────────────
WMO = {
    0: ("Clear", "☀"), 1: ("Mainly Clear", "☀"), 2: ("Partly Cloudy", "◐"),
    3: ("Overcast", "☁"),
    45: ("Fog", "≋"), 48: ("Rime Fog", "≋"),
    51: ("Light Drizzle", "☂"), 53: ("Drizzle", "☂"), 55: ("Heavy Drizzle", "☂"),
    61: ("Light Rain", "☂"), 63: ("Rain", "☂"), 65: ("Heavy Rain", "☂"),
    71: ("Light Snow", "❄"), 73: ("Snow", "❄"), 75: ("Heavy Snow", "❄"),
    77: ("Snow Grains", "❄"),
    80: ("Showers", "☂"), 81: ("Heavy Showers", "☂"), 82: ("Violent Showers", "☂"),
    85: ("Snow Showers", "❄"), 86: ("Heavy Snow Show", "❄"),
    95: ("Thunderstorm", "⚡"), 96: ("Storm + Hail", "⚡"), 99: ("Storm + Hail", "⚡"),
}


def build_weather_card() -> Gtk.Box:
    card = card_shell("weather", "Weather", "☼", "OPEN-METEO · LIVE · NO AUTH")
    cfg = load_config()
    loc = cfg["weather"]

    top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    glyph_lbl = Gtk.Label(label="◯")
    glyph_lbl.add_css_class("weather-glyph")
    info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
    temp_lbl = Gtk.Label(label="—")
    temp_lbl.add_css_class("weather-temp")
    temp_lbl.set_xalign(0)
    cond_lbl = Gtk.Label(label="loading…")
    cond_lbl.add_css_class("weather-cond")
    cond_lbl.set_xalign(0)
    info.append(temp_lbl)
    info.append(cond_lbl)
    top.append(glyph_lbl)
    top.append(info)
    card.body.append(top)

    meta_lbl = Gtk.Label(label="")
    meta_lbl.add_css_class("weather-meta")
    meta_lbl.set_xalign(0)
    card.body.append(meta_lbl)

    loc_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
    loc_lbl = Gtk.Label(label=loc["label"])
    loc_lbl.add_css_class("clock-day")
    loc_lbl.set_xalign(0)
    loc_lbl.set_hexpand(True)
    edit_btn = Gtk.Button(label="EDIT")
    edit_btn.add_css_class("nyxus-btn")
    loc_row.append(loc_lbl)
    loc_row.append(edit_btn)
    card.body.append(loc_row)

    # editor (collapsed by default)
    editor = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
    editor.set_visible(False)
    label_entry = Gtk.Entry()
    label_entry.add_css_class("nyxus-input")
    label_entry.set_text(loc["label"])
    label_entry.set_placeholder_text("Label")
    coords = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
    lat_entry = Gtk.Entry()
    lat_entry.add_css_class("nyxus-input")
    lat_entry.set_text(str(loc["lat"]))
    lat_entry.set_placeholder_text("Lat")
    lat_entry.set_hexpand(True)
    lon_entry = Gtk.Entry()
    lon_entry.add_css_class("nyxus-input")
    lon_entry.set_text(str(loc["lon"]))
    lon_entry.set_placeholder_text("Lon")
    lon_entry.set_hexpand(True)
    coords.append(lat_entry)
    coords.append(lon_entry)
    save_btn = Gtk.Button(label="SAVE LOCATION")
    save_btn.add_css_class("nyxus-btn-primary")
    editor.append(label_entry)
    editor.append(coords)
    editor.append(save_btn)
    card.body.append(editor)

    state = {"lat": loc["lat"], "lon": loc["lon"]}

    def fetch_async():
        url = ("https://api.open-meteo.com/v1/forecast?"
               + urlencode({
                   "latitude":            state["lat"],
                   "longitude":           state["lon"],
                   "current":             "temperature_2m,weather_code,wind_speed_10m",
                   "temperature_unit":    "fahrenheit",
                   "wind_speed_unit":     "mph",
                   "daily":               "temperature_2m_max,temperature_2m_min",
                   "timezone":            "auto",
                   "forecast_days":       1,
               }))

        def worker():
            try:
                req = Request(url, headers={"User-Agent": "nyxus-home/1.0"})
                with urlopen(req, timeout=10) as r:
                    data = json.loads(r.read().decode("utf-8"))
                GLib.idle_add(apply_data, data)
            except Exception as e:
                GLib.idle_add(apply_error, str(e))

        threading.Thread(target=worker, daemon=True).start()

    def apply_data(data):
        cur  = data.get("current", {})
        code = cur.get("weather_code", 0)
        label, glyph = WMO.get(code, ("Unknown", "◯"))
        temp = cur.get("temperature_2m")
        wind = cur.get("wind_speed_10m")
        glyph_lbl.set_label(glyph)
        if isinstance(temp, (int, float)):
            temp_lbl.set_markup(
                f'<span weight="bold" font_family="JetBrains Mono" size="36000">{round(temp)}</span>'
                f'<span foreground="{HEX["dim"]}" size="14000">°F</span>'
            )
        cond_lbl.set_label(label)
        daily = data.get("daily", {})
        hi = daily.get("temperature_2m_max", [None])[0]
        lo = daily.get("temperature_2m_min", [None])[0]
        meta_lbl.set_label(
            f"↑ {round(hi)}°    ↓ {round(lo)}°    WIND {round(wind)} MPH"
            if hi is not None and lo is not None and wind is not None
            else f"WIND {round(wind) if wind is not None else '—'} MPH"
        )
        return False

    def apply_error(msg):
        cond_lbl.set_label("offline")
        meta_lbl.set_label(f"open-meteo: {msg[:60]}")
        return False

    def on_edit_clicked(_btn):
        editor.set_visible(not editor.get_visible())

    def on_save_clicked(_btn):
        try:
            new_lat = float(lat_entry.get_text().strip())
            new_lon = float(lon_entry.get_text().strip())
        except ValueError:
            return
        new_label = label_entry.get_text().strip() or f"{new_lat:.2f}, {new_lon:.2f}"
        state["lat"] = new_lat
        state["lon"] = new_lon
        loc_lbl.set_label(new_label)
        cfg2 = load_config()
        cfg2["weather"] = {"lat": new_lat, "lon": new_lon, "label": new_label,
                           "unit": cfg2["weather"].get("unit", "fahrenheit")}
        save_config(cfg2)
        editor.set_visible(False)
        cond_lbl.set_label("loading…")
        fetch_async()

    edit_btn.connect("clicked", on_edit_clicked)
    save_btn.connect("clicked", on_save_clicked)

    fetch_async()
    GLib.timeout_add_seconds(15 * 60, lambda: (fetch_async() or True))
    return card


# ── CALENDAR ────────────────────────────────────────────────────────────
def build_calendar_card() -> Gtk.Box:
    card = card_shell("calendar", "Calendar", "▦", "LOCAL · GREGORIAN")
    cal = Gtk.Calendar()
    cal.set_show_heading(True)
    cal.set_show_day_names(True)
    cal.set_show_week_numbers(False)
    today = datetime.date.today()
    try:
        cal.select_day(GLib.DateTime.new_local(today.year, today.month, today.day, 0, 0, 0))
    except Exception:
        pass
    card.body.append(cal)

    today_btn = Gtk.Button(label="◉ TODAY")
    today_btn.add_css_class("nyxus-btn")
    today_btn.set_halign(Gtk.Align.START)

    def go_today(_b):
        d = datetime.date.today()
        try:
            cal.select_day(GLib.DateTime.new_local(d.year, d.month, d.day, 0, 0, 0))
        except Exception:
            pass

    today_btn.connect("clicked", go_today)
    card.body.append(today_btn)
    return card


# ── NOTIFICATIONS ───────────────────────────────────────────────────────
SEED_NOTIFS = [
    ("intel",    "◉", HEX["purple"], "INTEL",     "Investigation auto-saved (3 findings).",                "2m"),
    ("shield",   "⛨", HEX["green"],  "Shield",    "Local scan complete — 0 open ports outside policy.",    "8m"),
    ("phantom",  "◈", HEX["blue"],   "Phantom",   "Daemon armed. 0 threats since boot.",                   "14m"),
    ("godsapp",  "✦", HEX["gold"],   "GodsApp",   "WiFi audit module ready.",                              "22m"),
    ("notepad",  "✑", HEX["purple"], "Notepad",   "5 notes synced to ~/.nyxus/notepad.json.",              "1h"),
    ("sysmon",   "◧", HEX["cyan"],   "SysMon",    "CPU steady at 15% · RAM 56% · Temp 84°C.",              "2h"),
]


def build_notifications_card() -> Gtk.Box:
    card = card_shell("notif", "Notifications", "✉", "0 ACTIVE · LIVE FEED")
    list_box = Gtk.ListBox()
    list_box.set_selection_mode(Gtk.SelectionMode.NONE)
    list_box.add_css_class("home-list")
    scroll = Gtk.ScrolledWindow()
    scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    scroll.set_min_content_height(220)
    scroll.set_child(list_box)
    card.body.append(scroll)

    reload_btn = Gtk.Button(label="↺ RELOAD FEED")
    reload_btn.add_css_class("nyxus-btn")
    reload_btn.set_halign(Gtk.Align.START)
    card.body.append(reload_btn)

    def render():
        # clear
        while True:
            row = list_box.get_first_child()
            if row is None:
                break
            list_box.remove(row)
        dismissed = set(load_dismissed_notifs())
        active = [n for n in SEED_NOTIFS if n[0] not in dismissed]
        for nid, glyph, color, title, body, when in active:
            row = Gtk.ListBoxRow()
            row.set_selectable(False)
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            box.add_css_class("notif-row")
            g = Gtk.Label(label=glyph)
            g.set_markup(f'<span foreground="{color}" size="14000">{glyph}</span>')
            g.set_valign(Gtk.Align.START)
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
            inner.set_hexpand(True)
            row1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            t = Gtk.Label(label=title)
            t.set_markup(f'<span foreground="{color}" font_family="Caveat" size="14000">{title}</span>')
            t.set_xalign(0)
            t.set_hexpand(True)
            tt = Gtk.Label(label=when)
            tt.add_css_class("notif-time")
            tt.set_xalign(1)
            row1.append(t)
            row1.append(tt)
            b = Gtk.Label(label=body)
            b.add_css_class("notif-body")
            b.set_xalign(0)
            b.set_wrap(True)
            inner.append(row1)
            inner.append(b)
            x = Gtk.Button(label="✕")
            x.add_css_class("nyxus-btn")
            x.set_valign(Gtk.Align.START)

            def make_dismiss(_id):
                def cb(_btn):
                    d = load_dismissed_notifs()
                    if _id not in d:
                        d.append(_id)
                        save_dismissed_notifs(d)
                    render()
                    update_footer()
                return cb

            x.connect("clicked", make_dismiss(nid))
            box.append(g)
            box.append(inner)
            box.append(x)
            row.set_child(box)
            list_box.append(row)
        if not active:
            placeholder = Gtk.ListBoxRow()
            placeholder.set_selectable(False)
            empty = Gtk.Label(label="inbox zero — all clear")
            empty.set_markup(
                f'<span foreground="{HEX["dim"]}" font_family="Caveat" size="16000">inbox zero — all clear</span>'
            )
            placeholder.set_child(empty)
            list_box.append(placeholder)

    def update_footer():
        active = len([n for n in SEED_NOTIFS if n[0] not in set(load_dismissed_notifs())])
        card.footer_label.set_label(f"{active} ACTIVE · LIVE FEED")

    def on_reload(_b):
        save_dismissed_notifs([])
        render()
        update_footer()

    reload_btn.connect("clicked", on_reload)
    render()
    update_footer()
    return card


# ── NOTEPAD ─────────────────────────────────────────────────────────────
def build_notepad_card() -> Gtk.Box:
    card = card_shell("notepad", "Notepad", "✑", "AUTOSAVE · 0 CHARS · 0 WORDS")
    buf = Gtk.TextBuffer()
    buf.set_text(load_notepad())
    view = Gtk.TextView.new_with_buffer(buf)
    view.add_css_class("notepad-view")
    view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
    view.set_top_margin(8)
    view.set_bottom_margin(8)
    view.set_left_margin(10)
    view.set_right_margin(10)

    scroll = Gtk.ScrolledWindow()
    scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    scroll.set_min_content_height(180)
    scroll.set_vexpand(True)
    scroll.set_child(view)
    card.body.append(scroll)

    btn_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    clear_btn = Gtk.Button(label="✕ CLEAR")
    clear_btn.add_css_class("nyxus-btn")
    copy_btn = Gtk.Button(label="▤ COPY ALL")
    copy_btn.add_css_class("nyxus-btn")
    btn_row.append(clear_btn)
    btn_row.append(copy_btn)
    card.body.append(btn_row)

    state = {"timer": 0, "saved_at": 0}

    def schedule_save():
        if state["timer"]:
            try:
                GLib.source_remove(state["timer"])
            except Exception:
                pass

        def fire():
            text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)
            try:
                save_notepad(text)
                import time as _t
                state["saved_at"] = _t.time()
                update_footer()
            except Exception:
                pass
            state["timer"] = 0
            return False

        state["timer"] = GLib.timeout_add(350, fire)

    def update_footer():
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)
        chars = len(text)
        words = len(text.split()) if text.strip() else 0
        if state["saved_at"]:
            import time as _t
            ago = max(0, int(_t.time() - state["saved_at"]))
            card.footer_label.set_label(
                f"AUTOSAVE · ~/.local/share/nyxus-home/notepad.txt · "
                f"{chars} CHARS · {words} WORDS · SAVED {ago}S AGO"
            )
        else:
            card.footer_label.set_label(
                f"AUTOSAVE · {chars} CHARS · {words} WORDS"
            )

    def on_changed(_buf):
        schedule_save()
        update_footer()

    def on_clear(_b):
        buf.set_text("")

    def on_copy(_b):
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)
        clip = Gdk.Display.get_default().get_clipboard()
        clip.set(text)

    buf.connect("changed", on_changed)
    clear_btn.connect("clicked", on_clear)
    copy_btn.connect("clicked", on_copy)
    update_footer()
    return card


# ── PASSWORD MANAGER ────────────────────────────────────────────────────
def build_password_card() -> Gtk.Box:
    store = PasswordStore()
    card = card_shell(
        "pw", "Password Manager", "⚿",
        f"{len(store.list_entries())} ENTRIES · {store.backend_status}"
    )

    # ── generator section
    gen_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
    gen_box.add_css_class("pw-section")
    gen_label = Gtk.Label(label="Generator")
    gen_label.set_xalign(0)
    gen_label.set_markup(f'<span foreground="{HEX["orange"]}" font_family="Caveat" size="14000">Generator</span>')
    gen_box.append(gen_label)

    len_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    len_lbl = Gtk.Label(label="length 18")
    len_lbl.set_markup(f'<span foreground="{HEX["dim"]}" font_family="JetBrains Mono" size="9000">LENGTH 18</span>')
    len_lbl.set_xalign(0)
    len_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 8, 64, 1)
    len_scale.set_value(18)
    len_scale.set_hexpand(True)
    len_scale.set_draw_value(False)
    len_row.append(len_lbl)
    len_row.append(len_scale)
    gen_box.append(len_row)

    flags = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    flag_widgets = {}
    for key, label in (("upper", "UPPER"), ("lower", "LOWER"), ("num", "NUM"), ("sym", "SYM")):
        cb = Gtk.CheckButton(label=label)
        cb.set_active(True)
        cb.add_css_class("home-checkbox")
        flag_widgets[key] = cb
        flags.append(cb)
    gen_box.append(flags)

    preview = Gtk.Label(label="")
    preview.add_css_class("pw-preview")
    preview.set_xalign(0)
    preview.set_selectable(True)
    preview.set_wrap(True)
    gen_box.append(preview)

    actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    roll_btn = Gtk.Button(label="↻ ROLL")
    roll_btn.add_css_class("nyxus-btn-primary")
    use_btn = Gtk.Button(label="↳ USE IN ADD")
    use_btn.add_css_class("nyxus-btn")
    copy_gen_btn = Gtk.Button(label="▤ COPY")
    copy_gen_btn.add_css_class("nyxus-btn")
    actions.append(roll_btn)
    actions.append(use_btn)
    actions.append(copy_gen_btn)
    gen_box.append(actions)
    card.body.append(gen_box)

    # ── add entry section
    add_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
    site_entry = Gtk.Entry()
    site_entry.add_css_class("nyxus-input")
    site_entry.set_placeholder_text("site / app")
    site_entry.set_hexpand(True)
    user_entry = Gtk.Entry()
    user_entry.add_css_class("nyxus-input")
    user_entry.set_placeholder_text("username / email")
    user_entry.set_hexpand(True)
    pw_entry = Gtk.Entry()
    pw_entry.add_css_class("nyxus-input")
    pw_entry.set_placeholder_text("password")
    pw_entry.set_visibility(False)
    pw_entry.set_hexpand(True)
    add_btn = Gtk.Button(label="+ ADD")
    add_btn.add_css_class("nyxus-btn-primary")
    add_row.append(site_entry)
    add_row.append(user_entry)
    add_row.append(pw_entry)
    add_row.append(add_btn)
    card.body.append(add_row)

    # ── entries list
    entries_box = Gtk.ListBox()
    entries_box.set_selection_mode(Gtk.SelectionMode.NONE)
    scroll = Gtk.ScrolledWindow()
    scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    scroll.set_min_content_height(180)
    scroll.set_child(entries_box)
    card.body.append(scroll)

    # ── helpers
    def gen():
        return generate_password(
            length=int(len_scale.get_value()),
            use_upper=flag_widgets["upper"].get_active(),
            use_lower=flag_widgets["lower"].get_active(),
            use_num=flag_widgets["num"].get_active(),
            use_sym=flag_widgets["sym"].get_active(),
        )

    def refresh_preview(*_a):
        p = gen()
        preview.set_text(p if p else "pick at least one option")

    def update_footer():
        card.footer_label.set_label(
            f"{len(store.list_entries())} ENTRIES · {store.backend_status}"
        )

    def render_list():
        while True:
            r = entries_box.get_first_child()
            if r is None:
                break
            entries_box.remove(r)
        items = store.list_entries()
        if not items:
            placeholder = Gtk.ListBoxRow()
            placeholder.set_selectable(False)
            empty = Gtk.Label(label="no entries — add one above or generate a password")
            empty.set_markup(
                f'<span foreground="{HEX["dim"]}" font_family="Caveat" size="16000">'
                f'no entries — add one above or generate a password</span>'
            )
            empty.set_xalign(0.5)
            placeholder.set_child(empty)
            entries_box.append(placeholder)
            return
        revealed = set()
        for entry in items:
            row = Gtk.ListBoxRow()
            row.set_selectable(False)
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            box.add_css_class("pw-row")
            site_lbl = Gtk.Label(label=entry["site"])
            site_lbl.add_css_class("pw-site")
            site_lbl.set_xalign(0)
            site_lbl.set_hexpand(True)
            site_lbl.set_ellipsize(2)  # END
            user_lbl = Gtk.Label(label=entry["user"])
            user_lbl.add_css_class("pw-user")
            user_lbl.set_xalign(0)
            user_lbl.set_hexpand(True)
            user_lbl.set_ellipsize(2)
            actual = store.get_password(entry["id"])
            mask = "•" * min(len(actual), 18)
            pw_lbl = Gtk.Label(label=mask)
            pw_lbl.set_xalign(0)
            pw_lbl.set_hexpand(True)
            pw_lbl.set_ellipsize(2)

            def make_toggle(_lbl, _id, _actual):
                def cb(btn):
                    if _id in revealed:
                        revealed.discard(_id)
                        _lbl.set_label("•" * min(len(_actual), 18))
                        btn.set_label("◯")
                    else:
                        revealed.add(_id)
                        _lbl.set_label(_actual)
                        btn.set_label("◐")
                return cb

            def make_copy(_id):
                def cb(_btn):
                    val = store.get_password(_id)
                    Gdk.Display.get_default().get_clipboard().set(val)
                return cb

            def make_delete(_id):
                def cb(_btn):
                    store.delete(_id)
                    render_list()
                    update_footer()
                return cb

            reveal_btn = Gtk.Button(label="◯")
            reveal_btn.add_css_class("nyxus-btn")
            reveal_btn.connect("clicked", make_toggle(pw_lbl, entry["id"], actual))
            copy_b = Gtk.Button(label="▤")
            copy_b.add_css_class("nyxus-btn")
            copy_b.connect("clicked", make_copy(entry["id"]))
            del_b = Gtk.Button(label="✕")
            del_b.add_css_class("nyxus-btn")
            del_b.connect("clicked", make_delete(entry["id"]))
            box.append(site_lbl)
            box.append(user_lbl)
            box.append(pw_lbl)
            box.append(reveal_btn)
            box.append(copy_b)
            box.append(del_b)
            row.set_child(box)
            entries_box.append(row)

    def on_roll(_b):
        refresh_preview()

    def on_use(_b):
        pw_entry.set_text(preview.get_text() if preview.get_text() != "pick at least one option" else "")

    def on_copy_gen(_b):
        text = preview.get_text()
        if text and text != "pick at least one option":
            Gdk.Display.get_default().get_clipboard().set(text)

    def on_add(_b):
        site = site_entry.get_text().strip()
        user = user_entry.get_text().strip()
        pw   = pw_entry.get_text()
        if not site or not user or not pw:
            return
        store.add(site, user, pw)
        site_entry.set_text("")
        user_entry.set_text("")
        pw_entry.set_text("")
        render_list()
        update_footer()

    def on_len_changed(scale):
        v = int(scale.get_value())
        len_lbl.set_markup(f'<span foreground="{HEX["dim"]}" font_family="JetBrains Mono" size="9000">LENGTH {v}</span>')
        refresh_preview()

    def on_flag_toggled(_btn):
        refresh_preview()

    roll_btn.connect("clicked", on_roll)
    use_btn.connect("clicked", on_use)
    copy_gen_btn.connect("clicked", on_copy_gen)
    add_btn.connect("clicked", on_add)
    len_scale.connect("value-changed", on_len_changed)
    for cb in flag_widgets.values():
        cb.connect("toggled", on_flag_toggled)

    refresh_preview()
    render_list()
    return card
