# ============================================
# NYXUS Home — palette + GTK4 CSS
# © 2026 Joseph Sierengowski
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
Single source of truth for colors and CSS used across all widgets.
Mirrors the NYXUS waybar palette so the Linux dashboard matches the
web mirror visually.
"""

# RGBA tuples (0..1) for Cairo drawing
PALETTE = {
    "pink":   (1.00, 0.00, 1.00),
    "cyan":   (0.13, 0.83, 0.93),
    "purple": (0.80, 0.00, 1.00),
    "gold":   (1.00, 1.00, 0.00),
    "indigo": (0.53, 0.00, 1.00),
    "green":  (0.22, 1.00, 0.08),
    "orange": (1.00, 0.33, 0.00),
    "blue":   (0.00, 0.53, 1.00),
    "red":    (1.00, 0.20, 0.27),
    "text":   (0.94, 0.91, 0.98),
    "dim":    (0.69, 0.64, 0.78),
    "void":   (0.03, 0.02, 0.07),
}

# Hex strings for CSS
HEX = {
    "pink":   "#ff00ff",
    "cyan":   "#22d3ee",
    "purple": "#cc00ff",
    "gold":   "#ffff00",
    "indigo": "#8800ff",
    "green":  "#39ff14",
    "orange": "#ff5500",
    "blue":   "#0088ff",
    "red":    "#ff3344",
    "text":   "#f0e8fa",
    "dim":    "#b0a3c8",
    "void":   "#080612",
}

# rotation order for graffiti & widgets
NEONS_HEX = [HEX["pink"], HEX["cyan"], HEX["gold"], HEX["green"],
             HEX["purple"], HEX["orange"], HEX["blue"], HEX["indigo"], HEX["red"]]
NEONS_RGB = [PALETTE[k] for k in
             ("pink", "cyan", "gold", "green", "purple", "orange", "blue", "indigo", "red")]


# ── CSS ──────────────────────────────────────────────────────────────────────
# GTK4 supports box-shadow + border + custom properties. It does NOT support
# CSS transforms (rotate/translate), so the hand-drawn tilt of the web
# mockup is replaced with dashed borders + neon glow. The background graffiti
# layer (with rotation) is drawn directly via Cairo in graffiti.py.
def card_css(name: str, color: str) -> str:
    return f"""
    .card-{name} {{
      background: rgba(6, 4, 18, 0.55);
      border: 1px dashed alpha({color}, 0.55);
      border-top: 2px solid {color};
      border-radius: 8px;
      padding: 12px 14px;
      box-shadow:
        0 0 0 1px alpha({color}, 0.13),
        0 0 18px alpha({color}, 0.35),
        0 0 38px alpha({color}, 0.20),
        0 6px 22px rgba(0, 0, 0, 0.55);
    }}
    .card-{name}-title {{
      color: {color};
      font-family: 'Caveat', 'Patrick Hand', cursive;
      font-weight: 700;
      font-size: 22px;
      letter-spacing: 0.02em;
    }}
    .card-{name}-glyph {{
      color: {color};
      font-size: 18px;
    }}
    .card-{name}-footer {{
      color: alpha({color}, 0.55);
      font-family: 'JetBrains Mono', monospace;
      font-size: 9px;
      letter-spacing: 0.18em;
    }}
    .card-{name}-accent {{
      color: {color};
    }}
    """


def build_full_css() -> str:
    parts = ["""
    window, .home-root {
      background: transparent;
      color: """ + HEX["text"] + """;
      font-family: 'Caveat', 'Patrick Hand', cursive;
    }
    .home-bg {
      background: """ + HEX["void"] + """;
    }
    .home-header {
      color: """ + HEX["text"] + """;
      font-family: 'Caveat', cursive;
      font-size: 30px;
      letter-spacing: 0.02em;
    }
    .home-header-tag {
      color: """ + HEX["pink"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 9px;
      letter-spacing: 0.28em;
    }
    .home-copyright {
      color: #444;
      font-family: 'JetBrains Mono', monospace;
      font-size: 8px;
      letter-spacing: 0.22em;
    }
    .clock-time {
      font-family: 'JetBrains Mono', monospace;
      font-weight: 700;
      font-size: 44px;
      color: """ + HEX["text"] + """;
    }
    .clock-day {
      font-family: 'Caveat', cursive;
      font-size: 22px;
      color: """ + HEX["cyan"] + """;
    }
    .clock-date {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: """ + HEX["dim"] + """;
      letter-spacing: 0.10em;
    }
    .weather-temp {
      font-family: 'JetBrains Mono', monospace;
      font-weight: 700;
      font-size: 36px;
      color: """ + HEX["text"] + """;
    }
    .weather-glyph {
      font-size: 36px;
      color: """ + HEX["gold"] + """;
    }
    .weather-cond {
      font-family: 'Caveat', cursive;
      font-size: 17px;
      color: """ + HEX["gold"] + """;
    }
    .weather-meta {
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      color: """ + HEX["dim"] + """;
      letter-spacing: 0.05em;
    }
    .nyxus-input {
      background: rgba(0, 0, 0, 0.45);
      border: 1px dashed alpha(""" + HEX["orange"] + """, 0.40);
      border-radius: 3px;
      color: """ + HEX["text"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      padding: 4px 8px;
      caret-color: """ + HEX["pink"] + """;
    }
    .nyxus-btn {
      background: rgba(0, 0, 0, 0.35);
      border: 1px solid alpha(""" + HEX["pink"] + """, 0.55);
      color: """ + HEX["pink"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      letter-spacing: 0.18em;
      padding: 4px 10px;
      border-radius: 3px;
    }
    .nyxus-btn:hover {
      background: alpha(""" + HEX["pink"] + """, 0.18);
    }
    .nyxus-btn-primary {
      background: alpha(""" + HEX["orange"] + """, 0.18);
      border: 1px solid """ + HEX["orange"] + """;
      color: """ + HEX["orange"] + """;
      font-weight: 700;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      letter-spacing: 0.18em;
      padding: 4px 12px;
      border-radius: 3px;
    }
    .notif-row {
      background: rgba(0, 0, 0, 0.30);
      border: 1px dashed alpha(""" + HEX["green"] + """, 0.30);
      border-left: 3px solid """ + HEX["green"] + """;
      padding: 6px 8px;
      border-radius: 3px;
    }
    .notif-title {
      color: """ + HEX["green"] + """;
      font-family: 'Caveat', cursive;
      font-size: 16px;
    }
    .notif-body {
      color: """ + HEX["dim"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
    }
    .notif-time {
      color: """ + HEX["dim"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 8px;
      letter-spacing: 0.10em;
    }
    .notepad-view {
      background: rgba(0, 0, 0, 0.50);
      border: 1px dashed alpha(""" + HEX["cyan"] + """, 0.30);
      border-radius: 4px;
      color: """ + HEX["text"] + """;
      font-family: 'Caveat', cursive;
      font-size: 19px;
      padding: 10px 12px;
      caret-color: """ + HEX["cyan"] + """;
    }
    .notepad-view text {
      background: transparent;
      color: """ + HEX["text"] + """;
    }
    .pw-row {
      background: rgba(0, 0, 0, 0.40);
      border: 1px dashed alpha(""" + HEX["orange"] + """, 0.30);
      border-radius: 3px;
      padding: 5px 8px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: """ + HEX["text"] + """;
    }
    .pw-site {
      color: """ + HEX["orange"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
    }
    .pw-user {
      color: """ + HEX["dim"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
    }
    .pw-preview {
      background: rgba(0, 0, 0, 0.55);
      border: 1px dashed alpha(""" + HEX["orange"] + """, 0.40);
      border-radius: 3px;
      color: """ + HEX["text"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      padding: 4px 8px;
    }
    .pw-section {
      border: 1px dashed alpha(""" + HEX["orange"] + """, 0.30);
      border-radius: 4px;
      background: alpha(""" + HEX["orange"] + """, 0.04);
      padding: 8px 10px;
    }
    calendar {
      background: transparent;
      color: """ + HEX["text"] + """;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
    }
    calendar:selected {
      background: """ + HEX["purple"] + """;
      color: """ + HEX["void"] + """;
      border-radius: 50%;
      box-shadow: 0 0 12px """ + HEX["purple"] + """;
    }
    """]
    for name, hex_ in (("clock", HEX["pink"]),
                       ("weather", HEX["gold"]),
                       ("calendar", HEX["purple"]),
                       ("notif", HEX["green"]),
                       ("notepad", HEX["cyan"]),
                       ("pw", HEX["orange"])):
        parts.append(card_css(name, hex_))
    return "\n".join(parts)
