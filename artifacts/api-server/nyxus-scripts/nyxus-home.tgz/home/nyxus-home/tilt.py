"""
NYXUS Home - TiltBox: a Gtk.Widget wrapper that rotates its single child by
a static angle (degrees) using GTK4's Gtk.Snapshot.rotate(). Mirrors the
web preview's per-card `transform: rotate(Xdeg)`.

Hover/click hit-tests in GTK4 stay axis-aligned; at <=2 deg this is invisible.
If GTK4 snapshot rotation is unavailable for any reason, the wrapper falls
back to rendering the child un-rotated rather than crashing.

(c) 2026 Joseph Sierengowski - NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
import math
import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Graphene  # noqa: E402


class TiltBox(Gtk.Widget):
    """Wraps one child widget, paints it rotated by `tilt` degrees about
    the wrapper's own center. Allocates extra space so corners don't clip."""

    def __init__(self, child: Gtk.Widget, tilt: float = 0.0):
        super().__init__()
        self._tilt = float(tilt)
        self._child = child
        child.set_parent(self)

    def do_dispose(self):
        if self._child is not None:
            self._child.unparent()
            self._child = None
        Gtk.Widget.do_dispose(self)

    # Forward sizing to child, padded so the rotated bbox always fits.
    def do_measure(self, orientation, for_size):
        if self._child is None:
            return (0, 0, -1, -1)
        rad = abs(math.radians(self._tilt))
        # Rotated AABB grows by sin(angle)*other_dim. Without knowing the
        # other dim here, use a conservative pad based on for_size when
        # available, else a fixed 24px pad. At small angles this is generous.
        pad = int(math.ceil(max(24, (for_size if for_size > 0 else 320) * rad)))
        min_s, nat_s, min_b, nat_b = self._child.measure(orientation, for_size)
        return (min_s + pad, nat_s + pad, min_b, nat_b)

    def do_size_allocate(self, width, height, baseline):
        if self._child is None:
            return
        # Give the child its natural size centered inside us; the snapshot
        # rotation happens around our center.
        self._child.allocate(width, height, baseline, None)

    def do_snapshot(self, snapshot: Gtk.Snapshot):
        if self._child is None:
            return
        if abs(self._tilt) < 0.01:
            self.snapshot_child(self._child, snapshot)
            return
        try:
            w = self.get_width()
            h = self.get_height()
            cx, cy = w / 2.0, h / 2.0
            snapshot.save()
            snapshot.translate(Graphene.Point().init(cx, cy))
            snapshot.rotate(self._tilt)
            snapshot.translate(Graphene.Point().init(-cx, -cy))
            self.snapshot_child(self._child, snapshot)
            snapshot.restore()
        except Exception:
            # Last-resort fallback: render un-rotated so the UI never breaks.
            self.snapshot_child(self._child, snapshot)
