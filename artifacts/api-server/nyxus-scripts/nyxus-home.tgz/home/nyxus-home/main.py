#!/usr/bin/env python3
# ============================================
# NYXUS Home — GTK4 dashboard
# © 2026 Joseph Sierengowski
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
Entry point for the NYXUS Home dashboard. Launches a single GTK4 window
with a Cairo-painted graffiti collage background and a 6-card grid of
widgets (Clock, Weather, Calendar, Notifications, Notepad, Password
Manager).

Mirrors the workspace-0 home page from the NYXUS web mirror.

Launch:
    nyxus-home
"""

import os
import sys

# Make our package modules importable when invoked as `python3 main.py`
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, Gio, GLib

from style import build_full_css, HEX
from graffiti import GraffitiBackground
from widgets import (
    build_clock_card,
    build_weather_card,
    build_calendar_card,
    build_notifications_card,
    build_notepad_card,
    build_password_card,
)


APP_ID = "com.sierengowski.nyxus.home"


def install_css():
    provider = Gtk.CssProvider()
    css = build_full_css()
    try:
        provider.load_from_data(css.encode("utf-8"))
    except TypeError:
        provider.load_from_data(css)
    display = Gdk.Display.get_default()
    if display is not None:
        Gtk.StyleContext.add_provider_for_display(
            display, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )


def build_header() -> Gtk.Box:
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    row.set_margin_start(8)
    row.set_margin_end(8)
    row.set_margin_top(2)
    row.set_margin_bottom(4)

    left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    left.set_hexpand(True)
    tag = Gtk.Label(label="NYXUS · WORKSPACE 0 · HOME")
    tag.add_css_class("home-header-tag")
    tag.set_xalign(0)
    headline = Gtk.Label()
    headline.set_markup(
        f'<span font_family="Caveat" size="30000">'
        f'<span foreground="{HEX["pink"]}">welcome</span> '
        f'back, <span foreground="{HEX["gold"]}">operator</span>'
        f'</span>'
    )
    headline.set_xalign(0)
    left.append(tag)
    left.append(headline)

    right = Gtk.Label(label="NYX-J5W-2026\nSIERENGOWSKI-LOCKED")
    right.add_css_class("home-copyright")
    right.set_xalign(1)
    right.set_yalign(0.5)

    row.append(left)
    row.append(right)
    return row


def build_grid() -> Gtk.Widget:
    """
    FlowBox auto-fits cards into 1/2/3 columns based on window width,
    matching the responsive grid in the web mirror.
    """
    fb = Gtk.FlowBox()
    fb.set_valign(Gtk.Align.START)
    fb.set_max_children_per_line(3)
    fb.set_min_children_per_line(1)
    fb.set_selection_mode(Gtk.SelectionMode.NONE)
    fb.set_homogeneous(False)
    fb.set_column_spacing(14)
    fb.set_row_spacing(14)
    fb.set_margin_start(8)
    fb.set_margin_end(8)
    fb.set_margin_top(4)
    fb.set_margin_bottom(12)

    for builder in (
        build_clock_card,
        build_weather_card,
        build_notifications_card,
        build_calendar_card,
        build_notepad_card,
        build_password_card,
    ):
        try:
            card = builder()
        except Exception as e:
            card = Gtk.Label(label=f"widget failed: {e}")
        child = Gtk.FlowBoxChild()
        child.set_child(card)
        fb.append(child)
    return fb


class NyxusHomeApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = Gtk.ApplicationWindow(application=self)
        win.set_title("NYXUS Home")
        win.set_default_size(1280, 800)

        install_css()

        # Stack: graffiti background + scrollable dashboard on top
        overlay = Gtk.Overlay()
        bg = GraffitiBackground()
        overlay.set_child(bg)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.add_css_class("home-root")
        outer.set_margin_start(14)
        outer.set_margin_end(14)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.append(build_header())

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        scroll.set_child(build_grid())
        outer.append(scroll)

        overlay.add_overlay(outer)
        win.set_child(overlay)

        # Esc closes
        ctrl = Gtk.EventControllerKey()

        def on_key(_c, keyval, _kc, _state):
            if keyval == Gdk.KEY_Escape:
                win.close()
                return True
            return False

        ctrl.connect("key-pressed", on_key)
        win.add_controller(ctrl)

        win.present()


def main(argv=None):
    app = NyxusHomeApp()
    return app.run(argv if argv is not None else sys.argv)


if __name__ == "__main__":
    sys.exit(main())
