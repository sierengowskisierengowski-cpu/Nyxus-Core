#!/usr/bin/env python3
# ============================================
# NYXUS Home — main GTK4 entry
# (c) 2026 Joseph Sierengowski
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
Workspace-0 dashboard: Clock · Weather · Calendar · Notifications ·
Notepad · Password Manager.  Cards float over a Cairo-painted
graffiti word-collage matching the web mirror.
"""
import os
import sys

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib  # noqa: E402

# Make sibling modules importable regardless of cwd
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from style import install_css, PALETTE                                # noqa: E402
from graffiti import GraffitiArea                                     # noqa: E402
from tilt import TiltBox                                              # noqa: E402
from widgets import (                                                  # noqa: E402
    ClockCard, WeatherCard, CalendarCard,
    NotificationsCard, NotepadCard, PasswordManagerCard,
)

# Per-card tilt angles (degrees) — exact values from web HomeDashboard.tsx
CARD_TILTS = {
    "Clock":         -1.2,
    "Weather":        0.8,
    "Notifications":  1.0,
    "Calendar":      -0.5,
    "Notepad":       -0.8,
    "Passwords":      0.5,
}

APP_ID = "io.nyxus.home"


def _header_strip():
    box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    box.set_margin_start(8)
    box.set_margin_end(8)
    box.set_margin_top(4)
    box.set_margin_bottom(8)

    left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
    tag = Gtk.Label(label="NYXUS \u00b7 WORKSPACE 0 \u00b7 HOME", xalign=0.0)
    tag.add_css_class("header-tag")
    left.append(tag)
    title = Gtk.Label(xalign=0.0)
    title.set_use_markup(True)
    title.set_markup(
        f"<span foreground='{PALETTE['pink']}'>welcome</span> "
        f"back, <span foreground='{PALETTE['gold']}'>operator</span>"
    )
    title.add_css_class("header-title")
    left.append(title)
    left.set_hexpand(True)
    box.append(left)

    right = Gtk.Label(label="NYX-J5W-2026\nSIERENGOWSKI-LOCKED", xalign=1.0)
    right.add_css_class("header-stamp")
    right.set_justify(Gtk.Justification.RIGHT)
    box.append(right)
    return box


def _build_grid():
    """4-column Gtk.Grid mirroring the web HomeDashboard layout exactly:
       Row 0: Clock | Weather | Notifications | Calendar  (each 1 col)
       Row 1: Notepad spans 2 cols (left half)
       Row 2: Password Manager spans full 4 cols
    """
    grid = Gtk.Grid()
    grid.set_valign(Gtk.Align.START)
    grid.set_halign(Gtk.Align.FILL)
    grid.set_column_spacing(28)
    grid.set_row_spacing(28)
    grid.set_column_homogeneous(True)
    grid.set_hexpand(True)

    layout = [
        # (name,            card,                       col, row, w, h)
        ("Clock",           ClockCard(),                0, 0, 1, 1),
        ("Weather",         WeatherCard(),              1, 0, 1, 1),
        ("Notifications",   NotificationsCard(),        2, 0, 1, 1),
        ("Calendar",        CalendarCard(),             3, 0, 1, 1),
        ("Notepad",         NotepadCard(),              0, 1, 2, 1),
        ("Passwords",       PasswordManagerCard(),      0, 2, 4, 1),
    ]
    for name, c, col, row, w, h in layout:
        tilt = CARD_TILTS.get(name, 0.0)
        tilted = TiltBox(c.root, tilt=tilt)
        tilted.set_hexpand(True)
        tilted.set_halign(Gtk.Align.FILL)
        grid.attach(tilted, col, row, w, h)
    return grid


class HomeWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title("NYXUS Home")
        self.set_default_size(1280, 820)

        # Overlay: graffiti BG underneath, content on top
        overlay = Gtk.Overlay()
        bg = GraffitiArea()
        overlay.set_child(bg)

        content_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        content_outer.set_margin_start(16)
        content_outer.set_margin_end(16)
        content_outer.set_margin_top(14)
        content_outer.set_margin_bottom(14)
        content_outer.append(_header_strip())

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_child(_build_grid())
        scroller.set_vexpand(True)
        scroller.set_hexpand(True)
        content_outer.append(scroller)

        overlay.add_overlay(content_outer)
        self.set_child(overlay)

        # Esc closes
        kc = Gtk.EventControllerKey()
        kc.connect("key-pressed", self._on_key)
        self.add_controller(kc)

    def _on_key(self, _ctrl, keyval, _kc, _state):
        if keyval == Gdk.KEY_Escape:
            self.close()
            return True
        return False


class HomeApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=0)

    def do_activate(self):
        install_css()
        win = HomeWindow(self)
        win.present()


def main():
    app = HomeApp()
    return app.run(sys.argv)



# ─────────────────────────── NYXUS CHROME (auto-injected) ───────────────────
# Unifies look across every NYXUS GTK4 app: graffiti background, Caveat
# font, neon palette. Monkey-patches ApplicationWindow.present so the
# canonical install_chrome() runs once per top-level window without
# touching the app's own window-construction code. nyxus-panel is
# intentionally excluded (LayerShell incompatibility with Gtk.Overlay).
# nyxus_chrome.py is shipped to ~/.nyxus by nyxus_install.sh.
try:
    import os as _nyx_os, sys as _nyx_sys
    _nyx_chrome_dir = _nyx_os.path.expanduser("~/.nyxus")
    if _nyx_chrome_dir not in _nyx_sys.path:
        _nyx_sys.path.insert(0, _nyx_chrome_dir)
    try:
        from nyxus_chrome import install_chrome as _nyx_install_chrome
    except ImportError:
        _nyx_install_chrome = lambda *a, **kw: None  # silent no-op
    import gi as _nyx_gi
    _nyx_gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk as _NyxGtk
    _NYX_PAGE_KEY = "_home"
    if not getattr(_NyxGtk.ApplicationWindow, "_nyx_chrome_hooked", False):
        _orig_present = _NyxGtk.ApplicationWindow.present
        def _nyx_present(self):
            try: _nyx_install_chrome(self, page_key=_NYX_PAGE_KEY)
            except Exception: pass
            return _orig_present(self)
        _NyxGtk.ApplicationWindow.present = _nyx_present
        _NyxGtk.ApplicationWindow._nyx_chrome_hooked = True
except Exception as _nyx_e:
    import sys as _nyx_sys
    print("nyxus-chrome bootstrap skipped: %s" % _nyx_e, file=_nyx_sys.stderr)
# ────────────────────────── /NYXUS CHROME ───────────────────────────────────

if __name__ == "__main__":
    raise SystemExit(main())
