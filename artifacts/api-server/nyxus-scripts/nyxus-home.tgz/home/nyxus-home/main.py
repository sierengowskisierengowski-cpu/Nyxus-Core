#!/usr/bin/env python3
# ============================================
# NYXUS Home — main GTK4 entry
# (c) 2026 Joseph Sierengowski
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
Workspace-0 dashboard: Clock · Weather · Calendar · Notifications ·
Notepad · Password Manager.  Cards float over a Cairo-painted
graffiti word-collage matching the web mirror.
"""
import os
import sys

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib  # noqa: E402

# Make sibling modules importable regardless of cwd
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from style import install_css, PALETTE                                # noqa: E402
from graffiti import GraffitiArea                                     # noqa: E402
from widgets import (                                                  # noqa: E402
    ClockCard, WeatherCard, CalendarCard,
    NotificationsCard, NotepadCard, PasswordManagerCard,
)

APP_ID = "io.nyxus.home"


def _header_strip():
    box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    box.set_margin_start(8)
    box.set_margin_end(8)
    box.set_margin_top(4)
    box.set_margin_bottom(8)

    left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
    tag = Gtk.Label(label="NYXUS \u00b7 WORKSPACE 0 \u00b7 HOME", xalign=0.0)
    tag.add_css_class("header-tag")
    left.append(tag)
    title = Gtk.Label(xalign=0.0)
    title.set_use_markup(True)
    title.set_markup(
        f"<span foreground='{PALETTE['pink']}'>welcome</span> "
        f"back, <span foreground='{PALETTE['gold']}'>operator</span>"
    )
    title.add_css_class("header-title")
    left.append(title)
    left.set_hexpand(True)
    box.append(left)

    right = Gtk.Label(label="NYX-J5W-2026\nSIERENGOWSKI-LOCKED", xalign=1.0)
    right.add_css_class("header-stamp")
    right.set_justify(Gtk.Justification.RIGHT)
    box.append(right)
    return box


def _build_grid():
    """FlowBox so the cards reflow like the web's auto-fit grid."""
    flow = Gtk.FlowBox()
    flow.set_valign(Gtk.Align.START)
    flow.set_max_children_per_line(3)
    flow.set_min_children_per_line(1)
    flow.set_homogeneous(False)
    flow.set_column_spacing(14)
    flow.set_row_spacing(14)
    flow.set_selection_mode(Gtk.SelectionMode.NONE)

    cards = [
        ClockCard(), WeatherCard(), NotificationsCard(),
        CalendarCard(), NotepadCard(), PasswordManagerCard(),
    ]
    # Wider cards for Notepad (span 2) and Password Manager (span 3) on wide displays
    for c in cards:
        wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        wrap.append(c.root)
        wrap.set_size_request(320, -1)
        flow.append(wrap)
    return flow


class HomeWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title("NYXUS Home")
        self.set_default_size(1280, 820)

        # Overlay: graffiti BG underneath, content on top
        overlay = Gtk.Overlay()
        bg = GraffitiArea()
        overlay.set_child(bg)

        content_outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        content_outer.set_margin_start(16)
        content_outer.set_margin_end(16)
        content_outer.set_margin_top(14)
        content_outer.set_margin_bottom(14)
        content_outer.append(_header_strip())

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_child(_build_grid())
        scroller.set_vexpand(True)
        scroller.set_hexpand(True)
        content_outer.append(scroller)

        overlay.add_overlay(content_outer)
        self.set_child(overlay)

        # Esc closes
        kc = Gtk.EventControllerKey()
        kc.connect("key-pressed", self._on_key)
        self.add_controller(kc)

    def _on_key(self, _ctrl, keyval, _kc, _state):
        if keyval == Gdk.KEY_Escape:
            self.close()
            return True
        return False


class HomeApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=0)

    def do_activate(self):
        install_css()
        win = HomeWindow(self)
        win.present()


def main():
    app = HomeApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    raise SystemExit(main())
