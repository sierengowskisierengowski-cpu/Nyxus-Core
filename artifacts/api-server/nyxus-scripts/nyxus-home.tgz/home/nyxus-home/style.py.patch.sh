#!/bin/bash
F=/tmp/nh/home/nyxus-home/style.py
# Rename app references handled in install.sh, not here.
# 1) Switch JetBrains Mono labels to Caveat for body/header text (keep mono ONLY for clock digits, weather temp, password chars where monospace alignment matters).
# 2) Add font-style: italic to header-title and all card title/header classes for slanted hand-drawn tilt feel.
python3 - <<'PY'
import re
p = "/tmp/nh/home/nyxus-home/style.py"
s = open(p).read()

# Add italic to header-title and card title classes
s = s.replace(
    '.header-title {\n    font-family: "Caveat", cursive;\n    font-size: 30px;',
    '.header-title {\n    font-family: "Caveat", cursive;\n    font-style: italic;\n    font-size: 32px;'
)
s = s.replace(
    'font-family: "Caveat", cursive;\n    font-size: 22px;\n    font-weight: 700;\n    color: {color};',
    'font-family: "Caveat", cursive;\n    font-style: italic;\n    font-size: 24px;\n    font-weight: 700;\n    color: {color};'
)
# Make ALL Caveat-using labels italic for the tilted handwriting feel
for cls in ['clock-day','wx-label','wx-loc','cal-month','notif-title','np-textarea','pw-gen-label']:
    s = re.sub(
        r'(\.' + cls + r' \{\n    font-family: "Caveat", cursive;\n)',
        r'\1    font-style: italic;\n',
        s
    )
open(p,'w').write(s)
print("OK style.py patched")
PY
