# ============================================
# NYXUS Home — graffiti word-collage background
# © 2026 Joseph Sierengowski
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
Cairo DrawingArea that paints the NYXUS / Arch / Hyprland lexicon as a
rotated neon graffiti collage, plus a few paint mist splats and drips.
Deterministic positions so the layout is stable across redraws.
"""

import math
import random
import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk

from style import NEONS_RGB

GRAFFITI_WORDS = [
    "NYXUS", "NYX", "ARCH", "LINUX", "HYPRLAND", "WAYBAR", "KITTY", "FOOT",
    "ROFI", "DUNST", "NEOVIM", "ZSH", "TMUX", "BTRFS", "WAYLAND", "PIPEWIRE",
    "NETWORKD", "SYSTEMD", "PACMAN", "AUR", "MAKEPKG", "CACHYOS",
    "INTEL", "PHANTOM", "SHIELD", "GODSAPP", "SAGE", "PANEL", "STUDIO",
    "NOTEPAD", "STICKIES", "SYSMON", "WIDGETS", "START", "HOME",
    "CAVEAT", "JETBRAINS", "NERDFONT", "NEON", "ROOT", "OPS",
    "AES-256-GCM", "PBKDF2", "SHA-256", "TAMPER-OK", "ARMED",
    "SIERENGOWSKI", "J5W", "2026", "v2.0",
    "SILENT", "DARK", "FUNCTIONAL", "OPERATIONAL", "LOCKED",
]


def _build_layout(seed: int = 20260502):
    """Pre-compute random word/splat positions in normalized [0, 1] space."""
    r = random.Random(seed)
    words = []
    for w in GRAFFITI_WORDS:
        words.append({
            "text":    w,
            "x":       r.uniform(0.02, 0.98),
            "y":       r.uniform(0.04, 0.96),
            "rot":     math.radians(r.uniform(-28, 28)),
            "size":    r.uniform(13, 38),       # px
            "color":   NEONS_RGB[r.randrange(len(NEONS_RGB))],
            "alpha":   r.uniform(0.10, 0.32),
            "weight":  "Bold" if r.random() > 0.55 else "Normal",
            "font":    "Caveat" if r.random() > 0.30 else "JetBrains Mono",
        })
    splats = []
    for _ in range(14):
        splats.append({
            "x":      r.uniform(0, 1),
            "y":      r.uniform(0, 1),
            "rx":     r.uniform(20, 80),
            "ry":     r.uniform(14, 60),
            "rot":    r.uniform(0, math.tau),
            "color":  NEONS_RGB[r.randrange(len(NEONS_RGB))],
            "alpha":  r.uniform(0.04, 0.10),
        })
    drips = []
    for _ in range(20):
        drips.append({
            "x":      r.uniform(0, 1),
            "y":      r.uniform(0, 0.85),
            "len":    r.uniform(20, 90),
            "color":  NEONS_RGB[r.randrange(len(NEONS_RGB))],
            "alpha":  r.uniform(0.10, 0.25),
        })
    return words, splats, drips


_WORDS, _SPLATS, _DRIPS = _build_layout()


class GraffitiBackground(Gtk.DrawingArea):
    """
    Renders the graffiti collage. Set this as the bottom layer of a
    Gtk.Overlay; the dashboard grid sits on top.
    """

    def __init__(self):
        super().__init__()
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.set_draw_func(self._on_draw)

    def _on_draw(self, _area, cr, w, h):
        # Solid void background
        cr.set_source_rgb(0.03, 0.02, 0.07)
        cr.rectangle(0, 0, w, h)
        cr.fill()

        # Splats — soft glowing ellipses (poor man's blur via radial pattern)
        for s in _SPLATS:
            cx, cy = s["x"] * w, s["y"] * h
            cr.save()
            cr.translate(cx, cy)
            cr.rotate(s["rot"])
            cr.scale(s["rx"], s["ry"])
            r_, g_, b_ = s["color"]
            try:
                import cairo
                grad = cairo.RadialGradient(0, 0, 0, 0, 0, 1)
                grad.add_color_stop_rgba(0.0, r_, g_, b_, s["alpha"])
                grad.add_color_stop_rgba(1.0, r_, g_, b_, 0.0)
                cr.set_source(grad)
            except Exception:
                cr.set_source_rgba(r_, g_, b_, s["alpha"] * 0.5)
            cr.arc(0, 0, 1, 0, math.tau)
            cr.fill()
            cr.restore()

        # Drips — thin vertical neon lines
        cr.set_line_width(1.5)
        cr.set_line_cap(__import__("cairo").LINE_CAP_ROUND)
        for d in _DRIPS:
            x = d["x"] * w
            y1 = d["y"] * h
            y2 = y1 + d["len"]
            r_, g_, b_ = d["color"]
            cr.set_source_rgba(r_, g_, b_, d["alpha"])
            cr.move_to(x, y1)
            cr.line_to(x, y2)
            cr.stroke()

        # Words — rotated neon Caveat / JetBrains Mono labels
        for word in _WORDS:
            x = word["x"] * w
            y = word["y"] * h
            r_, g_, b_ = word["color"]
            cr.save()
            cr.translate(x, y)
            cr.rotate(word["rot"])
            # pick font
            slant = __import__("cairo").FONT_SLANT_NORMAL
            weight = (__import__("cairo").FONT_WEIGHT_BOLD
                      if word["weight"] == "Bold"
                      else __import__("cairo").FONT_WEIGHT_NORMAL)
            cr.select_font_face(word["font"], slant, weight)
            cr.set_font_size(word["size"])

            # measure to center
            extents = cr.text_extents(word["text"])
            tx = -extents.width / 2 - extents.x_bearing
            ty = -extents.height / 2 - extents.y_bearing

            # soft glow halo
            cr.set_source_rgba(r_, g_, b_, word["alpha"] * 0.55)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1),
                           (-1, -1), (1, 1), (-1, 1), (1, -1)):
                cr.move_to(tx + dx, ty + dy)
                cr.show_text(word["text"])

            # main fill
            cr.set_source_rgba(r_, g_, b_, word["alpha"])
            cr.move_to(tx, ty)
            cr.show_text(word["text"])
            cr.restore()

        # Vignette
        try:
            import cairo
            grad = cairo.RadialGradient(w / 2, h / 2, w * 0.2,
                                        w / 2, h / 2, max(w, h) * 0.7)
            grad.add_color_stop_rgba(0.0, 0, 0, 0, 0.18)
            grad.add_color_stop_rgba(1.0, 0, 0, 0, 0.55)
            cr.set_source(grad)
            cr.rectangle(0, 0, w, h)
            cr.fill()
        except Exception:
            pass
