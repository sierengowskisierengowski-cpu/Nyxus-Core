#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────
# NYXUS Home — sub-app installer
#
# Called by the top-level nyxus_home_install.sh after the tarball is
# extracted. Lays files into ~/.nyxus/nyxus-home/, installs Python +
# system deps, drops a launcher script and a .desktop entry.
#
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ──────────────────────────────────────────────────────────────────────
set -euo pipefail

B=$'\e[1m'; R=$'\e[0m'; PINK=$'\e[38;5;201m'; CYAN=$'\e[38;5;51m'
GOLD=$'\e[38;5;220m'; PURPLE=$'\e[38;5;177m'; DIM=$'\e[2m'

step() { printf "\n${PURPLE}▌${R} ${B}%s${R}\n" "$*"; }
ok()   { printf "  ${CYAN}✓${R}  %s\n" "$*"; }
warn() { printf "  ${GOLD}!${R}  %s\n" "$*"; }
fail() { printf "  ${PINK}✗${R}  %s\n" "$*" >&2; }

# ── resolve real user (script may run as root via sudo)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6)"
[[ -z "$REAL_HOME" || ! -d "$REAL_HOME" ]] && REAL_HOME="$HOME"

INSTALL_DIR="${REAL_HOME}/.nyxus/nyxus-home"
BIN_DIR="${REAL_HOME}/.local/bin"
APP_DIR="${REAL_HOME}/.local/share/applications"
CONFIG_DIR="${REAL_HOME}/.config/nyxus-home"
DATA_DIR="${REAL_HOME}/.local/share/nyxus-home"

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

step "preflight"
for cmd in python3 install; do
  command -v "$cmd" >/dev/null || { fail "$cmd not found"; exit 1; }
done
ok "python3 / install present"

# ── system packages (best-effort, all individually wrapped)
step "system packages (pacman)"
if command -v pacman >/dev/null; then
  pacman -S --noconfirm --needed \
    gtk4 python-gobject python-cairo \
    python-requests \
    2>/dev/null \
    && ok "gtk4 / python-gobject / python-cairo / requests" \
    || warn "pacman: some core packages failed (re-run: sudo pacman -S gtk4 python-gobject python-cairo)"

  # Secret Service backend — passwords are encrypted by the OS, not by us
  pacman -S --noconfirm --needed gnome-keyring libsecret python-keyring \
    2>/dev/null \
    && ok "gnome-keyring / libsecret / python-keyring (real password encryption)" \
    || warn "keyring stack missing — passwords will be plaintext until you install gnome-keyring"
else
  warn "pacman not found — install GTK4 + python-gobject + python-keyring manually"
fi

# ── pip fallback for python-keyring
step "python-keyring availability"
if sudo -u "$REAL_USER" python3 -c "import keyring" 2>/dev/null; then
  ok "keyring importable"
else
  if sudo -u "$REAL_USER" pip install --user keyring 2>/dev/null; then
    ok "installed via pip --user"
  elif pip install --break-system-packages keyring 2>/dev/null; then
    ok "installed via pip --break-system-packages"
  else
    warn "keyring install failed — Password Manager will use plaintext fallback"
  fi
fi

# ── lay down files
step "deploy files → ${INSTALL_DIR}"
install -d -o "$REAL_USER" -g "$REAL_USER" \
  "${INSTALL_DIR}" "${BIN_DIR}" "${APP_DIR}" "${CONFIG_DIR}" "${DATA_DIR}"

cp -r "${SRC_DIR}/nyxus-home/." "${INSTALL_DIR}/"
chown -R "$REAL_USER":"$REAL_USER" "${INSTALL_DIR}"
chmod -R u+rw,go+r "${INSTALL_DIR}"
ok "deployed $(find "${INSTALL_DIR}" -maxdepth 1 -type f | wc -l) files"

# ── launcher script
step "launcher script"
cat > "${BIN_DIR}/nyxus-home" <<EOF
#!/usr/bin/env bash
exec python3 "${INSTALL_DIR}/main.py" "\$@"
EOF
chmod +x "${BIN_DIR}/nyxus-home"
chown "$REAL_USER":"$REAL_USER" "${BIN_DIR}/nyxus-home"
ok "${BIN_DIR}/nyxus-home"

# ── .desktop entry
step ".desktop entry"
cat > "${APP_DIR}/nyxus-home.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Main Page
GenericName=Main Page
Comment=Personal dashboard — clock, weather, calendar, notepad, passwords
Exec=${BIN_DIR}/nyxus-home
Icon=io.nyxus.home
Terminal=false
Categories=Utility;
Keywords=dashboard;home;widgets;
StartupNotify=true
EOF
chown "$REAL_USER":"$REAL_USER" "${APP_DIR}/nyxus-home.desktop"
ok "${APP_DIR}/nyxus-home.desktop"

# ── default config (only if not present)
if [[ ! -f "${CONFIG_DIR}/config.json" ]]; then
  step "default config"
  cat > "${CONFIG_DIR}/config.json" <<'EOF'
{
  "weather": {
    "lat": 40.7128,
    "lon": -74.0060,
    "label": "New York, NY",
    "unit": "fahrenheit"
  },
  "ui": {
    "graffiti_density": "high"
  }
}
EOF
  chown "$REAL_USER":"$REAL_USER" "${CONFIG_DIR}/config.json"
  ok "${CONFIG_DIR}/config.json (NYC default)"
fi

cat <<EOF

──────────────────────────────────────────────────────────────────────

  ${GOLD}NYXUS Home installed.${R}

  ${B}launch:${R}    ${PINK}nyxus-home${R}
  ${B}config:${R}    ${DIM}${CONFIG_DIR}/config.json${R}
  ${B}data:${R}      ${DIM}${DATA_DIR}/${R}        (notepad + entry index)
  ${B}secrets:${R}   ${DIM}gnome-keyring${R}       (real OS encryption)

  ${PURPLE}C L O C K  ·  W E A T H E R  ·  C A L E N D A R${R}
  ${PURPLE}N O T E S   ·  P A S S W O R D S    ·  N O T I F${R}

──────────────────────────────────────────────────────────────────────
EOF
