# NYXUS Home

A GTK4 desktop dashboard mirroring the workspace-0 home page from the NYXUS
web mirror. Six widgets in a translucent neon-glow grid over a graffiti
word-collage background:

- **Clock** — live local time with day & date
- **Weather** — Open-Meteo (no API key required), editable location
- **Calendar** — current month with today highlighted
- **Notifications** — dismissible feed
- **Notepad** — autosaves to `~/.local/share/nyxus-home/notepad.txt`
- **Password Manager** — entries indexed in JSON, **passwords encrypted by
  the OS via Secret Service / GNOME Keyring** (never on disk in plaintext
  unless the keyring backend is missing)

## Install

```bash
curl -fsSL https://nyxus-core.replit.app/api/download/nyxus/nyxus_home_install.sh | bash
```

## Launch

```bash
nyxus-home
```

## Files

| Location                                          | Purpose                          |
|---------------------------------------------------|----------------------------------|
| `~/.nyxus/nyxus-home/`                            | App code                         |
| `~/.local/bin/nyxus-home`                         | Launcher script                  |
| `~/.local/share/applications/nyxus-home.desktop`  | Desktop entry                    |
| `~/.config/nyxus-home/config.json`                | Weather location, UI prefs       |
| `~/.local/share/nyxus-home/notepad.txt`           | Notepad autosave                 |
| `~/.local/share/nyxus-home/passwords.json`        | Password entry **index** only    |
| Secret Service (gnome-keyring)                    | Actual encrypted password values |

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
