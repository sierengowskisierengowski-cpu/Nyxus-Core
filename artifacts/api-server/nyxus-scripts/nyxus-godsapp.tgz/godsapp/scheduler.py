"""
NYXUS GodsApp — scheduling engine.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Runs as a background thread inside the main app process. Reads
scheduled-job rows from the godsapp.db `schedules` table and triggers
the corresponding module's CLI handler.
"""
from __future__ import annotations

import threading
import time
from typing import Callable

from db import conn

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Scheduler:
    def __init__(self, dispatch: Callable[[str, str], None]):
        """`dispatch(module_name, target)` is called when a job fires."""
        self.dispatch = dispatch
        self.stop = threading.Event()
        self.thread: threading.Thread | None = None

    def start(self) -> None:
        self.thread = threading.Thread(target=self._loop, daemon=True, name="sched")
        self.thread.start()

    def shutdown(self) -> None:
        self.stop.set()

    def _loop(self) -> None:
        while not self.stop.wait(15):
            now = time.time()
            c = conn()
            cur = c.execute(
                "SELECT id, name, module, target, cadence_seconds "
                "FROM schedules WHERE enabled=1 AND next_run <= ?",
                (now,),
            )
            for sid, name, module, target, cadence in cur.fetchall():
                try:
                    self.dispatch(module, target or "")
                except Exception:
                    pass
                c.execute("UPDATE schedules SET next_run=? WHERE id=?",
                          (now + cadence, sid))


def add_schedule(name: str, module: str, target: str, cadence_seconds: int) -> int:
    c = conn()
    cur = c.execute(
        "INSERT INTO schedules(name, module, target, cadence_seconds, next_run) "
        "VALUES(?,?,?,?,?)",
        (name, module, target, cadence_seconds, time.time() + cadence_seconds),
    )
    return cur.lastrowid


def list_schedules() -> list[dict]:
    cur = conn().execute("SELECT id,name,module,target,cadence_seconds,next_run,enabled "
                         "FROM schedules ORDER BY id")
    return [{"id": r[0], "name": r[1], "module": r[2], "target": r[3],
             "cadence_seconds": r[4], "next_run": r[5], "enabled": bool(r[6])}
            for r in cur.fetchall()]


def toggle_schedule(sid: int, enabled: bool) -> None:
    conn().execute("UPDATE schedules SET enabled=? WHERE id=?",
                   (1 if enabled else 0, sid))


def delete_schedule(sid: int) -> None:
    conn().execute("DELETE FROM schedules WHERE id=?", (sid,))
