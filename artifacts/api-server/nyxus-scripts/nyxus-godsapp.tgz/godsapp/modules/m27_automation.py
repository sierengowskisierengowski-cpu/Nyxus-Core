"""Module 27 — Automation and Scheduling."""
from __future__ import annotations

import time

from ui import BaseModule
import db

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Automation"
    ICON = "⏱"
    DESCRIPTION = ("Schedule recurring scans (any module) at fixed intervals. "
                   "Persisted in sqlite and executed by the GodsApp scheduler thread.")

    PRESETS = [
        ("hourly Quick Surface scan", "m07_attack_surface", 3600),
        ("daily SSL audit",            "m05_vulns",          86400),
        ("daily failed-login report",  "m21_logs",           86400),
        ("weekly full vuln scan",      "m05_vulns",          604800),
    ]

    def build(self):
        self.add_action("📋 list schedules",     self.list_, primary=True)
        for label, mod, sec in self.PRESETS:
            self.add_action(f"➕ {label}",
                            lambda m=mod, s=sec, n=label: self.add(n, m, s))
        self.add_action("🗑 disable all",        self.disable_all, danger=True)

    def list_(self):
        cur = db.conn().execute(
            "SELECT id,name,module,target,cadence_seconds,next_run,enabled FROM schedules ORDER BY id")
        rows = cur.fetchall()
        if not rows:
            self.write("(no schedules)"); return
        for r in rows:
            mins = r[4] // 60
            nxt  = time.strftime("%Y-%m-%d %H:%M", time.localtime(r[5]))
            on   = "ON " if r[6] else "off"
            self.write(f"  [{r[0]:>3}] {on}  every {mins:>5} min  next={nxt}  {r[1]}")

    def add(self, name: str, module: str, secs: int):
        db.conn().execute(
            "INSERT INTO schedules(name,module,target,cadence_seconds,next_run,enabled) "
            "VALUES(?,?,?,?,?,1)", (name, module, self.target or "", secs, time.time()+secs))
        self.write(f"added: {name} (every {secs//60} min)")

    def disable_all(self):
        db.conn().execute("UPDATE schedules SET enabled=0")
        self.write("all schedules disabled")
