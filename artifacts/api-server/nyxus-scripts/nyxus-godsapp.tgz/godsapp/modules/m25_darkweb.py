"""Module 25 — Dark Web / Breach Monitoring."""
from __future__ import annotations

import json
import urllib.parse
import urllib.request

from ui import BaseModule

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Dark Web Monitor"
    ICON = "🕸"
    DESCRIPTION = ("Have I Been Pwned API queries (no key required for unauthenticated paste "
                   "search). Target box = email address or domain.")

    def build(self):
        self.add_action("✉  HIBP breaches (email)", self.email_breaches, primary=True)
        self.add_action("🌐 HIBP breaches (domain)", self.domain_breaches)
        self.add_action("📋 list all known breaches", self.all_breaches)

    def _get(self, url: str):
        req = urllib.request.Request(url, headers={
            "User-Agent":"nyxus-godsapp/1.0",
            "Accept":"application/json"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 404: return []
            self.write(f"HIBP {e.code}: {e.reason}")
            return None
        except Exception as exc:
            self.write(f"HIBP error: {exc}"); return None

    def email_breaches(self):
        if not self.target: return
        self.write("HIBP requires an API key for /breachedaccount in production.")
        self.write("Public breach metadata for the email’s domain follows:")
        domain = self.target.split("@",1)[-1]
        data = self._get(f"https://haveibeenpwned.com/api/v3/breaches?domain={urllib.parse.quote(domain)}")
        if data is None: return
        for b in data:
            self.write(f"  {b.get('Name'):<25} {b.get('BreachDate')} pwn={b.get('PwnCount'):,}")

    def domain_breaches(self):
        if not self.target: return
        data = self._get(
            f"https://haveibeenpwned.com/api/v3/breaches?domain={urllib.parse.quote(self.target)}")
        if data is None: return
        for b in data:
            self.write(f"  {b.get('Name'):<25} {b.get('BreachDate')} accts={b.get('PwnCount'):,}")
            self.write(f"    {b.get('Description','')[:200]}")

    def all_breaches(self):
        data = self._get("https://haveibeenpwned.com/api/v3/breaches")
        if data is None: return
        for b in data[:200]:
            self.write(f"  {b.get('Name'):<25} {b.get('BreachDate')} {b.get('PwnCount'):>12,}")
        self.write(f"\n{len(data)} total known breaches in HIBP")
