"""Module 11 — USB and Hardware Monitor."""
from __future__ import annotations

import time

from ui import BaseModule, run_subprocess
import db

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "USB / Hardware"
    ICON = "🔌"
    DESCRIPTION = ("Live USB enumeration via lsusb / udevadm, BadUSB / mass-storage "
                   "warnings, dmesg device events, and PCI hardware inventory.")

    def build(self):
        self.add_action("📋 lsusb",                self.lsusb, primary=True)
        self.add_action("📜 dmesg (last 200)",     self.dmesg)
        self.add_action("🧷 udevadm monitor 30 s", self.udev)
        self.add_action("🖥 PCI devices",         self.pci)
        self.add_action("⚠  USBGuard policy",      self.usbguard)

    def lsusb(self):
        if not self.need("lsusb"):
            return
        rc, out = run_subprocess(["lsusb","-v"], timeout=20)
        self.write(out[:60000])
        rc, brief = run_subprocess(["lsusb"], timeout=10)
        self.write("\n--- summary ---\n" + brief)
        for line in brief.splitlines():
            parts = line.split()
            if len(parts) >= 6 and parts[0] == "Bus":
                vidpid = parts[5]
                desc = " ".join(parts[6:])
                db.see_device(vidpid.lower(), vendor=desc)

    def dmesg(self):
        rc, out = run_subprocess(["dmesg","-T","--ctime"], timeout=15)
        tail = "\n".join(out.splitlines()[-200:])
        self.write(tail)

    def udev(self):
        if not self.need("udevadm"):
            return
        # short non-blocking watch
        rc, out = run_subprocess(["timeout","30","udevadm","monitor","--udev"], timeout=35)
        self.write(out)

    def pci(self):
        if not self.need("lspci"):
            return
        rc, out = run_subprocess(["lspci","-vnn"], timeout=15)
        self.write(out)

    def usbguard(self):
        rc, out = run_subprocess(["usbguard","list-devices"], timeout=10)
        self.write(out or "usbguard not installed — `sudo pacman -S usbguard`")
