"""Module 18 — Industrial / SCADA / IoT."""
from __future__ import annotations

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "SCADA / ICS"
    ICON = "🏭"
    DESCRIPTION = ("Modbus, S7, BACnet, DNP3 and EtherNet/IP enumeration via Nmap NSE. "
                   "READ-ONLY identity probes — never sends control writes.")

    def build(self):
        self.add_action("⚙  Modbus discover (502)", self.modbus, primary=True)
        self.add_action("🏭 Siemens S7 (102)",       self.s7)
        self.add_action("🌡  BACnet (47808/UDP)",    self.bacnet)
        self.add_action("⚡ EtherNet/IP (44818)",     self.enip)
        self.add_action("📡 DNP3 (20000)",           self.dnp3)
        self.add_action("🌐 IoT banners (top 100 ports)", self.banners)

    def modbus(self):
        if not self.target or not self.need("nmap"): return
        rc, out = run_subprocess(
            ["nmap","-p","502","--script","modbus-discover", self.target], timeout=120)
        self.write(out)

    def s7(self):
        if not self.target or not self.need("nmap"): return
        rc, out = run_subprocess(
            ["nmap","-p","102","--script","s7-info", self.target], timeout=120)
        self.write(out)

    def bacnet(self):
        if not self.target or not self.need("nmap"): return
        rc, out = run_subprocess(
            ["nmap","-sU","-p","47808","--script","bacnet-info", self.target], timeout=120)
        self.write(out)

    def enip(self):
        if not self.target or not self.need("nmap"): return
        rc, out = run_subprocess(
            ["nmap","-p","44818","--script","enip-info", self.target], timeout=120)
        self.write(out)

    def dnp3(self):
        if not self.target or not self.need("nmap"): return
        rc, out = run_subprocess(
            ["nmap","-p","20000","--script","dnp3-info", self.target], timeout=120)
        self.write(out)

    def banners(self):
        if not self.target or not self.need("nmap"): return
        rc, out = run_subprocess(["nmap","-sV","--top-ports","100","--version-intensity","2", self.target],
                                  timeout=600)
        self.write(out)
