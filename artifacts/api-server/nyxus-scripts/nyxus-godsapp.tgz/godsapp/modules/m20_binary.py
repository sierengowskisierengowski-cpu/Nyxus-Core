"""Module 20 — Binary and File Analysis."""
from __future__ import annotations

import hashlib
from pathlib import Path

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Binary Analysis"
    ICON = "🧩"
    DESCRIPTION = ("file, strings, objdump, readelf, nm, ldd, checksec.sh, and "
                   "rabin2 (radare2) if available. Target box = path to a binary.")

    def build(self):
        self.add_action("📄 file + sha256",     self.fileinfo, primary=True)
        self.add_action("🔡 strings",           self.strings)
        self.add_action("📚 readelf -h -d",     self.readelf)
        self.add_action("🛠 ldd / dynamic libs", self.ldd)
        self.add_action("🔒 checksec",          self.checksec)
        self.add_action("⚡ rabin2 -I",          self.rabin2)

    def _path(self) -> Path | None:
        p = Path(self.target).expanduser()
        if not p.is_file():
            self.write(f"file not found: {p}"); return None
        return p

    def fileinfo(self):
        p = self._path()
        if not p: return
        rc, out = run_subprocess(["file","-b", str(p)], timeout=10)
        self.write("type: " + out.strip())
        h = hashlib.sha256()
        with open(p,"rb") as f:
            for c in iter(lambda: f.read(65536), b""): h.update(c)
        self.write(f"sha256: {h.hexdigest()}\nsize:   {p.stat().st_size}")

    def strings(self):
        p = self._path()
        if not p: return
        rc, out = run_subprocess(["strings","-n","8", str(p)], timeout=60)
        self.write("\n".join(out.splitlines()[:500]))

    def readelf(self):
        p = self._path()
        if not p or not self.need("readelf"): return
        rc, out = run_subprocess(["readelf","-h","-d","-l", str(p)], timeout=30)
        self.write(out)

    def ldd(self):
        p = self._path()
        if not p or not self.need("ldd"): return
        rc, out = run_subprocess(["ldd", str(p)], timeout=30)
        self.write(out)

    def checksec(self):
        p = self._path()
        if not p or not self.need("checksec"): return
        rc, out = run_subprocess(["checksec","--file="+str(p)], timeout=30)
        self.write(out)

    def rabin2(self):
        p = self._path()
        if not p or not self.need("rabin2"): return
        rc, out = run_subprocess(["rabin2","-I", str(p)], timeout=30)
        self.write(out)
