"""Module 30 — Built-in Terminal."""
from __future__ import annotations

import shlex

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────


ALLOWED_PREFIXES = (
    "nmap","dig","whois","curl","ip","ss","ping","traceroute","tcpdump","arp","arp-scan",
    "nikto","gobuster","dirb","sqlmap","wapiti","searchsploit","clamscan","yara","strings",
    "file","openssl","gpg","journalctl","dmesg","lsusb","lspci","lsmod","systemctl","ufw",
    "iptables","nft","mokutil","bootctl","dmidecode","tpm2_getcap","aws","gcloud","az",
    "adb","ideviceinfo","ideviceinstaller","setoolkit","mmls","fls","vol","echo","cat",
    "ls","head","tail","wc","sort","uniq","grep","awk","sed","ps","top","htop","uname",
    "hostnamectl","ip-route","ip-link","ip-addr","ip-neigh"
)


class Page(BaseModule):
    NAME = "Terminal"
    ICON = "💻"
    DESCRIPTION = ("Run security tools directly from inside GodsApp. Output is captured "
                   "to the pane and recorded in the scan database. Allow-listed binaries only.")

    def build(self):
        self.input = self.target  # not used; we use the global target box as command
        self.add_action("▶ run command (target box)", self.run_cmd, primary=True)
        for preset in (
            "nmap -sV --top-ports 100 192.168.1.1",
            "dig +short example.com ANY",
            "ss -tulpn",
            "journalctl -p err --since today",
            "ip -br addr",
            "ufw status verbose",
            "lsusb",
        ):
            self.add_action(f"📋 {preset}", lambda c=preset: self.run_preset(c))

    def _allowed(self, cmd_list: list[str]) -> bool:
        if not cmd_list: return False
        bin_name = cmd_list[0].split("/")[-1]
        return any(bin_name == p or bin_name.startswith(p+"-") for p in ALLOWED_PREFIXES)

    def run_cmd(self):
        cmd = self.target.strip()
        if not cmd:
            self.write("type a command in the target box, e.g.  nmap -sV scanme.nmap.org")
            return
        try:
            parts = shlex.split(cmd)
        except ValueError as e:
            self.write(f"parse error: {e}"); return
        if not self._allowed(parts):
            self.write(f"⚠  blocked: '{parts[0]}' is not on the allow-list.\n"
                        f"Allow-list: {', '.join(ALLOWED_PREFIXES[:30])}…")
            return
        self.write(f"$ {cmd}")
        rc, out = run_subprocess(parts, timeout=600)
        self.write(out + f"\n[exit {rc}]")
        import db
        db.record_scan(self.NAME, "", "terminal", cmd, f"rc={rc}")

    def run_preset(self, cmd: str):
        # temporarily override
        old = self.app.target_input.get_text() if self.app else ""
        self.app.target_input.set_text(cmd)
        try:
            self.run_cmd()
        finally:
            self.app.target_input.set_text(old)
