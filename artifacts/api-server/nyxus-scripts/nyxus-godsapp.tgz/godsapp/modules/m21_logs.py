"""Module 21 — Log Analysis Engine."""
from __future__ import annotations

import re
from collections import Counter

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Log Analysis"
    ICON = "📜"
    DESCRIPTION = ("journalctl + auth.log triage: failed logins, sudo abuse, kernel "
                   "anomalies, brute-force IPs, and per-unit error counts.")

    def build(self):
        self.add_action("🚨 failed logins (today)", self.failed, primary=True)
        self.add_action("🛂 sudo events (today)",   self.sudo)
        self.add_action("🐧 kernel errors (today)", self.kernel)
        self.add_action("📊 top noisy units",       self.top_units)
        self.add_action("🌐 brute-force source IPs", self.brute_ips)

    def failed(self):
        rc, out = run_subprocess(
            ["journalctl","--since","today","-g","Failed password|authentication failure",
             "--no-pager","-q"], timeout=20)
        self.write(out or "(no failed logins today)")

    def sudo(self):
        rc, out = run_subprocess(
            ["journalctl","_COMM=sudo","--since","today","--no-pager","-q"], timeout=20)
        self.write(out or "(no sudo activity today)")

    def kernel(self):
        rc, out = run_subprocess(
            ["journalctl","-k","--since","today","-p","err","--no-pager","-q"], timeout=20)
        self.write(out or "(no kernel errors today)")

    def top_units(self):
        rc, out = run_subprocess(
            ["journalctl","--since","today","-p","err","-o","short-iso","--no-pager","-q"], timeout=20)
        units: Counter[str] = Counter()
        for line in out.splitlines():
            m = re.search(r"\b([\w.-]+)\[\d+\]:", line)
            if m: units[m.group(1)] += 1
        for unit, n in units.most_common(20):
            self.write(f"  {n:>6}  {unit}")

    def brute_ips(self):
        rc, out = run_subprocess(
            ["journalctl","--since","today","-g","Failed password","--no-pager","-q"], timeout=30)
        ips: Counter[str] = Counter()
        for line in out.splitlines():
            m = re.search(r"from\s+(\d+\.\d+\.\d+\.\d+)", line)
            if m: ips[m.group(1)] += 1
        for ip, n in ips.most_common(40):
            self.write(f"  {n:>6}  {ip}")
        if not ips: self.write("(no brute-force sources today)")
