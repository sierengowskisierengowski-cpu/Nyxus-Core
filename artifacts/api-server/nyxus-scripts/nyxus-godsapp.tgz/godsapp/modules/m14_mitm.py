"""Module 14 — MITM Framework (defensive posture)."""
from __future__ import annotations

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "MITM Framework"
    ICON = "🪞"
    DESCRIPTION = ("Defensive ARP / DNS / SSL anomaly detection plus active toolkits "
                   "(arp-scan, mitmproxy, ettercap) for authorised lab testing.")

    def build(self):
        self.add_action("📋 ARP table",          self.arp_table, primary=True)
        self.add_action("🔎 arp-scan local",     self.arp_scan)
        self.add_action("🛡  ARP poisoning watch (10 s)", self.arp_watch)
        self.add_action("🌐 DNS resolver test",  self.dns_test)
        self.add_action("ℹ  mitmproxy status",   self.mitm)
        self.add_action("ℹ  ettercap NG check",  self.ettercap)

    def arp_table(self):
        rc, out = run_subprocess(["ip","neigh","show"], timeout=5); self.write(out)

    def arp_scan(self):
        if not self.need("arp-scan"): return
        rc, out = run_subprocess(["arp-scan","--localnet"], timeout=60); self.write(out)

    def arp_watch(self):
        # snapshot, sleep, snapshot, diff
        rc, a = run_subprocess(["ip","neigh","show"], timeout=5)
        rc, _ = run_subprocess(["sleep","10"], timeout=12)
        rc, b = run_subprocess(["ip","neigh","show"], timeout=5)
        sa = {l.split(maxsplit=4)[0]: l for l in a.splitlines() if l}
        sb = {l.split(maxsplit=4)[0]: l for l in b.splitlines() if l}
        for ip in set(sa) | set(sb):
            if sa.get(ip) != sb.get(ip):
                self.write(f"⚠  changed {ip}\n  was: {sa.get(ip,'(absent)')}\n  now: {sb.get(ip,'(absent)')}")
        if all(sa.get(ip) == sb.get(ip) for ip in set(sa) | set(sb)):
            self.write("ARP table stable — no changes in 10 s")

    def dns_test(self):
        if not self.need("dig"): return
        for resolver in ("1.1.1.1","8.8.8.8","9.9.9.9"):
            rc, out = run_subprocess(["dig","@"+resolver,"+short", self.target or "example.com"], timeout=5)
            self.write(f"{resolver}: {out.strip() or '(no answer)'}")

    def mitm(self):
        rc, out = run_subprocess(["mitmproxy","--version"], timeout=5); self.write(out)

    def ettercap(self):
        rc, out = run_subprocess(["ettercap","-v"], timeout=5); self.write(out)
