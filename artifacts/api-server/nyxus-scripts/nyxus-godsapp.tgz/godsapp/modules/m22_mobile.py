"""Module 22 — Mobile Device Security."""
from __future__ import annotations

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Mobile"
    ICON = "📱"
    DESCRIPTION = ("Android (adb) + iOS (libimobiledevice) inspection. Lists devices, "
                   "installed packages, debug-bridge security posture, MDM hints.")

    def build(self):
        self.add_action("📱 adb devices",         self.adb_devices, primary=True)
        self.add_action("📦 adb installed packages", self.adb_pkgs)
        self.add_action("🛂 adb dangerous perms", self.adb_perms)
        self.add_action("🍎 ideviceinfo",         self.ideviceinfo)
        self.add_action("🍎 ideviceinstaller -l", self.ideviceinstaller)

    def adb_devices(self):
        if not self.need("adb"): return
        rc, out = run_subprocess(["adb","devices","-l"], timeout=10); self.write(out)

    def adb_pkgs(self):
        if not self.need("adb"): return
        rc, out = run_subprocess(["adb","shell","pm","list","packages","-3"], timeout=30)
        self.write(out)

    def adb_perms(self):
        if not self.need("adb"): return
        rc, pkgs = run_subprocess(["adb","shell","pm","list","packages","-3"], timeout=30)
        for line in pkgs.splitlines()[:30]:
            pkg = line.replace("package:","").strip()
            rc, perms = run_subprocess(
                ["adb","shell","dumpsys","package", pkg], timeout=10)
            risky = [p for p in perms.splitlines() if "granted=true" in p and any(
                k in p.lower() for k in ("camera","location","contacts","sms","record_audio"))]
            if risky:
                self.write(f"\n--- {pkg} ---")
                for r in risky: self.write("  " + r.strip())

    def ideviceinfo(self):
        rc, out = run_subprocess(["ideviceinfo"], timeout=15)
        self.write(out or "libimobiledevice not installed")

    def ideviceinstaller(self):
        rc, out = run_subprocess(["ideviceinstaller","-l"], timeout=30)
        self.write(out or "ideviceinstaller not installed")
