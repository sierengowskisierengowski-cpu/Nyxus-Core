"""Module 29 — God Mode Master Dashboard."""
from __future__ import annotations

import time

from ui import BaseModule, run_subprocess
import db

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "✦ GOD MODE"
    ICON = "✦"
    DESCRIPTION = ("One-button master scan. Runs a curated subset of modules against the "
                   "target box and aggregates findings into a single dashboard.")

    SEQUENCE = [
        ("WHOIS",        ["whois"]),
        ("DNS records",  ["dig","+short","ANY"]),
        ("Top 1000 ports + versions", ["nmap","-Pn","--top-ports","1000","-sV","-T4"]),
        ("OS guess",     ["nmap","-Pn","-O","--osscan-guess"]),
        ("Vuln scripts", ["nmap","--script","vuln","-sV"]),
        ("HTTP banner",  ["curl","-sI","--max-time","10"]),
    ]

    def build(self):
        self.add_action("✦ RUN GOD MODE",        self.go, primary=True)
        self.add_action("📊 dashboard summary",   self.dashboard)
        self.add_action("📋 last 50 findings",   self.findings)

    def go(self):
        if not self.target:
            self.write("type a target in the box first"); return
        self.write(f"=== GOD MODE START ({time.strftime('%H:%M:%S')}) — target {self.target} ===\n")
        for label, cmd in self.SEQUENCE:
            self.write(f"\n--- {label} ---")
            full = list(cmd) + [self.target]
            rc, out = run_subprocess(full, timeout=600)
            self.write(out[:8000])
            db.record_scan("GOD MODE", self.target, label, " ".join(full), f"rc={rc}")
        self.write(f"\n=== GOD MODE COMPLETE ({time.strftime('%H:%M:%S')}) ===")

    def dashboard(self):
        c = db.conn()
        scans = c.execute("SELECT COUNT(*) FROM scans").fetchone()[0]
        finds = c.execute("SELECT COUNT(*) FROM findings").fetchone()[0]
        crit  = c.execute("SELECT COUNT(*) FROM findings WHERE severity IN ('CRIT','HIGH')").fetchone()[0]
        cves  = c.execute("SELECT COUNT(*) FROM cve_cache").fetchone()[0]
        devs  = c.execute("SELECT COUNT(*) FROM device_history").fetchone()[0]
        self.write(f"scans recorded   : {scans}")
        self.write(f"findings total   : {finds}")
        self.write(f"  CRIT/HIGH      : {crit}")
        self.write(f"CVEs cached      : {cves}")
        self.write(f"devices observed : {devs}")
        self.write("\nrecent scans:")
        for r in db.list_recent_scans(10):
            ts = time.strftime("%H:%M:%S", time.localtime(r["ts"]))
            self.write(f"  {ts}  {r['module']:<20} {r['target'] or '':<25} {r['summary'] or ''}")

    def findings(self):
        cur = db.conn().execute(
            "SELECT severity, title, cvss, cve FROM findings ORDER BY id DESC LIMIT 50")
        for sev, title, cvss, cve in cur.fetchall():
            self.write(f"[{sev:<5}] {cvss or 0:>4.1f}  {cve or '':<16}  {title[:120]}")
