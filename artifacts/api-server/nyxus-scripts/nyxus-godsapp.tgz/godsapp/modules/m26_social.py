"""Module 26 — Social Engineering Toolkit (defensive prep)."""
from __future__ import annotations

import textwrap
from pathlib import Path

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Social Engineering"
    ICON = "🎭"
    DESCRIPTION = ("Phishing-awareness lab kit: generate test templates, render landing "
                   "pages, point at gophish/setoolkit if installed. Authorised internal use only.")

    TEMPLATES = {
        "password-reset": (
            "Subject: ⚠ Action required — password reset\n\n"
            "Hi {name},\n\nWe noticed unusual activity on your account. "
            "Please confirm your identity by clicking the link below within 24 hours.\n\n"
            "  → {link}\n\n— IT Security"
        ),
        "package-delivery": (
            "Subject: Your package could not be delivered\n\n"
            "Carrier was unable to deliver order #{order}. "
            "Reschedule via the secure portal: {link}\n"
        ),
        "invoice": (
            "Subject: INVOICE #{n} — overdue\n\n"
            "Please find the attached overdue invoice. Settlement portal: {link}\n"
        ),
    }

    def build(self):
        for k in self.TEMPLATES:
            self.add_action(f"📧 template · {k}", lambda k=k: self.render(k))
        self.add_action("📂 export to ~/nyxus-phishing-lab/", self.export, primary=True)
        self.add_action("ℹ  setoolkit",  self.setoolkit)
        self.add_action("ℹ  gophish",    self.gophish)

    def render(self, k: str):
        t = self.TEMPLATES[k].format(name="<NAME>", link="https://lab.example.test/{}".format(k),
                                      order="ABC-123", n="9472")
        self.write(t)

    def export(self):
        out = Path.home() / "nyxus-phishing-lab"
        out.mkdir(exist_ok=True)
        for k, t in self.TEMPLATES.items():
            (out / f"{k}.eml").write_text(textwrap.dedent(t))
        self.write(f"templates exported → {out}")

    def setoolkit(self):
        rc, out = run_subprocess(["setoolkit","--version"], timeout=5)
        self.write(out or "setoolkit not installed")

    def gophish(self):
        rc, out = run_subprocess(["gophish","--version"], timeout=5)
        self.write(out or "gophish not installed — see https://getgophish.com")
