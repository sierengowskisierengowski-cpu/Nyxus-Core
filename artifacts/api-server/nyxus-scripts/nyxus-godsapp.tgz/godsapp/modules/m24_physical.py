"""Module 24 — Physical Security."""
from __future__ import annotations

from pathlib import Path

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Physical Security"
    ICON = "🔒"
    DESCRIPTION = ("Webcam / mic exposure, kernel-locked-down state, secure-boot, "
                   "TPM presence, BIOS security, port and lid sensor checks.")

    def build(self):
        self.add_action("📷 video / mic devices",  self.video_mic, primary=True)
        self.add_action("🛡  Secure Boot status",   self.secboot)
        self.add_action("🧷 TPM presence",          self.tpm)
        self.add_action("🔧 BIOS / DMI",            self.dmi)
        self.add_action("🐧 kernel lockdown",       self.lockdown)
        self.add_action("🔌 USB port count",        self.usbports)

    def video_mic(self):
        for d in sorted(Path("/dev").glob("video*")):
            self.write(f"video device: {d}")
        for d in sorted(Path("/proc/asound").glob("card*")):
            self.write(f"audio card  : {d.name}")
        rc, out = run_subprocess(["arecord","-l"], timeout=10); self.write(out)

    def secboot(self):
        rc, out = run_subprocess(["mokutil","--sb-state"], timeout=5)
        self.write(out or "mokutil not present")
        rc, out = run_subprocess(["bootctl","status"], timeout=5)
        self.write(out)

    def tpm(self):
        for d in ("/dev/tpm0","/dev/tpmrm0"):
            self.write(f"{d}: {'present' if Path(d).exists() else 'absent'}")
        rc, out = run_subprocess(["tpm2_getcap","properties-fixed"], timeout=10)
        if out: self.write(out[:4000])

    def dmi(self):
        rc, out = run_subprocess(
            ["bash","-c","sudo -n dmidecode -t bios -t system -t chassis 2>&1 || dmidecode -t bios -t system -t chassis 2>&1"],
            timeout=15)
        self.write(out)

    def lockdown(self):
        try:
            self.write("kernel lockdown: " + Path("/sys/kernel/security/lockdown").read_text().strip())
        except Exception as e:
            self.write(f"(unavailable: {e})")

    def usbports(self):
        rc, out = run_subprocess(["lsusb"], timeout=10)
        self.write(out)
        self.write(f"\n{len(out.splitlines())} USB devices currently enumerated")
