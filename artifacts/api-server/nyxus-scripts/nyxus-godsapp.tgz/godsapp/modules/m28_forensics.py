"""Module 28 — Forensics."""
from __future__ import annotations

import hashlib
import time
from pathlib import Path

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Forensics"
    ICON = "🧪"
    DESCRIPTION = ("Disk imaging (dd / dcfldd), Sleuthkit triage, Volatility memory "
                   "analysis, evidence hashing + chain-of-custody log.")

    def build(self):
        self.add_action("🧷 hash file (sha256+md5)",     self.hash_file, primary=True)
        self.add_action("📦 dd image (target → ~/evidence)", self.dd_image)
        self.add_action("📂 fls / mmls (Sleuthkit)",     self.sleuthkit)
        self.add_action("🧠 vol2 image info",            self.vol_imageinfo)
        self.add_action("📓 view chain-of-custody",      self.coc)

    def _coc_path(self) -> Path:
        d = Path.home() / "evidence"; d.mkdir(exist_ok=True)
        return d / "chain_of_custody.log"

    def hash_file(self):
        p = Path(self.target).expanduser()
        if not p.is_file(): self.write(f"not a file: {p}"); return
        sha = hashlib.sha256(); md = hashlib.md5()
        with open(p,"rb") as f:
            for c in iter(lambda: f.read(1<<16), b""):
                sha.update(c); md.update(c)
        line = f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}  HASH  {p}  sha256={sha.hexdigest()} md5={md.hexdigest()}"
        self.write(line)
        with open(self._coc_path(),"a") as f: f.write(line + "\n")

    def dd_image(self):
        if not self.target: return
        src = self.target
        dst = Path.home() / "evidence" / (Path(src).name + f".{int(time.time())}.img")
        dst.parent.mkdir(exist_ok=True)
        rc, out = run_subprocess(
            ["sudo","-n","dd",f"if={src}",f"of={dst}","bs=1M","status=progress","conv=noerror,sync"],
            timeout=3600)
        self.write(out + f"\nimage → {dst}")
        line = f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}  IMAGE {src}  →  {dst}"
        with open(self._coc_path(),"a") as f: f.write(line + "\n")

    def sleuthkit(self):
        if not self.target: return
        rc, out = run_subprocess(["mmls", self.target], timeout=60); self.write(out)
        rc, out = run_subprocess(["fls","-r", self.target], timeout=120); self.write(out[:60000])

    def vol_imageinfo(self):
        if not self.target: return
        # Volatility 3 syntax
        rc, out = run_subprocess(["vol","-f", self.target, "windows.info"], timeout=300)
        self.write(out or "install volatility3 (`pip install volatility3`)")

    def coc(self):
        p = self._coc_path()
        if not p.exists():
            self.write("(no chain-of-custody entries yet)"); return
        self.write(p.read_text())
