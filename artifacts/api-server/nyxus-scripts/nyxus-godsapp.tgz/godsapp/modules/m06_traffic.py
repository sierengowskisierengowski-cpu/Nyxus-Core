"""Module 06 — Traffic Intelligence. tcpdump + per-flow stats."""
from __future__ import annotations

import re
import shutil
import subprocess
import time
from collections import Counter
from pathlib import Path

from ui import BaseModule, run_subprocess
import db

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Traffic Intelligence"
    ICON = "📡"
    DESCRIPTION = ("Live tcpdump capture + per-talker / per-port flow stats. "
                   "Saves a rolling pcap to ~/.cache/nyxus-godsapp/.")

    def build(self):
        self.add_action("▶ 30 s capture", self.capture, primary=True)
        self.add_action("📊 Top talkers (last pcap)", self.top_talkers)
        self.add_action("🔎 DNS query log",  self.dns_log)
        self.add_action("⚠  Plaintext creds (telnet/ftp/http auth)", self.plain)

    def _iface(self) -> str:
        # default route iface
        try:
            r = subprocess.run(["ip","route","get","1.1.1.1"], capture_output=True, text=True, timeout=3)
            m = re.search(r"dev (\S+)", r.stdout)
            return m.group(1) if m else "any"
        except Exception:
            return "any"

    def capture(self):
        if not self.need("tcpdump"):
            return
        iface = self._iface()
        out_pcap = Path.home() / ".cache/nyxus-godsapp/last.pcap"
        cmd = ["tcpdump","-i",iface,"-w",str(out_pcap),"-G","30","-W","1"]
        self.write(f"$ {' '.join(cmd)}\n")
        rc, out = run_subprocess(cmd, timeout=45)
        self.write(out + f"\nsaved → {out_pcap}")
        db.record_scan(self.NAME, iface, "capture30", " ".join(cmd), f"rc={rc}", str(out_pcap))

    def top_talkers(self):
        pcap = Path.home() / ".cache/nyxus-godsapp/last.pcap"
        if not pcap.exists() or not self.need("tcpdump"):
            self.write("no capture yet — run a 30 s capture first")
            return
        rc, out = run_subprocess(["tcpdump","-r",str(pcap),"-nn","-q"], timeout=60)
        srcs: Counter[str] = Counter()
        for line in out.splitlines():
            m = re.search(r"IP6?\s+([\w:.]+)\s*[.:]\d+\s*>", line)
            if m: srcs[m.group(1)] += 1
        self.write("top 20 source IPs:")
        for ip, n in srcs.most_common(20):
            self.write(f"  {n:>6}  {ip}")

    def dns_log(self):
        if not self.need("tcpdump"):
            return
        iface = self._iface()
        rc, out = run_subprocess(
            ["tcpdump","-i",iface,"-nn","-c","100","port","53"], timeout=60
        )
        self.write(out)

    def plain(self):
        if not self.need("tcpdump"):
            return
        iface = self._iface()
        rc, out = run_subprocess(
            ["tcpdump","-i",iface,"-A","-c","50",
             "tcp port 21 or tcp port 23 or tcp port 80"], timeout=60
        )
        self.write(out)
        for line in out.splitlines():
            if any(k in line.lower() for k in ("password","user ","pass ","authorization:")):
                self.write(f"⚠  plaintext: {line[:140]}")
