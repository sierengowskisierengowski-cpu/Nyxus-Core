"""Module 10 — Bluetooth Scanner."""
from __future__ import annotations

from ui import BaseModule, run_subprocess
import db

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Bluetooth"
    ICON = "📶"
    DESCRIPTION = ("Bluetooth Classic + BLE discovery via bluetoothctl / hcitool / btmgmt. "
                   "Lists devices, services, and weak/legacy pairing modes.")

    def build(self):
        self.add_action("📡 scan 30 s",            self.scan, primary=True)
        self.add_action("🔎 BLE scan (bluetoothctl)", self.ble)
        self.add_action("🛰 inquiry (hcitool)",   self.hcitool)
        self.add_action("📋 paired devices",       self.paired)
        self.add_action("🔧 controllers / status", self.status)

    def status(self):
        rc, out = run_subprocess(["bluetoothctl","show"], timeout=10)
        self.write(out)

    def scan(self):
        if not self.need("bluetoothctl"):
            return
        rc, out = run_subprocess(
            ["bluetoothctl","--timeout","30","scan","on"], timeout=45)
        self.write(out)
        rc, devs = run_subprocess(["bluetoothctl","devices"], timeout=10)
        self.write("\n--- discovered ---\n" + devs)
        for line in devs.splitlines():
            parts = line.split(maxsplit=2)
            if len(parts) == 3 and parts[0] == "Device":
                db.see_device(parts[1].lower(), hostname=parts[2], vendor="bt")

    def ble(self):
        if not self.need("bluetoothctl"):
            return
        rc, out = run_subprocess(
            ["bluetoothctl","--timeout","20","scan","le"], timeout=30)
        self.write(out)

    def hcitool(self):
        if not self.need("hcitool"):
            return
        rc, out = run_subprocess(["hcitool","scan"], timeout=20)
        self.write(out)
        rc, out = run_subprocess(["hcitool","inq"], timeout=20)
        self.write("\n--- inquiry ---\n" + out)

    def paired(self):
        rc, out = run_subprocess(["bluetoothctl","paired-devices"], timeout=10)
        self.write(out or "(none paired)")
