"""Module 13 — Web Application Scanner."""
from __future__ import annotations

import shutil

from ui import BaseModule, run_subprocess
import db

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Web Scanner"
    ICON = "🌐"
    DESCRIPTION = ("nikto, dirb / gobuster, wapiti, sqlmap baseline + WAF detection. "
                   "Flags missing security headers and weak TLS.")

    def build(self):
        self.add_action("🌐 nikto",          self.nikto, primary=True)
        self.add_action("📁 gobuster dir",   self.gobuster)
        self.add_action("📁 dirb",           self.dirb)
        self.add_action("🕷  wapiti",         self.wapiti)
        self.add_action("💉 sqlmap (-u)",    self.sqlmap)
        self.add_action("🛡  WAF detect",     self.wafw00f)
        self.add_action("📋 security headers", self.headers)

    def _u(self) -> str:
        t = self.target
        if not t.startswith(("http://","https://")): t = "http://"+t
        return t

    def nikto(self):
        if not self.target or not self.need("nikto"): return
        rc, out = run_subprocess(["nikto","-h",self._u()], timeout=900); self.write(out)
        db.record_scan(self.NAME, self.target, "nikto", "nikto", f"rc={rc}")

    def gobuster(self):
        if not self.target or not self.need("gobuster"): return
        wl = "/usr/share/wordlists/dirb/common.txt"
        rc, out = run_subprocess(["gobuster","dir","-q","-u",self._u(),"-w",wl,"-t","30"], timeout=600)
        self.write(out)

    def dirb(self):
        if not self.target or not self.need("dirb"): return
        rc, out = run_subprocess(["dirb", self._u()], timeout=600); self.write(out)

    def wapiti(self):
        if not self.target or not self.need("wapiti"): return
        rc, out = run_subprocess(["wapiti","-u",self._u(),"-f","txt","-o","/tmp/wapiti"], timeout=900)
        self.write(out)

    def sqlmap(self):
        if not self.target or not self.need("sqlmap"): return
        rc, out = run_subprocess(["sqlmap","-u",self._u(),"--batch","--crawl","2","--level","2"], timeout=900)
        self.write(out)

    def wafw00f(self):
        if not self.target: return
        if shutil.which("wafw00f"):
            rc, out = run_subprocess(["wafw00f", self._u()], timeout=60); self.write(out)
        else:
            self.write("install wafw00f for WAF detection")

    def headers(self):
        if not self.target: return
        import urllib.request
        try:
            req = urllib.request.Request(self._u(), headers={"User-Agent":"nyxus-godsapp/1.0"})
            r = urllib.request.urlopen(req, timeout=15)
            hdrs = dict(r.headers)
        except Exception as exc:
            self.write(f"error: {exc}"); return
        recommended = ["Strict-Transport-Security","Content-Security-Policy","X-Frame-Options",
                       "X-Content-Type-Options","Referrer-Policy","Permissions-Policy"]
        self.write("--- response headers ---")
        for k,v in hdrs.items(): self.write(f"  {k}: {v}")
        self.write("\n--- missing recommended ---")
        for h in recommended:
            if h not in hdrs: self.write(f"  ⚠  missing: {h}")
