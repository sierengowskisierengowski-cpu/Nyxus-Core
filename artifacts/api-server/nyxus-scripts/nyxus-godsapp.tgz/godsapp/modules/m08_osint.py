"""Module 08 — OSINT Engine."""
from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request

from ui import BaseModule, run_subprocess
import db

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "OSINT Engine"
    ICON = "🕵"
    DESCRIPTION = ("Open-source intelligence collection: DNS records, WHOIS, "
                   "Wayback Machine snapshots, GitHub mentions, email harvesting via dorks.")

    def build(self):
        self.add_action("📜 DNS records (all)",   self.dns_all, primary=True)
        self.add_action("🕰  Wayback snapshots",   self.wayback)
        self.add_action("📨 email patterns",      self.emails)
        self.add_action("🐙 GitHub mentions",     self.github)
        self.add_action("📰 dork: PDFs",          lambda: self.dork("filetype:pdf"))
        self.add_action("📰 dork: index of",      lambda: self.dork("intitle:\"index of\""))

    def dns_all(self):
        if not self.target or not self.need("dig"):
            return
        for rt in ("A","AAAA","MX","NS","TXT","SOA","CAA","SRV"):
            rc, out = run_subprocess(["dig","+short", rt, self.target], timeout=10)
            self.write(f"--- {rt} ---\n{out or '(none)'}")
        db.record_scan(self.NAME, self.target, "dns", "dig", "ok")

    def wayback(self):
        if not self.target:
            return
        url = ("http://web.archive.org/cdx/search/cdx?output=json&fl=timestamp,original"
               f"&limit=50&url={urllib.parse.quote(self.target)}")
        try:
            with urllib.request.urlopen(url, timeout=20) as r:
                rows = json.load(r)
        except Exception as exc:
            self.write(f"wayback error: {exc}"); return
        for row in rows[1:]:
            self.write(f"  {row[0]}  {row[1][:120]}")

    def emails(self):
        if not self.target:
            return
        # google dork via duckduckgo lite (no JS)
        q = f'site:{self.target} ("@" OR "email" OR "contact")'
        try:
            req = urllib.request.Request(
                "https://duckduckgo.com/html/?q="+urllib.parse.quote(q),
                headers={"User-Agent":"nyxus-godsapp/1.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                html = r.read(200000).decode("utf8","ignore")
        except Exception as exc:
            self.write(f"search error: {exc}"); return
        emails = sorted(set(re.findall(r"[A-Za-z0-9._%+-]+@"+re.escape(self.target), html)))
        for e in emails:
            self.write(f"  {e}")
        if not emails:
            self.write("(no emails matched the target domain in first page)")

    def github(self):
        if not self.target:
            return
        url = "https://api.github.com/search/code?q=" + urllib.parse.quote(self.target)
        try:
            req = urllib.request.Request(url, headers={"Accept":"application/vnd.github+json",
                                                        "User-Agent":"nyxus-godsapp/1.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.load(r)
        except Exception as exc:
            self.write(f"github error (rate-limit?): {exc}"); return
        for item in data.get("items", [])[:30]:
            self.write(f"  {item['repository']['full_name']:<40}  {item['path']}")

    def dork(self, fragment: str):
        if not self.target:
            return
        q = f"site:{self.target} {fragment}"
        url = "https://duckduckgo.com/html/?q=" + urllib.parse.quote(q)
        try:
            req = urllib.request.Request(url, headers={"User-Agent":"nyxus-godsapp/1.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                html = r.read(200000).decode("utf8","ignore")
        except Exception as exc:
            self.write(f"dork error: {exc}"); return
        for m in re.finditer(r'<a [^>]*class="result__a"[^>]*href="([^"]+)"', html):
            self.write(f"  {m.group(1)[:160]}")
