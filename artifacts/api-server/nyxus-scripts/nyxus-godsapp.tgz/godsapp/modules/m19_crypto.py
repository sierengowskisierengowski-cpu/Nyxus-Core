"""Module 19 — Cryptography Suite."""
from __future__ import annotations

import base64
import hashlib
import os
import secrets

from ui import BaseModule, run_subprocess

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



class Page(BaseModule):
    NAME = "Cryptography"
    ICON = "🔐"
    DESCRIPTION = ("OpenSSL helpers + GPG inspection. Generate keys, hash files, "
                   "verify certs, compute HMACs, and detect algorithm weakness.")

    def build(self):
        self.add_action("📜 inspect cert (target)", self.cert_info, primary=True)
        self.add_action("🔑 RSA-4096 keypair",       self.gen_rsa)
        self.add_action("🔑 Ed25519 keypair",        self.gen_ed25519)
        self.add_action("🔢 random 256-bit token",   self.token)
        self.add_action("📝 SHA-256 of target",      self.sha256)
        self.add_action("🛂 GPG list keys",          self.gpg_list)

    def cert_info(self):
        if not self.target or not self.need("openssl"): return
        host, _, port = self.target.partition(":"); port = port or "443"
        rc, out = run_subprocess(
            ["bash","-c", f"echo | openssl s_client -connect {host}:{port} -servername {host} 2>/dev/null "
                          f"| openssl x509 -noout -text -fingerprint -sha256"], timeout=30)
        self.write(out)

    def gen_rsa(self):
        if not self.need("openssl"): return
        rc, key = run_subprocess(["openssl","genpkey","-algorithm","RSA","-pkeyopt","rsa_keygen_bits:4096"],
                                  timeout=60)
        self.write(key)

    def gen_ed25519(self):
        if not self.need("openssl"): return
        rc, key = run_subprocess(["openssl","genpkey","-algorithm","ED25519"], timeout=10)
        self.write(key)

    def token(self):
        self.write(secrets.token_urlsafe(48))
        self.write("hex: " + secrets.token_hex(32))
        self.write("b64: " + base64.b64encode(os.urandom(32)).decode())

    def sha256(self):
        self.write("sha256: " + hashlib.sha256(self.target.encode()).hexdigest())
        self.write("sha3  : " + hashlib.sha3_256(self.target.encode()).hexdigest())
        self.write("blake2: " + hashlib.blake2b(self.target.encode()).hexdigest())

    def gpg_list(self):
        rc, out = run_subprocess(["gpg","--list-keys","--with-fingerprint"], timeout=10)
        self.write(out or "no GPG keys")
