"""
NYXUS GodsApp — main window, sidebar, content stack, BaseModule.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Discovers all `modules/m*.py` files dynamically, instantiates each one,
adds it to the sidebar in order, and lazily loads the page on selection.
"""
from __future__ import annotations

import importlib
import importlib.util
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Callable

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib, Gtk, Gdk, Adw  # noqa: E402

# theme — same fallback as main.py
sys.path.insert(0, "/usr/share/nyxus/theme")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "theme"))
sys.path.insert(0, str(Path.home() / ".local/share/nyxus/theme"))
try:
    from nyxus_theme import COLORS, header, card, make_badge
except ImportError:
    COLORS = {"gold": "#FFD700", "pink": "#C4607A", "purple": "#7B5EA7"}
    def header(t, level=1):
        return Gtk.Label(label=t, xalign=0)
    def card(c, *, active=False):
        f = Gtk.Frame(); f.set_child(c); return f
    def make_badge(s, t=None):
        return Gtk.Label(label=t or s)

# --------------------------------------------------------------------------- #
# constants                                                                   #
# --------------------------------------------------------------------------- #
APP_NAME = "NYXUS GodsApp"
DATA_DIR  = Path.home() / ".config" / "nyxus-godsapp"
CACHE_DIR = Path.home() / ".cache"  / "nyxus-godsapp"
SCAN_DIR  = DATA_DIR / "scans"
AUTHORIZE_FLAG_PATH = DATA_DIR / "authorized.json"
for d in (DATA_DIR, CACHE_DIR, SCAN_DIR):
    d.mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------- #
# subprocess helpers                                                          #
# --------------------------------------------------------------------------- #
def have(*tools: str) -> bool:
    return all(shutil.which(t) for t in tools)


def require_tools(*tools: str) -> str | None:
    """Returns a friendly install message if any tool missing, else None."""
    missing = [t for t in tools if not shutil.which(t)]
    if not missing:
        return None
    return ("Required tool(s) not installed: " + ", ".join(missing) +
            "\n\nInstall with:  sudo pacman -S " + " ".join(missing) +
            "\n           or:  sudo apt install " + " ".join(missing))


def run_subprocess(cmd: list[str], timeout: float = 60,
                   stdin: str | None = None) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout, input=stdin)
        return r.returncode, (r.stdout + ("\n--STDERR--\n" + r.stderr if r.stderr else ""))
    except FileNotFoundError:
        return 127, f"{cmd[0]}: not installed"
    except subprocess.TimeoutExpired:
        return 124, f"timeout after {timeout}s"
    except Exception as exc:
        return 1, f"error: {exc}"


# --------------------------------------------------------------------------- #
# BaseModule — every module page inherits from this                           #
# --------------------------------------------------------------------------- #
class BaseModule(Gtk.Box):
    """Standard GodsApp module page layout.

    Subclasses set NAME, ICON, DESCRIPTION (optional, for module metadata)
    and override `build()` to add action buttons via `self.add_action(...)`.

    Inside an action handler:
        self.write("…")            — append text to the output pane
        self.set_running(True)     — gate the buttons + show spinner
        self.run_in_thread(fn)     — run fn() off the UI thread
        self.target_input.get_text() — current target string
    """
    NAME = "Module"
    ICON = "•"
    DESCRIPTION = ""

    def __init__(self, app=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                         margin_top=14, margin_bottom=14,
                         margin_start=20, margin_end=20)
        self.app = app
        self._buttons: list[Gtk.Button] = []
        self._build_skeleton()
        try:
            self.build()
        except Exception as exc:
            self.write(f"[BUILD ERROR] {exc}")

    def _build_skeleton(self):
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        title = header(f"{self.ICON}  {self.NAME}", level=1)
        head.append(title)
        self.spinner = Gtk.Spinner()
        head.append(self.spinner)
        self.append(head)
        if self.DESCRIPTION:
            d = Gtk.Label(label=self.DESCRIPTION, xalign=0, wrap=True)
            d.get_style_context().add_class("nyx-dim")
            self.append(d)

        # actions row container
        self.actions_row = Gtk.FlowBox(homogeneous=False, max_children_per_line=8,
                                       column_spacing=8, row_spacing=8,
                                       selection_mode=Gtk.SelectionMode.NONE)
        self.append(self.actions_row)

        # output area
        self.output = Gtk.TextView(editable=False, monospace=True,
                                   wrap_mode=Gtk.WrapMode.NONE)
        self.output.get_style_context().add_class("nyx-mono")
        sw = Gtk.ScrolledWindow(vexpand=True, hexpand=True); sw.set_child(self.output)
        self.append(sw)

        # status bar
        self.status = Gtk.Label(label="ready", xalign=0)
        self.status.get_style_context().add_class("nyx-faint")
        self.append(self.status)

    # --- subclass hooks ---------------------------------------------------- #
    def build(self):
        """Override: add action buttons via self.add_action(...)."""

    # --- helpers ----------------------------------------------------------- #
    def add_action(self, label: str, handler: Callable[[], None],
                   primary: bool = False, danger: bool = False):
        b = Gtk.Button(label=label)
        if primary:
            b.get_style_context().add_class("nyx-btn-primary")
        if danger:
            b.get_style_context().add_class("nyx-btn-danger")
        def on_click(_btn):
            self.set_running(True)
            self.run_in_thread(handler)
        b.connect("clicked", on_click)
        self.actions_row.append(b)
        self._buttons.append(b)
        return b

    def write(self, text: str, *, replace: bool = False):
        def do():
            buf = self.output.get_buffer()
            if replace:
                buf.set_text(text)
            else:
                end = buf.get_end_iter()
                buf.insert(end, text + ("\n" if not text.endswith("\n") else ""))
            return False
        GLib.idle_add(do)

    def clear(self):
        self.write("", replace=True)

    def set_status(self, txt: str):
        GLib.idle_add(lambda: (self.status.set_label(txt), False)[1])

    def set_running(self, running: bool):
        def do():
            for b in self._buttons:
                b.set_sensitive(not running)
            if running:
                self.spinner.start()
                self.status.set_label("running …")
            else:
                self.spinner.stop()
                self.status.set_label("ready")
            return False
        GLib.idle_add(do)

    def run_in_thread(self, fn: Callable[[], None]):
        def worker():
            try:
                fn()
            except Exception as exc:
                self.write(f"[ERROR] {exc}")
            finally:
                self.set_running(False)
        threading.Thread(target=worker, daemon=True, name=self.NAME).start()

    @property
    def target(self) -> str:
        if self.app and hasattr(self.app, "target_input"):
            return self.app.target_input.get_text().strip()
        return ""

    def need(self, *tools: str) -> bool:
        msg = require_tools(*tools)
        if msg:
            self.write(msg)
            return False
        return True


# --------------------------------------------------------------------------- #
# Module discovery & loader                                                   #
# --------------------------------------------------------------------------- #
def discover_modules() -> list[tuple[str, type[BaseModule]]]:
    """Scan modules/ directory, import each, return [(label, class), ...]"""
    here = Path(__file__).resolve().parent / "modules"
    out: list[tuple[str, type[BaseModule]]] = []
    if not here.is_dir():
        return out
    for f in sorted(here.glob("m*.py")):
        if f.name.startswith("__"):
            continue
        spec = importlib.util.spec_from_file_location(f.stem, str(f))
        if spec is None or spec.loader is None:
            continue
        try:
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            cls = getattr(mod, "Page", None)
            if cls and issubclass(cls, BaseModule):
                label = f"{getattr(cls, 'ICON', '•')}  {getattr(cls, 'NAME', f.stem)}"
                out.append((label, cls))
        except Exception as exc:
            print(f"[modules] failed to load {f.name}: {exc}", file=sys.stderr)
    return out


# --------------------------------------------------------------------------- #
# MainWindow                                                                  #
# --------------------------------------------------------------------------- #
class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.app = app
        self.set_title(APP_NAME)
        self.set_default_size(1500, 920)

        # header bar
        head = Adw.HeaderBar()
        title = Gtk.Label(label=APP_NAME); title.get_style_context().add_class("title")
        head.set_title_widget(title)

        # target input + scan profile
        self.target_input = Gtk.Entry(placeholder_text="target  (host / IP / range / URL)",
                                       hexpand=True)
        head.pack_start(self.target_input)

        self.profile = Gtk.DropDown.new_from_strings(
            ["Quick","Full","Stealth","Aggressive","Paranoid","Insane","Custom"]
        )
        head.pack_start(self.profile)

        god_btn = Gtk.Button(label="✦ GOD MODE")
        god_btn.get_style_context().add_class("nyx-btn-gold")
        god_btn.connect("clicked", self.on_god_mode)
        head.pack_end(god_btn)

        # outer
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        outer.append(head)

        split = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                        hexpand=True, vexpand=True)

        # sidebar
        sidebar = Gtk.ListBox()
        sidebar.get_style_context().add_class("nyx-sidebar")
        sidebar.set_size_request(260, -1)

        modules = discover_modules()
        self.modules = modules
        self.stack = Gtk.Stack(transition_type=Gtk.StackTransitionType.CROSSFADE,
                               hexpand=True, vexpand=True)
        for label, cls in modules:
            try:
                page = cls(self)
            except Exception as exc:
                page = Gtk.Label(label=f"[load error] {label}: {exc}", xalign=0)
            self.stack.add_named(page, label)
            row = Gtk.Label(label=label, xalign=0,
                            margin_top=2, margin_bottom=2,
                            margin_start=12, margin_end=12)
            sidebar.append(row)

        if not modules:
            self.stack.add_named(Gtk.Label(label="no modules discovered", xalign=0),
                                 "empty")

        sidebar.connect("row-selected", self._on_select)
        sidebar.select_row(sidebar.get_row_at_index(0))

        scroll_sb = Gtk.ScrolledWindow(); scroll_sb.set_child(sidebar)
        scroll_sb.set_size_request(260, -1)
        split.append(scroll_sb)
        split.append(self.stack)

        outer.append(split)

        # status bar
        sb = Gtk.Label(label=f"{APP_NAME} · {len(modules)} modules loaded · "
                             f"target: type a host above and press Enter on any module",
                       xalign=0)
        sb.get_style_context().add_class("nyx-statusbar")
        outer.append(sb)
        self.statusbar = sb

        self.set_content(outer)

    def _on_select(self, lb, row):
        if not row:
            return
        idx = row.get_index()
        if idx < len(self.modules):
            label, _cls = self.modules[idx]
            self.stack.set_visible_child_name(label)

    def on_god_mode(self, _b):
        # GOD MODE = run a curated subset of modules against the current target
        target = self.target_input.get_text().strip()
        if not target:
            self.statusbar.set_label("GOD MODE needs a target — type a host first")
            return
        # delegate to the dedicated GOD MODE module (m29)
        for label, _cls in self.modules:
            if "GOD MODE" in label.upper() or "MASTER" in label.upper():
                self.stack.set_visible_child_name(label)
                return
        self.statusbar.set_label("GOD MODE module not found")
