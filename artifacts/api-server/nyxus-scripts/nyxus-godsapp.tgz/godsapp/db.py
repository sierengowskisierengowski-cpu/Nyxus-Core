"""
NYXUS GodsApp — sqlite scan history + cached lookups.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────


DB_PATH = Path.home() / ".config" / "nyxus-godsapp" / "godsapp.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

SCHEMA = """
CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    module TEXT NOT NULL,
    target TEXT,
    profile TEXT,
    cmd TEXT,
    result_summary TEXT,
    result_path TEXT
);
CREATE INDEX IF NOT EXISTS idx_scan_ts ON scans(ts);
CREATE INDEX IF NOT EXISTS idx_scan_mod ON scans(module);

CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER REFERENCES scans(id),
    severity TEXT NOT NULL,
    title TEXT NOT NULL,
    detail TEXT,
    cvss REAL,
    cve TEXT
);
CREATE INDEX IF NOT EXISTS idx_findings_sev ON findings(severity);

CREATE TABLE IF NOT EXISTS cve_cache (
    cve TEXT PRIMARY KEY,
    cvss REAL,
    description TEXT,
    refs TEXT,
    fetched REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS device_history (
    mac TEXT NOT NULL,
    ip TEXT,
    hostname TEXT,
    vendor TEXT,
    first_seen REAL NOT NULL,
    last_seen REAL NOT NULL,
    PRIMARY KEY(mac)
);

CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    module TEXT NOT NULL,
    target TEXT,
    cadence_seconds INTEGER NOT NULL,
    next_run REAL NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1
);
"""


def conn() -> sqlite3.Connection:
    c = sqlite3.connect(str(DB_PATH), isolation_level=None, check_same_thread=False)
    c.executescript(SCHEMA)
    return c


def record_scan(module: str, target: str, profile: str, cmd: str,
                summary: str, output_path: str | None = None) -> int:
    c = conn()
    cur = c.execute(
        "INSERT INTO scans(ts,module,target,profile,cmd,result_summary,result_path) "
        "VALUES(?,?,?,?,?,?,?)",
        (time.time(), module, target, profile, cmd, summary, output_path),
    )
    return cur.lastrowid


def add_finding(scan_id: int, severity: str, title: str,
                detail: str = "", cvss: float = 0, cve: str = "") -> None:
    conn().execute(
        "INSERT INTO findings(scan_id,severity,title,detail,cvss,cve) VALUES(?,?,?,?,?,?)",
        (scan_id, severity, title, detail, cvss, cve),
    )


def see_device(mac: str, ip: str = "", hostname: str = "", vendor: str = "") -> None:
    now = time.time()
    c = conn()
    row = c.execute("SELECT first_seen FROM device_history WHERE mac=?", (mac,)).fetchone()
    if row:
        c.execute("UPDATE device_history SET ip=?, hostname=?, vendor=?, last_seen=? "
                  "WHERE mac=?", (ip, hostname, vendor, now, mac))
    else:
        c.execute("INSERT INTO device_history VALUES(?,?,?,?,?,?)",
                  (mac, ip, hostname, vendor, now, now))


def cve_get(cve_id: str) -> dict | None:
    row = conn().execute(
        "SELECT cvss, description, refs FROM cve_cache WHERE cve=?",
        (cve_id,)
    ).fetchone()
    if not row:
        return None
    return {"cve": cve_id, "cvss": row[0], "description": row[1], "refs": json.loads(row[2] or "[]")}


def cve_put(cve_id: str, cvss: float, description: str, refs: list[str]) -> None:
    conn().execute(
        "INSERT OR REPLACE INTO cve_cache VALUES(?,?,?,?,?)",
        (cve_id, cvss, description, json.dumps(refs), time.time()),
    )


def list_recent_scans(limit: int = 50) -> list[dict]:
    cur = conn().execute(
        "SELECT id, ts, module, target, result_summary FROM scans "
        "ORDER BY id DESC LIMIT ?", (limit,)
    )
    return [{"id": r[0], "ts": r[1], "module": r[2], "target": r[3], "summary": r[4]}
            for r in cur.fetchall()]
