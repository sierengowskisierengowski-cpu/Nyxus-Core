#!/usr/bin/env python3
"""
NYXUS GodsApp — professional security auditing suite.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Native GTK4. 30 modules. Real backends. No stubs.
First launch presents the authorization gate exactly once.

    sudo nyxus-godsapp           # full capabilities
    nyxus-godsapp                # user mode (limited)
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import GLib, Gtk, Gdk, Adw  # noqa: E402

# theme
sys.path.insert(0, "/usr/share/nyxus/theme")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "theme"))
sys.path.insert(0, str(Path.home() / ".local/share/nyxus/theme"))
try:
    from nyxus_theme import apply_theme, COLORS, header
except ImportError:
    COLORS = {"gold": "#FFD700", "pink": "#C4607A", "purple": "#7B5EA7"}
    def apply_theme(*_a, **_k): pass
    def header(t, level=1):
        return Gtk.Label(label=t, xalign=0)

from ui import MainWindow, AUTHORIZE_FLAG_PATH   # noqa: E402

APP_ID = "co.nyxus.GodsApp"


class AuthorizationGate(Adw.ApplicationWindow):
    """Shown ONCE. Records timestamp + user acceptance. Never reappears."""
    BODY = (
        "NYXUS GodsApp is a professional security auditing and research tool.\n\n"
        "You are solely responsible for ensuring you have proper authorization "
        "before scanning, auditing, or testing any network, system, or device "
        "you do not own. Unauthorized use of these tools may be illegal in "
        "your jurisdiction.\n\n"
        "By continuing you accept full and complete responsibility for how you "
        "use these tools."
    )

    def __init__(self, app):
        super().__init__(application=app, title="NYXUS GodsApp · Authorization")
        self.app = app
        self.set_default_size(720, 520)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                        margin_top=40, margin_bottom=40,
                        margin_start=40, margin_end=40, spacing=18)

        outer.append(header("NYXUS GodsApp", level=1))
        sub = header("authorization required", level=3)
        outer.append(sub)

        body = Gtk.Label(label=self.BODY, wrap=True, xalign=0)
        body.set_max_width_chars(70)
        outer.append(body)

        self.check = Gtk.CheckButton(
            label="I accept full responsibility for my use of these tools."
        )
        self.check.connect("toggled", lambda c: self.cont.set_sensitive(c.get_active()))
        outer.append(self.check)

        bar = Gtk.Box(spacing=12)
        cancel = Gtk.Button(label="Cancel"); cancel.connect("clicked", lambda _b: app.quit())
        self.cont = Gtk.Button(label="Continue", sensitive=False)
        self.cont.get_style_context().add_class("nyx-btn-gold")
        self.cont.connect("clicked", self.on_continue)
        bar.append(cancel); bar.append(self.cont)
        outer.append(bar)

        self.set_content(outer)

    def on_continue(self, _b):
        AUTHORIZE_FLAG_PATH.parent.mkdir(parents=True, exist_ok=True)
        AUTHORIZE_FLAG_PATH.write_text(json.dumps({
            "accepted": True,
            "ts": time.time(),
            "ts_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "user": os.environ.get("USER", "?"),
            "uid": os.getuid(),
        }, indent=2))
        self.close()
        self.app.launch_main()


class GodsApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gtk.ApplicationFlags.HANDLES_OPEN)
        self.connect("activate", self.on_activate)
        self.win: MainWindow | None = None

    def on_activate(self, _a):
        apply_theme(Gdk.Display.get_default())
        if AUTHORIZE_FLAG_PATH.exists():
            self.launch_main()
        else:
            AuthorizationGate(self).present()

    def launch_main(self):
        self.win = MainWindow(self)
        self.win.present()


def main() -> int:
    app = GodsApp()
    return app.run(None)


if __name__ == "__main__":
    raise SystemExit(main())
