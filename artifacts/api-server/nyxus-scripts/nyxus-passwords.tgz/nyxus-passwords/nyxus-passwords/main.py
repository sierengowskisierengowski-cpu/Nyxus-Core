#!/usr/bin/env python3
"""
NYXUS Passwords — standalone real native GTK4 app.
Mirrors the matching card on the NYXUS Home dashboard EXACTLY (same
widget code) but wrapped in a normal-sized application window. Real
data, real APIs, real keyring. No mocks.
(c) 2026 Joseph Sierengowski - NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GLib  # noqa: E402

from style import install_css            # noqa: E402
from widgets import PasswordManagerCard         # noqa: E402

APP_ID  = "io.nyxus.passwords"
TITLE   = "NYXUS Passwords"
WIN_W   = 620
WIN_H   = 720


class NyxusPasswordsApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window
        if win is None:
            install_css()
            win = Gtk.ApplicationWindow(application=self)
            win.set_title(TITLE)
            win.set_default_size(WIN_W, WIN_H)
            # Normal window — NEVER fullscreen / maximized
            win.set_resizable(True)
            win.add_css_class("home-root")

            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                            spacing=0, margin_top=10, margin_bottom=10,
                            margin_start=10, margin_end=10)
            card = PasswordManagerCard()
            outer.append(card.root)
            win.set_child(outer)
        win.present()


def main():
    app = NyxusPasswordsApp()
    return app.run(sys.argv)



# ─────────────────────────── NYXUS CHROME (auto-injected) ───────────────────
# Unifies look across every NYXUS GTK4 app: graffiti background, Caveat
# font, neon palette. Monkey-patches ApplicationWindow.present so the
# canonical install_chrome() runs once per top-level window without
# touching the app's own window-construction code. nyxus-panel is
# intentionally excluded (LayerShell incompatibility with Gtk.Overlay).
# nyxus_chrome.py is shipped to ~/.nyxus by nyxus_install.sh.
try:
    import os as _nyx_os, sys as _nyx_sys
    _nyx_chrome_dir = _nyx_os.path.expanduser("~/.nyxus")
    if _nyx_chrome_dir not in _nyx_sys.path:
        _nyx_sys.path.insert(0, _nyx_chrome_dir)
    try:
        from nyxus_chrome import install_chrome as _nyx_install_chrome
    except ImportError:
        _nyx_install_chrome = lambda *a, **kw: None  # silent no-op
    import gi as _nyx_gi
    _nyx_gi.require_version("Gtk", "4.0")
    from gi.repository import Gtk as _NyxGtk
    _NYX_PAGE_KEY = "_passwords"
    if not getattr(_NyxGtk.ApplicationWindow, "_nyx_chrome_hooked", False):
        _orig_present = _NyxGtk.ApplicationWindow.present
        def _nyx_present(self):
            try: _nyx_install_chrome(self, page_key=_NYX_PAGE_KEY)
            except Exception: pass
            return _orig_present(self)
        _NyxGtk.ApplicationWindow.present = _nyx_present
        _NyxGtk.ApplicationWindow._nyx_chrome_hooked = True
except Exception as _nyx_e:
    import sys as _nyx_sys
    print("nyxus-chrome bootstrap skipped: %s" % _nyx_e, file=_nyx_sys.stderr)
# ────────────────────────── /NYXUS CHROME ───────────────────────────────────

if __name__ == "__main__":
    raise SystemExit(main())
