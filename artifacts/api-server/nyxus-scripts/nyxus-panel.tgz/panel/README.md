# NYXUS Panel

A native GTK4 flyout panel modeled after the Windows 11 News & Interests
popup — fully NYXUS-themed.  Click the bolt icon on your Waybar bar and
a 460 × 680 graffiti-walled card slides up from the corner with weather,
system stats, and a personalized tech / Linux / security news feed.

> © 2026 Joseph Sierengowski — `NYX-J5W-2026-SIERENGOWSKI-LOCKED`

## Features

| Section            | What it shows                                             |
|--------------------|-----------------------------------------------------------|
| **Header**         | City pulled from NYXUS Weather, refresh / settings / more |
| **Weather tile**   | Current temp, condition, feels-like, hi / lo, click → opens NYXUS Weather |
| **System tile**    | CPU, RAM, GPU (NVIDIA), network up/down — color-coded     |
| **News feed**      | RSS-driven hero card + masonry sub-cards, save / read-later / share |
| **Footer**         | "See more tech news" + 6 quick-launch buttons             |
| **Settings**       | Per-source toggles, custom RSS feeds, keyword filters, browser, cache |

## Built-in news sources

* **Linux** — DistroWatch, LWN.net, Phoronix, Arch Linux News, Kali Blog
* **Security** — Krebs on Security, The Hacker News, Bleeping Computer, NVD CVEs
* **Hardware** — NVIDIA Developer, AnandTech, Tom's Hardware, NotebookCheck
* **Developer** — GitHub Blog, Python.org

Add your own RSS feed in **Settings → News Sources → Custom RSS feeds**.

## Install

The recommended install path is via the top-level installer:

```bash
curl -fsSL https://nyxus-core.replit.app/api/download/nyxus/nyxus_panel_install.sh | bash
```

That script downloads `nyxus-panel.tgz`, extracts it, and runs the
inner `install.sh`, which:

1. Installs the system + Python deps (see `packages.txt`, `requirements.txt`)
2. Lays the source into `~/.nyxus/nyxus-panel/`
3. Drops a launcher script at `~/.local/bin/nyxus-panel`
4. Adds a `.desktop` entry so the panel appears in your app launcher

## Run

```bash
nyxus-panel        # opens the panel (or closes it if already open)
```

The panel uses a PID-file toggle, so binding it to a Waybar custom
module gives you a single click-to-toggle taskbar button.  See
`waybar_integration.md` for the exact JSON to add.

## Files in this package

| File                        | Purpose                                          |
|-----------------------------|--------------------------------------------------|
| `main.py`                   | Entry point, GTK4 window, layout, lifecycle, bg renderer |
| `news_feed.py`              | Background RSS fetcher (feedparser + thumbs)     |
| `weather_widget.py`         | Weather tile (open-meteo, reads NYXUS Weather config) |
| `system_widget.py`          | System stats tile (psutil + nvidia-smi)          |
| `news_card.py`              | Hero / sub article cards                         |
| `settings.py`               | Settings dialog + JSON config persistence        |
| `install.sh`                | Sub-app installer                                |
| `waybar_integration.md`     | How to wire it into Waybar                       |
| `requirements.txt`          | Python deps                                      |
| `packages.txt`              | System (pacman) deps                             |

## Config & cache locations

* Settings JSON   `~/.config/nyxus-panel/config.json`
* Article cache   `~/.config/nyxus-panel/cache/articles.json`
* Thumbnails     `~/.config/nyxus-panel/cache/thumbs/`
* Favicons        `~/.config/nyxus-panel/cache/favicons/`
* Background      `~/.cache/nyxus-panel/bg-460x680.png`

Clear all of them from **Settings → Cache → Clear cache**.
