# NYXUS Panel — Waybar integration

The panel is built so that running `nyxus-panel` a second time **closes
the running instance** (PID-file toggle).  That means a single Waybar
custom-module entry gives you a click-to-toggle button with no extra
state management.

## 1.  Add the module

Edit `~/.config/waybar/config.jsonc` (or the JSON config that your bar
loads).  Inside the bar block where you want the button to live, add
the module name to `modules-right` (or `modules-left` / `modules-center`)
and define the module:

```jsonc
{
  // ... existing bar config ...

  "modules-right": [
    "custom/nyxus-panel",
    "clock"
  ],

  "custom/nyxus-panel": {
    "format":   "\uf0e7",                     // FA bolt — change to any glyph
    "tooltip":  true,
    "tooltip-format": "<span foreground='#ff00ff' weight='bold'>NYXUS</span>\nNews · Weather · System",
    "on-click": "nyxus-panel"
  }
}
```

If you prefer hover-to-open instead of click-to-open:

1.  Open the panel once and click the **pencil** icon → enable
    **Open on hover** (and tune the **Hover delay** slider).
2.  In the Waybar module add `"on-hover": "nyxus-panel"` alongside
    `"on-click"`.  The panel itself manages the hover-delay timing.

## 2.  Style the button

Add the following to `~/.config/waybar/style.css`:

```css
#custom-nyxus-panel {
    font-family:        "JetBrains Mono Nerd Font", "Symbols Nerd Font", monospace;
    font-size:          15px;
    color:              #ffffff;
    background:         rgba(255, 0, 255, 0.20);
    border:             2px solid #ff00ff;
    border-radius:      8px;
    padding:            3px 14px;
    margin:             3px 4px;
    box-shadow:         0 0 12px rgba(255, 0, 255, 0.55);
    text-shadow:        0 0 10px rgba(255, 0, 255, 0.85);
    transition:         all 0.15s ease;
}
#custom-nyxus-panel:hover {
    background:         rgba(255, 0, 255, 0.45);
    box-shadow:         0 0 22px rgba(255, 0, 255, 0.90);
    text-shadow:        0 0 16px #ffffff;
}
```

## 3.  Reload Waybar

```bash
pkill waybar; sleep 1; (setsid waybar </dev/null &>/dev/null &)
```

Click the new button — the panel slides up from the bottom-right
corner.  Click outside it (or hit `Esc`) to dismiss it.  Click the
button again to toggle.

## 4.  Anchoring (`gtk4-layer-shell`)

If `gtk4-layer-shell` is installed (the bundled installer pulls it in
on Arch), the panel will anchor itself to the **bottom-right** corner
above the taskbar.  Without it, the panel still works but appears in
the centered floating position the compositor chooses.

To switch to a side-anchored layout, open Settings → General → **Panel
position** → `side`.

## 5.  Hyprland keybind (optional)

For a quick keyboard shortcut, add to `~/.config/hypr/hyprland.conf`:

```ini
bind = SUPER, N, exec, nyxus-panel
```

Now `Super + N` toggles the panel from anywhere.
