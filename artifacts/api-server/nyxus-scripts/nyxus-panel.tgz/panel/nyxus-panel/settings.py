"""
NYXUS Panel — Settings module.

Provides a Gtk.Window-based settings dialog (notebook-tabbed) and a tiny
JSON-backed config object.  All defaults live here; the rest of the app
imports `load_config()` and `save_config()`.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Dict, List

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib, Gio, Pango  # noqa: E402

# ───────────────────────────────────────────────── paths
CFG_DIR  = Path(os.path.expanduser("~/.config/nyxus-panel"))
CFG_PATH = CFG_DIR / "config.json"
CACHE_DIR = CFG_DIR / "cache"
CACHE_DIR.mkdir(parents=True, exist_ok=True)
(CACHE_DIR / "thumbs").mkdir(parents=True, exist_ok=True)
(CACHE_DIR / "favicons").mkdir(parents=True, exist_ok=True)

# ───────────────────────────────────────────────── default sources
# Curated tech / Linux / security RSS feeds.  Each entry: id, label, url, category.
DEFAULT_SOURCES: List[Dict[str, str]] = [
    # Linux
    {"id": "distrowatch", "label": "DistroWatch",       "url": "https://distrowatch.com/news/dw.xml",                     "cat": "linux"},
    {"id": "lwn",          "label": "LWN.net",           "url": "https://lwn.net/headlines/newrss",                        "cat": "linux"},
    {"id": "phoronix",     "label": "Phoronix",          "url": "https://www.phoronix.com/rss.php",                        "cat": "linux"},
    {"id": "archnews",     "label": "Arch Linux News",   "url": "https://archlinux.org/feeds/news/",                       "cat": "linux"},
    {"id": "kalinews",     "label": "Kali Linux Blog",   "url": "https://www.kali.org/rss.xml",                            "cat": "linux"},
    # Security
    {"id": "krebs",        "label": "Krebs on Security", "url": "https://krebsonsecurity.com/feed/",                       "cat": "security"},
    {"id": "thn",          "label": "The Hacker News",   "url": "https://feeds.feedburner.com/TheHackersNews",             "cat": "security"},
    {"id": "bleeping",     "label": "Bleeping Computer", "url": "https://www.bleepingcomputer.com/feed/",                  "cat": "security"},
    {"id": "nvd_critical", "label": "NVD CVEs",          "url": "https://nvd.nist.gov/feeds/xml/cve/misc/nvd-rss.xml",     "cat": "security"},
    # Hardware
    {"id": "nvidia_dev",   "label": "NVIDIA Developer",  "url": "https://developer.nvidia.com/blog/feed/",                 "cat": "hardware"},
    {"id": "anandtech",    "label": "AnandTech",         "url": "https://www.anandtech.com/rss/",                          "cat": "hardware"},
    {"id": "tomshw",       "label": "Tom's Hardware",    "url": "https://www.tomshardware.com/feeds/all",                  "cat": "hardware"},
    {"id": "notebook",     "label": "NotebookCheck",     "url": "https://www.notebookcheck.net/News.152.0.html?type=rss",  "cat": "hardware"},
    # Developer
    {"id": "github",       "label": "GitHub Blog",       "url": "https://github.blog/feed/",                               "cat": "dev"},
    {"id": "python",       "label": "Python.org",        "url": "https://www.python.org/jobs/feed/rss/",                   "cat": "dev"},
]

DEFAULT_CONFIG: Dict[str, Any] = {
    "version": 1,
    "open_on_hover": False,
    "hover_delay_ms": 500,
    "open_on_click": True,
    "reduce_animations": False,
    "panel_position": "above-taskbar",     # above-taskbar | side
    "refresh_interval_min": 30,            # 15 | 30 | 60
    "max_articles": 30,
    "browser": "chromium",                 # chromium | firefox | xdg-open | <custom>
    "browser_private": False,
    "browser_reader_mode": False,
    "notify_breaking_security": True,
    "load_on_startup": True,
    # source enable/disable: dict id -> bool (anything missing defaults to True)
    "sources": {s["id"]: True for s in DEFAULT_SOURCES},
    "custom_sources": [],                  # list of {label, url, cat}
    "keyword_allow": [],                   # only show articles containing any of these (empty == all)
    "keyword_block": [],                   # never show articles containing these
    "saved_articles": [],                  # heart icon
    "read_later": [],                      # bookmark icon
}


# ────────────────────────────────────────────────────── load / save
def _ensure_dir() -> None:
    CFG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> Dict[str, Any]:
    _ensure_dir()
    if not CFG_PATH.exists():
        save_config(DEFAULT_CONFIG)
        return dict(DEFAULT_CONFIG)
    try:
        with CFG_PATH.open() as f:
            cfg = json.load(f)
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULT_CONFIG)
    # Merge in any missing keys (forward-compat with new releases)
    out = dict(DEFAULT_CONFIG)
    out.update(cfg)
    # Ensure every default source has an entry
    src_map = dict(DEFAULT_CONFIG["sources"])
    src_map.update(out.get("sources", {}))
    out["sources"] = src_map
    return out


def save_config(cfg: Dict[str, Any]) -> None:
    _ensure_dir()
    tmp = CFG_PATH.with_suffix(".json.tmp")
    with tmp.open("w") as f:
        json.dump(cfg, f, indent=2)
    tmp.replace(CFG_PATH)


def all_sources(cfg: Dict[str, Any]) -> List[Dict[str, str]]:
    """Return enabled sources (built-in + custom)."""
    out: List[Dict[str, str]] = []
    for s in DEFAULT_SOURCES:
        if cfg.get("sources", {}).get(s["id"], True):
            out.append(s)
    for c in cfg.get("custom_sources", []):
        # custom sources default to enabled
        out.append({
            "id":    c.get("id") or f"custom_{abs(hash(c.get('url', ''))) % 999999}",
            "label": c.get("label", c.get("url", "Custom")),
            "url":   c.get("url", ""),
            "cat":   c.get("cat", "custom"),
        })
    return out


def clear_cache() -> int:
    """Wipe cache dir, return number of bytes freed."""
    total = 0
    if CACHE_DIR.exists():
        for p in CACHE_DIR.rglob("*"):
            if p.is_file():
                try:
                    total += p.stat().st_size
                except OSError:
                    pass
        try:
            shutil.rmtree(CACHE_DIR)
        except OSError:
            pass
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    (CACHE_DIR / "thumbs").mkdir(parents=True, exist_ok=True)
    (CACHE_DIR / "favicons").mkdir(parents=True, exist_ok=True)
    return total


# ────────────────────────────────────────────────────── settings dialog (GTK4)
class SettingsWindow(Gtk.Window):
    """Standalone settings window — opened from the Panel header pencil icon."""

    def __init__(self, on_saved=None):
        super().__init__(title="NYXUS Panel · Settings")
        self.set_default_size(640, 720)
        self._cfg = load_config()
        self._on_saved = on_saved
        self.add_css_class("nyxus-settings")

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.set_child(outer)

        # ── header
        hdr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12, margin_top=18, margin_bottom=14, margin_start=22, margin_end=22)
        title = Gtk.Label(label="NYXUS PANEL")
        title.add_css_class("nyxus-title")
        sub = Gtk.Label(label="Settings")
        sub.add_css_class("nyxus-subtitle")
        sub.set_hexpand(True); sub.set_xalign(0)
        hdr.append(title); hdr.append(sub)
        outer.append(hdr)

        # ── notebook
        nb = Gtk.Notebook()
        nb.set_margin_start(14); nb.set_margin_end(14); nb.set_margin_bottom(8)
        nb.set_vexpand(True); nb.set_hexpand(True)
        outer.append(nb)

        nb.append_page(self._tab_general(),  Gtk.Label(label="General"))
        nb.append_page(self._tab_sources(),  Gtk.Label(label="News Sources"))
        nb.append_page(self._tab_filters(),  Gtk.Label(label="Keyword Filters"))
        nb.append_page(self._tab_browser(),  Gtk.Label(label="Browser"))
        nb.append_page(self._tab_cache(),    Gtk.Label(label="Cache"))

        # ── footer
        ft = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10,
                     margin_top=8, margin_bottom=18, margin_start=22, margin_end=22)
        spacer = Gtk.Label(label=""); spacer.set_hexpand(True)
        cancel = Gtk.Button(label="Cancel"); cancel.add_css_class("nyxus-btn-ghost")
        save   = Gtk.Button(label="Save");   save.add_css_class("nyxus-btn-primary")
        ft.append(spacer); ft.append(cancel); ft.append(save)
        outer.append(ft)

        cancel.connect("clicked", lambda *_: self.close())
        save.connect("clicked",   self._on_save)

    # ───────────── tab builders ─────────────
    def _tab_general(self) -> Gtk.Widget:
        box = self._tab_box()

        self.w_hover  = self._switch_row(box, "Open on hover",
                                         "Hover the taskbar button to open the panel automatically",
                                         self._cfg["open_on_hover"])
        self.w_hover_ms = self._slider_row(box, "Hover delay",
                                           300, 1000, self._cfg["hover_delay_ms"], unit=" ms")
        self.w_click  = self._switch_row(box, "Open on click",
                                         "Click the taskbar button to toggle the panel",
                                         self._cfg["open_on_click"])
        self.w_anim   = self._switch_row(box, "Reduce animations",
                                         "Skip the slide-up / fade animations",
                                         self._cfg["reduce_animations"])

        self.w_position = self._combo_row(box, "Panel position",
                                          ["above-taskbar", "side"],
                                          self._cfg["panel_position"])
        self.w_refresh = self._combo_row(box, "Auto refresh interval",
                                         ["15", "30", "60"],
                                         str(self._cfg["refresh_interval_min"]),
                                         suffix=" min")
        self.w_max = self._slider_row(box, "Max articles",
                                      10, 80, self._cfg["max_articles"])
        self.w_notify = self._switch_row(box, "Breaking security notifications",
                                         "Send a desktop notification for new high-severity CVEs",
                                         self._cfg["notify_breaking_security"])
        self.w_startup = self._switch_row(box, "Load content on boot",
                                          "Start fetching feeds on login (otherwise: wait until panel opens)",
                                          self._cfg["load_on_startup"])
        return box

    def _tab_sources(self) -> Gtk.Widget:
        box = self._tab_box()
        intro = Gtk.Label(label="Toggle each built-in source on or off.")
        intro.set_xalign(0); intro.add_css_class("nyxus-help")
        box.append(intro)

        self.src_switches: Dict[str, Gtk.Switch] = {}
        # Group by category
        categories = [("linux", "Linux & Distros"), ("security", "Security & CVEs"),
                      ("hardware", "Hardware & GPUs"), ("dev", "Developer")]
        for cat_id, cat_label in categories:
            hdr = Gtk.Label(label=cat_label.upper()); hdr.set_xalign(0)
            hdr.add_css_class("nyxus-cat")
            box.append(hdr)
            for s in DEFAULT_SOURCES:
                if s["cat"] != cat_id:
                    continue
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10, margin_top=4)
                lbl = Gtk.Label(label=s["label"]); lbl.set_xalign(0); lbl.set_hexpand(True)
                sw  = Gtk.Switch()
                sw.set_active(self._cfg["sources"].get(s["id"], True))
                sw.set_valign(Gtk.Align.CENTER)
                self.src_switches[s["id"]] = sw
                row.append(lbl); row.append(sw)
                box.append(row)

        # ── custom RSS feeds ──
        sep = Gtk.Separator(); sep.set_margin_top(12); sep.set_margin_bottom(8); box.append(sep)
        chdr = Gtk.Label(label="CUSTOM RSS FEEDS"); chdr.set_xalign(0); chdr.add_css_class("nyxus-cat")
        box.append(chdr)

        self.custom_list_box = Gtk.ListBox()
        self.custom_list_box.set_selection_mode(Gtk.SelectionMode.NONE)
        self.custom_list_box.add_css_class("nyxus-listbox")
        box.append(self.custom_list_box)
        for c in self._cfg.get("custom_sources", []):
            self._append_custom_row(c)

        # add row
        addrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8, margin_top=10)
        self.add_label = Gtk.Entry(); self.add_label.set_placeholder_text("Label  (e.g. My Blog)")
        self.add_url   = Gtk.Entry(); self.add_url.set_placeholder_text("https://example.com/feed.xml")
        self.add_url.set_hexpand(True)
        addbtn = Gtk.Button(label="Add"); addbtn.add_css_class("nyxus-btn-primary")
        addbtn.connect("clicked", self._on_add_custom)
        addrow.append(self.add_label); addrow.append(self.add_url); addrow.append(addbtn)
        box.append(addrow)
        return box

    def _tab_filters(self) -> Gtk.Widget:
        box = self._tab_box()
        intro = Gtk.Label(label=(
            "Allow-list: only show articles whose title or summary contains any of these words.\n"
            "Block-list: never show articles containing any of these words.\n"
            "One word per line. Case-insensitive."
        ))
        intro.set_xalign(0); intro.add_css_class("nyxus-help"); intro.set_wrap(True)
        box.append(intro)

        # allow list
        a_lbl = Gtk.Label(label="ALLOW (one per line)"); a_lbl.set_xalign(0); a_lbl.add_css_class("nyxus-cat")
        box.append(a_lbl)
        sw_a = Gtk.ScrolledWindow(); sw_a.set_min_content_height(120)
        self.tv_allow = Gtk.TextView(); self.tv_allow.add_css_class("nyxus-textarea")
        self.tv_allow.get_buffer().set_text("\n".join(self._cfg.get("keyword_allow", [])))
        sw_a.set_child(self.tv_allow)
        box.append(sw_a)

        # block list
        b_lbl = Gtk.Label(label="BLOCK (one per line)"); b_lbl.set_xalign(0); b_lbl.add_css_class("nyxus-cat")
        box.append(b_lbl)
        sw_b = Gtk.ScrolledWindow(); sw_b.set_min_content_height(120)
        self.tv_block = Gtk.TextView(); self.tv_block.add_css_class("nyxus-textarea")
        self.tv_block.get_buffer().set_text("\n".join(self._cfg.get("keyword_block", [])))
        sw_b.set_child(self.tv_block)
        box.append(sw_b)
        return box

    def _tab_browser(self) -> Gtk.Widget:
        box = self._tab_box()
        intro = Gtk.Label(label="Where to open article links when you click a news card.")
        intro.set_xalign(0); intro.add_css_class("nyxus-help")
        box.append(intro)

        # Detect installed browsers
        candidates = ["chromium", "google-chrome", "firefox", "brave", "vivaldi", "qutebrowser", "xdg-open"]
        present = [c for c in candidates if shutil.which(c)]
        if not present:
            present = ["xdg-open"]
        if self._cfg["browser"] not in present:
            present = list(dict.fromkeys([self._cfg["browser"], *present]))

        self.w_browser = self._combo_row(box, "Browser", present, self._cfg["browser"])
        self.w_private = self._switch_row(box, "Private window",
                                          "Open links in a private/incognito window",
                                          self._cfg["browser_private"])
        self.w_reader  = self._switch_row(box, "Reader mode",
                                          "Open links with browser reader/distraction-free mode",
                                          self._cfg["browser_reader_mode"])
        return box

    def _tab_cache(self) -> Gtk.Widget:
        box = self._tab_box()
        size_lbl = Gtk.Label(label=f"Cache location: {CACHE_DIR}")
        size_lbl.set_xalign(0); size_lbl.set_wrap(True); size_lbl.add_css_class("nyxus-mono")
        box.append(size_lbl)

        total = sum(p.stat().st_size for p in CACHE_DIR.rglob("*") if p.is_file())
        usage = Gtk.Label(label=f"Disk usage: {total/1024:.1f} KiB")
        usage.set_xalign(0); usage.add_css_class("nyxus-help")
        box.append(usage)

        clear = Gtk.Button(label="Clear cache")
        clear.add_css_class("nyxus-btn-danger")
        clear.set_halign(Gtk.Align.START); clear.set_margin_top(10)
        def _do_clear(_):
            n = clear_cache()
            usage.set_text(f"Cleared {n/1024:.1f} KiB.")
        clear.connect("clicked", _do_clear)
        box.append(clear)
        return box

    # ───────────── helpers ─────────────
    def _tab_box(self) -> Gtk.Widget:
        """Return a ScrolledWindow that *acts* like a Box for `.append()`.

        Notebook pages must be the ScrolledWindow itself (not a wrapped Box)
        for the page to actually scroll, so we expose the inner Box's
        ``append`` method on the wrapper for ergonomic use by callers.
        """
        inner = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL, spacing=8,
            margin_top=16, margin_bottom=16, margin_start=16, margin_end=16,
        )
        sw = Gtk.ScrolledWindow()
        sw.set_child(inner)
        sw.set_vexpand(True); sw.set_hexpand(True)
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        # Forward .append to the inner box so existing callers keep working.
        sw.append = inner.append  # type: ignore[attr-defined]
        return sw

    def _switch_row(self, parent, label, help_text, value: bool) -> Gtk.Switch:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10, margin_top=8)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); col.set_hexpand(True)
        l = Gtk.Label(label=label); l.set_xalign(0); l.add_css_class("nyxus-row-title")
        h = Gtk.Label(label=help_text); h.set_xalign(0); h.set_wrap(True); h.add_css_class("nyxus-help")
        col.append(l); col.append(h)
        sw = Gtk.Switch(); sw.set_active(bool(value)); sw.set_valign(Gtk.Align.CENTER)
        row.append(col); row.append(sw)
        parent.append(row)
        return sw

    def _slider_row(self, parent, label, lo, hi, value, unit="") -> Gtk.Scale:
        row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, margin_top=10)
        l = Gtk.Label(label=label); l.set_xalign(0); l.add_css_class("nyxus-row-title")
        sl = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, lo, hi, 1)
        sl.set_value(value); sl.set_draw_value(True); sl.set_value_pos(Gtk.PositionType.RIGHT)
        if unit:
            sl.set_format_value_func(lambda _s, v: f"{int(v)}{unit}")
        row.append(l); row.append(sl)
        parent.append(row)
        return sl

    def _combo_row(self, parent, label, options, value, suffix="") -> Gtk.DropDown:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10, margin_top=10)
        l = Gtk.Label(label=label); l.set_xalign(0); l.set_hexpand(True); l.add_css_class("nyxus-row-title")
        sl = Gtk.StringList()
        for o in options:
            sl.append(f"{o}{suffix}")
        dd = Gtk.DropDown(model=sl)
        try:
            dd.set_selected(options.index(value))
        except ValueError:
            dd.set_selected(0)
        dd._options = options  # type: ignore[attr-defined]
        row.append(l); row.append(dd)
        parent.append(row)
        return dd

    def _append_custom_row(self, c: Dict[str, str]) -> None:
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8, margin_top=4, margin_bottom=4, margin_start=6, margin_end=6)
        l = Gtk.Label(label=f"{c.get('label','(no label)')} — {c.get('url','')}")
        l.set_xalign(0); l.set_hexpand(True); l.set_ellipsize(Pango.EllipsizeMode.END)
        rm = Gtk.Button(label="Remove"); rm.add_css_class("nyxus-btn-ghost")
        def _remove(_):
            self._cfg["custom_sources"] = [
                x for x in self._cfg.get("custom_sources", [])
                if x.get("url") != c.get("url")
            ]
            parent_lb = row.get_parent()
            if parent_lb is not None:
                parent_lb.remove(row.get_parent())
        rm.connect("clicked", _remove)
        row.append(l); row.append(rm)
        self.custom_list_box.append(row)

    def _on_add_custom(self, _btn) -> None:
        url = self.add_url.get_text().strip()
        lbl = self.add_label.get_text().strip() or url
        if not url:
            return
        c = {"label": lbl, "url": url, "cat": "custom"}
        self._cfg.setdefault("custom_sources", []).append(c)
        self._append_custom_row(c)
        self.add_label.set_text(""); self.add_url.set_text("")

    # ───────────── save ─────────────
    def _on_save(self, _btn) -> None:
        self._cfg["open_on_hover"]            = self.w_hover.get_active()
        self._cfg["hover_delay_ms"]           = int(self.w_hover_ms.get_value())
        self._cfg["open_on_click"]            = self.w_click.get_active()
        self._cfg["reduce_animations"]        = self.w_anim.get_active()
        self._cfg["panel_position"]           = self.w_position._options[self.w_position.get_selected()]  # type: ignore[attr-defined]
        self._cfg["refresh_interval_min"]     = int(self.w_refresh._options[self.w_refresh.get_selected()])  # type: ignore[attr-defined]
        self._cfg["max_articles"]             = int(self.w_max.get_value())
        self._cfg["notify_breaking_security"] = self.w_notify.get_active()
        self._cfg["load_on_startup"]          = self.w_startup.get_active()
        self._cfg["browser"]                  = self.w_browser._options[self.w_browser.get_selected()]  # type: ignore[attr-defined]
        self._cfg["browser_private"]          = self.w_private.get_active()
        self._cfg["browser_reader_mode"]      = self.w_reader.get_active()
        # sources
        for sid, sw in self.src_switches.items():
            self._cfg["sources"][sid] = sw.get_active()
        # filters
        ab = self.tv_allow.get_buffer()
        bb = self.tv_block.get_buffer()
        self._cfg["keyword_allow"] = [w.strip() for w in ab.get_text(ab.get_start_iter(), ab.get_end_iter(), True).splitlines() if w.strip()]
        self._cfg["keyword_block"] = [w.strip() for w in bb.get_text(bb.get_start_iter(), bb.get_end_iter(), True).splitlines() if w.strip()]
        save_config(self._cfg)
        if callable(self._on_saved):
            try:
                self._on_saved(self._cfg)
            except Exception:
                pass
        self.close()


__all__ = ["DEFAULT_CONFIG", "DEFAULT_SOURCES", "CFG_DIR", "CFG_PATH", "CACHE_DIR",
           "load_config", "save_config", "all_sources", "clear_cache", "SettingsWindow"]
