#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────
# NYXUS Panel — sub-app installer
#
# Called by the top-level nyxus_panel_install.sh after the tarball is
# extracted.  Lays files into ~/.nyxus/nyxus-panel/, installs Python +
# system deps, drops a launcher script and a .desktop entry.
#
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ──────────────────────────────────────────────────────────────────────
set -euo pipefail

B=$'\e[1m'; R=$'\e[0m'; PINK=$'\e[38;5;201m'; CYAN=$'\e[38;5;51m'
GOLD=$'\e[38;5;220m'; PURPLE=$'\e[38;5;177m'; DIM=$'\e[2m'

step() { printf "\n${PURPLE}▌${R} ${B}%s${R}\n" "$*"; }
ok()   { printf "  ${CYAN}✓${R}  %s\n" "$*"; }
warn() { printf "  ${GOLD}!${R}  %s\n" "$*"; }
fail() { printf "  ${PINK}✗${R}  %s\n" "$*" >&2; }

# ── resolve real user (script may run as root via sudo)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6)"
[[ -z "$REAL_HOME" || ! -d "$REAL_HOME" ]] && REAL_HOME="$HOME"

INSTALL_DIR="${REAL_HOME}/.nyxus/nyxus-panel"
BIN_DIR="${REAL_HOME}/.local/bin"
APP_DIR="${REAL_HOME}/.local/share/applications"
ICON_DIR="${REAL_HOME}/.local/share/icons/hicolor/256x256/apps"

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

step "preflight"
for cmd in python3 install; do
  command -v "$cmd" >/dev/null || { fail "$cmd not found"; exit 1; }
done
ok "python3 / install present"

# ── system packages (best-effort, all individually wrapped)
step "system packages (pacman)"
if command -v pacman >/dev/null; then
  # core: gtk4, python bindings, image processing
  pacman -S --noconfirm --needed \
    gtk4 python-gobject python-cairo \
    python-psutil python-requests python-beautifulsoup4 python-pillow \
    2>/dev/null \
    && ok "gtk4 / python-gobject / python-cairo / psutil / requests / bs4 / pillow" \
    || warn "pacman: some core packages failed (re-run: sudo pacman -S gtk4 python-gobject python-psutil python-pillow)"

  # layer-shell — lets the panel anchor above the taskbar
  pacman -S --noconfirm --needed gtk4-layer-shell 2>/dev/null \
    && ok "gtk4-layer-shell (panel anchors above taskbar)" \
    || warn "gtk4-layer-shell missing — falls back to centered floating window"

  # browser
  if ! command -v chromium >/dev/null && ! command -v firefox >/dev/null; then
    pacman -S --noconfirm --needed chromium 2>/dev/null \
      && ok "chromium installed (default browser for news links)" \
      || warn "no browser installed — install chromium or firefox manually"
  else
    ok "browser already present ($(command -v chromium || command -v firefox))"
  fi
else
  warn "pacman not found — install GTK4 + python-gobject manually"
fi

# ── feedparser (Arch repos: not always available, try AUR then pip)
step "python-feedparser"
if python3 -c "import feedparser" 2>/dev/null; then
  ok "feedparser already installed"
else
  if command -v pacman >/dev/null && pacman -S --noconfirm --needed python-feedparser 2>/dev/null; then
    ok "installed via pacman"
  elif sudo -u "$REAL_USER" pip install --user feedparser 2>/dev/null; then
    ok "installed via pip --user"
  else
    pip install --break-system-packages feedparser 2>/dev/null \
      && ok "installed via pip --break-system-packages" \
      || warn "feedparser install failed — news feed will be unavailable until you install it"
  fi
fi

# ── lay down files
step "deploy files → ${INSTALL_DIR}"
install -d -o "$REAL_USER" "${INSTALL_DIR}" "${BIN_DIR}" "${APP_DIR}" "${ICON_DIR}" "${REAL_HOME}/.config/nyxus-panel"

# Copy the inner package
cp -r "${SRC_DIR}/nyxus-panel/." "${INSTALL_DIR}/"
chown -R "$REAL_USER":"$REAL_USER" "${INSTALL_DIR}"
chmod -R u+rw,go+r "${INSTALL_DIR}"
ok "deployed $(find "${INSTALL_DIR}" -maxdepth 1 -type f | wc -l) files"

# ── launcher script
step "launcher script"
cat > "${BIN_DIR}/nyxus-panel" <<EOF
#!/usr/bin/env bash
exec python3 "${INSTALL_DIR}/main.py" "\$@"
EOF
chmod +x "${BIN_DIR}/nyxus-panel"
chown "$REAL_USER":"$REAL_USER" "${BIN_DIR}/nyxus-panel"
ok "${BIN_DIR}/nyxus-panel"

# ── nyxus-settings standalone launcher (opens the panel SettingsWindow directly)
cat > "${BIN_DIR}/nyxus-settings" <<'EOF'
#!/usr/bin/env python3
"""NYXUS Settings — standalone launcher for the unified settings window."""
import sys
sys.path.insert(0, "__INSTALL_DIR__")
import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib  # noqa: E402
from settings import SettingsWindow  # noqa: E402

def _main():
    app = Gtk.Application(application_id="io.nyxus.settings")
    def _on_activate(a):
        win = SettingsWindow()
        win.set_application(a)
        win.present()
    app.connect("activate", _on_activate)
    app.run(sys.argv)

if __name__ == "__main__":
    _main()
EOF
sed -i "s|__INSTALL_DIR__|${INSTALL_DIR}|" "${BIN_DIR}/nyxus-settings"
chmod +x "${BIN_DIR}/nyxus-settings"
chown "$REAL_USER":"$REAL_USER" "${BIN_DIR}/nyxus-settings"
ok "${BIN_DIR}/nyxus-settings"

# ── .desktop files
cat > "${APP_DIR}/io.nyxus.panel.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=NYXUS Panel
GenericName=News & System Flyout
Comment=Windows-style flyout panel — news, weather, system stats
Exec=python3 ${INSTALL_DIR}/main.py
Icon=io.nyxus.panel
Terminal=false
Categories=Utility;System;
StartupNotify=false
EOF
chown "$REAL_USER":"$REAL_USER" "${APP_DIR}/io.nyxus.panel.desktop"
ok ".desktop entry (panel)"

cat > "${APP_DIR}/io.nyxus.settings.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=NYXUS Settings
GenericName=Hand-drawn desktop settings
Comment=Appearance, profile, notifications and panel settings for the NYXUS ecosystem
Exec=${BIN_DIR}/nyxus-settings
Icon=io.nyxus.settings
Terminal=false
Categories=Settings;Utility;
StartupNotify=false
EOF
chown "$REAL_USER":"$REAL_USER" "${APP_DIR}/io.nyxus.settings.desktop"
ok ".desktop entry (settings)"

# refresh desktop db (best-effort)
sudo -u "$REAL_USER" update-desktop-database "${APP_DIR}" 2>/dev/null || true

cat <<EOF

──────────────────────────────────────────────────────────────────────
${B}NYXUS Panel installed.${R}

${B}launch:${R}    ${GOLD}nyxus-panel${R}                    ${DIM}(toggles open / close)${R}
${B}config:${R}    ${REAL_HOME}/.config/nyxus-panel/config.json
${B}cache:${R}     ${REAL_HOME}/.config/nyxus-panel/cache/
${B}install:${R}   ${INSTALL_DIR}

${B}waybar:${R}    See waybar_integration.md to add the taskbar button.
──────────────────────────────────────────────────────────────────────
EOF
