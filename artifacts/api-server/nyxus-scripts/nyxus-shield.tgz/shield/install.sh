#!/usr/bin/env bash
# ============================================================================
# NYXUS Shield — installer
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
#
#   sudo bash install.sh   # system-wide install
# ============================================================================
set -euo pipefail
if [[ $EUID -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    echo "[NYXUS Shield] elevating with sudo …"
    exec sudo -E bash "$0" "$@"
  fi
  echo "ERROR: must be run as root (sudo not available)" >&2; exit 1
fi

INSTALL_DIR="/opt/nyxus-shield"
THEME_DIR="/usr/share/nyxus/theme"
DESKTOP_FILE="/usr/share/applications/nyxus-shield.desktop"
BIN_LINK="/usr/local/bin/nyxus-shield"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "──────────────────────────────────────────────────────────────"
echo "  NYXUS Shield · install"
echo "──────────────────────────────────────────────────────────────"

echo "[1/6] system packages …"
if command -v pacman >/dev/null 2>&1; then
  pacman -Sy --needed --noconfirm \
      python python-gobject gtk4 libadwaita \
      nmap ufw clamav rkhunter wireguard-tools \
      python-psutil python-requests
elif command -v apt-get >/dev/null 2>&1; then
  apt-get update
  apt-get install -y python3 python3-gi gir1.2-gtk-4.0 gir1.2-adw-1 \
      nmap ufw clamav rkhunter wireguard-tools \
      python3-psutil python3-requests
fi

echo "[2/6] copying app …"
mkdir -p "$INSTALL_DIR"
install -m 0755 "$HERE/main.py"      "$INSTALL_DIR/main.py"
install -m 0644 "$HERE/scans.py"     "$INSTALL_DIR/scans.py"
install -m 0644 "$HERE/net.py"       "$INSTALL_DIR/net.py"
install -m 0644 "$HERE/db.py"        "$INSTALL_DIR/db.py"

echo "[3/6] copying theme assets …"
mkdir -p "$THEME_DIR"
install -m 0644 "$HERE/../theme/nyxus_theme.css" "$THEME_DIR/nyxus_theme.css" 2>/dev/null \
  || install -m 0644 "$HERE/nyxus_theme.css" "$THEME_DIR/nyxus_theme.css" 2>/dev/null \
  || echo "  (theme css not found in payload; theme will fall back to defaults)"
install -m 0644 "$HERE/../theme/nyxus_theme.py" "$THEME_DIR/nyxus_theme.py" 2>/dev/null \
  || install -m 0644 "$HERE/nyxus_theme.py" "$THEME_DIR/nyxus_theme.py" 2>/dev/null || true

echo "[4/6] installing handwritten fonts …"
if [[ -x "$HERE/../theme/install_fonts.sh" ]]; then
  bash "$HERE/../theme/install_fonts.sh" || true
elif [[ -x "$HERE/install_fonts.sh" ]]; then
  bash "$HERE/install_fonts.sh" || true
fi

echo "[5/6] launcher + desktop entry …"
ln -sf "$INSTALL_DIR/main.py" "$BIN_LINK"
chmod +x "$BIN_LINK"

cat > "$DESKTOP_FILE" <<'DESK'
[Desktop Entry]
Type=Application
Name=NYXUS Shield
Comment=Everyday security for NyX.x.OS
Exec=python3 /opt/nyxus-shield/main.py
Icon=io.nyxus.shield
Terminal=false
Categories=System;Security;
DESK

echo "[6/6] done — launch with:  nyxus-shield"
