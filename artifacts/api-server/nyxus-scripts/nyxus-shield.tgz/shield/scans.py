"""
NYXUS Shield — scanning engines (firewall · ports · packages · malware).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

These functions wrap real backends (UFW, ClamAV, rkhunter, chkrootkit,
nmap, lsof, ss, pacman/apt). Every check returns plain English so the
UI never has to translate technical jargon.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Callable

from net import FirewallManager

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



def _have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _run(cmd: list[str], timeout: float = 30) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr)
    except FileNotFoundError:
        return 127, f"{cmd[0]}: not installed"
    except Exception as exc:
        return 1, str(exc)


# =========================================================================== #
# QUICK SCAN ENGINE                                                           #
# =========================================================================== #
class QuickScanner:
    """Runs the dashboard's quick health checks plus the full scan list."""

    # ---- short, cheap checks for the dashboard ------------------------- #
    def health_checks(self) -> list[tuple[str, bool, str]]:
        out = []
        # firewall
        s = FirewallManager().status()
        out.append(("Firewall", s["enabled"], s["msg"]))
        # antivirus daemon
        out.append(("Antivirus (clamd)",
                    _have("clamd") and self._systemd_active("clamav-daemon")
                                       or self._systemd_active("clamd"),
                    "ClamAV daemon"))
        # updates
        if _have("checkupdates"):
            n = subprocess.getoutput("checkupdates 2>/dev/null | wc -l").strip()
            try:
                n = int(n)
            except Exception:
                n = 0
            out.append(("Updates", n == 0, f"{n} pending updates"))
        elif _have("apt"):
            n = subprocess.getoutput(
                "apt list --upgradable 2>/dev/null | wc -l"
            ).strip()
            try:
                n = max(0, int(n) - 1)
            except Exception:
                n = 0
            out.append(("Updates", n == 0, f"{n} pending updates"))
        else:
            out.append(("Updates", True, "package manager not detected"))
        # vpn
        wg = subprocess.getoutput("ip link show type wireguard 2>/dev/null")
        out.append(("VPN", "wg" in wg, "WireGuard interface present" if "wg" in wg
                    else "no WireGuard tunnel"))
        # phantom
        sock = Path.home() / ".nyxus" / "phantom" / "phantom.pid"
        out.append(("Phantom Daemon", sock.is_file(),
                    "running" if sock.is_file() else "not running"))
        return out

    def _systemd_active(self, unit: str) -> bool:
        if not _have("systemctl"):
            return False
        return subprocess.run(["systemctl", "is-active", "--quiet", unit]).returncode == 0

    # ---- full scan ----------------------------------------------------- #
    CHECKS: list[tuple[str, str]] = [
        ("Firewall enabled and configured", "_chk_firewall"),
        ("All system packages up to date", "_chk_updates"),
        ("No known vulnerable packages", "_chk_vuln_packages"),
        ("No unauthorized open ports", "_chk_ports"),
        ("No suspicious processes", "_chk_processes"),
        ("SSH configured securely", "_chk_ssh"),
        ("No unauthorized sudoers", "_chk_sudoers"),
        ("No world-writable sensitive files", "_chk_world_writable"),
        ("No suspicious cron jobs", "_chk_cron"),
        ("Disk encryption status", "_chk_luks"),
        ("DNS configuration is secure", "_chk_dns"),
        ("No plaintext passwords lying around", "_chk_plaintext_pw"),
        ("Browser extensions audit", "_chk_browser_ext"),
        ("Startup applications audit", "_chk_startup"),
        ("Phantom daemon healthy", "_chk_phantom"),
    ]

    def full_scan(self, on_progress: Callable[[int, int, str, bool, str], None]) -> None:
        total = len(self.CHECKS)
        for i, (label, fn_name) in enumerate(self.CHECKS, start=1):
            try:
                ok, detail = getattr(self, fn_name)()
            except Exception as exc:
                ok, detail = False, f"check error: {exc}"
            on_progress(i, total, label, ok, detail)

    def run_autofix(self, toast: Callable[[str], None]) -> None:
        # tries to enable UFW and start clamav. Idempotent and safe.
        if _have("ufw") and not FirewallManager().status()["enabled"]:
            _run(["pkexec", "ufw", "--force", "enable"])
            toast("Firewall enabled")
        if _have("systemctl") and not self._systemd_active("clamav-daemon"):
            _run(["pkexec", "systemctl", "enable", "--now", "clamav-daemon"])
            toast("ClamAV daemon enabled")
        toast("Autofix complete")

    # ---- individual checks --------------------------------------------- #
    def _chk_firewall(self):
        s = FirewallManager().status()
        return s["enabled"], s["msg"]

    def _chk_updates(self):
        if _have("checkupdates"):
            n = len(subprocess.getoutput("checkupdates 2>/dev/null").splitlines())
            return n == 0, f"{n} pending updates"
        if _have("apt"):
            o = subprocess.getoutput("apt list --upgradable 2>/dev/null").splitlines()
            return len(o) <= 1, f"{max(0,len(o)-1)} pending"
        return True, "package manager not detected"

    def _chk_vuln_packages(self):
        # quick heuristic: arch-audit / debsecan
        if _have("arch-audit"):
            txt = subprocess.getoutput("arch-audit -q 2>/dev/null")
            n = len([l for l in txt.splitlines() if l.strip()])
            return n == 0, f"{n} flagged"
        if _have("debsecan"):
            txt = subprocess.getoutput("debsecan --suite=$(lsb_release -cs) 2>/dev/null")
            n = len([l for l in txt.splitlines() if l.strip()])
            return n == 0, f"{n} flagged"
        return True, "no audit tool installed"

    def _chk_ports(self):
        if not _have("ss"):
            return True, "ss not installed"
        rc, out = _run(["ss", "-tunlp"])
        public = []
        for line in out.splitlines()[1:]:
            cols = line.split()
            if len(cols) < 5:
                continue
            local = cols[4]
            if local.startswith("0.0.0.0:") or local.startswith("[::]:"):
                public.append(local)
        return len(public) == 0, f"{len(public)} public listener(s)"

    def _chk_processes(self):
        # cheap: anything running as root with name not in known set?
        try:
            import psutil
        except ImportError:
            return True, "psutil missing"
        unknown = []
        ok_names = {"systemd","init","kworker","kthreadd","sshd","NetworkManager",
                    "Xorg","Hyprland","python","python3","bash","zsh","sudo"}
        for p in psutil.process_iter(["name","username"]):
            try:
                if p.info["username"] == "root" and p.info["name"] not in ok_names:
                    unknown.append(p.info["name"])
            except Exception:
                continue
        return len(unknown) < 25, f"{len(unknown)} root processes"

    def _chk_ssh(self):
        cfg = Path("/etc/ssh/sshd_config")
        if not cfg.is_file():
            return True, "SSH server not installed"
        try:
            txt = cfg.read_text()
        except Exception:
            return True, "(unreadable)"
        bad = []
        if "PermitRootLogin yes" in txt: bad.append("root login allowed")
        if "PasswordAuthentication yes" in txt and "PasswordAuthentication no" not in txt:
            bad.append("password auth enabled")
        return not bad, "ok" if not bad else "; ".join(bad)

    def _chk_sudoers(self):
        s = Path("/etc/sudoers")
        if not s.is_file():
            return True, "no /etc/sudoers"
        try:
            txt = s.read_text()
        except Exception:
            return True, "(needs root to read)"
        bad = [l for l in txt.splitlines() if l.strip().startswith(("#","Defaults"))
               is False and "NOPASSWD:ALL" in l]
        return len(bad) == 0, f"{len(bad)} NOPASSWD entries"

    def _chk_world_writable(self):
        rc, out = _run(["find", "/etc", "/usr/local", "-xdev", "-perm", "-0002",
                        "-type", "f", "-not", "-path", "*/proc/*"], timeout=10)
        n = len([l for l in out.splitlines() if l.strip()])
        return n == 0, f"{n} world-writable files"

    def _chk_cron(self):
        susp = []
        for p in ("/etc/crontab", "/etc/cron.d"):
            try:
                if Path(p).is_file():
                    txt = Path(p).read_text()
                    if "curl" in txt or "wget" in txt or "/dev/tcp/" in txt:
                        susp.append(p)
            except Exception:
                continue
        return len(susp) == 0, f"{len(susp)} suspicious entries"

    def _chk_luks(self):
        rc, out = _run(["lsblk", "-no", "TYPE,NAME"])
        ok = "crypt" in out
        return ok, "encrypted volume present" if ok else "no LUKS volume found"

    def _chk_dns(self):
        try:
            txt = Path("/etc/resolv.conf").read_text()
            secure = any(s in txt for s in ("1.1.1.1","9.9.9.9","94.140.14.14"))
            return secure, "secure resolver in use" if secure else "system DNS in use"
        except Exception:
            return True, "(unreadable)"

    def _chk_plaintext_pw(self):
        rc, out = _run(["grep","-rIli","-w","password","--include=*.env","--include=*.txt",
                        f"{Path.home()}"], timeout=10)
        n = len([l for l in out.splitlines() if l.strip()])
        return n == 0, f"{n} files mention 'password'"

    def _chk_browser_ext(self):
        prof = Path.home() / ".mozilla" / "firefox"
        if not prof.exists():
            return True, "no Firefox profile"
        n = sum(1 for p in prof.rglob("extensions/*"))
        return True, f"{n} extension entries (review manually)"

    def _chk_startup(self):
        n = 0
        for p in (Path.home() / ".config/autostart", Path("/etc/xdg/autostart")):
            if p.is_dir():
                n += len(list(p.glob("*.desktop")))
        return True, f"{n} autostart entries"

    def _chk_phantom(self):
        pid_file = Path.home() / ".nyxus/phantom/phantom.pid"
        if not pid_file.is_file():
            return False, "Phantom not installed"
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)
            return True, f"running (pid {pid})"
        except Exception:
            return False, "stale pid file"


# =========================================================================== #
# NETWORK SCANNER                                                             #
# =========================================================================== #
class NetworkScanner:
    def lan_discover(self) -> list[dict]:
        if not _have("nmap"):
            return [{"ip": "?", "mac": "", "hostname": "nmap not installed",
                     "status": "warn"}]
        # determine the local /24
        rc, out = _run(["ip","-4","addr","show","scope","global"])
        cidr = "192.168.1.0/24"
        for line in out.splitlines():
            line = line.strip()
            if line.startswith("inet "):
                a = line.split()[1]
                # convert to /24
                ip = a.split("/")[0]
                octs = ip.split(".")
                cidr = f"{octs[0]}.{octs[1]}.{octs[2]}.0/24"
                break
        rc, out = _run(["nmap","-sn",cidr], timeout=120)
        devices = []
        cur: dict | None = None
        for line in out.splitlines():
            if line.startswith("Nmap scan report for"):
                if cur:
                    devices.append(cur)
                # "Nmap scan report for hostname (1.2.3.4)" or "for 1.2.3.4"
                rest = line.split("for", 1)[1].strip()
                if "(" in rest:
                    name, ip = rest.split("(", 1)
                    cur = {"hostname": name.strip(), "ip": ip.rstrip(")"), "mac": "", "status": "live"}
                else:
                    cur = {"hostname": "?", "ip": rest, "mac": "", "status": "live"}
            elif line.startswith("MAC Address:"):
                if cur:
                    parts = line.split()
                    cur["mac"] = parts[2]
                    cur["hostname"] = " ".join(parts[3:]).strip("()") or cur["hostname"]
        if cur:
            devices.append(cur)
        return devices

    def own_ports(self) -> list[dict]:
        if not _have("ss"):
            return []
        rc, out = _run(["ss", "-tunlp"])
        rows = []
        for line in out.splitlines()[1:]:
            cols = line.split()
            if len(cols) < 5:
                continue
            proto = cols[0]
            local = cols[4]
            ip, _, port = local.rpartition(":")
            proc = ""
            if "users:" in line:
                proc = line.split("users:")[1][:120]
            rows.append({"proto": proto, "port": port, "bind": ip, "process": proc})
        return rows

    def external_ip(self) -> dict:
        out = {"ip": "?", "country": "?", "asn": "?"}
        try:
            import urllib.request, json as _json
            with urllib.request.urlopen("https://ipinfo.io/json", timeout=5) as r:
                d = _json.load(r)
                out.update({"ip": d.get("ip","?"), "country": d.get("country","?"),
                            "asn": d.get("org","?"), "city": d.get("city","")})
        except Exception as exc:
            out["error"] = str(exc)
        return out


# =========================================================================== #
# MALWARE SCANNER                                                             #
# =========================================================================== #
class MalwareScanner:
    def run_all(self) -> str:
        sections = []
        if _have("clamscan"):
            rc, out = _run(["clamscan","-ri","--no-summary",str(Path.home())], timeout=600)
            sections.append("==== ClamAV (home dir) ====\n" + (out or "(clean)"))
        else:
            sections.append("ClamAV not installed (pacman -S clamav)")
        if _have("rkhunter"):
            rc, out = _run(["rkhunter","--check","--sk","--rwo"], timeout=300)
            sections.append("==== rkhunter ====\n" + (out or "(clean)"))
        else:
            sections.append("rkhunter not installed")
        if _have("chkrootkit"):
            rc, out = _run(["chkrootkit"], timeout=300)
            sections.append("==== chkrootkit ====\n" + (out or "(clean)"))
        else:
            sections.append("chkrootkit not installed")
        return "\n\n".join(sections) or "no scanners available"


# =========================================================================== #
# HIBP                                                                        #
# =========================================================================== #
def hibp_email_count(email: str) -> int:
    """Use HIBP unified API. Anonymous range — returns count via search."""
    if not email or "@" not in email:
        return 0
    try:
        import urllib.request
        # HIBP has rate-limited public endpoints; use the "breachedaccount" with
        # truncated response which works without a key for the range query.
        # Many users won't have the key — fall back gracefully.
        req = urllib.request.Request(
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}?truncateResponse=true",
            headers={"User-Agent": "nyxus-shield/1.0",
                     "hibp-api-key": os.environ.get("HIBP_API_KEY", "")},
        )
        with urllib.request.urlopen(req, timeout=8) as r:
            import json as _json
            return len(_json.load(r) or [])
    except Exception:
        return 0


# =========================================================================== #
# REPORT BUILDER                                                              #
# =========================================================================== #
def build_report_markdown() -> str:
    qs = QuickScanner()
    out = ["# NYXUS Shield — security report",
           f"_generated: {time.strftime('%Y-%m-%d %H:%M:%S %Z')}_", "",
           "## Health summary"]
    for name, ok, detail in qs.health_checks():
        out.append(f"- [{'x' if ok else ' '}] **{name}** — {detail}")
    out.append("")
    out.append("## Detailed checks")
    results: list[str] = []
    def cb(i, total, name, ok, detail):
        results.append(f"- [{'x' if ok else ' '}] **{name}** — {detail}")
    qs.full_scan(cb)
    out.extend(results)
    out.append("")
    out.append("_© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED_")
    return "\n".join(out)
