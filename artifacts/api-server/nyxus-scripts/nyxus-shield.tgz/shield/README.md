# NYXUS Shield

> The everyday security app for NyX.x.OS — plain-English controls that anyone
> in the household can use, sitting on top of NYXUS Phantom's silent daemon.
> © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

## What it does

Twelve panels behind a left sidebar:

| panel       | what it does                                           |
| ----------- | ------------------------------------------------------ |
| Dashboard   | threat score, 5 health checks, recent Phantom alerts   |
| Quick Scan  | 15-step end-to-end audit with pass/fail per step       |
| Network     | LAN sweep (nmap), own listening ports, external IP     |
| Firewall    | UFW manager + Gaming / Work / Max Security presets     |
| Malware     | ClamAV + rkhunter + chkrootkit one-click               |
| Passwords   | strength meter, HIBP breach check                      |
| Privacy     | camera/mic/audio device + DNS audit                    |
| Updates     | pacman / apt update list                               |
| VPN         | WireGuard up/down + DNS-leak check                     |
| Phantom     | live timeline of the daemon's events                   |
| Reports     | one-click markdown daily security report               |
| Settings    | scan schedule, notification level, autofix policy      |

## Theme

Shield runs the official NYXUS dark dark theme — purple → pink gradient borders,
gold accents, and the handwritten Caveat / Patrick Hand display + body fonts.
The theme is installed system-wide at `/usr/share/nyxus/theme/` and loaded
automatically on launch.

## Install

```bash
sudo bash install.sh
nyxus-shield
```

## Files

```
/opt/nyxus-shield/main.py        # entry + window + view classes
/opt/nyxus-shield/scans.py       # quick-scan engine, network scanner, malware
/opt/nyxus-shield/net.py         # UFW + WireGuard helpers
/opt/nyxus-shield/db.py          # local sqlite store
/usr/share/nyxus/theme/          # nyxus_theme.css + nyxus_theme.py
/usr/share/applications/nyxus-shield.desktop
~/.local/share/fonts/nyxus/      # Caveat, PatrickHand, JetBrainsMono TTFs
~/.nyxus/shield/                 # local store, reports
```

## Phantom integration

Shield reads Phantom's database read-only:

```
~/.nyxus/phantom/events.db   # event timeline (id, ts, severity, module, message)
~/.nyxus/phantom/spool/      # ad-hoc notification pickups
```

If Phantom is not installed yet, Shield's Phantom panel shows a friendly
"not installed" notice and the dashboard's threat score is computed from
its own checks alone.
