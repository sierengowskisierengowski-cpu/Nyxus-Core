"""
NYXUS Shield — network helpers (UFW firewall + WireGuard VPN).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────



def _run(cmd: list[str], timeout: float = 10) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr)
    except Exception as exc:
        return 1, str(exc)


# =========================================================================== #
# FIREWALL MANAGER (UFW)                                                      #
# =========================================================================== #
class FirewallManager:
    def status(self) -> dict:
        if not shutil.which("ufw"):
            return {"enabled": False, "msg": "ufw not installed", "rules": []}
        rc, out = _run(["ufw", "status", "verbose"])
        enabled = "Status: active" in out
        rules: list[dict] = []
        for line in out.splitlines():
            line = line.rstrip()
            if not line or "Status:" in line or "To " in line.strip()[:4]:
                continue
            # rough rule parse — UFW format varies
            if "ALLOW" in line.upper():
                rules.append({"action": "ALLOW", "plain": line.strip()})
            elif "DENY" in line.upper() or "REJECT" in line.upper():
                rules.append({"action": "DENY", "plain": line.strip()})
            elif "LIMIT" in line.upper():
                rules.append({"action": "LIMIT", "plain": line.strip()})
        return {"enabled": enabled,
                "msg": "active" if enabled else "inactive",
                "rules": rules}

    def enable(self) -> bool:
        rc, _ = _run(["pkexec", "ufw", "--force", "enable"])
        return rc == 0

    def disable(self) -> bool:
        rc, _ = _run(["pkexec", "ufw", "--force", "disable"])
        return rc == 0

    def apply_preset(self, name: str) -> bool:
        # convenience presets
        commands: list[list[str]] = []
        if name == "Gaming":
            commands = [
                ["pkexec","ufw","--force","reset"],
                ["pkexec","ufw","default","deny","incoming"],
                ["pkexec","ufw","default","allow","outgoing"],
                ["pkexec","ufw","allow","27015:27030/tcp"],
                ["pkexec","ufw","allow","27015:27030/udp"],
                ["pkexec","ufw","--force","enable"],
            ]
        elif name == "Work":
            commands = [
                ["pkexec","ufw","--force","reset"],
                ["pkexec","ufw","default","deny","incoming"],
                ["pkexec","ufw","default","allow","outgoing"],
                ["pkexec","ufw","allow","ssh"],
                ["pkexec","ufw","allow","https"],
                ["pkexec","ufw","--force","enable"],
            ]
        elif name == "Maximum Security":
            commands = [
                ["pkexec","ufw","--force","reset"],
                ["pkexec","ufw","default","deny","incoming"],
                ["pkexec","ufw","default","deny","outgoing"],
                ["pkexec","ufw","allow","out","53"],     # DNS
                ["pkexec","ufw","allow","out","443/tcp"],# HTTPS
                ["pkexec","ufw","allow","out","123"],    # NTP
                ["pkexec","ufw","--force","enable"],
            ]
        elif name == "Custom":
            return True   # leave existing rules
        for c in commands:
            _run(c)
        return True


# =========================================================================== #
# VPN MANAGER (WireGuard)                                                     #
# =========================================================================== #
class VPNManager:
    def status(self) -> dict:
        if not shutil.which("wg"):
            return {"installed": False, "msg": "wireguard-tools not installed"}
        rc, out = _run(["wg", "show"])
        if not out.strip():
            return {"installed": True, "active": False,
                    "msg": "no tunnel up · use `wg-quick up <name>`"}
        return {"installed": True, "active": True, "details": out}

    def connect(self) -> dict:
        # find first config in /etc/wireguard
        cfgs = list(Path("/etc/wireguard").glob("*.conf")) if Path("/etc/wireguard").exists() else []
        if not cfgs:
            return {"ok": False, "msg": "no .conf in /etc/wireguard"}
        name = cfgs[0].stem
        rc, out = _run(["pkexec", "wg-quick", "up", name])
        return {"ok": rc == 0, "msg": out.strip() or "ok"}

    def disconnect(self) -> dict:
        rc, out = _run(["wg", "show", "interfaces"])
        ifaces = out.split()
        if not ifaces:
            return {"ok": True, "msg": "no active tunnel"}
        rc, out = _run(["pkexec", "wg-quick", "down", ifaces[0]])
        return {"ok": rc == 0, "msg": out.strip() or "ok"}

    def dns_leak_check(self) -> dict:
        try:
            import urllib.request, json
            with urllib.request.urlopen("https://1.1.1.1/cdn-cgi/trace", timeout=5) as r:
                txt = r.read().decode()
            ip = next((l.split("=")[1] for l in txt.splitlines()
                       if l.startswith("ip=")), "?")
            return {"visible_ip": ip, "service": "cloudflare-trace"}
        except Exception as exc:
            return {"error": str(exc)}
