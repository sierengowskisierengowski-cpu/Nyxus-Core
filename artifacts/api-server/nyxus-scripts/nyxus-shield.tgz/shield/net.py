"""
NYXUS Shield — network helpers (UFW firewall + WireGuard VPN).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path


def _run(cmd: list[str], timeout: float = 10) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr)
    except Exception as exc:
        return 1, str(exc)


# =========================================================================== #
# FIREWALL MANAGER (UFW)                                                      #
# =========================================================================== #
class FirewallManager:
    def status(self) -> dict:
        if not shutil.which("ufw"):
            return {"enabled": False, "msg": "ufw not installed", "rules": []}
        rc, out = _run(["ufw", "status", "verbose"])
        enabled = "Status: active" in out
        rules: list[dict] = []
        for line in out.splitlines():
            line = line.rstrip()
            if not line or "Status:" in line or "To " in line.strip()[:4]:
                continue
            # rough rule parse — UFW format varies
            if "ALLOW" in line.upper():
                rules.append({"action": "ALLOW", "plain": line.strip()})
            elif "DENY" in line.upper() or "REJECT" in line.upper():
                rules.append({"action": "DENY", "plain": line.strip()})
            elif "LIMIT" in line.upper():
                rules.append({"action": "LIMIT", "plain": line.strip()})
        return {"enabled": enabled,
                "msg": "active" if enabled else "inactive",
                "rules": rules}

    def enable(self) -> bool:
        rc, _ = _run(["pkexec", "ufw", "--force", "enable"])
        return rc == 0

    def disable(self) -> bool:
        rc, _ = _run(["pkexec", "ufw", "--force", "disable"])
        return rc == 0

    def apply_preset(self, name: str) -> bool:
        # convenience presets
        commands: list[list[str]] = []
        if name == "Gaming":
            commands = [
                ["pkexec","ufw","--force","reset"],
                ["pkexec","ufw","default","deny","incoming"],
                ["pkexec","ufw","default","allow","outgoing"],
                ["pkexec","ufw","allow","27015:27030/tcp"],
                ["pkexec","ufw","allow","27015:27030/udp"],
                ["pkexec","ufw","--force","enable"],
            ]
        elif name == "Work":
            commands = [
                ["pkexec","ufw","--force","reset"],
                ["pkexec","ufw","default","deny","incoming"],
                ["pkexec","ufw","default","allow","outgoing"],
                ["pkexec","ufw","allow","ssh"],
                ["pkexec","ufw","allow","https"],
                ["pkexec","ufw","--force","enable"],
            ]
        elif name == "Maximum Security":
            commands = [
                ["pkexec","ufw","--force","reset"],
                ["pkexec","ufw","default","deny","incoming"],
                ["pkexec","ufw","default","deny","outgoing"],
                ["pkexec","ufw","allow","out","53"],     # DNS
                ["pkexec","ufw","allow","out","443/tcp"],# HTTPS
                ["pkexec","ufw","allow","out","123"],    # NTP
                ["pkexec","ufw","--force","enable"],
            ]
        elif name == "Custom":
            return True   # leave existing rules
        for c in commands:
            _run(c)
        return True


# =========================================================================== #
# VPN MANAGER (WireGuard)                                                     #
# =========================================================================== #
class VPNManager:
    def status(self) -> dict:
        if not shutil.which("wg"):
            return {"installed": False, "msg": "wireguard-tools not installed"}
        rc, out = _run(["wg", "show"])
        if not out.strip():
            return {"installed": True, "active": False,
                    "msg": "no tunnel up · use `wg-quick up <name>`"}
        return {"installed": True, "active": True, "details": out}

    def connect(self) -> dict:
        # find first config in /etc/wireguard
        cfgs = list(Path("/etc/wireguard").glob("*.conf")) if Path("/etc/wireguard").exists() else []
        if not cfgs:
            return {"ok": False, "msg": "no .conf in /etc/wireguard"}
        name = cfgs[0].stem
        rc, out = _run(["pkexec", "wg-quick", "up", name])
        return {"ok": rc == 0, "msg": out.strip() or "ok"}

    def disconnect(self) -> dict:
        rc, out = _run(["wg", "show", "interfaces"])
        ifaces = out.split()
        if not ifaces:
            return {"ok": True, "msg": "no active tunnel"}
        rc, out = _run(["pkexec", "wg-quick", "down", ifaces[0]])
        return {"ok": rc == 0, "msg": out.strip() or "ok"}

    def dns_leak_check(self) -> dict:
        try:
            import urllib.request, json
            with urllib.request.urlopen("https://1.1.1.1/cdn-cgi/trace", timeout=5) as r:
                txt = r.read().decode()
            ip = next((l.split("=")[1] for l in txt.splitlines()
                       if l.startswith("ip=")), "?")
            return {"visible_ip": ip, "service": "cloudflare-trace"}
        except Exception as exc:
            return {"error": str(exc)}
