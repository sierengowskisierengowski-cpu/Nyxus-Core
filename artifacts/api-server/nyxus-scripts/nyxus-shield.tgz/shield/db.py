"""
NYXUS Shield — local sqlite store (scan history + whitelist).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path


SCHEMA = """
CREATE TABLE IF NOT EXISTS scan_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    type TEXT NOT NULL,
    pass_count INTEGER NOT NULL,
    fail_count INTEGER NOT NULL,
    summary TEXT
);
CREATE TABLE IF NOT EXISTS whitelist (
    kind TEXT NOT NULL,         -- 'ip', 'process', 'usb', 'extension'
    value TEXT NOT NULL,
    note TEXT,
    added REAL NOT NULL,
    PRIMARY KEY(kind, value)
);
CREATE TABLE IF NOT EXISTS preferences (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


class ShieldDB:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
        self.conn.executescript(SCHEMA)

    def record_scan(self, scan_type: str, pass_n: int, fail_n: int, summary: str = "") -> None:
        self.conn.execute(
            "INSERT INTO scan_history(ts, type, pass_count, fail_count, summary) VALUES(?,?,?,?,?)",
            (time.time(), scan_type, pass_n, fail_n, summary),
        )

    def whitelist(self, kind: str, value: str, note: str = "") -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO whitelist(kind, value, note, added) VALUES(?,?,?,?)",
            (kind, value, note, time.time()),
        )

    def is_whitelisted(self, kind: str, value: str) -> bool:
        return bool(self.conn.execute(
            "SELECT 1 FROM whitelist WHERE kind=? AND value=?",
            (kind, value),
        ).fetchone())

    def set_pref(self, key: str, value: str) -> None:
        self.conn.execute("INSERT OR REPLACE INTO preferences VALUES(?,?)", (key, value))

    def get_pref(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM preferences WHERE key=?", (key,)).fetchone()
        return row[0] if row else default
