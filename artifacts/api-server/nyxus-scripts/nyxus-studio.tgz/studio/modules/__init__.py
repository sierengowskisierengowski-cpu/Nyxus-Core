"""NYXUS Studio modules — m01_paint .. m08_type."""
