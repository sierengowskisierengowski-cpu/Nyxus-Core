"""NYXUS Studio — m08 Type (stub)."""
from ui import build_stub_panel


class Module:
    KEY = "type"
    TITLE = "Type"
    GLYPH = "🅰"
    ACCENT = (1.00, 0.55, 0.00)
    DESC = "Type design · glyphs, kerning, font export"
    ENABLED = False

    def __init__(self, app): self.app = app

    def build_workspace(self):
        return build_stub_panel(
            "Type Designer", "🅰", self.ACCENT,
            "glyphs  ·  metrics  ·  kerning  ·  OTF / WOFF export")

    def build_top_tools(self):  return None
    def build_right_panel(self): return None
    def on_activate(self):  pass
    def on_deactivate(self): pass
