"""NYXUS Studio — m05 Animate (stub)."""
from ui import build_stub_panel


class Module:
    KEY = "animate"
    TITLE = "Animate"
    GLYPH = "⏱"
    ACCENT = (0.22, 1.00, 0.08)
    DESC = "Frame animation · keyframes, easing, GIF export"
    ENABLED = False

    def __init__(self, app): self.app = app

    def build_workspace(self):
        return build_stub_panel(
            "Animator", "⏱", self.ACCENT,
            "keyframes  ·  easing curves  ·  GIF / WebM export")

    def build_top_tools(self):  return None
    def build_right_panel(self): return None
    def on_activate(self):  pass
    def on_deactivate(self): pass
