"""NYXUS Studio — m01 Paint: raster painting with brushes, eraser, and layers."""
from __future__ import annotations

import math
from pathlib import Path

from gi.repository import Gtk, Gdk, GObject  # noqa: E402
import cairo  # noqa: E402

from ui import (SketchButton, ColorPalette, SketchSlider, LayerPanel,
                NEON_PINK)


class Module:
    KEY = "paint"
    TITLE = "Paint"
    GLYPH = "🖌"
    ACCENT = (1.00, 0.00, 1.00)
    DESC = "Raster painting · brushes · layers · PNG export"
    ENABLED = True

    def __init__(self, app):
        self.app = app
        self.doc = app.document
        if not any(l.kind == "raster" for l in self.doc.layers):
            self.doc.add_layer("raster")
        self.tool = "brush"
        self.color = (0.96, 0.0, 0.96, 1.0)
        self.size = 14.0
        self.opacity = 1.0
        self.canvas = None
        self.layer_panel = None
        self.color_preview = None

    # ── widgets ─
    def build_workspace(self):
        self.canvas = PaintCanvas(self)
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.set_hexpand(True); sw.set_vexpand(True)
        sw.set_child(self.canvas)
        return sw

    def build_top_tools(self):
        box = Gtk.Box(spacing=4)
        for key, glyph, tip in [
            ("brush",  "🖌", "Brush"),
            ("eraser", "▱", "Eraser"),
            ("fill",   "▣", "Fill layer"),
            ("picker", "⊙", "Color picker"),
            ("clear",  "🗑", "Clear layer"),
        ]:
            b = SketchButton(tip, width=84, height=26, color=self.ACCENT,
                             glyph=glyph, tooltip=tip)
            b.connect("clicked", lambda _b, k=key: self._top_tool(k))
            box.append(b)
        return box

    def build_right_panel(self):
        wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        wrap.set_margin_start(10); wrap.set_margin_end(10)
        wrap.set_margin_top(10); wrap.set_margin_bottom(10)

        t = Gtk.Label(label="color", xalign=0)
        t.add_css_class("nyx-panel-title")
        wrap.append(t)
        pal = ColorPalette(columns=4)
        pal.connect("chosen", self._on_color)
        wrap.append(pal)
        self.color_preview = Gtk.DrawingArea()
        self.color_preview.set_size_request(-1, 22)
        try:
            self.color_preview.set_content_height(22)
        except Exception:
            pass
        self.color_preview.set_draw_func(self._draw_color_preview)
        wrap.append(self.color_preview)

        t = Gtk.Label(label="brush", xalign=0)
        t.add_css_class("nyx-panel-title")
        wrap.append(t)
        size_s = SketchSlider("size", self.size, 1, 200)
        size_s.connect("value-changed", lambda _s, v: setattr(self, "size", v))
        wrap.append(size_s)
        opa = SketchSlider("opacity", self.opacity * 100, 1, 100)
        opa.connect("value-changed",
                    lambda _s, v: setattr(self, "opacity", v / 100))
        wrap.append(opa)

        self.layer_panel = LayerPanel(self.doc)
        self.layer_panel.connect("changed", lambda *_:
                                 (self.canvas.queue_draw()
                                  if self.canvas else None,
                                  self.app._refresh_status()))
        wrap.append(self.layer_panel)
        return wrap

    # ── handlers ─
    def _on_color(self, _w, r, g, b, a):
        self.color = (r, g, b, a)
        if self.color_preview:
            self.color_preview.queue_draw()

    def _draw_color_preview(self, area, cr, w, h, _=None):
        cr.set_source_rgba(*self.color)
        cr.rectangle(0, 0, w, h)
        cr.fill()
        cr.set_source_rgba(1, 1, 1, 0.30)
        cr.set_line_width(1)
        cr.rectangle(0.5, 0.5, w - 1, h - 1)
        cr.stroke()

    def _top_tool(self, key):
        if key == "clear":
            self.clear_active(); return
        self.tool = key
        if self.app:
            self.app.set_status(f"tool: {key}")

    def get_active_raster(self):
        l = self.doc.get_active()
        if l and l.kind == "raster":
            return l
        for l in self.doc.layers:
            if l.kind == "raster":
                return l
        return None

    # ── drawing ops ─
    def stamp(self, cr, x, y):
        cr.set_operator(cairo.OPERATOR_OVER)
        cr.set_source_rgba(self.color[0], self.color[1], self.color[2],
                           self.color[3] * self.opacity)
        cr.arc(x, y, max(0.5, self.size / 2), 0, math.pi * 2)
        cr.fill()

    def erase(self, cr, x, y):
        cr.set_operator(cairo.OPERATOR_CLEAR)
        cr.arc(x, y, max(0.5, self.size / 2), 0, math.pi * 2)
        cr.fill()
        cr.set_operator(cairo.OPERATOR_OVER)

    def fill_layer(self):
        layer = self.get_active_raster()
        if not layer:
            return
        cr = cairo.Context(layer.surface)
        cr.set_operator(cairo.OPERATOR_OVER)
        cr.set_source_rgba(self.color[0], self.color[1], self.color[2],
                           self.color[3] * self.opacity)
        cr.paint()
        if self.canvas:
            self.canvas.queue_draw()
        self.doc.modified = True

    def pick_at(self, x, y):
        rendered = self.doc.render_to_surface()
        ix, iy = int(x), int(y)
        if 0 <= ix < rendered.get_width() and 0 <= iy < rendered.get_height():
            data = rendered.get_data()
            stride = rendered.get_stride()
            o = iy * stride + ix * 4
            # cairo ARGB32 little-endian = BGRA bytes
            b, g, r, a = data[o], data[o + 1], data[o + 2], data[o + 3]
            self.color = (r / 255, g / 255, b / 255, max(a / 255, 0.01))
            if self.color_preview:
                self.color_preview.queue_draw()
            if self.app:
                self.app.set_status(
                    f"picked rgba({r},{g},{b},{a})")

    def clear_active(self):
        layer = self.get_active_raster()
        if not layer:
            return
        cr = cairo.Context(layer.surface)
        cr.set_operator(cairo.OPERATOR_CLEAR)
        cr.paint()
        if self.canvas:
            self.canvas.queue_draw()
        self.doc.modified = True

    def on_activate(self):
        if self.layer_panel:
            self.layer_panel.refresh()
        if self.canvas:
            self.canvas.queue_draw()
        if self.app:
            self.app.set_status("paint mode — drag on the canvas to draw")

    def on_deactivate(self):
        pass

    def save_native(self):
        p = Path.home() / f"{self.doc.name}.nyxpaint.png"
        self.doc.export_png(str(p))
        if self.app:
            self.app.set_status(f"saved → {p}")

    def export(self):
        p = Path.home() / f"{self.doc.name}.png"
        self.doc.export_png(str(p))
        if self.app:
            self.app.set_status(f"exported → {p}")


class PaintCanvas(Gtk.DrawingArea):
    def __init__(self, module: "Module"):
        super().__init__()
        self.m = module
        self.doc = module.doc
        self.set_size_request(self.doc.w, self.doc.h)
        try:
            self.set_content_width(self.doc.w)
            self.set_content_height(self.doc.h)
        except Exception:
            pass
        self.set_draw_func(self._draw)
        gd = Gtk.GestureDrag()
        gd.set_button(1)
        gd.connect("drag-begin",  self._begin)
        gd.connect("drag-update", self._update)
        gd.connect("drag-end",    self._end)
        self.add_controller(gd)
        self._start = None
        self._last = None

    def _begin(self, gd, x, y):
        self._start = (x, y)
        self._last = (x, y)
        if self.m.tool == "fill":
            self.m.fill_layer(); return
        if self.m.tool == "picker":
            self.m.pick_at(x, y); return
        layer = self.m.get_active_raster()
        if not layer:
            return
        cr = cairo.Context(layer.surface)
        if self.m.tool == "eraser":
            self.m.erase(cr, x, y)
        else:
            self.m.stamp(cr, x, y)
        self.queue_draw()

    def _update(self, gd, dx, dy):
        if not self._start:
            return
        if self.m.tool in ("fill", "picker"):
            return
        x = self._start[0] + dx
        y = self._start[1] + dy
        layer = self.m.get_active_raster()
        if not layer:
            return
        cr = cairo.Context(layer.surface)
        lx, ly = self._last
        dist = math.hypot(x - lx, y - ly)
        steps = max(1, int(dist / max(1.0, self.m.size / 4)))
        for i in range(1, steps + 1):
            ix = lx + (x - lx) * (i / steps)
            iy = ly + (y - ly) * (i / steps)
            if self.m.tool == "eraser":
                self.m.erase(cr, ix, iy)
            else:
                self.m.stamp(cr, ix, iy)
        self._last = (x, y)
        self.queue_draw()

    def _end(self, *a):
        self._start = None
        self._last = None
        self.doc.modified = True

    def _draw(self, area, cr, w, h, _=None):
        cs = 12
        for y in range(0, h, cs):
            for x in range(0, w, cs):
                if ((x // cs) + (y // cs)) % 2:
                    cr.set_source_rgb(0.05, 0.05, 0.09)
                else:
                    cr.set_source_rgb(0.07, 0.07, 0.11)
                cr.rectangle(x, y, cs, cs)
                cr.fill()
        rendered = self.doc.render_to_surface()
        cr.set_source_surface(rendered, 0, 0)
        cr.paint()
        cr.set_source_rgba(1.0, 0.0, 1.0, 0.45)
        cr.set_line_width(1.5)
        cr.rectangle(0.5, 0.5, self.doc.w - 1, self.doc.h - 1)
        cr.stroke()
