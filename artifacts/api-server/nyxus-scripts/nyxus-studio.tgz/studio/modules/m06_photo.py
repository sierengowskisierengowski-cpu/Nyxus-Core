"""NYXUS Studio — m06 Photo (stub)."""
from ui import build_stub_panel


class Module:
    KEY = "photo"
    TITLE = "Photo"
    GLYPH = "🌃"
    ACCENT = (1.00, 0.84, 0.00)
    DESC = "Photo edit · adjust, filter, crop, retouch"
    ENABLED = False

    def __init__(self, app): self.app = app

    def build_workspace(self):
        return build_stub_panel(
            "Photo Editor", "🌃", self.ACCENT,
            "exposure  ·  curves  ·  filters  ·  crop  ·  spot heal")

    def build_top_tools(self):  return None
    def build_right_panel(self): return None
    def on_activate(self):  pass
    def on_deactivate(self): pass
