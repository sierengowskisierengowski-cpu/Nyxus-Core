"""NYXUS Studio — m07 Layout (stub)."""
from ui import build_stub_panel


class Module:
    KEY = "layout"
    TITLE = "Layout"
    GLYPH = "📐"
    ACCENT = (0.00, 1.00, 0.70)
    DESC = "Page layout · grids, columns, multi-page export"
    ENABLED = False

    def __init__(self, app): self.app = app

    def build_workspace(self):
        return build_stub_panel(
            "Page Layout", "📐", self.ACCENT,
            "grids  ·  columns  ·  master pages  ·  PDF export")

    def build_top_tools(self):  return None
    def build_right_panel(self): return None
    def on_activate(self):  pass
    def on_deactivate(self): pass
