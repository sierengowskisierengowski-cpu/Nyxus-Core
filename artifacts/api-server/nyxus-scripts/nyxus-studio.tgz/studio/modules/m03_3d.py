"""NYXUS Studio — m03 3D (stub)."""
from ui import build_stub_panel


class Module:
    KEY = "3d"
    TITLE = "3D"
    GLYPH = "🧊"
    ACCENT = (0.70, 0.40, 1.00)
    DESC = "3D modeling · primitives, materials, viewport"
    ENABLED = False

    def __init__(self, app): self.app = app

    def build_workspace(self):
        return build_stub_panel(
            "3D Modeler", "🧊", self.ACCENT,
            "primitives  ·  gizmos  ·  materials  ·  OBJ export")

    def build_top_tools(self):  return None
    def build_right_panel(self): return None
    def on_activate(self):  pass
    def on_deactivate(self): pass
