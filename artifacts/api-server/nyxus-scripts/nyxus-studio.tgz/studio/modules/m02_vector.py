"""NYXUS Studio — m02 Vector: shapes, text, and SVG export on a vector layer."""
from __future__ import annotations

import math
from pathlib import Path

from gi.repository import Gtk, Gdk, GObject  # noqa: E402
import cairo  # noqa: E402

from ui import (SketchButton, ColorPalette, SketchSlider, LayerPanel,
                TextEntryDialog, NEON_BLUE, NEON_PINK)
from document import VectorObject


class Module:
    KEY = "vector"
    TITLE = "Vector"
    GLYPH = "✏"
    ACCENT = (0.42, 0.86, 1.00)
    DESC = "Vector design · shapes · text · SVG export"
    ENABLED = True

    def __init__(self, app):
        self.app = app
        self.doc = app.document
        if not any(l.kind == "vector" for l in self.doc.layers):
            self.doc.add_layer("vector")
        self.tool = "select"
        self.fill = (0.60, 0.40, 1.00, 1.0)
        self.stroke = (1.00, 0.00, 1.00, 1.0)
        self.stroke_w = 2.0
        self.font_size = 28
        self.selected = None
        self.canvas = None
        self.layer_panel = None

    def build_workspace(self):
        self.canvas = VectorCanvas(self)
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.set_hexpand(True); sw.set_vexpand(True)
        sw.set_child(self.canvas)
        return sw

    def build_top_tools(self):
        box = Gtk.Box(spacing=4)
        for key, glyph, tip in [
            ("select",  "↖", "Select / move"),
            ("rect",    "▭", "Rectangle"),
            ("ellipse", "○", "Ellipse"),
            ("line",    "／", "Line"),
            ("text",    "T", "Text"),
            ("delete",  "✕", "Delete selected"),
        ]:
            b = SketchButton(tip, width=88, height=26, color=self.ACCENT,
                             glyph=glyph, tooltip=tip)
            b.connect("clicked", lambda _b, k=key: self._top_tool(k))
            box.append(b)
        return box

    def build_right_panel(self):
        wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        wrap.set_margin_start(10); wrap.set_margin_end(10)
        wrap.set_margin_top(10); wrap.set_margin_bottom(10)

        t = Gtk.Label(label="fill", xalign=0)
        t.add_css_class("nyx-panel-title"); wrap.append(t)
        pal_f = ColorPalette(columns=4)
        pal_f.connect("chosen",
                      lambda _w, r, g, b, a: self._set_fill((r, g, b, a)))
        wrap.append(pal_f)

        t = Gtk.Label(label="stroke", xalign=0)
        t.add_css_class("nyx-panel-title"); wrap.append(t)
        pal_s = ColorPalette(columns=4)
        pal_s.connect("chosen",
                      lambda _w, r, g, b, a: self._set_stroke((r, g, b, a)))
        wrap.append(pal_s)
        sw = SketchSlider("width", self.stroke_w, 0, 24)
        sw.connect("value-changed", lambda _s, v: self._set_stroke_w(v))
        wrap.append(sw)
        fs = SketchSlider("text", self.font_size, 8, 144)
        fs.connect("value-changed", lambda _s, v: self._set_font_size(int(v)))
        wrap.append(fs)

        self.layer_panel = LayerPanel(self.doc)
        self.layer_panel.connect("changed", lambda *_:
                                 (self.canvas.queue_draw()
                                  if self.canvas else None,
                                  self.app._refresh_status()))
        wrap.append(self.layer_panel)
        return wrap

    def _set_fill(self, c):
        self.fill = c
        if self.selected:
            self.selected.fill = c
            if self.canvas:
                self.canvas.queue_draw()
            self.doc.modified = True

    def _set_stroke(self, c):
        self.stroke = c
        if self.selected:
            self.selected.stroke = c
            if self.canvas:
                self.canvas.queue_draw()
            self.doc.modified = True

    def _set_stroke_w(self, v):
        self.stroke_w = v
        if self.selected:
            self.selected.stroke_width = v
            if self.canvas:
                self.canvas.queue_draw()
            self.doc.modified = True

    def _set_font_size(self, v):
        self.font_size = v
        if self.selected and self.selected.kind == "text":
            self.selected.font_size = v
            if self.canvas:
                self.canvas.queue_draw()
            self.doc.modified = True

    def _top_tool(self, key):
        if key == "delete":
            self.delete_selected(); return
        self.tool = key
        if self.app:
            self.app.set_status(f"tool: {key}")

    def get_active_vector(self):
        l = self.doc.get_active()
        if l and l.kind == "vector":
            return l
        for l in self.doc.layers:
            if l.kind == "vector":
                return l
        return None

    def add_object(self, obj: VectorObject):
        l = self.get_active_vector()
        if not l:
            return
        l.objects.append(obj)
        self.selected = obj
        self.doc.modified = True
        if self.canvas:
            self.canvas.queue_draw()

    def delete_selected(self):
        if not self.selected:
            return
        for l in self.doc.layers:
            if l.kind == "vector" and self.selected in l.objects:
                l.objects.remove(self.selected)
        self.selected = None
        self.doc.modified = True
        if self.canvas:
            self.canvas.queue_draw()

    def hit_test(self, x, y):
        for l in reversed(self.doc.layers):
            if l.kind != "vector" or not l.visible:
                continue
            for o in reversed(l.objects):
                if o.hit(x, y):
                    return o
        return None

    def on_activate(self):
        if self.layer_panel:
            self.layer_panel.refresh()
        if self.canvas:
            self.canvas.queue_draw()
        if self.app:
            self.app.set_status("vector mode — drag to draw, click to select")

    def on_deactivate(self):
        pass

    def save_native(self):
        p = Path.home() / f"{self.doc.name}.svg"
        self._write_svg(p)
        if self.app:
            self.app.set_status(f"saved → {p}")

    def export(self):
        svg_p = Path.home() / f"{self.doc.name}.svg"
        png_p = Path.home() / f"{self.doc.name}.png"
        self._write_svg(svg_p)
        self.doc.export_png(str(png_p))
        if self.app:
            self.app.set_status(f"exported → {svg_p.name} + {png_p.name}")

    def _hex(self, c):
        r, g, b, a = c
        return (f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}", a)

    def _write_svg(self, path: Path):
        d = self.doc
        out = ['<?xml version="1.0" encoding="UTF-8"?>',
               f'<svg xmlns="http://www.w3.org/2000/svg" '
               f'width="{d.w}" height="{d.h}" '
               f'viewBox="0 0 {d.w} {d.h}">']
        for layer in d.layers:
            if layer.kind != "vector" or not layer.visible:
                continue
            out.append(
                f'  <g opacity="{layer.opacity:.3f}" '
                f'data-name="{layer.name}">')
            for o in layer.objects:
                out.append("    " + self._object_svg(o))
            out.append("  </g>")
        out.append("</svg>")
        Path(path).write_text("\n".join(out))

    def _object_svg(self, o: VectorObject) -> str:
        f, fa = self._hex(o.fill)
        s, sa = self._hex(o.stroke)
        common = (f'fill="{f}" fill-opacity="{fa:.3f}" '
                  f'stroke="{s}" stroke-opacity="{sa:.3f}" '
                  f'stroke-width="{o.stroke_width:.2f}"')
        if o.kind == "rect":
            return (f'<rect x="{o.x:.1f}" y="{o.y:.1f}" '
                    f'width="{o.w:.1f}" height="{o.h:.1f}" {common}/>')
        if o.kind == "ellipse":
            cx, cy = o.x + o.w / 2, o.y + o.h / 2
            return (f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" '
                    f'rx="{o.w/2:.1f}" ry="{o.h/2:.1f}" {common}/>')
        if o.kind == "line":
            return (f'<line x1="{o.x:.1f}" y1="{o.y:.1f}" '
                    f'x2="{o.x2:.1f}" y2="{o.y2:.1f}" '
                    f'stroke="{s}" stroke-opacity="{sa:.3f}" '
                    f'stroke-width="{o.stroke_width:.2f}" '
                    f'stroke-linecap="round"/>')
        if o.kind == "text":
            text = (o.text or "").replace("&", "&amp;").replace("<", "&lt;")
            return (f'<text x="{o.x:.1f}" y="{o.y + o.font_size:.1f}" '
                    f'fill="{f}" fill-opacity="{fa:.3f}" '
                    f'font-family="Caveat" font-size="{o.font_size}">'
                    f'{text}</text>')
        return ""


class VectorCanvas(Gtk.DrawingArea):
    def __init__(self, module: "Module"):
        super().__init__()
        self.m = module
        self.doc = module.doc
        self.set_size_request(self.doc.w, self.doc.h)
        try:
            self.set_content_width(self.doc.w)
            self.set_content_height(self.doc.h)
        except Exception:
            pass
        self.set_draw_func(self._draw)
        gd = Gtk.GestureDrag()
        gd.set_button(1)
        gd.connect("drag-begin",  self._begin)
        gd.connect("drag-update", self._update)
        gd.connect("drag-end",    self._end)
        self.add_controller(gd)
        # double-click on text to edit
        gc = Gtk.GestureClick()
        gc.set_button(1)
        gc.connect("released", self._click_release)
        self.add_controller(gc)
        self._pending = None
        self._start = None
        self._dragging = None
        self._drag_offset = (0, 0)
        self._click_count = 0
        self._click_pt = (0, 0)

    def _click_release(self, gc, n_press, x, y):
        if n_press >= 2:
            obj = self.m.hit_test(x, y)
            if obj and obj.kind == "text":
                self._edit_text(obj)

    def _edit_text(self, obj):
        win = self.get_root()
        dlg = TextEntryDialog(win, prompt="edit text", initial=obj.text)
        dlg.connect("submitted", lambda _w, t: self._apply_text(obj, t))
        dlg.present()

    def _apply_text(self, obj, t):
        obj.text = t
        self.doc.modified = True
        self.queue_draw()

    def _begin(self, gd, x, y):
        self._start = (x, y)
        if self.m.tool == "select":
            obj = self.m.hit_test(x, y)
            self.m.selected = obj
            self._dragging = obj
            if obj:
                self._drag_offset = (x - obj.x, y - obj.y)
            self.queue_draw()
            return
        if self.m.tool == "text":
            win = self.get_root()
            dlg = TextEntryDialog(win, prompt="enter text", initial="")
            def on_ok(_w, txt):
                if not txt:
                    return
                obj = VectorObject(
                    "text", x=x, y=y, w=200, h=40,
                    text=txt, font_size=self.m.font_size,
                    fill=self.m.fill, stroke=self.m.stroke,
                    stroke_width=self.m.stroke_w)
                self.m.add_object(obj)
            dlg.connect("submitted", on_ok)
            dlg.present()
            return
        # build a pending shape
        obj = None
        if self.m.tool == "rect":
            obj = VectorObject("rect", x=x, y=y, w=1, h=1,
                               fill=self.m.fill, stroke=self.m.stroke,
                               stroke_width=self.m.stroke_w)
        elif self.m.tool == "ellipse":
            obj = VectorObject("ellipse", x=x, y=y, w=1, h=1,
                               fill=self.m.fill, stroke=self.m.stroke,
                               stroke_width=self.m.stroke_w)
        elif self.m.tool == "line":
            obj = VectorObject("line", x=x, y=y, x2=x, y2=y,
                               fill=self.m.fill, stroke=self.m.stroke,
                               stroke_width=self.m.stroke_w)
        if obj:
            self.m.add_object(obj)
            self._pending = obj

    def _update(self, gd, dx, dy):
        if not self._start:
            return
        x = self._start[0] + dx
        y = self._start[1] + dy
        if self.m.tool == "select" and self._dragging:
            o = self._dragging
            o.x = x - self._drag_offset[0]
            o.y = y - self._drag_offset[1]
            self.queue_draw()
            return
        if self._pending:
            o = self._pending
            if o.kind in ("rect", "ellipse"):
                o.w = max(1.0, abs(dx))
                o.h = max(1.0, abs(dy))
                o.x = self._start[0] if dx >= 0 else self._start[0] + dx
                o.y = self._start[1] if dy >= 0 else self._start[1] + dy
            elif o.kind == "line":
                o.x2 = x
                o.y2 = y
            self.queue_draw()

    def _end(self, *a):
        self._pending = None
        self._dragging = None
        self._start = None

    def _draw(self, area, cr, w, h, _=None):
        cs = 12
        for y in range(0, h, cs):
            for x in range(0, w, cs):
                if ((x // cs) + (y // cs)) % 2:
                    cr.set_source_rgb(0.05, 0.05, 0.09)
                else:
                    cr.set_source_rgb(0.07, 0.07, 0.11)
                cr.rectangle(x, y, cs, cs)
                cr.fill()
        rendered = self.doc.render_to_surface()
        cr.set_source_surface(rendered, 0, 0)
        cr.paint()
        cr.set_source_rgba(0.42, 0.86, 1.0, 0.55)
        cr.set_line_width(1.5)
        cr.rectangle(0.5, 0.5, self.doc.w - 1, self.doc.h - 1)
        cr.stroke()
        if self.m.selected:
            o = self.m.selected
            bx, by, bw, bh = o.bounds()
            cr.set_source_rgba(1.0, 0.0, 1.0, 0.95)
            cr.set_line_width(1.5)
            cr.set_dash([5, 4])
            cr.rectangle(bx - 2, by - 2, bw + 4, bh + 4)
            cr.stroke()
            cr.set_dash([])
            for hx, hy in [(bx, by), (bx + bw, by),
                           (bx, by + bh), (bx + bw, by + bh)]:
                cr.set_source_rgba(1.0, 0.0, 1.0, 1.0)
                cr.rectangle(hx - 3, hy - 3, 6, 6)
                cr.fill()
