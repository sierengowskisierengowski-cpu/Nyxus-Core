"""NYXUS Studio — m04 Video (stub)."""
from ui import build_stub_panel


class Module:
    KEY = "video"
    TITLE = "Video"
    GLYPH = "🎬"
    ACCENT = (1.00, 0.27, 0.40)
    DESC = "Video edit · timeline, cut, render"
    ENABLED = False

    def __init__(self, app): self.app = app

    def build_workspace(self):
        return build_stub_panel(
            "Video Editor", "🎬", self.ACCENT,
            "timeline  ·  cuts  ·  effects  ·  MP4 render")

    def build_top_tools(self):  return None
    def build_right_panel(self): return None
    def on_activate(self):  pass
    def on_deactivate(self): pass
