"""NYXUS Studio shared UI widgets — sketch buttons, color palette, layer panel."""
from __future__ import annotations

import hashlib
import math
import random

from gi.repository import Gtk, Gdk, GObject, Pango, PangoCairo
import cairo

# ── palette ──────────────────────────────────────────────────────────────────
NEON_PINK   = (1.00, 0.00, 1.00)
NEON_BLUE   = (0.42, 0.86, 1.00)
NEON_PURPLE = (0.70, 0.40, 1.00)
NEON_GREEN  = (0.22, 1.00, 0.08)
NEON_GOLD   = (1.00, 0.84, 0.00)
NEON_ORANGE = (1.00, 0.55, 0.00)
INK_TEXT    = (0.94, 0.92, 0.97)
INK_DIM     = (0.62, 0.59, 0.72)
DANGER_RED  = (1.00, 0.27, 0.40)
BG_DEEP     = (0.039, 0.039, 0.071)


def build_studio_css() -> str:
    return """
* { font-family: 'Caveat', 'Patrick Hand', cursive; }
window, .nyx-studio-workspace, .nyx-studio-rail, .nyx-studio-right,
.nyx-studio-header, .nyx-studio-status, .nyx-stub {
  background-color: #0a0a12; color: #f0eef8;
}
.nyx-studio-rail   { background-color: #07070d;
  border-right: 1px solid rgba(255,0,255,0.12); }
.nyx-studio-right  { background-color: #08080f;
  border-left:  1px solid rgba(255,0,255,0.12); }
.nyx-studio-header { background-color: rgba(10,10,18,0.96);
  border-bottom: 1px solid rgba(255,0,255,0.12); padding: 4px 8px; }
.nyx-studio-status { background-color: rgba(7,7,13,0.95);
  border-top: 1px solid rgba(255,0,255,0.10); }
.nyx-studio-headline {
  color: #ff00ff; font-size: 18px; font-weight: bold;
  text-shadow: 0 0 10px rgba(255,0,255,0.55);
}
.nyx-studio-module-lbl { color: #ffd700; font-size: 16px; }
.nyx-studio-logo { color: rgba(255,0,255,0.32); font-size: 11px; }
.nyx-meta { color: rgba(240,235,250,0.55); font-size: 13px; }
.nyx-panel-title {
  color: #ffd700; font-size: 16px; font-weight: bold; padding: 4px 0;
}
.nyx-stub-glyph { color: #ff00ff; font-size: 96px;
  text-shadow: 0 0 30px rgba(255,0,255,0.6); }
.nyx-stub-title { color: #ff00ff; font-size: 36px; font-weight: bold; }
.nyx-stub-msg   { color: #ffd700; font-size: 18px; }
.nyx-stub-teaser { color: rgba(240,235,250,0.45); font-size: 14px;
  padding-top: 8px; }
scrollbar slider { background-color: rgba(255,0,255,0.30);
  border: 1px solid rgba(255,0,255,0.45); border-radius: 6px;
  min-width: 8px; min-height: 8px; }
scrollbar { background-color: transparent; }
spinbutton, entry {
  background-color: #0e0710; color: #f0eef8;
  border: 1px solid rgba(255,0,255,0.22);
  padding: 2px 6px; min-height: 26px; font-size: 14px;
}
scale trough { background-color: rgba(255,255,255,0.08);
  border-radius: 4px; min-height: 4px; }
scale highlight { background-color: rgba(255,0,255,0.55); border-radius: 4px; }
scale slider { background-color: #ff00ff; border: none;
  min-width: 14px; min-height: 14px; border-radius: 7px;
  box-shadow: 0 0 8px rgba(255,0,255,0.6); }
listview row, list row {
  background-color: transparent; padding: 2px 4px;
}
listview row:selected, list row:selected {
  background-color: rgba(255,0,255,0.18);
}
checkbutton check { min-width: 14px; min-height: 14px; }
"""


# ── sketch helpers ───────────────────────────────────────────────────────────
def _seed(*p):
    h = hashlib.md5(repr(p).encode("utf-8")).digest()
    return random.Random(int.from_bytes(h[:8], "big"))


def sketch_line(cr, x1, y1, x2, y2, *, jitter=0.6, segments=10, key=None):
    rng = _seed(key or ("ln", round(x1, 1), round(y1, 1),
                        round(x2, 1), round(y2, 1)))
    n = max(2, segments)
    cr.move_to(x1, y1)
    for i in range(1, n):
        t = i / (n - 1)
        x = x1 + (x2 - x1) * t + (rng.random() - 0.5) * jitter
        y = y1 + (y2 - y1) * t + (rng.random() - 0.5) * jitter
        cr.line_to(x, y)
    cr.line_to(x2, y2)
    cr.stroke()


def sketch_rect(cr, x, y, w, h, *, jitter=0.6, key=None):
    k = key or ("rc", round(x), round(y), round(w), round(h))
    sketch_line(cr, x, y,     x + w, y,     jitter=jitter, key=(k, "t"))
    sketch_line(cr, x + w, y, x + w, y + h, jitter=jitter, key=(k, "r"))
    sketch_line(cr, x + w, y + h, x, y + h, jitter=jitter, key=(k, "b"))
    sketch_line(cr, x, y + h, x, y,         jitter=jitter, key=(k, "l"))


# ── sketch button ────────────────────────────────────────────────────────────
class SketchButton(Gtk.DrawingArea):
    __gsignals__ = {"clicked": (GObject.SignalFlags.RUN_FIRST, None, ())}

    def __init__(self, label, *, width=110, height=26, color=NEON_PINK,
                 tooltip=None, primary=False, glyph=None):
        super().__init__()
        self.label = str(label)
        self.color = color
        self.primary = primary
        self.glyph = glyph
        self._hover = False
        self._press = False
        self._on = False
        self.set_size_request(width, height)
        try:
            self.set_content_width(width)
            self.set_content_height(height)
        except Exception:
            pass
        self.set_draw_func(self._draw)
        if tooltip:
            self.set_tooltip_text(tooltip)
        gc = Gtk.GestureClick()
        gc.set_button(1)
        gc.connect("pressed",  lambda *a: (setattr(self, "_press", True),
                                           self.queue_draw()))
        gc.connect("released", self._release)
        self.add_controller(gc)
        mc = Gtk.EventControllerMotion()
        mc.connect("enter", lambda *a: (setattr(self, "_hover", True),
                                        self.queue_draw()))
        mc.connect("leave", lambda *a: (setattr(self, "_hover", False),
                                        setattr(self, "_press", False),
                                        self.queue_draw()))
        self.add_controller(mc)
        self.set_cursor(Gdk.Cursor.new_from_name("pointer"))

    def set_active(self, on: bool):
        if self._on != on:
            self._on = on
            self.queue_draw()

    def _release(self, *a):
        was = self._press
        self._press = False
        self.queue_draw()
        if was:
            self.emit("clicked")

    def _draw(self, area, cr, w, h, _=None):
        c = self.color
        a = 0.30 if (self.primary or self._on) else 0.10
        if self._press:   a += 0.18
        elif self._hover: a += 0.10
        cr.set_source_rgba(*c, a)
        cr.rectangle(2, 2, w - 4, h - 4)
        cr.fill()
        cr.set_source_rgba(*c, 0.95 if (self._hover or self._on) else 0.70)
        cr.set_line_width(1.4 if (self.primary or self._on) else 1.1)
        sketch_rect(cr, 1.5, 1.5, w - 3, h - 3, jitter=0.55,
                    key=("btn", id(self), w, h))
        layout = PangoCairo.create_layout(cr)
        fd = Pango.FontDescription()
        fd.set_family("Caveat")
        fd.set_size(int(13 * Pango.SCALE))
        fd.set_weight(Pango.Weight.BOLD if self.primary else Pango.Weight.NORMAL)
        layout.set_font_description(fd)
        text = (self.glyph + "  " + self.label) if self.glyph else self.label
        layout.set_text(text, -1)
        tw, th = layout.get_pixel_size()
        cr.set_source_rgba(0.94, 0.92, 0.97,
                           1.0 if (self._hover or self._on) else 0.92)
        cr.move_to((w - tw) / 2, (h - th) / 2)
        PangoCairo.show_layout(cr, layout)


# ── color palette ────────────────────────────────────────────────────────────
PALETTE = [
    (1.00, 0.00, 1.00, 1.0), (1.00, 0.42, 0.70, 1.0),
    (1.00, 0.27, 0.40, 1.0), (1.00, 0.55, 0.00, 1.0),
    (1.00, 0.84, 0.00, 1.0), (0.80, 1.00, 0.00, 1.0),
    (0.22, 1.00, 0.08, 1.0), (0.00, 1.00, 0.70, 1.0),
    (0.42, 0.86, 1.00, 1.0), (0.30, 0.50, 1.00, 1.0),
    (0.60, 0.40, 1.00, 1.0), (0.85, 0.50, 1.00, 1.0),
    (1.00, 1.00, 1.00, 1.0), (0.70, 0.70, 0.70, 1.0),
    (0.40, 0.40, 0.40, 1.0), (0.00, 0.00, 0.00, 1.0),
]


class ColorSwatch(Gtk.DrawingArea):
    __gsignals__ = {"chosen": (GObject.SignalFlags.RUN_FIRST, None,
                               (float, float, float, float))}

    def __init__(self, rgba, size=26):
        super().__init__()
        self.rgba = rgba
        self.set_size_request(size, size)
        try:
            self.set_content_width(size)
            self.set_content_height(size)
        except Exception:
            pass
        self.set_draw_func(self._draw)
        gc = Gtk.GestureClick()
        gc.set_button(1)
        gc.connect("released", lambda *a: self.emit("chosen", *self.rgba))
        self.add_controller(gc)
        self.set_cursor(Gdk.Cursor.new_from_name("pointer"))

    def _draw(self, area, cr, w, h, _=None):
        # checker (transparency hint)
        cs = 6
        cr.set_source_rgb(0.18, 0.18, 0.22)
        cr.rectangle(0, 0, w, h)
        cr.fill()
        for y in range(0, h, cs):
            for x in range(0, w, cs):
                if ((x // cs) + (y // cs)) % 2:
                    cr.set_source_rgb(0.30, 0.30, 0.35)
                    cr.rectangle(x, y, cs, cs)
                    cr.fill()
        cr.set_source_rgba(*self.rgba)
        cr.rectangle(0, 0, w, h)
        cr.fill()
        cr.set_source_rgba(0, 0, 0, 0.7)
        cr.set_line_width(1)
        cr.rectangle(0.5, 0.5, w - 1, h - 1)
        cr.stroke()


class ColorPalette(Gtk.Box):
    __gsignals__ = {"chosen": (GObject.SignalFlags.RUN_FIRST, None,
                               (float, float, float, float))}

    def __init__(self, columns: int = 4):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        flow = Gtk.FlowBox()
        flow.set_max_children_per_line(columns)
        flow.set_min_children_per_line(columns)
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_homogeneous(True)
        self.append(flow)
        for c in PALETTE:
            sw = ColorSwatch(c, size=26)
            sw.connect("chosen",
                       lambda _w, r, g, b, a: self.emit("chosen", r, g, b, a))
            flow.append(sw)


# ── slider ───────────────────────────────────────────────────────────────────
class SketchSlider(Gtk.Box):
    __gsignals__ = {"value-changed": (GObject.SignalFlags.RUN_FIRST, None,
                                      (float,))}

    def __init__(self, label, value, vmin=0.0, vmax=100.0, step=1.0):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        l = Gtk.Label(label=label, xalign=0)
        l.set_size_request(60, -1)
        l.add_css_class("nyx-meta")
        self.append(l)
        self.adj = Gtk.Adjustment(value=value, lower=vmin, upper=vmax,
                                  step_increment=step,
                                  page_increment=step * 5)
        self.scale = Gtk.Scale(adjustment=self.adj)
        self.scale.set_hexpand(True)
        self.scale.set_draw_value(False)
        self.scale.connect("value-changed",
                           lambda s: self.emit("value-changed",
                                               float(s.get_value())))
        self.append(self.scale)
        self.value_lbl = Gtk.Label(label=f"{value:.0f}")
        self.value_lbl.set_size_request(36, -1)
        self.value_lbl.add_css_class("nyx-meta")
        self.append(self.value_lbl)
        self.scale.connect("value-changed",
                           lambda s: self.value_lbl.set_text(
                               f"{s.get_value():.0f}"))

    def get_value(self) -> float:
        return float(self.adj.get_value())

    def set_value(self, v: float):
        self.adj.set_value(float(v))


# ── layer panel ──────────────────────────────────────────────────────────────
class LayerPanel(Gtk.Box):
    __gsignals__ = {"changed": (GObject.SignalFlags.RUN_FIRST, None, ())}

    def __init__(self, document):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.doc = document
        title = Gtk.Label(label="layers", xalign=0)
        title.add_css_class("nyx-panel-title")
        self.append(title)
        ctrl = Gtk.Box(spacing=4)
        self.append(ctrl)
        ar = SketchButton("+ raster", width=80, height=24, color=NEON_PINK)
        ar.connect("clicked", lambda *_: self._add("raster"))
        ctrl.append(ar)
        av = SketchButton("+ vector", width=80, height=24, color=NEON_BLUE)
        av.connect("clicked", lambda *_: self._add("vector"))
        ctrl.append(av)
        dl = SketchButton("✕", width=30, height=24, color=DANGER_RED)
        dl.connect("clicked", lambda *_: self._delete())
        ctrl.append(dl)
        # list
        self.list_box = Gtk.ListBox()
        self.list_box.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.list_box.connect("row-selected", self._on_select)
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_vexpand(True)
        sw.set_min_content_height(160)
        sw.set_child(self.list_box)
        self.append(sw)
        self.refresh()

    def _add(self, kind):
        self.doc.add_layer(kind)
        self.refresh()
        self.emit("changed")

    def _delete(self):
        self.doc.remove_layer(self.doc.active_layer)
        self.refresh()
        self.emit("changed")

    def _on_select(self, lb, row):
        if row is None:
            return
        idx = row.get_index()
        # rows are top-of-stack first; map back to doc ordering
        if 0 <= idx < len(self.doc.layers):
            self.doc.active_layer = len(self.doc.layers) - 1 - idx
            self.emit("changed")

    def refresh(self):
        while True:
            r = self.list_box.get_row_at_index(0)
            if r is None:
                break
            self.list_box.remove(r)
        for layer in reversed(self.doc.layers):
            row = Gtk.ListBoxRow()
            box = Gtk.Box(spacing=6)
            box.set_margin_start(4); box.set_margin_end(4)
            box.set_margin_top(2); box.set_margin_bottom(2)
            vis = Gtk.CheckButton()
            vis.set_active(layer.visible)
            vis.connect("toggled",
                        lambda b, l=layer: (setattr(l, "visible",
                                                     b.get_active()),
                                            self.emit("changed")))
            box.append(vis)
            glyph = "🖌" if layer.kind == "raster" else "✏"
            box.append(Gtk.Label(label=glyph))
            box.append(Gtk.Label(label=layer.name, xalign=0, hexpand=True))
            row.set_child(box)
            self.list_box.append(row)
        active_visible = len(self.doc.layers) - 1 - self.doc.active_layer
        if 0 <= active_visible < len(self.doc.layers):
            r = self.list_box.get_row_at_index(active_visible)
            if r:
                self.list_box.select_row(r)


# ── stub panel for inactive modules ──────────────────────────────────────────
def build_stub_panel(title: str, glyph: str, accent, message: str):
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
    box.add_css_class("nyx-stub")
    box.set_halign(Gtk.Align.CENTER)
    box.set_valign(Gtk.Align.CENTER)
    box.set_hexpand(True)
    box.set_vexpand(True)

    g = Gtk.Label(label=glyph)
    g.add_css_class("nyx-stub-glyph")
    box.append(g)

    t = Gtk.Label(label=title)
    t.add_css_class("nyx-stub-title")
    box.append(t)

    s = Gtk.Label(label=message)
    s.add_css_class("nyx-stub-msg")
    box.append(s)

    teaser = Gtk.Label(
        label="this module slot is wired in.\n"
              "functionality lands in a future release.")
    teaser.add_css_class("nyx-stub-teaser")
    teaser.set_justify(Gtk.Justification.CENTER)
    box.append(teaser)
    return box


# ── tiny modal text input dialog ─────────────────────────────────────────────
class TextEntryDialog(Gtk.Window):
    __gsignals__ = {"submitted": (GObject.SignalFlags.RUN_FIRST, None, (str,))}

    def __init__(self, parent, prompt="enter text", initial=""):
        super().__init__(transient_for=parent, title=prompt)
        self.set_modal(True)
        self.set_default_size(380, -1)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        outer.set_margin_start(16); outer.set_margin_end(16)
        outer.set_margin_top(16); outer.set_margin_bottom(16)
        self.set_child(outer)
        outer.append(Gtk.Label(label=prompt, xalign=0))
        self.entry = Gtk.Entry()
        self.entry.set_text(initial)
        self.entry.connect("activate", lambda *_: self._submit())
        outer.append(self.entry)
        row = Gtk.Box(spacing=8)
        outer.append(row)
        sp = Gtk.Box(); sp.set_hexpand(True); row.append(sp)
        cancel = SketchButton("cancel", width=70, height=26, color=DANGER_RED)
        cancel.connect("clicked", lambda *_: self.close())
        row.append(cancel)
        ok = SketchButton("ok", width=60, height=26, color=NEON_GREEN,
                          primary=True)
        ok.connect("clicked", lambda *_: self._submit())
        row.append(ok)

    def _submit(self):
        self.emit("submitted", self.entry.get_text())
        self.close()
