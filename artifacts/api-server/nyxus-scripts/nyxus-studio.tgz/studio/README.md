# NYXUS Studio

A modular design suite for the NYXUS desktop. Inspired by Adobe Creative Cloud
+ Blender, but neon-pink and hand-sketched.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

## Modules

The left rail switches between eight workspace modules, each loaded
dynamically from `modules/m0N_*.py`.

| Slot | Name    | Status      | Capability                              |
|------|---------|-------------|-----------------------------------------|
| m01  | Paint   | **active**  | raster brush · eraser · fill · picker · multi-layer · PNG export |
| m02  | Vector  | **active**  | rect · ellipse · line · text · select/move · SVG + PNG export |
| m03  | 3D      | slot wired  | (primitives, materials, OBJ export — coming) |
| m04  | Video   | slot wired  | (timeline, cuts, MP4 render — coming) |
| m05  | Animate | slot wired  | (keyframes, easing, GIF export — coming) |
| m06  | Photo   | slot wired  | (exposure, curves, filters, retouch — coming) |
| m07  | Layout  | slot wired  | (grids, columns, PDF export — coming) |
| m08  | Type    | slot wired  | (glyphs, kerning, OTF/WOFF export — coming) |

All modules share the same `Document` model (multi-layer, raster + vector),
the same color palette, and the same NYXUS sketch-neon look.

## Install

```bash
sudo bash install.sh
```

Then launch:

```bash
nyxus-studio
```

Or click *NYXUS Studio* in your application menu.

## Adding a module

A module is a Python file in `modules/` that exposes a `Module` class with:

```python
class Module:
    KEY = "myname"          # unique string
    TITLE = "My Module"     # shown on the rail and header
    GLYPH = "✨"             # one-glyph rail icon
    ACCENT = (r, g, b)      # 0-1 floats, used for highlights
    DESC = "short tooltip"
    ENABLED = True          # False → renders as a 'coming soon' panel

    def __init__(self, app):       ...   # the window object (has .document)
    def build_workspace(self):     ...   # main center widget
    def build_top_tools(self):     ...   # optional Gtk.Box for the header
    def build_right_panel(self):   ...   # optional Gtk.Box for the right
    def on_activate(self):         ...   # called when switched-to
    def on_deactivate(self):       ...   # called when switched-away
    def save_native(self):         ...   # optional — File → Save
    def export(self):              ...   # optional — File → Export
```

Then add the file's stem to `MODULES_ORDER` in `main.py`.
