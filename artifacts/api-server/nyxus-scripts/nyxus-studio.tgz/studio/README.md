# NYXUS Studio

**The complete NYXUS creative suite — paint, vector, 3D, video, animation, photo,
layout, type, voice — in one GTK4 application.**

© 2026 Joseph Sierengowski — `NYX-J5W-2026-SIERENGOWSKI-LOCKED`

---

## install (one-liner)

```bash
curl -fsSL https://nyxus-core.replit.app/api/download/nyxus/nyxus_studio_install.sh | bash
```

This downloads, extracts and installs Studio system-wide.

## launch

```bash
nyxus-studio
```

Or open **NYXUS Studio** from your application launcher.

## modules

| tab        | description                                              |
|------------|----------------------------------------------------------|
| paint      | 12 brushes · 11 blend modes · layers · 14 filters · adjust |
| vector     | pen + 8 shapes · boolean ops · gradients · SVG export    |
| 3d         | 8 primitives · subdivide/extrude/bevel/inset · OBJ/STL/PLY/GLTF |
| video      | NLE · trim · drag clips · text/color overlays · MP4 render |
| animate    | frame-by-frame · onion skin · GIF + MP4 export           |
| photo      | before/after split · 6 adjustments · 12 filters · histogram |
| layout     | multi-page · text/image/shape frames · PDF export        |
| type       | live font lab · stroke/shadow/gradient · PNG + SVG export |
| voice      | record · 6 voice presets · pitch · effects · WAV/MP3 save |

## requirements

System packages (Arch):

```
gtk4 python-gobject python-cairo python-numpy python-pillow ffmpeg
```

Optional Python packages (auto-installed via `pip --user`):

```
sounddevice    # microphone capture
soundfile      # WAV save
scipy          # better DSP
trimesh        # 3D boolean ops + GLTF export
```

## file locations

| path                                                | purpose                |
|-----------------------------------------------------|------------------------|
| `/opt/nyxus-studio/studio/`                         | python package         |
| `/usr/local/bin/nyxus-studio`                       | launcher script        |
| `~/.local/share/applications/nyxus-studio.desktop`  | menu entry             |
| `~/.local/share/icons/hicolor/512x512/apps/nyxus-studio.png` | app icon       |
| `~/.local/share/nyxus-studio/output/`               | default export folder  |
| `~/.local/share/nyxus-studio/log/studio.log`        | session log            |

## uninstall

```bash
sudo rm -rf /opt/nyxus-studio /usr/local/bin/nyxus-studio
rm -f ~/.local/share/applications/nyxus-studio.desktop
rm -f ~/.local/share/icons/hicolor/512x512/apps/nyxus-studio.png
```
