"""NYXUS Studio — document model: multi-layer canvas with raster + vector.

A Document holds an ordered list of Layers. Each Layer is either:
  • raster  — a cairo.ImageSurface (paintable pixels)
  • vector  — a list of VectorObject (rect/ellipse/line/text/path)

The Document can flatten itself to a single ImageSurface for export.
"""
from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import List, Optional

import cairo


class VectorObject:
    """A single drawable vector primitive."""
    def __init__(self, kind: str, **kw):
        self.id = uuid.uuid4().hex[:12]
        self.kind = kind  # rect | ellipse | line | text | path
        self.x  = float(kw.get("x", 0));  self.y  = float(kw.get("y", 0))
        self.w  = float(kw.get("w", 100)); self.h = float(kw.get("h", 100))
        self.x2 = float(kw.get("x2", 0)); self.y2 = float(kw.get("y2", 0))
        self.fill         = tuple(kw.get("fill",   (0.6, 0.4, 0.9, 1.0)))
        self.stroke       = tuple(kw.get("stroke", (1.0, 0.0, 1.0, 1.0)))
        self.stroke_width = float(kw.get("stroke_width", 2.0))
        self.text         = str(kw.get("text", ""))
        self.font_size    = int(kw.get("font_size", 24))
        self.rotation     = float(kw.get("rotation", 0.0))
        self.points       = list(kw.get("points", []))

    def bounds(self):
        if self.kind == "line":
            return (min(self.x, self.x2), min(self.y, self.y2),
                    max(1, abs(self.x2 - self.x)),
                    max(1, abs(self.y2 - self.y)))
        if self.kind == "path" and self.points:
            xs = [p[0] for p in self.points]
            ys = [p[1] for p in self.points]
            return (min(xs), min(ys),
                    max(1, max(xs) - min(xs)),
                    max(1, max(ys) - min(ys)))
        if self.kind == "text":
            return (self.x, self.y, max(60, len(self.text) * self.font_size * 0.55),
                    self.font_size + 6)
        return (self.x, self.y, self.w, self.h)

    def hit(self, px, py):
        bx, by, bw, bh = self.bounds()
        return bx - 4 <= px <= bx + bw + 4 and by - 4 <= py <= by + bh + 4


class Layer:
    def __init__(self, kind: str, name: str, w: int, h: int):
        self.id = uuid.uuid4().hex[:12]
        self.kind = kind  # raster | vector
        self.name = name
        self.visible = True
        self.opacity = 1.0
        self.locked = False
        if kind == "raster":
            self.surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
        else:
            self.objects: List[VectorObject] = []


class Document:
    def __init__(self, w: int = 1200, h: int = 800, name: str = "Untitled"):
        self.id = uuid.uuid4().hex[:12]
        self.w = int(w)
        self.h = int(h)
        self.name = name
        self.layers: List[Layer] = []
        self.active_layer = 0
        self.created = time.time()
        self.modified = False
        self.path: Optional[str] = None
        # background color (rgba) — 0 alpha = transparent
        self.bg = (1.0, 1.0, 1.0, 1.0)

    def add_layer(self, kind: str = "raster", name: Optional[str] = None) -> Layer:
        if name is None:
            n = sum(1 for l in self.layers if l.kind == kind) + 1
            name = f"{kind.title()} {n}"
        l = Layer(kind, name, self.w, self.h)
        self.layers.append(l)
        self.active_layer = len(self.layers) - 1
        self.modified = True
        return l

    def remove_layer(self, idx: int):
        if 0 <= idx < len(self.layers) and len(self.layers) > 1:
            self.layers.pop(idx)
            self.active_layer = max(0, min(self.active_layer, len(self.layers) - 1))
            self.modified = True

    def get_active(self) -> Optional[Layer]:
        if 0 <= self.active_layer < len(self.layers):
            return self.layers[self.active_layer]
        return None

    def render_to_surface(self) -> cairo.ImageSurface:
        out = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.w, self.h)
        cr = cairo.Context(out)
        cr.set_source_rgba(*self.bg)
        cr.paint()
        for layer in self.layers:
            if not layer.visible:
                continue
            cr.save()
            if layer.kind == "raster":
                cr.set_source_surface(layer.surface, 0, 0)
                cr.paint_with_alpha(layer.opacity)
            else:
                cr.push_group()
                for o in layer.objects:
                    self._draw_vector_object(cr, o)
                cr.pop_group_to_source()
                cr.paint_with_alpha(layer.opacity)
            cr.restore()
        return out

    def _draw_vector_object(self, cr, o: VectorObject):
        cr.save()
        if o.kind == "text":
            cr.set_source_rgba(*o.fill)
            cr.move_to(o.x, o.y + o.font_size)
            cr.select_font_face("Caveat",
                                cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_NORMAL)
            cr.set_font_size(o.font_size)
            cr.show_text(o.text or "")
            cr.restore()
            return
        if o.kind == "rect":
            cr.rectangle(o.x, o.y, o.w, o.h)
        elif o.kind == "ellipse":
            cr.save()
            cr.translate(o.x + o.w / 2, o.y + o.h / 2)
            cr.scale(max(0.001, o.w / 2), max(0.001, o.h / 2))
            cr.arc(0, 0, 1, 0, 6.283185)
            cr.restore()
        elif o.kind == "line":
            cr.move_to(o.x, o.y)
            cr.line_to(o.x2, o.y2)
        elif o.kind == "path" and o.points:
            cr.move_to(*o.points[0])
            for p in o.points[1:]:
                cr.line_to(*p)
        if o.kind != "line":
            cr.set_source_rgba(*o.fill)
            cr.fill_preserve()
        cr.set_source_rgba(*o.stroke)
        cr.set_line_width(o.stroke_width)
        cr.set_line_cap(cairo.LINE_CAP_ROUND)
        cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.stroke()
        cr.restore()

    def export_png(self, path: str):
        s = self.render_to_surface()
        s.write_to_png(str(path))
