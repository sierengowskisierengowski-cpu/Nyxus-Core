"""
NYXUS Studio — video engine (Video module).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Wraps ffmpeg + ffprobe for clip introspection, thumbnail generation,
trim/transition rendering, and timeline export.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Iterable


def have_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


def have_ffprobe() -> bool:
    return shutil.which("ffprobe") is not None


def probe(path: str) -> dict:
    """Return {duration_ms, width, height, fps, has_audio}."""
    if not have_ffprobe():
        return {}
    try:
        out = subprocess.check_output([
            "ffprobe", "-v", "quiet", "-print_format", "json",
            "-show_format", "-show_streams", path,
        ], text=True)
        meta = json.loads(out)
    except Exception:
        return {}
    info = {"duration_ms": 0, "width": 0, "height": 0,
            "fps": 30.0, "has_audio": False}
    fmt = meta.get("format", {})
    try:
        info["duration_ms"] = int(float(fmt.get("duration", 0.0)) * 1000)
    except Exception:
        pass
    for s in meta.get("streams", []):
        ct = s.get("codec_type")
        if ct == "video" and not info["width"]:
            info["width"] = int(s.get("width") or 0)
            info["height"] = int(s.get("height") or 0)
            fr = s.get("r_frame_rate", "30/1")
            try:
                a, b = fr.split("/")
                info["fps"] = float(a) / max(1.0, float(b))
            except Exception:
                pass
        elif ct == "audio":
            info["has_audio"] = True
    return info


def thumbnail(path: str, ms: int, out_png: str, w: int = 320) -> bool:
    if not have_ffmpeg():
        return False
    try:
        subprocess.run([
            "ffmpeg", "-y", "-ss", f"{ms/1000:.3f}", "-i", path,
            "-frames:v", "1", "-vf", f"scale={w}:-1", out_png,
        ], check=True, capture_output=True)
        return Path(out_png).exists()
    except Exception:
        return False


# ────────────────────────────────────────────────────────────────────────────
# timeline rendering — generate ffmpeg concat + filter graph
# ────────────────────────────────────────────────────────────────────────────

def render_timeline(timeline, out_path: str,
                    on_log: callable | None = None) -> bool:
    """Render VideoTimeline → out_path via ffmpeg concat + overlays.

    Strategy:
      1. for each VideoClip: extract & re-encode the trimmed segment
      2. concat the resulting segments
      3. apply overlays (text/image/color) as a single filter pass
    """
    if not have_ffmpeg() or not timeline.clips:
        return False

    workdir = Path(tempfile.mkdtemp(prefix="nyx_studio_video_"))
    parts: list[Path] = []
    sorted_clips = sorted(timeline.clips, key=lambda c: c.start_ms)

    try:
        for i, clip in enumerate(sorted_clips):
            seg = workdir / f"seg_{i:03d}.mp4"
            cmd = ["ffmpeg", "-y"]
            if clip.in_ms > 0:
                cmd += ["-ss", f"{clip.in_ms/1000:.3f}"]
            cmd += ["-i", clip.src]
            if clip.out_ms > 0 and clip.out_ms > clip.in_ms:
                cmd += ["-t", f"{(clip.out_ms - clip.in_ms)/1000:.3f}"]
            cmd += [
                "-vf", f"scale={timeline.width}:{timeline.height}:force_original_aspect_ratio=decrease,"
                       f"pad={timeline.width}:{timeline.height}:(ow-iw)/2:(oh-ih)/2,"
                       f"setsar=1,fps={timeline.fps}",
                "-c:v", "libx264", "-preset", "fast", "-crf", "20",
                "-c:a", "aac", "-b:a", "192k",
                "-pix_fmt", "yuv420p",
                str(seg),
            ]
            r = subprocess.run(cmd, capture_output=True, text=True)
            if on_log:
                on_log(f"clip {i+1}/{len(sorted_clips)}  ·  {Path(clip.src).name}")
            if r.returncode != 0:
                if on_log:
                    on_log(f"  ✗  {r.stderr[-300:]}")
                continue
            parts.append(seg)

        if not parts:
            return False

        # concat
        list_file = workdir / "list.txt"
        list_file.write_text("\n".join(f"file '{p}'" for p in parts))
        concat_out = workdir / "concat.mp4"
        r = subprocess.run([
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(list_file), "-c", "copy", str(concat_out),
        ], capture_output=True, text=True)
        if r.returncode != 0:
            if on_log:
                on_log(f"concat failed: {r.stderr[-300:]}")
            return False

        # overlays — single pass
        if not timeline.overlays:
            shutil.copyfile(concat_out, out_path)
            if on_log:
                on_log(f"done  ·  {out_path}")
            return True

        filt_parts = ["[0:v]"]
        for j, ov in enumerate(timeline.overlays):
            if ov.kind == "text":
                t0 = ov.start_ms / 1000
                t1 = ov.end_ms / 1000
                txt = ov.text.replace(":", "\\:").replace("'", "\\'")
                filt_parts.append(
                    f"drawtext=text='{txt}':"
                    f"x={ov.x}:y={ov.y}:fontsize={ov.font_size}:"
                    f"fontcolor=white@{ov.color[3]:.2f}:"
                    f"enable='between(t,{t0},{t1})'"
                )
            elif ov.kind == "color":
                t0 = ov.start_ms / 1000
                t1 = ov.end_ms / 1000
                r_, g_, b_ = ov.color[:3]
                filt_parts.append(
                    f"drawbox=x={ov.x}:y={ov.y}:w={ov.w}:h={ov.h}:"
                    f"color=0x{int(r_*255):02x}{int(g_*255):02x}{int(b_*255):02x}@{ov.color[3]:.2f}:t=fill:"
                    f"enable='between(t,{t0},{t1})'"
                )
        filt = ",".join(filt_parts) + "[v]"
        r = subprocess.run([
            "ffmpeg", "-y", "-i", str(concat_out),
            "-filter_complex", filt,
            "-map", "[v]", "-map", "0:a?",
            "-c:v", "libx264", "-preset", "fast", "-crf", "20",
            "-c:a", "aac", "-b:a", "192k",
            "-pix_fmt", "yuv420p",
            out_path,
        ], capture_output=True, text=True)
        if r.returncode != 0:
            if on_log:
                on_log(f"overlay pass failed: {r.stderr[-300:]}")
            return False
        if on_log:
            on_log(f"done  ·  {out_path}")
        return True
    finally:
        try:
            shutil.rmtree(workdir, ignore_errors=True)
        except Exception:
            pass


def export_gif(images: Iterable[str], out_path: str,
               fps: int = 12, loop: int = 0) -> bool:
    """Encode a sequence of PNG frames to an animated GIF via Pillow."""
    try:
        from PIL import Image
    except Exception:
        return False
    frames = [Image.open(p).convert("RGBA") for p in images]
    if not frames:
        return False
    duration = max(20, int(1000 / max(1, fps)))
    frames[0].save(out_path, save_all=True, append_images=frames[1:],
                   duration=duration, loop=loop, optimize=True, disposal=2)
    return True


def export_mp4_from_pngs(images: list[str], out_path: str,
                         fps: int = 24) -> bool:
    if not have_ffmpeg() or not images:
        return False
    workdir = Path(tempfile.mkdtemp(prefix="nyx_studio_anim_"))
    try:
        for i, p in enumerate(images):
            shutil.copyfile(p, workdir / f"f_{i:05d}.png")
        cmd = [
            "ffmpeg", "-y", "-framerate", str(fps),
            "-i", str(workdir / "f_%05d.png"),
            "-c:v", "libx264", "-preset", "medium", "-crf", "18",
            "-pix_fmt", "yuv420p",
            out_path,
        ]
        r = subprocess.run(cmd, capture_output=True, text=True)
        return r.returncode == 0
    finally:
        try:
            shutil.rmtree(workdir, ignore_errors=True)
        except Exception:
            pass
