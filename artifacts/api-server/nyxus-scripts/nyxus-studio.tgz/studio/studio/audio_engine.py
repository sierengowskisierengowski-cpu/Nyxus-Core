"""
NYXUS Studio — audio engine (Voice module).
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Real recording, playback, and DSP for the voice changer:
  • mic record via sounddevice (or arecord fallback)
  • playback via sounddevice (or aplay fallback)
  • pitch shift, formant shift, robot, demon, chipmunk, deep, telephone,
    reverb, delay, normalize, fade, distortion
  • file i/o via soundfile (wav/flac) and pydub (mp3 via ffmpeg)
"""
from __future__ import annotations

import io
import math
import shutil
import subprocess
import tempfile
import threading
import time
from pathlib import Path
from typing import Callable

try:
    import numpy as np
except Exception:
    np = None

try:
    import sounddevice as sd
except Exception:
    sd = None

try:
    import soundfile as sf
except Exception:
    sf = None


SR = 44100


# ────────────────────────────────────────────────────────────────────────────
# capability probe
# ────────────────────────────────────────────────────────────────────────────

def have_record() -> bool:
    return sd is not None and np is not None


def have_play() -> bool:
    if sd is not None:
        return True
    return shutil.which("aplay") is not None or shutil.which("paplay") is not None


def have_ffmpeg() -> bool:
    return shutil.which("ffmpeg") is not None


# ────────────────────────────────────────────────────────────────────────────
# recorder
# ────────────────────────────────────────────────────────────────────────────

class Recorder:
    """Push-style recorder. Call start() / stop(); samples land in `.buf`."""
    def __init__(self, samplerate: int = SR, channels: int = 1,
                 on_level: Callable[[float], None] | None = None):
        self.sr = samplerate
        self.channels = channels
        self.on_level = on_level
        self.buf: list = []
        self._stream = None
        self._lock = threading.Lock()
        self._t0 = 0.0
        self.elapsed = 0.0

    def _cb(self, indata, frames, time_, status):  # noqa: ARG002
        if np is None:
            return
        with self._lock:
            self.buf.append(indata.copy())
        if self.on_level is not None:
            try:
                rms = float(np.sqrt(np.mean(indata.astype(np.float32) ** 2)))
                self.on_level(rms)
            except Exception:
                pass

    def start(self) -> None:
        if not have_record():
            raise RuntimeError("sounddevice + numpy required to record audio")
        self.buf = []
        self._t0 = time.time()
        self._stream = sd.InputStream(samplerate=self.sr, channels=self.channels,
                                      dtype="float32", callback=self._cb,
                                      blocksize=1024)
        self._stream.start()

    def stop(self):
        if self._stream is None:
            return None
        self._stream.stop()
        self._stream.close()
        self._stream = None
        self.elapsed = time.time() - self._t0
        if not self.buf or np is None:
            return None
        data = np.concatenate(self.buf, axis=0)
        if self.channels == 1 and data.ndim > 1:
            data = data[:, 0]
        return data


# ────────────────────────────────────────────────────────────────────────────
# playback
# ────────────────────────────────────────────────────────────────────────────

_play_thread: threading.Thread | None = None
_play_stream = None


def play(samples, sr: int = SR, blocking: bool = False) -> None:
    """Play samples; non-blocking by default."""
    if samples is None or np is None:
        return
    arr = np.ascontiguousarray(samples.astype(np.float32))
    if sd is not None:
        try:
            sd.stop()
            sd.play(arr, samplerate=sr)
            if blocking:
                sd.wait()
            return
        except Exception:
            pass
    # fallback: write to temp wav and shell out
    if sf is None:
        return
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    tmp.close()
    sf.write(tmp.name, arr, sr)
    cmd = None
    if shutil.which("paplay"):
        cmd = ["paplay", tmp.name]
    elif shutil.which("aplay"):
        cmd = ["aplay", "-q", tmp.name]
    if cmd:
        if blocking:
            subprocess.run(cmd)
        else:
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def stop_playback() -> None:
    if sd is not None:
        try:
            sd.stop()
        except Exception:
            pass


# ────────────────────────────────────────────────────────────────────────────
# basic edits
# ────────────────────────────────────────────────────────────────────────────

def normalize(samples, target_peak: float = 0.95):
    if samples is None or np is None or len(samples) == 0:
        return samples
    peak = float(np.max(np.abs(samples)))
    if peak < 1e-6:
        return samples
    return (samples * (target_peak / peak)).astype(np.float32)


def fade_in(samples, ms: int = 80, sr: int = SR):
    if samples is None or np is None:
        return samples
    n = max(1, int(ms * sr / 1000))
    n = min(n, len(samples))
    ramp = np.linspace(0, 1, n, dtype=np.float32)
    out = samples.copy()
    if out.ndim == 1:
        out[:n] *= ramp
    else:
        out[:n] *= ramp[:, None]
    return out


def fade_out(samples, ms: int = 80, sr: int = SR):
    if samples is None or np is None:
        return samples
    n = max(1, int(ms * sr / 1000))
    n = min(n, len(samples))
    ramp = np.linspace(1, 0, n, dtype=np.float32)
    out = samples.copy()
    if out.ndim == 1:
        out[-n:] *= ramp
    else:
        out[-n:] *= ramp[:, None]
    return out


def trim(samples, start_ms: int, end_ms: int, sr: int = SR):
    if samples is None or np is None:
        return samples
    a = max(0, int(start_ms * sr / 1000))
    b = max(a + 1, int(end_ms * sr / 1000)) if end_ms > 0 else len(samples)
    return samples[a:b]


def reverse(samples):
    if samples is None or np is None:
        return samples
    return samples[::-1].copy()


# ────────────────────────────────────────────────────────────────────────────
# voice-changer DSP (numpy-only — no librosa dependency required)
# ────────────────────────────────────────────────────────────────────────────

def _resample_linear(samples, factor: float):
    if np is None:
        return samples
    n = len(samples)
    new_n = max(2, int(n / factor))
    src = np.linspace(0, n - 1, new_n).astype(np.float32)
    i0 = np.floor(src).astype(np.int64)
    i1 = np.minimum(i0 + 1, n - 1)
    f = src - i0
    out = samples[i0] * (1 - f) + samples[i1] * f
    return out.astype(np.float32)


def pitch_shift_semitones(samples, semitones: float, sr: int = SR):
    """Pitch shift via PSOLA-lite (resample + time-stretch back)."""
    if samples is None or np is None or abs(semitones) < 1e-6:
        return samples
    factor = 2.0 ** (semitones / 12.0)
    rs = _resample_linear(samples, 1.0 / factor)         # speed up / slow down
    return _time_stretch(rs, factor)                      # bring back to original length


def _time_stretch(samples, rate: float, sr: int = SR):
    """Simple OLA time-stretch. rate > 1 → faster (shorter), rate < 1 → slower."""
    if np is None or samples is None or abs(rate - 1.0) < 1e-6:
        return samples
    win = 1024
    hop_in = int(win / 2)
    hop_out = int(hop_in / rate)
    n = len(samples)
    out = np.zeros(int(n / rate) + win, dtype=np.float32)
    w = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(win) / (win - 1))
    pos_in = 0
    pos_out = 0
    while pos_in + win < n and pos_out + win < len(out):
        chunk = samples[pos_in:pos_in + win] * w
        out[pos_out:pos_out + win] += chunk.astype(np.float32)
        pos_in += hop_in
        pos_out += hop_out
    out = out[:max(1, int(n / rate))]
    peak = float(np.max(np.abs(out)) or 1.0)
    if peak > 0.99:
        out = out * (0.99 / peak)
    return out.astype(np.float32)


def voice_robot(samples, sr: int = SR, freq: float = 75.0):
    """Ring-modulate with a square carrier → robot."""
    if np is None or samples is None:
        return samples
    t = np.arange(len(samples)) / sr
    car = np.sign(np.sin(2 * np.pi * freq * t)).astype(np.float32)
    return (samples * car * 0.85).astype(np.float32)


def voice_demon(samples, sr: int = SR):
    """Pitch down + light distortion + slap delay."""
    s = pitch_shift_semitones(samples, -8, sr)
    s = np.tanh(s * 1.6).astype(np.float32)
    return delay(s, ms=110, mix=0.45, sr=sr)


def voice_chipmunk(samples, sr: int = SR):
    return pitch_shift_semitones(samples, +9, sr)


def voice_deep(samples, sr: int = SR):
    return pitch_shift_semitones(samples, -5, sr)


def voice_telephone(samples, sr: int = SR):
    """Bandpass 300-3400 Hz via FFT."""
    if np is None or samples is None:
        return samples
    spec = np.fft.rfft(samples)
    freqs = np.fft.rfftfreq(len(samples), 1 / sr)
    mask = (freqs > 300) & (freqs < 3400)
    spec = spec * mask
    out = np.fft.irfft(spec, n=len(samples)).astype(np.float32)
    return np.clip(out * 0.9 + np.random.normal(0, 0.005, size=len(out)).astype(np.float32), -1, 1)


def voice_alien(samples, sr: int = SR):
    s = pitch_shift_semitones(samples, +4, sr)
    return voice_robot(s, sr, 38.0)


# ────────────────────────────────────────────────────────────────────────────
# effects
# ────────────────────────────────────────────────────────────────────────────

def reverb(samples, sr: int = SR, decay: float = 0.45, ms: int = 200):
    """Schroeder-lite IR convolution."""
    if np is None or samples is None:
        return samples
    n_taps = max(2, int(ms * sr / 1000))
    ir = np.exp(-np.linspace(0, 4, n_taps)).astype(np.float32) * decay
    ir[0] = 1.0
    out = np.convolve(samples, ir, mode="same").astype(np.float32)
    peak = float(np.max(np.abs(out)) or 1.0)
    if peak > 0.99:
        out = out * (0.99 / peak)
    return out


def delay(samples, ms: int = 250, mix: float = 0.40, sr: int = SR, feedback: float = 0.30):
    if np is None or samples is None:
        return samples
    n_delay = max(1, int(ms * sr / 1000))
    out = samples.copy().astype(np.float32)
    buf = np.zeros(len(samples) + n_delay, dtype=np.float32)
    buf[:len(samples)] = samples
    for i in range(len(samples)):
        if i + n_delay < len(buf):
            buf[i + n_delay] += buf[i] * feedback
    out += buf[:len(samples)] * mix
    peak = float(np.max(np.abs(out)) or 1.0)
    if peak > 0.99:
        out = out * (0.99 / peak)
    return out.astype(np.float32)


def distortion(samples, drive: float = 4.0):
    if np is None or samples is None:
        return samples
    return np.tanh(samples * drive).astype(np.float32) * 0.7


# ────────────────────────────────────────────────────────────────────────────
# i/o
# ────────────────────────────────────────────────────────────────────────────

def save_wav(path: str, samples, sr: int = SR) -> bool:
    if sf is None or np is None or samples is None:
        return False
    sf.write(path, samples.astype(np.float32), sr)
    return True


def save_mp3(path: str, samples, sr: int = SR) -> bool:
    """Encode via ffmpeg."""
    if not have_ffmpeg() or np is None or samples is None:
        return False
    tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
    tmp.close()
    if not save_wav(tmp.name, samples, sr):
        return False
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", tmp.name, "-codec:a", "libmp3lame",
             "-qscale:a", "2", path],
            check=True, capture_output=True,
        )
        return True
    except Exception:
        return False
    finally:
        try:
            Path(tmp.name).unlink()
        except Exception:
            pass


def load_audio(path: str, target_sr: int = SR):
    """Load any common audio format. Returns samples (mono) at target_sr."""
    if np is None:
        return None
    p = Path(path)
    if not p.exists():
        return None
    if sf is not None and p.suffix.lower() in (".wav", ".flac", ".ogg"):
        data, sr = sf.read(path, dtype="float32", always_2d=False)
        if data.ndim > 1:
            data = data.mean(axis=1)
    else:
        if not have_ffmpeg():
            return None
        tmp = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        tmp.close()
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-i", path, "-ac", "1", "-ar", str(target_sr),
                 tmp.name],
                check=True, capture_output=True,
            )
            if sf is None:
                return None
            data, sr = sf.read(tmp.name, dtype="float32", always_2d=False)
        finally:
            try:
                Path(tmp.name).unlink()
            except Exception:
                pass
    if sr != target_sr:
        factor = sr / target_sr
        data = _resample_linear(data, factor)
    return data.astype(np.float32)
