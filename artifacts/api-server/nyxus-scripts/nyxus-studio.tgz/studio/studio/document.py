"""
NYXUS Studio — document model.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

A Document is a stack of Layers. Each Layer holds either a raster surface
(cairo) for paint/photo modules, a list of VectorObjects for vector,
a Frame timeline for animate, a 3D Scene for the 3d module, an AudioClip
for voice, a VideoTimeline for video, or PageGroup for layout.
The model is intentionally union-typed so a single document can mix media.
"""
from __future__ import annotations

import io
import json
import math
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────


try:
    import cairo
except Exception:  # pragma: no cover
    cairo = None  # type: ignore


# default output directory for renders / exports / autosaves
OUT_DIR = Path.home() / "NYXUS Studio"
try:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    OUT_DIR = Path("/tmp") / "NYXUS Studio"
    try:
        OUT_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


# ────────────────────────────────────────────────────────────────────────────
# raster layers (paint / photo / animate / layout backdrops)
# ────────────────────────────────────────────────────────────────────────────

BLEND_MODES = [
    "normal", "multiply", "screen", "overlay", "soft-light",
    "hard-light", "color-dodge", "color-burn", "difference",
    "exclusion", "darken", "lighten",
]

CAIRO_BLEND = {
    "normal":      cairo.OPERATOR_OVER       if cairo else 0,
    "multiply":    cairo.OPERATOR_MULTIPLY   if cairo else 0,
    "screen":      cairo.OPERATOR_SCREEN     if cairo else 0,
    "overlay":     cairo.OPERATOR_OVERLAY    if cairo else 0,
    "soft-light":  cairo.OPERATOR_SOFT_LIGHT if cairo else 0,
    "hard-light":  cairo.OPERATOR_HARD_LIGHT if cairo else 0,
    "color-dodge": cairo.OPERATOR_COLOR_DODGE if cairo else 0,
    "color-burn":  cairo.OPERATOR_COLOR_BURN if cairo else 0,
    "difference":  cairo.OPERATOR_DIFFERENCE if cairo else 0,
    "exclusion":   cairo.OPERATOR_EXCLUSION  if cairo else 0,
    "darken":      cairo.OPERATOR_DARKEN     if cairo else 0,
    "lighten":     cairo.OPERATOR_LIGHTEN    if cairo else 0,
}


@dataclass
class RasterLayer:
    name: str
    width: int
    height: int
    surface: Any = None   # cairo.ImageSurface
    visible: bool = True
    locked: bool = False
    opacity: float = 1.0
    blend: str = "normal"
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def __post_init__(self) -> None:
        if self.surface is None and cairo is not None:
            self.surface = cairo.ImageSurface(
                cairo.FORMAT_ARGB32, max(1, self.width), max(1, self.height)
            )


# ────────────────────────────────────────────────────────────────────────────
# vector layer
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class VectorObject:
    """Generic vector object. Subtypes via `kind`:
       'rect' / 'ellipse' / 'polygon' / 'path' / 'text' / 'group'
    """
    kind: str
    x: float = 0.0
    y: float = 0.0
    w: float = 100.0
    h: float = 100.0
    points: list[tuple[float, float]] = field(default_factory=list)
    handles: list[tuple[float, float, float, float]] = field(default_factory=list)
    fill: tuple[float, float, float, float] | None = (0.55, 0.20, 0.95, 1.0)
    stroke: tuple[float, float, float, float] | None = (1.0, 0.40, 0.85, 1.0)
    stroke_width: float = 2.5
    rotation: float = 0.0
    text: str = ""
    font: str = "Inter Display"
    font_size: float = 32.0
    children: list["VectorObject"] = field(default_factory=list)
    closed: bool = True
    visible: bool = True
    locked: bool = False
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def bounds(self) -> tuple[float, float, float, float]:
        if self.kind == "path" and self.points:
            xs = [p[0] for p in self.points]
            ys = [p[1] for p in self.points]
            return (min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys))
        return (self.x, self.y, self.w, self.h)


@dataclass
class VectorLayer:
    name: str
    objects: list[VectorObject] = field(default_factory=list)
    visible: bool = True
    locked: bool = False
    opacity: float = 1.0
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


# ────────────────────────────────────────────────────────────────────────────
# animation timeline (animate module)
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class Frame:
    surface: Any = None
    duration_ms: int = 100        # per-frame hold
    label: str = ""
    width: int = 0
    height: int = 0
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def __post_init__(self) -> None:
        if self.surface is None and cairo is not None and self.width > 0 and self.height > 0:
            self.surface = cairo.ImageSurface(
                cairo.FORMAT_ARGB32, max(1, self.width), max(1, self.height)
            )


@dataclass
class AnimationLayer:
    name: str
    width: int
    height: int
    frames: list[Frame] = field(default_factory=list)
    fps: int = 12
    visible: bool = True
    onion_back: int = 1
    onion_fwd: int = 0
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def new_frame(self) -> Frame:
        if cairo:
            s = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.width, self.height)
        else:
            s = None
        f = Frame(surface=s)
        self.frames.append(f)
        return f


# ────────────────────────────────────────────────────────────────────────────
# audio clip (voice module)
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class AudioClip:
    name: str = "voice"
    samplerate: int = 44100
    channels: int = 1
    samples: Any = None        # numpy float32 [-1.0,1.0]  shape (N,) or (N,ch)
    label: str = ""
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    @property
    def duration(self) -> float:
        if self.samples is None:
            return 0.0
        n = self.samples.shape[0] if hasattr(self.samples, "shape") else len(self.samples)
        return n / float(self.samplerate)


# ────────────────────────────────────────────────────────────────────────────
# video timeline (video module)
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class VideoClip:
    src: str               # path on disk
    in_ms: int = 0
    out_ms: int = 0        # 0 = full
    track: int = 0
    start_ms: int = 0
    label: str = ""
    transition_in: str = ""    # "", "fade", "dissolve", "wipe"
    transition_in_ms: int = 0
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


@dataclass
class VideoOverlay:
    kind: str              # "text" | "image" | "color"
    text: str = ""
    src: str = ""
    color: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 0.5)
    x: int = 0
    y: int = 0
    w: int = 0
    h: int = 0
    start_ms: int = 0
    end_ms: int = 1000
    font: str = "Inter Display"
    font_size: int = 36
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


@dataclass
class VideoTimeline:
    width: int = 1280
    height: int = 720
    fps: int = 30
    clips: list[VideoClip] = field(default_factory=list)
    overlays: list[VideoOverlay] = field(default_factory=list)


# ────────────────────────────────────────────────────────────────────────────
# 3d scene (3d module)  — stored as a dict of meshes; rendering owned by GL view
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class Mesh3D:
    name: str
    primitive: str = "cube"          # cube|sphere|cone|cylinder|plane|torus|obj
    src: str = ""                    # for kind=obj
    pos: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rot: tuple[float, float, float] = (0.0, 0.0, 0.0)
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)
    color: tuple[float, float, float, float] = (0.55, 0.30, 0.90, 1.0)
    wireframe: bool = False
    visible: bool = True
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


@dataclass
class Scene3D:
    meshes: list[Mesh3D] = field(default_factory=list)
    cam_yaw: float = 0.7
    cam_pitch: float = 0.4
    cam_dist: float = 6.0
    bg: tuple[float, float, float] = (0.04, 0.02, 0.06)
    light_dir: tuple[float, float, float] = (0.4, 0.8, 0.5)
    ambient: float = 0.18


# ────────────────────────────────────────────────────────────────────────────
# layout (layout module) — multi-page composite
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class LayoutItem:
    kind: str                # "image" | "text" | "rect" | "ellipse" | "line"
    x: int = 0
    y: int = 0
    w: int = 200
    h: int = 100
    src: str = ""
    image_path: str = ""
    surface: Any = None              # cairo.ImageSurface for image items
    text: str = ""
    fill: tuple[float, float, float, float] | None = (0.10, 0.08, 0.14, 1.0)
    stroke: tuple[float, float, float, float] | None = (1.0, 0.40, 0.85, 1.0)
    stroke_width: float = 2.0
    font: str = "Inter Display"
    font_size: int = 24
    rotation: float = 0.0
    visible: bool = True
    locked: bool = False
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


@dataclass
class LayoutPage:
    name: str = "Page"
    width: int = 1240
    height: int = 1754                # ~A4 @ 150dpi
    items: list[LayoutItem] = field(default_factory=list)
    bg: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])


# friendly aliases used throughout the modules
Page = LayoutPage
PageItem = LayoutItem


# ────────────────────────────────────────────────────────────────────────────
# document — owns whatever the active module needs
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class Document:
    title: str = "Untitled"
    width: int = 1280
    height: int = 800
    bg: tuple[float, float, float, float] = (0.04, 0.02, 0.06, 1.0)
    raster_layers: list[RasterLayer] = field(default_factory=list)
    vector_layers: list[VectorLayer] = field(default_factory=list)
    frames: list[Frame] = field(default_factory=list)
    animation: AnimationLayer | None = None
    audio: AudioClip | None = None
    video_timeline: VideoTimeline | None = None
    scene3d: Scene3D | None = None
    pages: list[LayoutPage] = field(default_factory=list)
    active_raster: int = 0
    active_vector: int = 0
    active_frame: int = 0
    active_page: int = 0
    history: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    path: str = ""

    # ──  raster helpers  ─────────────────────────────────────────────────
    def add_raster_layer(self, name: str | None = None) -> RasterLayer:
        layer = RasterLayer(
            name=name or f"Layer {len(self.raster_layers) + 1}",
            width=self.width, height=self.height,
        )
        self.raster_layers.append(layer)
        self.active_raster = len(self.raster_layers) - 1
        self.log(f"add raster layer · {layer.name}")
        return layer

    def remove_raster_layer(self, idx: int) -> None:
        if 0 <= idx < len(self.raster_layers):
            removed = self.raster_layers.pop(idx)
            self.active_raster = max(0, idx - 1)
            self.log(f"remove raster layer · {removed.name}")

    def merge_down_raster(self, idx: int) -> None:
        if idx <= 0 or idx >= len(self.raster_layers) or cairo is None:
            return
        upper = self.raster_layers[idx]
        lower = self.raster_layers[idx - 1]
        cr = cairo.Context(lower.surface)
        cr.set_source_surface(upper.surface, 0, 0)
        cr.paint_with_alpha(upper.opacity)
        self.raster_layers.pop(idx)
        self.active_raster = idx - 1
        self.log(f"merge down · {upper.name} → {lower.name}")

    def flatten_raster(self) -> RasterLayer | None:
        if cairo is None or not self.raster_layers:
            return None
        out = RasterLayer(name="Flattened", width=self.width, height=self.height)
        cr = cairo.Context(out.surface)
        cr.set_source_rgba(*self.bg)
        cr.paint()
        for layer in self.raster_layers:
            if not layer.visible:
                continue
            cr.set_operator(CAIRO_BLEND.get(layer.blend, cairo.OPERATOR_OVER))
            cr.set_source_surface(layer.surface, 0, 0)
            cr.paint_with_alpha(layer.opacity)
        return out

    # ──  vector helpers  ─────────────────────────────────────────────────
    def add_vector_layer(self, name: str | None = None) -> VectorLayer:
        layer = VectorLayer(name=name or f"Vectors {len(self.vector_layers) + 1}")
        self.vector_layers.append(layer)
        self.active_vector = len(self.vector_layers) - 1
        self.log(f"add vector layer · {layer.name}")
        return layer

    # ──  animate frame helpers  ──────────────────────────────────────────
    def add_frame(self, width: int | None = None, height: int | None = None,
                  label: str = "") -> Frame:
        w = int(width or self.width); h = int(height or self.height)
        f = Frame(width=w, height=h, label=label or f"frame {len(self.frames) + 1}")
        self.frames.append(f)
        self.active_frame = len(self.frames) - 1
        self.log(f"add frame · {f.label}")
        return f

    def duplicate_frame(self, idx: int) -> Frame | None:
        if not (0 <= idx < len(self.frames)) or cairo is None:
            return None
        src = self.frames[idx]
        w = src.width or self.width; h = src.height or self.height
        f = Frame(width=w, height=h, label=src.label + " copy",
                  duration_ms=src.duration_ms)
        if src.surface is not None and f.surface is not None:
            cr = cairo.Context(f.surface)
            cr.set_source_surface(src.surface, 0, 0)
            cr.paint()
        self.frames.insert(idx + 1, f)
        self.log(f"duplicate frame · {f.label}")
        return f

    # ──  layout page helpers  ────────────────────────────────────────────
    def add_page(self, name: str | None = None,
                 width: int | None = None, height: int | None = None) -> LayoutPage:
        p = LayoutPage(
            name=name or f"Page {len(self.pages) + 1}",
            width=int(width or 1240),
            height=int(height or 1754),
        )
        self.pages.append(p)
        self.active_page = len(self.pages) - 1
        self.log(f"add page · {p.name}")
        return p

    def duplicate_page(self, idx: int) -> LayoutPage | None:
        if not (0 <= idx < len(self.pages)):
            return None
        from copy import deepcopy
        src = self.pages[idx]
        new = deepcopy(src)
        new.name = src.name + " copy"
        new.uid = uuid.uuid4().hex[:8]
        self.pages.insert(idx + 1, new)
        self.log(f"duplicate page · {new.name}")
        return new

    # ──  history  ────────────────────────────────────────────────────────
    def log(self, msg: str) -> None:
        self.history.append(f"{time.strftime('%H:%M:%S')}  ·  {msg}")
        if len(self.history) > 250:
            self.history = self.history[-250:]

    # ──  i/o (PNG export of flattened raster)  ──────────────────────────
    def export_png(self, path: str) -> bool:
        flat = self.flatten_raster()
        if flat is None or cairo is None:
            return False
        flat.surface.write_to_png(path)
        self.log(f"export · {path}")
        return True

    # ──  serialization (lightweight, raster surfaces dropped to PNG bytes)
    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "size": [self.width, self.height],
            "bg": list(self.bg),
            "raster_layers": [
                {"name": L.name, "opacity": L.opacity, "blend": L.blend,
                 "visible": L.visible, "locked": L.locked, "uid": L.uid}
                for L in self.raster_layers
            ],
            "vector_layers": [
                {"name": L.name, "objects": [vars(o) for o in L.objects]}
                for L in self.vector_layers
            ],
        }

    def save_meta(self, path: str) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, default=str))
        self.log(f"save meta · {path}")
