#!/usr/bin/env python3
"""
NYXUS Studio — main shell.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Modular creative suite. 9 modules — Paint · Vector · 3D · Video ·
Animate · Photo · Layout · Type · Voice — all backed by real engines
(Cairo, ffmpeg, sounddevice, trimesh).
"""
from __future__ import annotations

import importlib
import sys
import traceback
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Gdk, Gio, GLib, Adw   # noqa: E402

# ── path bootstrap so submodules import as `studio.*`
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from studio import ui                           # noqa: E402
from studio.document import Document            # noqa: E402

APP_ID = "io.nyxus.studio"
VERSION = "2.0"

# ── module registry  ────────────────────────────────────────────────────
MODULES = [
    ("paint",    "Paint",    "studio.modules.m01_paint",    ui.NYX["pink"]),
    ("vector",   "Vector",   "studio.modules.m02_vector",   ui.NYX["purple"]),
    ("3d",       "3D",       "studio.modules.m03_3d",       ui.NYX["blue"]),
    ("video",    "Video",    "studio.modules.m04_video",    ui.NYX["orange"]),
    ("animate",  "Animate",  "studio.modules.m05_animate",  ui.NYX["green"]),
    ("photo",    "Photo",    "studio.modules.m06_photo",    ui.NYX["cyan"]),
    ("layout",   "Layout",   "studio.modules.m07_layout",   ui.NYX["gold"]),
    ("type",     "Type",     "studio.modules.m08_type",     ui.NYX["red"]),
    ("voice",    "Voice",    "studio.modules.m09_voice",    ui.NYX["pink"]),
]


# ────────────────────────────────────────────────────────────────────────
# main window
# ────────────────────────────────────────────────────────────────────────

class StudioWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title="NYXUS Studio")
        self.set_default_size(1480, 920)
        ui.install_global_css(Gdk.Display.get_default())

        self.document = Document(title="Untitled", width=1280, height=800)
        self.module_widgets: dict[str, Gtk.Widget] = {}
        self.module_objects: dict[str, object] = {}
        self.active_module: str = "paint"

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.add_css_class("nyx-shell")
        self.set_content(root)

        root.append(self._build_menubar())
        root.append(self._build_module_tabs())

        self.body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0,
                            hexpand=True, vexpand=True)
        root.append(self.body)

        self.status = Gtk.Label(label="ready  ·  paint", xalign=0.0)
        self.status.add_css_class("nyx-statusbar")
        self.status.set_margin_start(10)
        root.append(self.status)

        # default module
        self._switch_module("paint")

    # ── menu bar  ──────────────────────────────────────────────────────
    def _build_menubar(self) -> Gtk.Widget:
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        bar.add_css_class("nyx-menubar")

        def menu(label: str, items: list[tuple[str, callable]]):
            btn = Gtk.MenuButton(label=label)
            btn.add_css_class("nyx-menu")
            m = Gio.Menu.new()
            grp = Gio.SimpleActionGroup()
            for name, cb in items:
                action_id = f"act_{label}_{name}".replace(" ", "_").replace("·", "")
                act = Gio.SimpleAction.new(action_id, None)
                act.connect("activate", lambda *_a, _cb=cb: _cb())
                grp.add_action(act)
                m.append(name, f"menu.{action_id}")
            btn.insert_action_group("menu", grp)
            btn.set_menu_model(m)
            bar.append(btn)

        menu("File", [
            ("New",            self._on_new),
            ("Open Image…",    self._on_open),
            ("Save PNG…",      self._on_save_png),
            ("Save Project Meta…", self._on_save_meta),
            ("Quit",           lambda: self.close()),
        ])
        menu("Edit", [
            ("Undo (history)", lambda: self._toast("undo not yet wired to per-module history")),
            ("Redo",           lambda: self._toast("redo not yet wired to per-module history")),
            ("Document Size…", self._on_doc_size),
        ])
        menu("View", [
            ("Show Layers",    lambda: self._broadcast("show_panel", "layers")),
            ("Show History",   lambda: self._broadcast("show_panel", "history")),
            ("Reset Zoom",     lambda: self._broadcast("reset_zoom")),
        ])
        menu("Image", [
            ("Brightness +",   lambda: self._broadcast("adjust", "brightness", +20)),
            ("Brightness −",   lambda: self._broadcast("adjust", "brightness", -20)),
            ("Contrast +",     lambda: self._broadcast("adjust", "contrast", 1.2)),
            ("Saturation +",   lambda: self._broadcast("adjust", "saturation", 1.4)),
            ("Saturation −",   lambda: self._broadcast("adjust", "saturation", 0.6)),
            ("Invert",         lambda: self._broadcast("filter", "invert")),
            ("Grayscale",      lambda: self._broadcast("filter", "grayscale")),
        ])
        menu("Layer", [
            ("Add Layer",      lambda: self._broadcast("layer_add")),
            ("Delete Layer",   lambda: self._broadcast("layer_del")),
            ("Merge Down",     lambda: self._broadcast("layer_merge")),
            ("Flatten",        lambda: self._broadcast("layer_flatten")),
        ])
        menu("Filter", [
            ("Blur",           lambda: self._broadcast("filter", "blur")),
            ("Gaussian Blur",  lambda: self._broadcast("filter", "gaussian")),
            ("Sharpen",        lambda: self._broadcast("filter", "sharpen")),
            ("Edge Detect",    lambda: self._broadcast("filter", "edge")),
            ("Emboss",         lambda: self._broadcast("filter", "emboss")),
            ("Posterize",      lambda: self._broadcast("filter", "posterize")),
            ("Sepia",          lambda: self._broadcast("filter", "sepia")),
            ("Vignette",       lambda: self._broadcast("filter", "vignette")),
            ("Grain",          lambda: self._broadcast("filter", "grain")),
        ])
        menu("Effects", [
            ("Glow",           lambda: self._toast("glow effect — module specific")),
            ("Shadow",         lambda: self._toast("shadow effect — module specific")),
        ])
        menu("3D", [
            ("Add Cube",       lambda: self._switch_then("3d", "add", "cube")),
            ("Add Sphere",     lambda: self._switch_then("3d", "add", "sphere")),
            ("Add Cylinder",   lambda: self._switch_then("3d", "add", "cylinder")),
            ("Add Cone",       lambda: self._switch_then("3d", "add", "cone")),
            ("Add Torus",      lambda: self._switch_then("3d", "add", "torus")),
            ("Add Plane",      lambda: self._switch_then("3d", "add", "plane")),
        ])
        menu("Animate", [
            ("Add Frame",      lambda: self._switch_then("animate", "add_frame")),
            ("Play",           lambda: self._switch_then("animate", "play")),
            ("Stop",           lambda: self._switch_then("animate", "stop")),
            ("Export GIF…",    lambda: self._switch_then("animate", "export_gif")),
            ("Export MP4…",    lambda: self._switch_then("animate", "export_mp4")),
        ])
        menu("Voice", [
            ("Record",         lambda: self._switch_then("voice", "record")),
            ("Stop",           lambda: self._switch_then("voice", "stop")),
            ("Play",           lambda: self._switch_then("voice", "play")),
            ("Save WAV…",      lambda: self._switch_then("voice", "save_wav")),
            ("Save MP3…",      lambda: self._switch_then("voice", "save_mp3")),
        ])
        menu("Window", [
            ("Switch to Paint",   lambda: self._switch_module("paint")),
            ("Switch to Vector",  lambda: self._switch_module("vector")),
            ("Switch to 3D",      lambda: self._switch_module("3d")),
            ("Switch to Video",   lambda: self._switch_module("video")),
            ("Switch to Animate", lambda: self._switch_module("animate")),
            ("Switch to Photo",   lambda: self._switch_module("photo")),
            ("Switch to Layout",  lambda: self._switch_module("layout")),
            ("Switch to Type",    lambda: self._switch_module("type")),
            ("Switch to Voice",   lambda: self._switch_module("voice")),
        ])
        menu("Help", [
            ("About",          self._on_about),
        ])
        return bar

    # ── module tabs (under menu bar)  ──────────────────────────────────
    def _build_module_tabs(self) -> Gtk.Widget:
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        bar.add_css_class("nyx-toolbar")
        for key, label, _path, color in MODULES:
            btn = ui.SketchButton(label, color, toggleable=True,
                                  height=30, width=86, font_size=16)
            btn.connect("clicked", lambda b, k=key: self._switch_module(k))
            bar.append(btn)
            if key == self.active_module:
                btn.set_toggled(True)
        # right-side: doc title
        spacer = Gtk.Box(hexpand=True); bar.append(spacer)
        self._title_label = Gtk.Label(label=self.document.title)
        self._title_label.add_css_class("nyx-faint")
        self._title_label.set_margin_end(12)
        bar.append(self._title_label)
        return bar

    # ── module switching  ──────────────────────────────────────────────
    def _switch_module(self, key: str) -> None:
        if key not in [k for k, *_ in MODULES]:
            return
        # untoggle siblings
        # (rely on user clicking; not strictly required for correctness)
        # remove current body child
        child = self.body.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.body.remove(child)
            child = nxt
        widget = self._load_module(key)
        if widget is not None:
            self.body.append(widget)
        self.active_module = key
        self._set_status(f"module · {key}")

    def _switch_then(self, key: str, method: str, *args) -> None:
        self._switch_module(key)
        obj = self.module_objects.get(key)
        if obj is None:
            return
        fn = getattr(obj, method, None)
        if callable(fn):
            try:
                fn(*args)
            except Exception:
                traceback.print_exc()

    def _load_module(self, key: str):
        if key in self.module_widgets:
            return self.module_widgets[key]
        path = next(p for k, _l, p, _c in MODULES if k == key)
        try:
            mod = importlib.import_module(path)
        except Exception as exc:
            return self._error_panel(key, exc)
        ctor = getattr(mod, "build", None)
        if not callable(ctor):
            return self._error_panel(key, RuntimeError("module has no build()"))
        try:
            widget, obj = ctor(self.document, self)
        except Exception as exc:
            return self._error_panel(key, exc)
        self.module_widgets[key] = widget
        self.module_objects[key] = obj
        return widget

    def _error_panel(self, key: str, exc: Exception):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                      margin_top=24, margin_bottom=24,
                      margin_start=24, margin_end=24)
        box.append(ui.TiltedHeader(f"{key} — failed to load", ui.NYX["red"]))
        msg = Gtk.Label(label=str(exc), xalign=0.0, wrap=True)
        msg.add_css_class("nyx-faint")
        box.append(msg)
        tb = Gtk.Label(label="".join(traceback.format_exception(exc)),
                       xalign=0.0, wrap=True, selectable=True)
        tb.add_css_class("nyx-faint")
        box.append(tb)
        return box

    # ── menu helpers  ──────────────────────────────────────────────────
    def _broadcast(self, method: str, *args) -> None:
        obj = self.module_objects.get(self.active_module)
        if obj is None:
            return
        fn = getattr(obj, method, None)
        if callable(fn):
            try:
                fn(*args)
            except Exception:
                traceback.print_exc()

    def _toast(self, msg: str) -> None:
        self._set_status(msg)

    def _set_status(self, text: str) -> None:
        self.status.set_text(f"{text}  ·  {self.active_module}")

    def _on_new(self):
        self.document = Document(title="Untitled",
                                 width=self.document.width,
                                 height=self.document.height)
        self._title_label.set_text(self.document.title)
        # clear cached module widgets so they rebuild against new doc
        self.module_widgets.clear()
        self.module_objects.clear()
        self._switch_module(self.active_module)
        self._set_status("new document")

    def _on_open(self):
        ui.open_file(self, "open image",
                     self._open_image_into_active,
                     filters=[("Images", ["*.png", "*.jpg", "*.jpeg", "*.webp", "*.bmp"])])

    def _open_image_into_active(self, path: str):
        from studio import engine
        surf = engine.load_image_to_surface(path)
        if surf is None:
            self._toast("could not open image")
            return
        # add as a new raster layer, sized to image
        from studio.document import RasterLayer
        L = RasterLayer(name=Path(path).name,
                        width=surf.get_width(),
                        height=surf.get_height(),
                        surface=surf)
        self.document.raster_layers.append(L)
        self.document.active_raster = len(self.document.raster_layers) - 1
        self.document.log(f"open · {Path(path).name}")
        self._broadcast("refresh_canvas")
        self._toast(f"opened · {Path(path).name}")

    def _on_save_png(self):
        ui.save_file(self, "save png",
                     "nyxus-untitled.png",
                     self._save_png_to)

    def _save_png_to(self, path: str):
        if not path.lower().endswith(".png"):
            path += ".png"
        ok = self.document.export_png(path)
        self._toast(f"saved · {path}" if ok else "save failed")

    def _on_save_meta(self):
        ui.save_file(self, "save project metadata",
                     "nyxus-project.json",
                     lambda p: (self.document.save_meta(p), self._toast(f"saved meta · {p}")))

    def _on_doc_size(self):
        ui.text_entry_dialog(self, "document size  (WxH)",
                             f"{self.document.width}x{self.document.height}",
                             on_ok=self._set_doc_size)

    def _set_doc_size(self, txt: str):
        try:
            w, h = txt.lower().replace(" ", "").split("x")
            self.document.width = max(16, int(w))
            self.document.height = max(16, int(h))
            self.module_widgets.clear()
            self.module_objects.clear()
            self._switch_module(self.active_module)
            self._toast(f"document → {self.document.width}×{self.document.height}")
        except Exception:
            self._toast("size syntax: WxH (e.g. 1920x1080)")

    def _on_about(self):
        dlg = Gtk.Window(title="About NYXUS Studio", transient_for=self, modal=True)
        dlg.set_default_size(420, 260)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10,
                      margin_top=14, margin_bottom=14, margin_start=14, margin_end=14)
        box.append(ui.TiltedHeader("NYXUS Studio", ui.NYX["gold"]))
        for line in (
            f"version {VERSION}",
            "Paint · Vector · 3D · Video · Animate",
            "Photo · Layout · Type · Voice",
            "",
            "© 2026 Joseph Sierengowski",
            "NYX-J5W-2026-SIERENGOWSKI-LOCKED",
        ):
            l = Gtk.Label(label=line, xalign=0.0)
            l.add_css_class("nyx-faint")
            box.append(l)
        close = ui.SketchButton("close", ui.NYX["pink"], width=110, height=34)
        close.connect("clicked", lambda *_: dlg.close())
        box.append(close)
        dlg.set_child(box)
        dlg.present()


# ────────────────────────────────────────────────────────────────────────
# application
# ────────────────────────────────────────────────────────────────────────

class StudioApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.HANDLES_OPEN)
        self.win: StudioWindow | None = None
        self.connect("activate", self._activate)

    def _activate(self, _a):
        self.win = StudioWindow(self)
        self.win.present()


def main() -> int:
    app = StudioApp()
    return app.run(None)


if __name__ == "__main__":
    raise SystemExit(main())
