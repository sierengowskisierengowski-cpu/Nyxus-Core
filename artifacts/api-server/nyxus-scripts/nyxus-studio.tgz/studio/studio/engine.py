"""
NYXUS Studio — shared image engine.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Pure-python image utilities used by Paint, Photo, Animate, Layout, Type.
All functions operate on cairo.ImageSurface objects (FORMAT_ARGB32) and
fall back to no-op if numpy or cairo are unavailable.
"""
from __future__ import annotations

import math
from typing import Iterable

try:
    import cairo
except Exception:
    cairo = None  # type: ignore

try:
    import numpy as np
except Exception:
    np = None  # type: ignore


# ────────────────────────────────────────────────────────────────────────────
# surface ↔ ndarray conversion (cairo ARGB32 is BGRA in memory on LE systems)
# ────────────────────────────────────────────────────────────────────────────

def surf_to_array(surface) -> "np.ndarray | None":
    if surface is None or np is None:
        return None
    w, h = surface.get_width(), surface.get_height()
    buf = surface.get_data()
    arr = np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 4).copy()
    return arr  # BGRA layout


def array_to_surf(arr) -> "cairo.ImageSurface | None":
    if arr is None or cairo is None or np is None:
        return None
    arr = np.ascontiguousarray(arr.astype(np.uint8))
    h, w = arr.shape[:2]
    stride = cairo.ImageSurface.format_stride_for_width(cairo.FORMAT_ARGB32, w)
    surf = cairo.ImageSurface.create_for_data(
        memoryview(arr), cairo.FORMAT_ARGB32, w, h, stride
    )
    surf._backing = arr  # keep alive
    return surf


def _ensure_arr(surface):
    arr = surf_to_array(surface)
    return arr if arr is not None else None


def copy_surface(surface):
    """Deep-copy a cairo ImageSurface into a brand-new ARGB32 surface.
    Used by photo module for non-destructive 'original' snapshots."""
    if surface is None or cairo is None:
        return None
    w, h = surface.get_width(), surface.get_height()
    fmt = surface.get_format() if hasattr(surface, "get_format") else cairo.FORMAT_ARGB32
    out = cairo.ImageSurface(fmt, w, h)
    cr = cairo.Context(out)
    cr.set_operator(cairo.OPERATOR_SOURCE)
    cr.set_source_surface(surface, 0, 0)
    cr.paint()
    return out


# ────────────────────────────────────────────────────────────────────────────
# brush stamping (paint module + animate module)
# ────────────────────────────────────────────────────────────────────────────

def stamp_round(cr, x: float, y: float, radius: float,
                rgba: tuple[float, float, float, float],
                hardness: float = 0.6) -> None:
    """Soft round brush stamp via radial gradient."""
    if cairo is None or radius <= 0:
        return
    pat = cairo.RadialGradient(x, y, radius * hardness, x, y, radius)
    pat.add_color_stop_rgba(0.0, *rgba)
    pat.add_color_stop_rgba(1.0, rgba[0], rgba[1], rgba[2], 0.0)
    cr.set_source(pat)
    cr.arc(x, y, radius, 0, math.pi * 2)
    cr.fill()


def stamp_square(cr, x, y, radius, rgba):
    if cairo is None:
        return
    cr.set_source_rgba(*rgba)
    cr.rectangle(x - radius, y - radius, radius * 2, radius * 2)
    cr.fill()


def stamp_calligraphy(cr, x, y, radius, rgba, angle: float = 0.4):
    if cairo is None:
        return
    cr.save()
    cr.translate(x, y)
    cr.rotate(angle)
    cr.set_source_rgba(*rgba)
    cr.scale(1.0, 0.35)
    cr.arc(0, 0, radius, 0, math.pi * 2)
    cr.fill()
    cr.restore()


def stamp_airbrush(cr, x, y, radius, rgba, density: int = 24):
    if cairo is None:
        return
    import random
    rng = random.Random(int(x * 13 + y * 7))
    r, g, b, a = rgba
    for _ in range(density):
        dx = rng.gauss(0, radius * 0.55)
        dy = rng.gauss(0, radius * 0.55)
        rad = rng.uniform(0.6, 1.4)
        cr.set_source_rgba(r, g, b, a * 0.20)
        cr.arc(x + dx, y + dy, rad, 0, math.pi * 2)
        cr.fill()


def stamp_splatter(cr, x, y, radius, rgba):
    if cairo is None:
        return
    import random
    rng = random.Random(int(x * 31 + y * 17 + radius * 7))
    r, g, b, a = rgba
    for _ in range(int(8 + radius / 2)):
        dx = rng.gauss(0, radius * 0.9)
        dy = rng.gauss(0, radius * 0.9)
        rad = rng.uniform(0.5, max(1.0, radius * 0.18))
        cr.set_source_rgba(r, g, b, a * rng.uniform(0.35, 0.95))
        cr.arc(x + dx, y + dy, rad, 0, math.pi * 2)
        cr.fill()


def stamp_marker(cr, x, y, radius, rgba):
    if cairo is None:
        return
    r, g, b, a = rgba
    cr.set_source_rgba(r, g, b, min(1.0, a * 0.55))
    cr.arc(x, y, radius, 0, math.pi * 2)
    cr.fill()


def stamp_eraser(cr, x, y, radius, rgba):
    if cairo is None:
        return
    cr.save()
    cr.set_operator(cairo.OPERATOR_CLEAR)
    cr.arc(x, y, radius, 0, math.pi * 2)
    cr.fill()
    cr.restore()


def smudge_step(surface, x: int, y: int, radius: int, strength: float) -> None:
    """Drag a small patch of pixels in the direction of motion."""
    arr = _ensure_arr(surface)
    if arr is None:
        return
    h, w = arr.shape[:2]
    r = max(1, int(radius))
    x0 = max(0, x - r); x1 = min(w, x + r)
    y0 = max(0, y - r); y1 = min(h, y + r)
    if x1 - x0 < 2 or y1 - y0 < 2:
        return
    region = arr[y0:y1, x0:x1].astype(np.float32)
    avg = region.mean(axis=(0, 1))
    blended = region * (1.0 - strength) + avg * strength
    arr[y0:y1, x0:x1] = blended.astype(np.uint8)


def blur_step(surface, x: int, y: int, radius: int, strength: float) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    h, w = arr.shape[:2]
    r = max(2, int(radius))
    x0 = max(0, x - r); x1 = min(w, x + r)
    y0 = max(0, y - r); y1 = min(h, y + r)
    if x1 - x0 < 3 or y1 - y0 < 3:
        return
    patch = arr[y0:y1, x0:x1].astype(np.float32)
    k = box_blur(patch, ksize=3)
    arr[y0:y1, x0:x1] = (patch * (1 - strength) + k * strength).astype(np.uint8)


def sharpen_step(surface, x, y, radius, strength) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    h, w = arr.shape[:2]
    r = max(2, int(radius))
    x0 = max(0, x - r); x1 = min(w, x + r)
    y0 = max(0, y - r); y1 = min(h, y + r)
    if x1 - x0 < 3 or y1 - y0 < 3:
        return
    patch = arr[y0:y1, x0:x1].astype(np.float32)
    k = box_blur(patch, ksize=3)
    high = patch - k
    out = np.clip(patch + high * strength * 2.0, 0, 255)
    arr[y0:y1, x0:x1] = out.astype(np.uint8)


# ────────────────────────────────────────────────────────────────────────────
# bucket fill (paint module)
# ────────────────────────────────────────────────────────────────────────────

def bucket_fill(surface, sx: int, sy: int,
                rgba: tuple[float, float, float, float],
                tolerance: int = 24) -> None:
    """Scanline flood fill on cairo BGRA surface."""
    arr = _ensure_arr(surface)
    if arr is None:
        return
    h, w = arr.shape[:2]
    if not (0 <= sx < w and 0 <= sy < h):
        return
    target = arr[sy, sx].astype(np.int32)
    fill = np.array([
        int(rgba[2] * 255), int(rgba[1] * 255),
        int(rgba[0] * 255), int(rgba[3] * 255)
    ], dtype=np.int32)
    if np.all(np.abs(target - fill) < 2):
        return
    stack = [(sx, sy)]
    visited = np.zeros((h, w), dtype=bool)
    while stack:
        x, y = stack.pop()
        if visited[y, x]:
            continue
        # walk left
        lx = x
        while lx >= 0 and not visited[y, lx] and \
                np.all(np.abs(arr[y, lx].astype(np.int32) - target) <= tolerance):
            lx -= 1
        lx += 1
        rx = x
        while rx < w and not visited[y, rx] and \
                np.all(np.abs(arr[y, rx].astype(np.int32) - target) <= tolerance):
            rx += 1
        rx -= 1
        arr[y, lx:rx + 1] = fill
        visited[y, lx:rx + 1] = True
        for nx in range(lx, rx + 1):
            if y > 0 and not visited[y - 1, nx] and \
                    np.all(np.abs(arr[y - 1, nx].astype(np.int32) - target) <= tolerance):
                stack.append((nx, y - 1))
            if y < h - 1 and not visited[y + 1, nx] and \
                    np.all(np.abs(arr[y + 1, nx].astype(np.int32) - target) <= tolerance):
                stack.append((nx, y + 1))


# ────────────────────────────────────────────────────────────────────────────
# filters (photo + paint Filter menu)
# ────────────────────────────────────────────────────────────────────────────

def box_blur(arr, ksize: int = 3):
    if np is None:
        return arr
    k = max(1, ksize // 2)
    pad = np.pad(arr, ((k, k), (k, k), (0, 0)), mode="edge")
    out = np.zeros_like(arr, dtype=np.float32)
    n = (2 * k + 1) ** 2
    for dy in range(-k, k + 1):
        for dx in range(-k, k + 1):
            out += pad[k + dy:k + dy + arr.shape[0],
                       k + dx:k + dx + arr.shape[1]].astype(np.float32)
    return out / n


def filter_blur(surface, radius: int = 3) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    arr[:] = np.clip(box_blur(arr, ksize=max(1, radius * 2 + 1)), 0, 255).astype(np.uint8)


def filter_gaussian(surface, sigma: float = 2.0) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    # 1d separable approximation
    radius = max(1, int(sigma * 2))
    xs = np.arange(-radius, radius + 1, dtype=np.float32)
    kernel = np.exp(-(xs ** 2) / (2 * sigma * sigma))
    kernel /= kernel.sum()
    out = arr.astype(np.float32)
    # horizontal
    pad = np.pad(out, ((0, 0), (radius, radius), (0, 0)), mode="edge")
    tmp = np.zeros_like(out)
    for i, w in enumerate(kernel):
        tmp += w * pad[:, i:i + arr.shape[1]]
    pad = np.pad(tmp, ((radius, radius), (0, 0), (0, 0)), mode="edge")
    out[:] = 0
    for i, w in enumerate(kernel):
        out += w * pad[i:i + arr.shape[0]]
    arr[:] = np.clip(out, 0, 255).astype(np.uint8)


def filter_sharpen(surface, amount: float = 1.0) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    soft = box_blur(arr, ksize=3)
    out = arr.astype(np.float32) + (arr.astype(np.float32) - soft) * amount * 1.5
    arr[:] = np.clip(out, 0, 255).astype(np.uint8)


def filter_edge(surface) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    g = arr[..., :3].mean(axis=2)
    gx = np.abs(np.diff(g, axis=1, prepend=g[:, :1]))
    gy = np.abs(np.diff(g, axis=0, prepend=g[:1, :]))
    edge = np.clip(gx + gy, 0, 255).astype(np.uint8)
    arr[..., 0] = edge
    arr[..., 1] = edge
    arr[..., 2] = edge


def filter_emboss(surface) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    g = arr[..., :3].mean(axis=2).astype(np.float32)
    shift = np.zeros_like(g)
    shift[1:, 1:] = g[:-1, :-1]
    out = np.clip(128 + (g - shift), 0, 255).astype(np.uint8)
    arr[..., 0] = out
    arr[..., 1] = out
    arr[..., 2] = out


def filter_posterize(surface, levels: int = 4) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    step = 256 // max(2, levels)
    arr[..., :3] = (arr[..., :3] // step) * step


def filter_threshold(surface, t: int = 128) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    g = arr[..., :3].mean(axis=2)
    mask = (g >= t).astype(np.uint8) * 255
    arr[..., 0] = mask
    arr[..., 1] = mask
    arr[..., 2] = mask


def filter_grayscale(surface) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    g = arr[..., :3].mean(axis=2).astype(np.uint8)
    arr[..., 0] = g
    arr[..., 1] = g
    arr[..., 2] = g


def filter_sepia(surface) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    rgb = arr[..., :3].astype(np.float32)
    b, g, r = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    nr = np.clip(0.393 * r + 0.769 * g + 0.189 * b, 0, 255)
    ng = np.clip(0.349 * r + 0.686 * g + 0.168 * b, 0, 255)
    nb = np.clip(0.272 * r + 0.534 * g + 0.131 * b, 0, 255)
    arr[..., 0] = nb.astype(np.uint8)
    arr[..., 1] = ng.astype(np.uint8)
    arr[..., 2] = nr.astype(np.uint8)


def filter_invert(surface) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    arr[..., :3] = 255 - arr[..., :3]


def filter_vignette(surface, strength: float = 0.6) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    h, w = arr.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = w / 2, h / 2
    d = np.sqrt(((xx - cx) / cx) ** 2 + ((yy - cy) / cy) ** 2)
    mask = np.clip(1.0 - (d - 0.6) * strength * 1.4, 0.0, 1.0)
    arr[..., :3] = (arr[..., :3].astype(np.float32) * mask[..., None]).astype(np.uint8)


def filter_grain(surface, amount: float = 0.10) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    noise = (np.random.rand(*arr.shape[:2]) - 0.5) * 255 * amount
    arr[..., :3] = np.clip(arr[..., :3].astype(np.float32) + noise[..., None], 0, 255).astype(np.uint8)


# ────────────────────────────────────────────────────────────────────────────
# adjustments (photo + paint Image menu)
# ────────────────────────────────────────────────────────────────────────────

def adjust_brightness(surface, delta: int) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    arr[..., :3] = np.clip(arr[..., :3].astype(np.int32) + delta, 0, 255).astype(np.uint8)


def adjust_contrast(surface, factor: float) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    arr[..., :3] = np.clip((arr[..., :3].astype(np.float32) - 128) * factor + 128, 0, 255).astype(np.uint8)


def adjust_saturation(surface, factor: float) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    g = arr[..., :3].mean(axis=2, keepdims=True)
    arr[..., :3] = np.clip(g + (arr[..., :3].astype(np.float32) - g) * factor, 0, 255).astype(np.uint8)


def adjust_hue(surface, degrees: float) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    rgb = arr[..., :3].astype(np.float32) / 255.0
    bb, gg, rr = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx = np.max(rgb, axis=2)
    mn = np.min(rgb, axis=2)
    df = mx - mn + 1e-9
    h = np.zeros_like(mx)
    mask = (mx == rr)
    h[mask] = (60 * ((gg - bb) / df) + 360)[mask] % 360
    mask = (mx == gg) & ~mask
    h[mask] = (60 * ((bb - rr) / df) + 120)[mask] % 360
    mask2 = (mx == bb) & (mx != rr) & (mx != gg)
    h[mask2] = (60 * ((rr - gg) / df) + 240)[mask2] % 360
    h = (h + degrees) % 360
    s = np.where(mx == 0, 0, df / (mx + 1e-9))
    v = mx
    c = v * s
    x = c * (1 - np.abs((h / 60) % 2 - 1))
    m = v - c
    r1 = np.zeros_like(h); g1 = np.zeros_like(h); b1 = np.zeros_like(h)
    cond = (h < 60); r1[cond], g1[cond], b1[cond] = c[cond], x[cond], 0
    cond = (h >= 60) & (h < 120); r1[cond], g1[cond], b1[cond] = x[cond], c[cond], 0
    cond = (h >= 120) & (h < 180); r1[cond], g1[cond], b1[cond] = 0, c[cond], x[cond]
    cond = (h >= 180) & (h < 240); r1[cond], g1[cond], b1[cond] = 0, x[cond], c[cond]
    cond = (h >= 240) & (h < 300); r1[cond], g1[cond], b1[cond] = x[cond], 0, c[cond]
    cond = (h >= 300); r1[cond], g1[cond], b1[cond] = c[cond], 0, x[cond]
    arr[..., 2] = np.clip((r1 + m) * 255, 0, 255).astype(np.uint8)
    arr[..., 1] = np.clip((g1 + m) * 255, 0, 255).astype(np.uint8)
    arr[..., 0] = np.clip((b1 + m) * 255, 0, 255).astype(np.uint8)


def adjust_levels(surface, lo: int = 0, hi: int = 255, gamma: float = 1.0) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    rgb = arr[..., :3].astype(np.float32)
    span = max(1, hi - lo)
    rgb = np.clip((rgb - lo) / span, 0, 1)
    rgb = np.power(rgb, 1.0 / max(0.1, gamma)) * 255
    arr[..., :3] = rgb.astype(np.uint8)


def adjust_temperature(surface, delta: int) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    arr[..., 2] = np.clip(arr[..., 2].astype(np.int32) + delta, 0, 255).astype(np.uint8)
    arr[..., 0] = np.clip(arr[..., 0].astype(np.int32) - delta, 0, 255).astype(np.uint8)


def adjust_exposure(surface, ev: float) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    factor = 2.0 ** ev
    arr[..., :3] = np.clip(arr[..., :3].astype(np.float32) * factor, 0, 255).astype(np.uint8)


# ────────────────────────────────────────────────────────────────────────────
# transforms
# ────────────────────────────────────────────────────────────────────────────

def transform_flip_h(surface) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    arr[:] = arr[:, ::-1]


def transform_flip_v(surface) -> None:
    arr = _ensure_arr(surface)
    if arr is None:
        return
    arr[:] = arr[::-1, :]


def transform_rotate90(surface):
    """Returns NEW surface rotated 90° cw."""
    arr = _ensure_arr(surface)
    if arr is None:
        return None
    rot = np.rot90(arr, -1).copy()
    return array_to_surf(rot)


# ────────────────────────────────────────────────────────────────────────────
# i/o helpers (PIL-backed, used by Photo / Layout / Animate)
# ────────────────────────────────────────────────────────────────────────────

def load_png_to_surface(path: str):
    if cairo is None:
        return None
    return cairo.ImageSurface.create_from_png(path)


def load_image_to_surface(path: str):
    """Load any common format (jpg/png/webp/bmp) through PIL → cairo surface."""
    try:
        from PIL import Image
    except Exception:
        return load_png_to_surface(path) if path.lower().endswith(".png") else None
    img = Image.open(path).convert("RGBA")
    if np is None:
        return load_png_to_surface(path) if path.lower().endswith(".png") else None
    arr = np.array(img)
    bgra = np.zeros_like(arr)
    bgra[..., 0] = arr[..., 2]
    bgra[..., 1] = arr[..., 1]
    bgra[..., 2] = arr[..., 0]
    bgra[..., 3] = arr[..., 3]
    return array_to_surf(bgra)


# ────────────────────────────────────────────────────────────────────────────
# Gdk.Texture → cairo.ImageSurface (for clipboard paste)
# ────────────────────────────────────────────────────────────────────────────

def texture_to_surface(texture):
    """Convert a Gdk.Texture (e.g. from clipboard) to a cairo ARGB32 surface.
    Returns None if cairo or numpy is unavailable, or on failure."""
    if texture is None or cairo is None or np is None:
        return None
    try:
        w = texture.get_width()
        h = texture.get_height()
        # download_format requires GdkMemoryFormat.R8G8B8A8 → 4 bytes/px
        try:
            from gi.repository import Gdk
            fmt = Gdk.MemoryFormat.R8G8B8A8
        except Exception:
            return None
        stride = w * 4
        buf = bytearray(stride * h)
        # Gdk.Texture.download(data, stride) writes to a writable buffer
        texture.download(buf, stride)
        rgba = np.frombuffer(bytes(buf), dtype=np.uint8).reshape(h, w, 4).copy()
        # convert RGBA → cairo BGRA (premultiplied alpha)
        bgra = np.zeros_like(rgba)
        a = rgba[..., 3:4].astype(np.float32) / 255.0
        bgra[..., 0] = (rgba[..., 2].astype(np.float32) * a[..., 0]).astype(np.uint8)
        bgra[..., 1] = (rgba[..., 1].astype(np.float32) * a[..., 0]).astype(np.uint8)
        bgra[..., 2] = (rgba[..., 0].astype(np.float32) * a[..., 0]).astype(np.uint8)
        bgra[..., 3] = rgba[..., 3]
        return array_to_surf(bgra)
    except Exception:
        return None
