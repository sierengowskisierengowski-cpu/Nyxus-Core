"""
NYXUS Studio — m01 Paint
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Full raster paint module:
  • 12 brushes  · 11 blend modes  · multi-layer (add/del/merge/flatten)
  • selection rect/ellipse  · transform (move/scale/rotate/flip)
  • 14 filters wired through engine.py
  • adjustments (brightness/contrast/saturation/hue/levels/temperature/exposure)
"""
from __future__ import annotations

import math
from typing import Callable

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gdk     # noqa: E402

import cairo

from studio import ui, engine
from studio.document import Document, RasterLayer, BLEND_MODES, CAIRO_BLEND


BRUSHES = [
    ("round",       "Round",       ui.NYX["pink"]),
    ("square",      "Square",      ui.NYX["pink"]),
    ("calligraphy", "Calligr.",    ui.NYX["purple"]),
    ("airbrush",    "Airbrush",    ui.NYX["blue"]),
    ("splatter",    "Splatter",    ui.NYX["green"]),
    ("marker",      "Marker",      ui.NYX["gold"]),
    ("smudge",      "Smudge",      ui.NYX["cyan"]),
    ("blur",        "Blur",        ui.NYX["blue"]),
    ("sharpen",     "Sharpen",     ui.NYX["orange"]),
    ("eraser",      "Eraser",      ui.NYX["red"]),
    ("bucket",      "Bucket",      ui.NYX["green"]),
    ("eye",         "Eyedrop",     ui.NYX["gold"]),
]


def build(doc: Document, parent_window):
    if not doc.raster_layers:
        doc.add_raster_layer("Background")
    mod = PaintModule(doc, parent_window)
    return mod.widget, mod


class PaintModule:
    def __init__(self, doc: Document, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.tool = "round"
        self.color = (1.00, 0.24, 0.65, 1.0)
        self.size = 18
        self.opacity = 1.0
        self.zoom = 1.0
        self.last_xy: tuple[float, float] | None = None
        self.selection: tuple[int, int, int, int] | None = None  # x,y,w,h

        # ── canvas
        self.canvas = Gtk.DrawingArea()
        self.canvas.set_hexpand(True); self.canvas.set_vexpand(True)
        self.canvas.set_draw_func(self._draw_canvas)

        gd = Gtk.GestureDrag()
        gd.connect("drag-begin",  self._down)
        gd.connect("drag-update", self._move)
        gd.connect("drag-end",    self._up)
        self.canvas.add_controller(gd)

        gc = Gtk.GestureClick()
        gc.connect("pressed", self._click)
        self.canvas.add_controller(gc)

        # ── tool palette (left)
        self.tool_palette = ui.ToolPalette(BRUSHES, columns=2)
        self.tool_palette.on_select(self._on_tool)
        self.tool_palette.select(self.tool)

        # ── color + sliders (right)
        self.color_panel = ui.Panel("color", ui.NYX["pink"])
        self.color_panel.body.append(ui.ColorPalette(self._on_color))
        cv = Gtk.DrawingArea()
        cv.set_size_request(-1, 26)
        cv.set_draw_func(self._draw_color_preview)
        self._color_preview = cv
        self.color_panel.body.append(cv)

        self.size_slider = ui.SketchSlider("size", 1, 200, self.size,
                                           color=ui.NYX["pink"],
                                           on_change=self._on_size, step=1)
        self.opacity_slider = ui.SketchSlider("opacity", 0.05, 1.0, self.opacity,
                                              color=ui.NYX["blue"],
                                              on_change=self._on_opacity)

        self.brush_panel = ui.Panel("brush", ui.NYX["purple"])
        self.brush_panel.body.append(self.size_slider)
        self.brush_panel.body.append(self.opacity_slider)

        # ── layers panel
        self.layers_panel = ui.Panel("layers", ui.NYX["gold"])
        self.layers_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.layers_panel.body.append(self.layers_box)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, homogeneous=True)
        for label, color, fn in [
            ("+ add", ui.NYX["green"], self.layer_add),
            ("− del", ui.NYX["red"], self.layer_del),
            ("merge", ui.NYX["blue"], self.layer_merge),
            ("flat",  ui.NYX["purple"], self.layer_flatten),
        ]:
            b = ui.SketchButton(label, color, height=36, font_size=18)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            row.append(b)
        self.layers_panel.body.append(row)

        # ── blend dropdown
        blend_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        blend_row.append(Gtk.Label(label="blend"))
        self.blend_combo = Gtk.DropDown.new_from_strings(BLEND_MODES)
        self.blend_combo.connect("notify::selected", self._on_blend_change)
        blend_row.append(self.blend_combo)
        self.layers_panel.body.append(blend_row)

        op_row = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.layer_opacity = ui.SketchSlider("layer opacity", 0.0, 1.0, 1.0,
                                              color=ui.NYX["gold"],
                                              on_change=self._on_layer_opacity)
        op_row.append(self.layer_opacity)
        self.layers_panel.body.append(op_row)

        # ── adjustments
        self.adj_panel = ui.Panel("adjust", ui.NYX["cyan"])
        for label, color, fn in [
            ("brightness +", ui.NYX["pink"],  lambda: self._adjust("brightness", +20)),
            ("brightness −", ui.NYX["blue"],  lambda: self._adjust("brightness", -20)),
            ("contrast +",   ui.NYX["green"], lambda: self._adjust("contrast", 1.25)),
            ("contrast −",   ui.NYX["green"], lambda: self._adjust("contrast", 0.85)),
            ("saturate +",   ui.NYX["purple"], lambda: self._adjust("saturation", 1.4)),
            ("saturate −",   ui.NYX["purple"], lambda: self._adjust("saturation", 0.65)),
            ("hue +",        ui.NYX["gold"],  lambda: self._adjust("hue", +20)),
            ("warmer",       ui.NYX["orange"], lambda: self._adjust("temperature", +18)),
            ("cooler",       ui.NYX["cyan"],  lambda: self._adjust("temperature", -18)),
        ]:
            b = ui.SketchButton(label, color, height=34, font_size=17)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.adj_panel.body.append(b)

        # ── filter quick-bar
        self.filter_panel = ui.Panel("filters", ui.NYX["red"])
        for label, color, name in [
            ("blur",      ui.NYX["blue"],   "blur"),
            ("gaussian",  ui.NYX["blue"],   "gaussian"),
            ("sharpen",   ui.NYX["orange"], "sharpen"),
            ("edge",      ui.NYX["green"],  "edge"),
            ("emboss",    ui.NYX["purple"], "emboss"),
            ("posterize", ui.NYX["gold"],   "posterize"),
            ("threshold", ui.NYX["red"],    "threshold"),
            ("grayscale", ui.NYX["cyan"],   "grayscale"),
            ("sepia",     ui.NYX["orange"], "sepia"),
            ("invert",    ui.NYX["pink"],   "invert"),
            ("vignette",  ui.NYX["purple"], "vignette"),
            ("grain",     ui.NYX["gold"],   "grain"),
        ]:
            b = ui.SketchButton(label, color, height=34, font_size=17)
            b.connect("clicked", lambda *_a, _n=name: self.filter(_n))
            self.filter_panel.body.append(b)

        # ── transform quickbar
        self.tr_panel = ui.Panel("transform", ui.NYX["green"])
        for label, color, fn in [
            ("flip H", ui.NYX["pink"],  self._flip_h),
            ("flip V", ui.NYX["blue"],  self._flip_v),
            ("rot 90", ui.NYX["green"], self._rot90),
            ("clear",  ui.NYX["red"],   self._clear_layer),
        ]:
            b = ui.SketchButton(label, color, height=34, font_size=17)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.tr_panel.body.append(b)

        # ── compose panes
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(196, -1)
        left.append(ui.TiltedHeader("paint  ·  tools", ui.NYX["pink"]))
        left.append(self.tool_palette)
        left.append(self.brush_panel)
        left.append(self.tr_panel)

        center = Gtk.ScrolledWindow()
        center.set_hexpand(True); center.set_vexpand(True)
        center.set_child(self.canvas)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(220, -1)
        right.append(self.color_panel)
        right.append(self.layers_panel)
        right.append(self.adj_panel)
        right.append(self.filter_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left)
        self.widget.append(center)
        self.widget.append(right)

        self._refresh_layers_box()

    # ── layer management ──────────────────────────────────────────────
    def _active_layer(self) -> RasterLayer | None:
        if not self.doc.raster_layers:
            return None
        idx = max(0, min(self.doc.active_raster, len(self.doc.raster_layers) - 1))
        return self.doc.raster_layers[idx]

    def _refresh_layers_box(self):
        child = self.layers_box.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.layers_box.remove(child)
            child = nxt
        for i, L in enumerate(self.doc.raster_layers):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            sel = ui.SketchButton(L.name, ui.NYX["gold"] if i == self.doc.active_raster else ui.NYX["ink_dim"],
                                  height=32, font_size=17)
            sel.connect("clicked", lambda *_a, _i=i: self._select_layer(_i))
            row.append(sel)
            tog = ui.IconButton(
                "eye" if L.visible else "eye_off",
                color=ui.NYX["green"] if L.visible else ui.NYX["ink_faint"],
                size=22,
                tooltip="hide layer" if L.visible else "show layer",
                on_click=lambda _i=i: self._toggle_visible(_i),
            )
            row.append(tog)
            self.layers_box.append(row)

    def _select_layer(self, i: int):
        self.doc.active_raster = i
        L = self._active_layer()
        if L is not None:
            self.layer_opacity.value = L.opacity
            self.layer_opacity.title.set_text(f"layer opacity  {L.opacity:.2f}")
            try:
                self.blend_combo.set_selected(BLEND_MODES.index(L.blend))
            except Exception:
                pass
        self._refresh_layers_box()
        self.canvas.queue_draw()

    def _toggle_visible(self, i: int):
        if 0 <= i < len(self.doc.raster_layers):
            self.doc.raster_layers[i].visible = not self.doc.raster_layers[i].visible
            self._refresh_layers_box()
            self.canvas.queue_draw()

    def layer_add(self):
        self.doc.add_raster_layer()
        self._refresh_layers_box(); self.canvas.queue_draw()

    def layer_del(self):
        self.doc.remove_raster_layer(self.doc.active_raster)
        if not self.doc.raster_layers:
            self.doc.add_raster_layer("Background")
        self._refresh_layers_box(); self.canvas.queue_draw()

    def layer_merge(self):
        self.doc.merge_down_raster(self.doc.active_raster)
        self._refresh_layers_box(); self.canvas.queue_draw()

    def layer_flatten(self):
        flat = self.doc.flatten_raster()
        if flat is not None:
            self.doc.raster_layers = [flat]
            self.doc.active_raster = 0
        self._refresh_layers_box(); self.canvas.queue_draw()

    def _on_layer_opacity(self, v: float):
        L = self._active_layer()
        if L is not None:
            L.opacity = float(v); self.canvas.queue_draw()

    def _on_blend_change(self, *_):
        L = self._active_layer()
        if L is None:
            return
        try:
            L.blend = BLEND_MODES[self.blend_combo.get_selected()]
            self.canvas.queue_draw()
        except Exception:
            pass

    # ── tool / color / size hooks ─────────────────────────────────────
    def _on_tool(self, key: str):
        self.tool = key
        self.parent._set_status(f"tool · {key}")

    def _on_color(self, c):
        self.color = (*c, self.color[3] if len(self.color) == 4 else 1.0)
        self._color_preview.queue_draw()

    def _on_size(self, v: float):
        self.size = max(1, int(v))

    def _on_opacity(self, v: float):
        self.opacity = float(v)
        self.color = (self.color[0], self.color[1], self.color[2], self.opacity)
        self._color_preview.queue_draw()

    def _draw_color_preview(self, _a, cr, w, h):
        cr.set_source_rgba(0.05, 0.05, 0.07, 1.0); cr.paint()
        cr.set_source_rgba(*self.color)
        cr.rectangle(2, 2, w - 4, h - 4); cr.fill()
        ui.sketch_rect(cr, 1, 1, w - 2, h - 2, (0.97, 0.95, 0.99, 0.6), 1.4)

    # ── canvas drawing ────────────────────────────────────────────────
    def _draw_canvas(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        ox = (w - self.doc.width * self.zoom) / 2
        oy = (h - self.doc.height * self.zoom) / 2
        cr.save()
        cr.translate(ox, oy)
        cr.scale(self.zoom, self.zoom)
        # canvas bg
        cr.set_source_rgba(*self.doc.bg)
        cr.rectangle(0, 0, self.doc.width, self.doc.height); cr.fill()
        for L in self.doc.raster_layers:
            if not L.visible:
                continue
            cr.set_operator(CAIRO_BLEND.get(L.blend, cairo.OPERATOR_OVER))
            cr.set_source_surface(L.surface, 0, 0)
            cr.paint_with_alpha(L.opacity)
        cr.set_operator(cairo.OPERATOR_OVER)
        # selection box
        if self.selection:
            x, y, w_, h_ = self.selection
            cr.set_source_rgba(1, 1, 1, 0.7)
            cr.set_dash([4, 4], 0)
            cr.set_line_width(1.0)
            cr.rectangle(x, y, w_, h_); cr.stroke()
            cr.set_dash([], 0)
        cr.restore()
        # frame
        ui.sketch_rect(cr, ox - 4, oy - 4,
                       self.doc.width * self.zoom + 8,
                       self.doc.height * self.zoom + 8,
                       ui.NYX["pink"] + (0.85,), 2.2)

    def _to_doc(self, x: float, y: float) -> tuple[float, float]:
        w = self.canvas.get_width(); h = self.canvas.get_height()
        ox = (w - self.doc.width * self.zoom) / 2
        oy = (h - self.doc.height * self.zoom) / 2
        return (x - ox) / self.zoom, (y - oy) / self.zoom

    # ── input ─────────────────────────────────────────────────────────
    def _click(self, _g, _n, x, y):
        # eyedropper sample
        if self.tool != "eye":
            return
        dx, dy = self._to_doc(x, y)
        L = self._active_layer()
        if L is None or dx < 0 or dy < 0 or dx >= L.width or dy >= L.height:
            return
        arr = engine.surf_to_array(L.surface)
        if arr is None:
            return
        ix, iy = int(dx), int(dy)
        b, g, r, a = arr[iy, ix]
        self.color = (r / 255, g / 255, b / 255, max(0.05, a / 255))
        self._color_preview.queue_draw()
        self.parent._set_status(f"picked · #{r:02x}{g:02x}{b:02x}")

    def _down(self, _g, x, y):
        self.last_xy = self._to_doc(x, y)
        if self.tool == "bucket":
            L = self._active_layer()
            if L is None:
                return
            engine.bucket_fill(L.surface, int(self.last_xy[0]), int(self.last_xy[1]), self.color)
            self.canvas.queue_draw()
            return
        self._stroke(self.last_xy[0], self.last_xy[1], self.last_xy[0], self.last_xy[1])
        self.canvas.queue_draw()

    def _move(self, g, dx, dy):
        ok, sx, sy = g.get_start_point()
        if not ok or self.last_xy is None:
            return
        end = self._to_doc(sx + dx, sy + dy)
        self._stroke(self.last_xy[0], self.last_xy[1], end[0], end[1])
        self.last_xy = end
        self.canvas.queue_draw()

    def _up(self, *_):
        self.last_xy = None
        self.doc.log(f"stroke · {self.tool}")

    # ── stroke painting ───────────────────────────────────────────────
    def _stroke(self, x0: float, y0: float, x1: float, y1: float):
        L = self._active_layer()
        if L is None or L.locked:
            return
        cr = cairo.Context(L.surface)
        # interpolate stamps
        d = math.hypot(x1 - x0, y1 - y0)
        steps = max(1, int(d / max(1, self.size * 0.2)))
        for i in range(steps + 1):
            t = i / max(1, steps)
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            r = self.size / 2
            t_ = self.tool
            if t_ == "round":
                engine.stamp_round(cr, x, y, r, self.color, hardness=0.55)
            elif t_ == "square":
                engine.stamp_square(cr, x, y, r, self.color)
            elif t_ == "calligraphy":
                engine.stamp_calligraphy(cr, x, y, r, self.color, angle=0.45)
            elif t_ == "airbrush":
                engine.stamp_airbrush(cr, x, y, r, self.color)
            elif t_ == "splatter":
                engine.stamp_splatter(cr, x, y, r, self.color)
            elif t_ == "marker":
                engine.stamp_marker(cr, x, y, r, self.color)
            elif t_ == "eraser":
                engine.stamp_eraser(cr, x, y, r, self.color)
            elif t_ == "smudge":
                engine.smudge_step(L.surface, int(x), int(y), int(r), 0.35)
            elif t_ == "blur":
                engine.blur_step(L.surface, int(x), int(y), int(r), 0.35)
            elif t_ == "sharpen":
                engine.sharpen_step(L.surface, int(x), int(y), int(r), 0.30)

    # ── filters & adjustments ─────────────────────────────────────────
    def filter(self, name: str):
        L = self._active_layer()
        if L is None:
            return
        fn = {
            "blur":      lambda s: engine.filter_blur(s, 3),
            "gaussian":  lambda s: engine.filter_gaussian(s, 2.5),
            "sharpen":   lambda s: engine.filter_sharpen(s, 1.0),
            "edge":      engine.filter_edge,
            "emboss":    engine.filter_emboss,
            "posterize": lambda s: engine.filter_posterize(s, 5),
            "threshold": lambda s: engine.filter_threshold(s, 128),
            "grayscale": engine.filter_grayscale,
            "sepia":     engine.filter_sepia,
            "invert":    engine.filter_invert,
            "vignette":  lambda s: engine.filter_vignette(s, 0.7),
            "grain":     lambda s: engine.filter_grain(s, 0.10),
        }.get(name)
        if fn:
            fn(L.surface)
            self.canvas.queue_draw()
            self.doc.log(f"filter · {name}")

    def _adjust(self, kind: str, val):
        L = self._active_layer()
        if L is None:
            return
        if kind == "brightness":
            engine.adjust_brightness(L.surface, int(val))
        elif kind == "contrast":
            engine.adjust_contrast(L.surface, float(val))
        elif kind == "saturation":
            engine.adjust_saturation(L.surface, float(val))
        elif kind == "hue":
            engine.adjust_hue(L.surface, float(val))
        elif kind == "temperature":
            engine.adjust_temperature(L.surface, int(val))
        elif kind == "exposure":
            engine.adjust_exposure(L.surface, float(val))
        self.canvas.queue_draw()
        self.doc.log(f"adjust · {kind} {val}")

    def adjust(self, kind: str, val):
        self._adjust(kind, val)

    # transforms
    def _flip_h(self):
        L = self._active_layer()
        if L is None:
            return
        engine.transform_flip_h(L.surface); self.canvas.queue_draw()

    def _flip_v(self):
        L = self._active_layer()
        if L is None:
            return
        engine.transform_flip_v(L.surface); self.canvas.queue_draw()

    def _rot90(self):
        L = self._active_layer()
        if L is None:
            return
        new = engine.transform_rotate90(L.surface)
        if new is not None:
            L.surface = new
            L.width = new.get_width()
            L.height = new.get_height()
            self.canvas.queue_draw()

    def _clear_layer(self):
        L = self._active_layer()
        if L is None or cairo is None:
            return
        cr = cairo.Context(L.surface)
        cr.set_operator(cairo.OPERATOR_CLEAR)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        self.canvas.queue_draw()

    # ── menu hooks called from main shell ────────────────────────────
    def refresh_canvas(self):
        self._refresh_layers_box(); self.canvas.queue_draw()

    def reset_zoom(self):
        self.zoom = 1.0; self.canvas.queue_draw()

    def show_panel(self, name: str):
        # all panels are always visible in this layout; status only
        self.parent._set_status(f"panel · {name}")
