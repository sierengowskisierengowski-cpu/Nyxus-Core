"""
NYXUS Studio — m05 Animate
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Frame-by-frame animation:
  • per-frame raster canvas
  • onion-skin (prev frames ghosted)
  • brushes (round/square/eraser) using engine.py
  • timeline strip with thumbnails
  • play/stop with adjustable FPS
  • export GIF + MP4 via video_engine
"""
from __future__ import annotations

import math
import tempfile
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib    # noqa: E402
import cairo

from studio import ui, engine, video_engine
from studio.document import Document, Frame


def build(doc: Document, parent_window):
    if not doc.frames:
        doc.add_frame()
    mod = AnimateModule(doc, parent_window)
    return mod.widget, mod


class AnimateModule:
    def __init__(self, doc: Document, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.tool = "round"
        self.color = (1.0, 0.24, 0.65, 1.0)
        self.size = 14
        self.fps = 12
        self.onion = 2
        self.last_xy: tuple[float, float] | None = None
        self._timer: int | None = None

        # ── canvas
        self.canvas = Gtk.DrawingArea()
        self.canvas.set_hexpand(True); self.canvas.set_vexpand(True)
        self.canvas.set_draw_func(self._draw_canvas)

        gd = Gtk.GestureDrag()
        gd.connect("drag-begin", self._down)
        gd.connect("drag-update", self._move)
        gd.connect("drag-end", self._up)
        self.canvas.add_controller(gd)

        # ── tools
        self.tool_palette = ui.ToolPalette([
            ("round", "Round", ui.NYX["pink"]),
            ("square", "Square", ui.NYX["pink"]),
            ("airbrush", "Airbrush", ui.NYX["blue"]),
            ("marker", "Marker", ui.NYX["gold"]),
            ("eraser", "Eraser", ui.NYX["red"]),
        ], columns=2)
        self.tool_palette.on_select(lambda k: setattr(self, "tool", k))
        self.tool_palette.select(self.tool)

        # ── color + sliders
        self.col_panel = ui.Panel("color", ui.NYX["pink"])
        self.col_panel.body.append(ui.ColorPalette(
            lambda c: setattr(self, "color", (*c, self.color[3])), columns=6))
        self.s_size = ui.SketchSlider("size", 1, 80, self.size,
                                       color=ui.NYX["pink"], step=1,
                                       on_change=lambda v: setattr(self, "size", int(v)))
        self.col_panel.body.append(self.s_size)

        # ── playback panel
        self.play_panel = ui.Panel("playback", ui.NYX["green"])
        self.s_fps = ui.SketchSlider("fps", 4, 30, self.fps, color=ui.NYX["green"],
                                      step=1, on_change=lambda v: setattr(self, "fps", int(v)))
        self.play_panel.body.append(self.s_fps)
        self.s_onion = ui.SketchSlider("onion skin", 0, 4, self.onion,
                                        color=ui.NYX["purple"], step=1,
                                        on_change=lambda v: (setattr(self, "onion", int(v)), self.canvas.queue_draw()))
        self.play_panel.body.append(self.s_onion)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, homogeneous=True)
        for label, color, fn in [
            ("play",  ui.NYX["green"], self.play),
            ("stop",  ui.NYX["red"],   self.stop),
            ("prev",  ui.NYX["blue"],  self._prev),
            ("next",  ui.NYX["gold"],  self._next),
        ]:
            b = ui.SketchButton(label, color, height=28, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            row.append(b)
        self.play_panel.body.append(row)

        # ── frames panel
        self.frames_panel = ui.Panel("frames", ui.NYX["gold"])
        row2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, homogeneous=True)
        for label, color, fn in [
            ("+ add",     ui.NYX["green"], self.add_frame),
            ("dup",       ui.NYX["blue"],  self._dup_frame),
            ("del",       ui.NYX["red"],   self._del_frame),
            ("clear",     ui.NYX["purple"], self._clear_frame),
        ]:
            b = ui.SketchButton(label, color, height=28, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            row2.append(b)
        self.frames_panel.body.append(row2)

        # ── export panel
        self.exp_panel = ui.Panel("export", ui.NYX["cyan"])
        for label, color, fn in [
            ("export GIF", ui.NYX["pink"], self.export_gif),
            ("export MP4", ui.NYX["blue"], self.export_mp4),
            ("export PNG seq", ui.NYX["green"], self._export_png_seq),
        ]:
            b = ui.SketchButton(label, color, height=28, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.exp_panel.body.append(b)

        # ── timeline strip
        self.strip = Gtk.DrawingArea()
        self.strip.set_size_request(-1, 80)
        self.strip.set_draw_func(self._draw_strip)

        gc = Gtk.GestureClick()
        gc.connect("released", self._click_strip)
        self.strip.add_controller(gc)

        # ── compose
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(196, -1)
        left.append(ui.TiltedHeader("animate", ui.NYX["green"]))
        left.append(self.tool_palette)
        left.append(self.col_panel)
        left.append(self.play_panel)

        center = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        center_sw = Gtk.ScrolledWindow()
        center_sw.set_hexpand(True); center_sw.set_vexpand(True)
        center_sw.set_child(self.canvas)
        center.append(center_sw)
        center.append(self.strip)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(220, -1)
        right.append(self.frames_panel); right.append(self.exp_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

    # ── helpers ──
    def _frame(self) -> Frame | None:
        if not self.doc.frames:
            return None
        return self.doc.frames[max(0, min(self.doc.active_frame, len(self.doc.frames) - 1))]

    def _to_doc(self, x: float, y: float) -> tuple[float, float]:
        w = self.canvas.get_width(); h = self.canvas.get_height()
        ox = (w - self.doc.width) / 2
        oy = (h - self.doc.height) / 2
        return x - ox, y - oy

    # ── input ──
    def _down(self, _g, x, y):
        self.last_xy = self._to_doc(x, y)
        self._stroke(self.last_xy[0], self.last_xy[1], self.last_xy[0], self.last_xy[1])
        self.canvas.queue_draw()

    def _move(self, g, dx, dy):
        ok, sx, sy = g.get_start_point()
        if not ok or self.last_xy is None:
            return
        end = self._to_doc(sx + dx, sy + dy)
        self._stroke(self.last_xy[0], self.last_xy[1], end[0], end[1])
        self.last_xy = end
        self.canvas.queue_draw()

    def _up(self, *_):
        self.last_xy = None
        self.strip.queue_draw()

    def _stroke(self, x0, y0, x1, y1):
        F = self._frame()
        if F is None:
            return
        cr = cairo.Context(F.surface)
        d = math.hypot(x1 - x0, y1 - y0)
        steps = max(1, int(d / max(1, self.size * 0.2)))
        for i in range(steps + 1):
            t = i / max(1, steps)
            x = x0 + (x1 - x0) * t
            y = y0 + (y1 - y0) * t
            r = self.size / 2
            if self.tool == "round":
                engine.stamp_round(cr, x, y, r, self.color)
            elif self.tool == "square":
                engine.stamp_square(cr, x, y, r, self.color)
            elif self.tool == "airbrush":
                engine.stamp_airbrush(cr, x, y, r, self.color)
            elif self.tool == "marker":
                engine.stamp_marker(cr, x, y, r, self.color)
            elif self.tool == "eraser":
                engine.stamp_eraser(cr, x, y, r, self.color)

    # ── frames ──
    def add_frame(self):
        self.doc.add_frame()
        self.doc.active_frame = len(self.doc.frames) - 1
        self.canvas.queue_draw(); self.strip.queue_draw()

    def _dup_frame(self):
        self.doc.duplicate_frame(self.doc.active_frame)
        self.doc.active_frame = len(self.doc.frames) - 1
        self.canvas.queue_draw(); self.strip.queue_draw()

    def _del_frame(self):
        if len(self.doc.frames) <= 1:
            return
        self.doc.frames.pop(self.doc.active_frame)
        self.doc.active_frame = max(0, self.doc.active_frame - 1)
        self.canvas.queue_draw(); self.strip.queue_draw()

    def _clear_frame(self):
        F = self._frame()
        if F is None:
            return
        cr = cairo.Context(F.surface)
        cr.set_operator(cairo.OPERATOR_CLEAR); cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        self.canvas.queue_draw(); self.strip.queue_draw()

    def _prev(self):
        self.doc.active_frame = max(0, self.doc.active_frame - 1)
        self.canvas.queue_draw(); self.strip.queue_draw()

    def _next(self):
        self.doc.active_frame = min(len(self.doc.frames) - 1, self.doc.active_frame + 1)
        self.canvas.queue_draw(); self.strip.queue_draw()

    # ── playback ──
    def play(self):
        if self._timer is not None:
            return
        delay = max(33, int(1000 / max(1, self.fps)))
        self._timer = GLib.timeout_add(delay, self._tick)

    def stop(self):
        if self._timer is not None:
            GLib.source_remove(self._timer); self._timer = None

    def _tick(self):
        self.doc.active_frame = (self.doc.active_frame + 1) % max(1, len(self.doc.frames))
        self.canvas.queue_draw(); self.strip.queue_draw()
        return True

    # ── export ──
    def export_gif(self):
        ui.save_file(self.parent, "export GIF", "nyxus-anim.gif", self._do_export_gif)

    def _do_export_gif(self, path: str):
        if not path.lower().endswith(".gif"):
            path += ".gif"
        td = Path(tempfile.mkdtemp(prefix="nyx_anim_"))
        files = []
        try:
            for i, F in enumerate(self.doc.frames):
                p = td / f"f_{i:05d}.png"
                F.surface.write_to_png(str(p))
                files.append(str(p))
            ok = video_engine.export_gif(files, path, fps=self.fps)
            self.parent._set_status(f"saved · {path}" if ok else "GIF export failed (Pillow needed)")
        finally:
            for p in files:
                try: Path(p).unlink()
                except Exception: pass
            try: td.rmdir()
            except Exception: pass

    def export_mp4(self):
        ui.save_file(self.parent, "export MP4", "nyxus-anim.mp4", self._do_export_mp4)

    def _do_export_mp4(self, path: str):
        if not path.lower().endswith(".mp4"):
            path += ".mp4"
        td = Path(tempfile.mkdtemp(prefix="nyx_anim_"))
        files = []
        try:
            for i, F in enumerate(self.doc.frames):
                p = td / f"f_{i:05d}.png"
                F.surface.write_to_png(str(p))
                files.append(str(p))
            ok = video_engine.export_mp4_from_pngs(files, path, fps=self.fps)
            self.parent._set_status(f"saved · {path}" if ok else "MP4 export failed (need ffmpeg)")
        finally:
            for p in files:
                try: Path(p).unlink()
                except Exception: pass
            try: td.rmdir()
            except Exception: pass

    def _export_png_seq(self):
        ui.save_file(self.parent, "export PNG sequence (base name)",
                     "nyxus-anim", self._do_png_seq)

    def _do_png_seq(self, base: str):
        for i, F in enumerate(self.doc.frames):
            F.surface.write_to_png(f"{base}_{i:04d}.png")
        self.parent._set_status(f"saved {len(self.doc.frames)} frames")

    # ── canvas / strip drawing ──
    def _draw_canvas(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        ox = (w - self.doc.width) / 2; oy = (h - self.doc.height) / 2
        cr.save(); cr.translate(ox, oy)
        cr.set_source_rgba(*self.doc.bg)
        cr.rectangle(0, 0, self.doc.width, self.doc.height); cr.fill()
        # onion skin
        cur = self.doc.active_frame
        for k in range(1, self.onion + 1):
            i = cur - k
            if i < 0:
                continue
            cr.set_source_surface(self.doc.frames[i].surface, 0, 0)
            cr.paint_with_alpha(max(0.05, 0.30 - 0.05 * k))
        F = self._frame()
        if F is not None:
            cr.set_source_surface(F.surface, 0, 0); cr.paint()
        cr.restore()
        ui.sketch_rect(cr, ox - 4, oy - 4,
                       self.doc.width + 8, self.doc.height + 8,
                       ui.NYX["green"] + (0.85,), 2.2)

    def _draw_strip(self, _a, cr, w, h):
        cr.set_source_rgba(0.05, 0.05, 0.08, 1.0); cr.paint()
        if not self.doc.frames:
            return
        sw = max(50, w / max(1, len(self.doc.frames)))
        for i, F in enumerate(self.doc.frames):
            x = i * sw; pad = 3
            inner_w = sw - 2 * pad; inner_h = h - 2 * pad
            scale = min(inner_w / F.surface.get_width(),
                        inner_h / F.surface.get_height())
            cr.save()
            cr.translate(x + pad + (inner_w - F.surface.get_width() * scale) / 2,
                         pad + (inner_h - F.surface.get_height() * scale) / 2)
            cr.scale(scale, scale)
            cr.set_source_rgba(*self.doc.bg)
            cr.rectangle(0, 0, F.surface.get_width(), F.surface.get_height()); cr.fill()
            cr.set_source_surface(F.surface, 0, 0); cr.paint()
            cr.restore()
            color = ui.NYX["gold"] if i == self.doc.active_frame else ui.NYX["ink_dim"]
            ui.sketch_rect(cr, x + 2, 2, sw - 4, h - 4, color + (0.85,), 1.6)

    def _click_strip(self, _g, _n, x, _y):
        w = self.strip.get_width()
        sw = max(50, w / max(1, len(self.doc.frames)))
        i = int(x / sw)
        i = max(0, min(len(self.doc.frames) - 1, i))
        self.doc.active_frame = i
        self.canvas.queue_draw(); self.strip.queue_draw()

    # menu hooks
    def refresh_canvas(self): self.canvas.queue_draw(); self.strip.queue_draw()
    def reset_zoom(self): pass
    def show_panel(self, name: str): self.parent._set_status(f"panel · {name}")
    def filter(self, name: str):
        F = self._frame()
        if F is None:
            return
        fn = {
            "blur":      lambda s: engine.filter_blur(s, 3),
            "gaussian":  lambda s: engine.filter_gaussian(s, 2.0),
            "sharpen":   lambda s: engine.filter_sharpen(s, 1.0),
            "edge":      engine.filter_edge,
            "emboss":    engine.filter_emboss,
            "posterize": lambda s: engine.filter_posterize(s, 5),
            "grayscale": engine.filter_grayscale,
            "sepia":     engine.filter_sepia,
            "invert":    engine.filter_invert,
            "vignette":  lambda s: engine.filter_vignette(s, 0.7),
            "grain":     lambda s: engine.filter_grain(s, 0.10),
        }.get(name)
        if fn:
            fn(F.surface); self.canvas.queue_draw(); self.strip.queue_draw()
    def adjust(self, kind, val): pass
    def layer_add(self): self.add_frame()
    def layer_del(self): self._del_frame()
    def layer_merge(self): pass
    def layer_flatten(self): pass
