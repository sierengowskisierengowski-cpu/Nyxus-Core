"""
NYXUS Studio — m06 Photo
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Non-destructive photo editor:
  • before/after split view
  • adjust: brightness, contrast, saturation, hue, temperature, exposure
  • filters: blur/gauss/sharp/edge/emboss/poster/sepia/grayscale/invert/
    vignette/grain/threshold
  • crop, rotate, flip
  • histogram preview
"""
from __future__ import annotations

import math
from typing import Callable

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk    # noqa: E402
import cairo

from studio import ui, engine
from studio.document import Document, RasterLayer

try:
    import numpy as np
except Exception:
    np = None


def build(doc: Document, parent_window):
    if not doc.raster_layers:
        doc.add_raster_layer("Photo")
    mod = PhotoModule(doc, parent_window)
    return mod.widget, mod


class PhotoModule:
    def __init__(self, doc: Document, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.split = 0.5
        self.zoom = 1.0
        self.original: cairo.ImageSurface | None = None
        self._snapshot()

        self.canvas = Gtk.DrawingArea()
        self.canvas.set_hexpand(True); self.canvas.set_vexpand(True)
        self.canvas.set_draw_func(self._draw)

        gd = Gtk.GestureDrag()
        gd.connect("drag-update", self._drag_split)
        self.canvas.add_controller(gd)

        # ── adjust panel
        self.adj = ui.Panel("adjust", ui.NYX["cyan"])
        self.s_bright = ui.SketchSlider("brightness", -100, 100, 0,
                                         color=ui.NYX["pink"], step=1,
                                         on_change=lambda v: self._stage("brightness", v))
        self.s_contr = ui.SketchSlider("contrast", 0.2, 2.5, 1.0,
                                        color=ui.NYX["blue"],
                                        on_change=lambda v: self._stage("contrast", v))
        self.s_sat = ui.SketchSlider("saturation", 0.0, 2.5, 1.0,
                                      color=ui.NYX["green"],
                                      on_change=lambda v: self._stage("saturation", v))
        self.s_hue = ui.SketchSlider("hue shift", -180, 180, 0,
                                      color=ui.NYX["purple"], step=1,
                                      on_change=lambda v: self._stage("hue", v))
        self.s_temp = ui.SketchSlider("temperature", -50, 50, 0,
                                       color=ui.NYX["orange"], step=1,
                                       on_change=lambda v: self._stage("temperature", v))
        self.s_exp = ui.SketchSlider("exposure", -2.0, 2.0, 0.0,
                                      color=ui.NYX["gold"],
                                      on_change=lambda v: self._stage("exposure", v))
        for w in (self.s_bright, self.s_contr, self.s_sat, self.s_hue,
                  self.s_temp, self.s_exp):
            self.adj.body.append(w)

        # ── filter panel
        self.flt = ui.Panel("filter", ui.NYX["red"])
        for label, color, name in [
            ("blur",      ui.NYX["blue"],   "blur"),
            ("gaussian",  ui.NYX["blue"],   "gaussian"),
            ("sharpen",   ui.NYX["orange"], "sharpen"),
            ("edge",      ui.NYX["green"],  "edge"),
            ("emboss",    ui.NYX["purple"], "emboss"),
            ("posterize", ui.NYX["gold"],   "posterize"),
            ("threshold", ui.NYX["red"],    "threshold"),
            ("grayscale", ui.NYX["cyan"],   "grayscale"),
            ("sepia",     ui.NYX["orange"], "sepia"),
            ("invert",    ui.NYX["pink"],   "invert"),
            ("vignette",  ui.NYX["purple"], "vignette"),
            ("grain",     ui.NYX["gold"],   "grain"),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _n=name: self._apply_filter(_n))
            self.flt.body.append(b)

        # ── transform panel
        self.tp = ui.Panel("transform", ui.NYX["green"])
        for label, color, fn in [
            ("flip H",  ui.NYX["pink"],  self._flip_h),
            ("flip V",  ui.NYX["blue"],  self._flip_v),
            ("rotate 90", ui.NYX["green"], self._rot90),
            ("commit",  ui.NYX["gold"],  self._commit),
            ("reset",   ui.NYX["red"],   self._reset),
            ("save PNG", ui.NYX["cyan"], self._save_png),
        ]:
            b = ui.SketchButton(label, color, height=28, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.tp.body.append(b)

        # ── histogram panel
        self.hist = Gtk.DrawingArea()
        self.hist.set_size_request(220, 90)
        self.hist.set_draw_func(self._draw_hist)
        self.hist_panel = ui.Panel("histogram", ui.NYX["gold"])
        self.hist_panel.body.append(self.hist)

        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(220, -1)
        left.append(ui.TiltedHeader("photo  ·  adjust", ui.NYX["cyan"]))
        left.append(self.adj)

        center = Gtk.ScrolledWindow()
        center.set_hexpand(True); center.set_vexpand(True)
        center.set_child(self.canvas)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(240, -1)
        right.append(self.flt); right.append(self.tp); right.append(self.hist_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

    # ── helpers ──
    def _layer(self) -> RasterLayer | None:
        if not self.doc.raster_layers:
            return None
        return self.doc.raster_layers[self.doc.active_raster]

    def _snapshot(self):
        L = self._layer()
        if L is None or cairo is None:
            self.original = None
            return
        self.original = engine.copy_surface(L.surface)

    def _drag_split(self, g, dx, _dy):
        ok, sx, _sy = g.get_start_point()
        if not ok:
            return
        w = self.canvas.get_width()
        ox = (w - self.doc.width * self.zoom) / 2
        x = (sx + dx - ox) / self.zoom
        self.split = max(0.0, min(1.0, x / max(1, self.doc.width)))
        self.canvas.queue_draw()

    def _stage(self, kind: str, val: float):
        """Live preview: reset to original then apply current sliders chain."""
        L = self._layer()
        if L is None or self.original is None:
            return
        L.surface = engine.copy_surface(self.original)
        # always re-apply full chain so sliders behave as expected
        engine.adjust_brightness(L.surface, int(self.s_bright.value))
        engine.adjust_contrast(L.surface, float(self.s_contr.value))
        engine.adjust_saturation(L.surface, float(self.s_sat.value))
        if abs(self.s_hue.value) > 0.5:
            engine.adjust_hue(L.surface, float(self.s_hue.value))
        if abs(self.s_temp.value) > 0.5:
            engine.adjust_temperature(L.surface, int(self.s_temp.value))
        if abs(self.s_exp.value) > 0.005:
            engine.adjust_exposure(L.surface, float(self.s_exp.value))
        self.canvas.queue_draw(); self.hist.queue_draw()
        self.parent._set_status(f"adjust · {kind}={val:.2f}")

    def _apply_filter(self, name: str):
        L = self._layer()
        if L is None:
            return
        fn = {
            "blur":      lambda s: engine.filter_blur(s, 3),
            "gaussian":  lambda s: engine.filter_gaussian(s, 2.5),
            "sharpen":   lambda s: engine.filter_sharpen(s, 1.0),
            "edge":      engine.filter_edge,
            "emboss":    engine.filter_emboss,
            "posterize": lambda s: engine.filter_posterize(s, 5),
            "threshold": lambda s: engine.filter_threshold(s, 128),
            "grayscale": engine.filter_grayscale,
            "sepia":     engine.filter_sepia,
            "invert":    engine.filter_invert,
            "vignette":  lambda s: engine.filter_vignette(s, 0.7),
            "grain":     lambda s: engine.filter_grain(s, 0.10),
        }.get(name)
        if fn:
            fn(L.surface); self._snapshot()
            self.canvas.queue_draw(); self.hist.queue_draw()
            self.doc.log(f"filter · {name}")

    def _flip_h(self):
        L = self._layer()
        if L is None:
            return
        engine.transform_flip_h(L.surface); self._snapshot(); self.canvas.queue_draw()

    def _flip_v(self):
        L = self._layer()
        if L is None:
            return
        engine.transform_flip_v(L.surface); self._snapshot(); self.canvas.queue_draw()

    def _rot90(self):
        L = self._layer()
        if L is None:
            return
        new = engine.transform_rotate90(L.surface)
        if new is not None:
            L.surface = new; L.width = new.get_width(); L.height = new.get_height()
            self._snapshot(); self.canvas.queue_draw()

    def _commit(self):
        self._snapshot()
        for s in (self.s_bright, self.s_contr, self.s_sat,
                  self.s_hue, self.s_temp, self.s_exp):
            s.value = 1.0 if s.label in ("contrast", "saturation") else 0.0
            s.title.set_text(f"{s.label}  {s._fmt(s.value)}")
            s.area.queue_draw()
        self.parent._set_status("committed")

    def _reset(self):
        L = self._layer()
        if L is None or self.original is None:
            return
        L.surface = engine.copy_surface(self.original)
        for s in (self.s_bright, self.s_contr, self.s_sat,
                  self.s_hue, self.s_temp, self.s_exp):
            s.value = 1.0 if s.label in ("contrast", "saturation") else 0.0
            s.title.set_text(f"{s.label}  {s._fmt(s.value)}")
            s.area.queue_draw()
        self.canvas.queue_draw(); self.hist.queue_draw()

    def _save_png(self):
        ui.save_file(self.parent, "save photo as PNG",
                     "nyxus-photo.png", self._do_save_png)

    def _do_save_png(self, path: str):
        L = self._layer()
        if L is None:
            return
        if not path.lower().endswith(".png"):
            path += ".png"
        L.surface.write_to_png(path)
        self.parent._set_status(f"saved · {path}")

    # ── canvas ──
    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        L = self._layer()
        if L is None:
            return
        ox = (w - self.doc.width * self.zoom) / 2
        oy = (h - self.doc.height * self.zoom) / 2
        cr.save()
        cr.translate(ox, oy); cr.scale(self.zoom, self.zoom)
        cr.set_source_rgba(*self.doc.bg)
        cr.rectangle(0, 0, self.doc.width, self.doc.height); cr.fill()
        # left half: original; right half: edited
        if self.original is not None:
            cr.save()
            cr.rectangle(0, 0, self.doc.width * self.split, self.doc.height); cr.clip()
            cr.set_source_surface(self.original, 0, 0); cr.paint()
            cr.restore()
        cr.save()
        cr.rectangle(self.doc.width * self.split, 0,
                     self.doc.width * (1 - self.split), self.doc.height); cr.clip()
        cr.set_source_surface(L.surface, 0, 0); cr.paint()
        cr.restore()
        # split bar
        x = self.doc.width * self.split
        cr.set_source_rgba(*ui.NYX["gold"], 0.95)
        cr.set_line_width(2.0); cr.move_to(x, 0); cr.line_to(x, self.doc.height); cr.stroke()
        cr.restore()
        ui.sketch_rect(cr, ox - 4, oy - 4,
                       self.doc.width * self.zoom + 8,
                       self.doc.height * self.zoom + 8,
                       ui.NYX["cyan"] + (0.85,), 2.2)
        # labels
        cr.select_font_face("Caveat", 0, 1); cr.set_font_size(18)
        cr.set_source_rgba(*ui.NYX["ink_dim"], 1.0)
        cr.move_to(ox + 8, oy - 6); cr.show_text("BEFORE")
        cr.move_to(ox + self.doc.width * self.zoom - 60, oy - 6); cr.show_text("AFTER")

    # ── histogram ──
    def _draw_hist(self, _a, cr, w, h):
        cr.set_source_rgba(0.06, 0.06, 0.10, 1.0); cr.paint()
        L = self._layer()
        if L is None or np is None:
            return
        arr = engine.surf_to_array(L.surface)
        if arr is None:
            return
        b = arr[:, :, 0].ravel(); g = arr[:, :, 1].ravel(); r = arr[:, :, 2].ravel()
        for ch, color in ((r, ui.NYX["red"]), (g, ui.NYX["green"]), (b, ui.NYX["blue"])):
            hist, _ = np.histogram(ch, bins=64, range=(0, 256))
            mx = max(1, hist.max())
            cr.set_source_rgba(*color, 0.7)
            cr.set_line_width(1.0)
            cr.move_to(0, h)
            for i, v in enumerate(hist):
                x = i * w / 64
                y = h - (v / mx) * (h - 4)
                cr.line_to(x, y)
            cr.line_to(w, h); cr.close_path(); cr.fill()
        ui.sketch_rect(cr, 1, 1, w - 2, h - 2, ui.NYX["gold"] + (0.7,), 1.4)

    # ── menu hooks ──
    def refresh_canvas(self):
        self._snapshot(); self.canvas.queue_draw(); self.hist.queue_draw()

    def reset_zoom(self):
        self.zoom = 1.0; self.canvas.queue_draw()

    def show_panel(self, name: str):
        self.parent._set_status(f"panel · {name}")

    def filter(self, name: str):
        self._apply_filter(name)

    def adjust(self, kind: str, val):
        # one-shot: re-stage with updated slider
        if kind == "brightness":
            self.s_bright.value = float(val); self._stage("brightness", val)
        elif kind == "contrast":
            self.s_contr.value = float(val); self._stage("contrast", val)
        elif kind == "saturation":
            self.s_sat.value = float(val); self._stage("saturation", val)

    def layer_add(self): self.doc.add_raster_layer(); self.refresh_canvas()
    def layer_del(self): self.doc.remove_raster_layer(self.doc.active_raster); self.refresh_canvas()
    def layer_merge(self): self.doc.merge_down_raster(self.doc.active_raster); self.refresh_canvas()
    def layer_flatten(self):
        flat = self.doc.flatten_raster()
        if flat is not None:
            self.doc.raster_layers = [flat]; self.doc.active_raster = 0
        self.refresh_canvas()
