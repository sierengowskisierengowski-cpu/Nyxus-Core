"""
NYXUS Studio — m07 Layout
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Page layout module:
  • multi-page document with rulers + grid
  • text frames (with size + alignment)
  • image frames (load + scale)
  • shape frames (rect, ellipse, line)
  • alignment guides
  • page presets (A4/Letter/Square/Story)
  • export PDF (all pages) + PNG (current page)
"""
from __future__ import annotations

from pathlib import Path
import math

import gi

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk    # noqa: E402
import cairo

from studio import ui, engine
from studio.document import Document, Page, PageItem


PAGE_PRESETS = [
    ("A4 portrait",  794, 1123),
    ("A4 landscape", 1123, 794),
    ("Letter",       816, 1056),
    ("Square 1080",  1080, 1080),
    ("Story",        1080, 1920),
    ("Custom",       1280, 800),
]


def build(doc: Document, parent_window):
    if not doc.pages:
        doc.add_page("Page 1", doc.width, doc.height)
    mod = LayoutModule(doc, parent_window)
    return mod.widget, mod


class LayoutModule:
    def __init__(self, doc: Document, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.tool = "select"
        self.zoom = 0.6
        self.dragging: PageItem | None = None
        self.drag_off = (0.0, 0.0)
        self.draw_anchor: tuple[float, float] | None = None
        self.font_size = 28
        self.color = (1.0, 0.84, 0.20, 1.0)
        self.fill = (0.30, 0.70, 1.0, 0.85)
        self.show_grid = True
        self._preview = None
        self.selected_uid: str | None = None

        self.canvas = Gtk.DrawingArea()
        self.canvas.set_hexpand(True); self.canvas.set_vexpand(True)
        self.canvas.set_draw_func(self._draw)

        gd = Gtk.GestureDrag()
        gd.connect("drag-begin",  self._down)
        gd.connect("drag-update", self._move)
        gd.connect("drag-end",    self._up)
        self.canvas.add_controller(gd)

        gc = Gtk.GestureClick()
        gc.connect("released", self._click)
        self.canvas.add_controller(gc)

        # ── tools
        self.tool_palette = ui.ToolPalette([
            ("select", "Select", ui.NYX["pink"]),
            ("text",   "Text",   ui.NYX["gold"]),
            ("image",  "Image",  ui.NYX["blue"]),
            ("rect",   "Rect",   ui.NYX["purple"]),
            ("ellipse","Ellipse",ui.NYX["green"]),
            ("line",   "Line",   ui.NYX["orange"]),
        ], columns=2)
        self.tool_palette.on_select(lambda k: setattr(self, "tool", k))
        self.tool_palette.select(self.tool)

        # ── presets / page mgmt
        self.page_panel = ui.Panel("page", ui.NYX["gold"])
        for name, w, h in PAGE_PRESETS:
            b = ui.SketchButton(name, ui.NYX["gold"], height=24, font_size=14)
            b.connect("clicked", lambda *_a, _w=w, _h=h: self._set_page_size(_w, _h))
            self.page_panel.body.append(b)

        self.pages_panel = ui.Panel("pages", ui.NYX["purple"])
        self.pages_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.pages_panel.body.append(self.pages_box)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, homogeneous=True)
        for label, color, fn in [
            ("+ add",  ui.NYX["green"], self._add_page),
            ("dup",    ui.NYX["blue"],  self._dup_page),
            ("del",    ui.NYX["red"],   self._del_page),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            row.append(b)
        self.pages_panel.body.append(row)

        # ── style
        self.style_panel = ui.Panel("style", ui.NYX["pink"])
        self.style_panel.body.append(Gtk.Label(label="text color", xalign=0.0))
        self.style_panel.body.append(ui.ColorPalette(
            lambda c: setattr(self, "color", (*c, 1.0)), columns=6))
        self.style_panel.body.append(Gtk.Label(label="shape fill", xalign=0.0))
        self.style_panel.body.append(ui.ColorPalette(
            lambda c: setattr(self, "fill", (*c, 0.85)), columns=6))
        self.style_panel.body.append(ui.SketchSlider(
            "font size", 10, 96, self.font_size, color=ui.NYX["gold"], step=1,
            on_change=lambda v: setattr(self, "font_size", int(v))))

        # ── arrange / export
        self.act_panel = ui.Panel("arrange", ui.NYX["cyan"])
        for label, color, fn in [
            ("delete",     ui.NYX["red"],   self._delete_selected),
            ("clear page", ui.NYX["red"],   self._clear_page),
            ("toggle grid", ui.NYX["gold"], self._toggle_grid),
            ("export PNG", ui.NYX["blue"],  self._export_png),
            ("export PDF", ui.NYX["purple"], self._export_pdf),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.act_panel.body.append(b)

        # ── compose
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(196, -1)
        left.append(ui.TiltedHeader("layout", ui.NYX["gold"]))
        left.append(self.tool_palette)
        left.append(self.page_panel)
        left.append(self.style_panel)

        center = Gtk.ScrolledWindow()
        center.set_hexpand(True); center.set_vexpand(True)
        center.set_child(self.canvas)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(220, -1)
        right.append(self.pages_panel); right.append(self.act_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

        self._refresh_pages_box()

    # ── helpers ──
    def _page(self) -> Page:
        if not self.doc.pages:
            self.doc.add_page("Page 1", self.doc.width, self.doc.height)
        return self.doc.pages[max(0, min(self.doc.active_page, len(self.doc.pages) - 1))]

    def _to_page(self, x: float, y: float) -> tuple[float, float]:
        P = self._page()
        w = self.canvas.get_width(); h = self.canvas.get_height()
        ox = (w - P.width * self.zoom) / 2
        oy = (h - P.height * self.zoom) / 2
        return (x - ox) / self.zoom, (y - oy) / self.zoom

    def _set_page_size(self, w: int, h: int):
        P = self._page()
        P.width = w; P.height = h
        self.canvas.queue_draw()

    def _add_page(self):
        self.doc.add_page(f"Page {len(self.doc.pages) + 1}",
                          self._page().width, self._page().height)
        self.doc.active_page = len(self.doc.pages) - 1
        self._refresh_pages_box(); self.canvas.queue_draw()

    def _dup_page(self):
        self.doc.duplicate_page(self.doc.active_page)
        self.doc.active_page = len(self.doc.pages) - 1
        self._refresh_pages_box(); self.canvas.queue_draw()

    def _del_page(self):
        if len(self.doc.pages) <= 1:
            return
        self.doc.pages.pop(self.doc.active_page)
        self.doc.active_page = max(0, self.doc.active_page - 1)
        self._refresh_pages_box(); self.canvas.queue_draw()

    def _refresh_pages_box(self):
        child = self.pages_box.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.pages_box.remove(child); child = nxt
        for i, P in enumerate(self.doc.pages):
            color = ui.NYX["gold"] if i == self.doc.active_page else ui.NYX["ink_dim"]
            b = ui.SketchButton(f"{i + 1} · {P.name}", color, height=24, font_size=14)
            b.connect("clicked", lambda *_a, _i=i: self._select_page(_i))
            self.pages_box.append(b)

    def _select_page(self, i: int):
        self.doc.active_page = i
        self._refresh_pages_box(); self.canvas.queue_draw()

    def _toggle_grid(self):
        self.show_grid = not self.show_grid
        self.canvas.queue_draw()

    def _delete_selected(self):
        P = self._page(); item = self._selected()
        if item:
            P.items.remove(item); self.canvas.queue_draw()

    def _clear_page(self):
        self._page().items.clear(); self.canvas.queue_draw()

    def _selected(self) -> PageItem | None:
        if not self.selected_uid:
            return None
        for it in self._page().items:
            if it.uid == self.selected_uid:
                return it
        return None

    # ── input ──
    def _click(self, _g, _n, x, y):
        dx, dy = self._to_page(x, y)
        if self.tool == "text":
            ui.text_entry_dialog(self.parent, "text", "Hello",
                                  on_ok=lambda txt: self._add_text(dx, dy, txt))
            return
        if self.tool == "image":
            ui.open_file(self.parent, "open image",
                         lambda p: self._add_image(dx, dy, p),
                         filters=[("Images", ["*.png", "*.jpg", "*.jpeg", "*.webp"])])
            return
        if self.tool == "select":
            it = self._hit_test(dx, dy)
            self.selected_uid = it.uid if it else None
            self.canvas.queue_draw()

    def _down(self, _g, x, y):
        dx, dy = self._to_page(x, y)
        if self.tool in ("rect", "ellipse", "line"):
            self.draw_anchor = (dx, dy)
        elif self.tool == "select":
            it = self._hit_test(dx, dy)
            if it:
                self.dragging = it
                self.drag_off = (dx - it.x, dy - it.y)
                self.selected_uid = it.uid

    def _move(self, g, dx, dy):
        ok, sx, sy = g.get_start_point()
        if not ok:
            return
        x_p, y_p = self._to_page(sx + dx, sy + dy)
        if self.tool in ("rect", "ellipse", "line") and self.draw_anchor:
            self._preview = (self.draw_anchor, (x_p, y_p))
            self.canvas.queue_draw()
        elif self.dragging:
            self.dragging.x = x_p - self.drag_off[0]
            self.dragging.y = y_p - self.drag_off[1]
            self.canvas.queue_draw()

    def _up(self, g, dx, dy):
        ok, sx, sy = g.get_start_point()
        if not ok:
            return
        x_p, y_p = self._to_page(sx + dx, sy + dy)
        if self.tool in ("rect", "ellipse", "line") and self.draw_anchor:
            ax, ay = self.draw_anchor
            x = min(ax, x_p); y = min(ay, y_p)
            w = abs(x_p - ax); h = abs(y_p - ay)
            if w >= 4 and h >= 4:
                it = PageItem(kind=self.tool, x=x, y=y, w=w, h=h,
                              fill=self.fill, stroke=self.color, stroke_width=2.5)
                self._page().items.append(it)
                self.selected_uid = it.uid
            self.draw_anchor = None; self._preview = None
            self.canvas.queue_draw()
        self.dragging = None

    def _add_text(self, x: float, y: float, txt: str):
        it = PageItem(kind="text", x=x, y=y, w=400, h=self.font_size + 8,
                      text=txt, font_size=self.font_size, fill=self.color)
        self._page().items.append(it)
        self.selected_uid = it.uid
        self.canvas.queue_draw()

    def _add_image(self, x: float, y: float, path: str):
        surf = engine.load_image_to_surface(path)
        if surf is None:
            self.parent._set_status("could not open image"); return
        it = PageItem(kind="image", x=x, y=y,
                      w=surf.get_width(), h=surf.get_height(),
                      surface=surf, image_path=path)
        self._page().items.append(it)
        self.selected_uid = it.uid
        self.canvas.queue_draw()

    def _hit_test(self, x: float, y: float) -> PageItem | None:
        for it in reversed(self._page().items):
            if it.x <= x <= it.x + it.w and it.y <= y <= it.y + it.h:
                return it
        return None

    # ── drawing ──
    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        P = self._page()
        ox = (w - P.width * self.zoom) / 2
        oy = (h - P.height * self.zoom) / 2
        cr.save(); cr.translate(ox, oy); cr.scale(self.zoom, self.zoom)
        # page paper
        cr.set_source_rgba(0.96, 0.94, 0.90, 1.0)
        cr.rectangle(0, 0, P.width, P.height); cr.fill()
        if self.show_grid:
            cr.set_source_rgba(0, 0, 0, 0.04)
            cr.set_line_width(1)
            for x in range(0, P.width, 50):
                cr.move_to(x, 0); cr.line_to(x, P.height)
            for y in range(0, P.height, 50):
                cr.move_to(0, y); cr.line_to(P.width, y)
            cr.stroke()
        # items
        for it in P.items:
            self._draw_item(cr, it)
        # preview
        if self._preview:
            (ax, ay), (bx, by) = self._preview
            cr.set_source_rgba(*self.color, 0.7); cr.set_line_width(2)
            cr.set_dash([5, 4], 0); cr.rectangle(min(ax, bx), min(ay, by),
                                                  abs(bx - ax), abs(by - ay)); cr.stroke()
            cr.set_dash([], 0)
        # selection halo
        sel = self._selected()
        if sel:
            cr.set_source_rgba(*ui.NYX["gold"], 0.9); cr.set_line_width(1.5)
            cr.set_dash([4, 3], 0); cr.rectangle(sel.x - 3, sel.y - 3,
                                                   sel.w + 6, sel.h + 6); cr.stroke()
            cr.set_dash([], 0)
        cr.restore()
        ui.sketch_rect(cr, ox - 4, oy - 4,
                       P.width * self.zoom + 8, P.height * self.zoom + 8,
                       ui.NYX["gold"] + (0.85,), 2.2)
        cr.select_font_face("Caveat", 0, 1); cr.set_font_size(16)
        cr.set_source_rgba(*ui.NYX["ink_dim"], 1.0)
        cr.move_to(ox, oy - 8)
        cr.show_text(f"{P.name}  ·  {P.width}×{P.height}  ·  page {self.doc.active_page + 1}/{len(self.doc.pages)}")

    def _draw_item(self, cr, it: PageItem):
        if it.kind == "text":
            cr.select_font_face(it.font, 0, 1)
            cr.set_font_size(it.font_size)
            cr.set_source_rgba(*it.fill if it.fill else (0.05, 0.05, 0.07, 1.0))
            for k, line in enumerate(it.text.split("\n")):
                cr.move_to(it.x, it.y + (k + 1) * it.font_size * 1.05)
                cr.show_text(line)
        elif it.kind == "image" and it.surface is not None:
            cr.save()
            cr.translate(it.x, it.y)
            sw = it.surface.get_width(); sh = it.surface.get_height()
            cr.scale(it.w / max(1, sw), it.h / max(1, sh))
            cr.set_source_surface(it.surface, 0, 0); cr.paint()
            cr.restore()
        elif it.kind == "rect":
            if it.fill:
                cr.set_source_rgba(*it.fill); cr.rectangle(it.x, it.y, it.w, it.h); cr.fill()
            if it.stroke:
                cr.set_source_rgba(*it.stroke); cr.set_line_width(it.stroke_width)
                cr.rectangle(it.x, it.y, it.w, it.h); cr.stroke()
        elif it.kind == "ellipse":
            cr.save(); cr.translate(it.x + it.w / 2, it.y + it.h / 2)
            cr.scale(it.w / 2, it.h / 2); cr.arc(0, 0, 1, 0, math.pi * 2); cr.restore()
            if it.fill:
                cr.set_source_rgba(*it.fill); cr.fill_preserve()
            if it.stroke:
                cr.set_source_rgba(*it.stroke); cr.set_line_width(it.stroke_width); cr.stroke()
        elif it.kind == "line":
            cr.set_source_rgba(*(it.stroke or (0.05, 0.05, 0.07, 1.0)))
            cr.set_line_width(it.stroke_width)
            cr.move_to(it.x, it.y); cr.line_to(it.x + it.w, it.y + it.h); cr.stroke()

    # ── export ──
    def _export_png(self):
        ui.save_file(self.parent, "export current page (PNG)",
                     "nyxus-layout.png", self._do_export_png)

    def _do_export_png(self, path: str):
        if not path.lower().endswith(".png"):
            path += ".png"
        P = self._page()
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, P.width, P.height)
        cr = cairo.Context(s)
        cr.set_source_rgba(0.96, 0.94, 0.90, 1.0); cr.paint()
        for it in P.items:
            self._draw_item(cr, it)
        s.write_to_png(path)
        self.parent._set_status(f"saved · {path}")

    def _export_pdf(self):
        ui.save_file(self.parent, "export PDF (all pages)",
                     "nyxus-layout.pdf", self._do_export_pdf)

    def _do_export_pdf(self, path: str):
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        if not self.doc.pages:
            return
        first = self.doc.pages[0]
        pdf = cairo.PDFSurface(path, first.width, first.height)
        cr = cairo.Context(pdf)
        for i, P in enumerate(self.doc.pages):
            pdf.set_size(P.width, P.height)
            cr.set_source_rgba(0.96, 0.94, 0.90, 1.0)
            cr.rectangle(0, 0, P.width, P.height); cr.fill()
            for it in P.items:
                self._draw_item(cr, it)
            cr.show_page()
        pdf.finish()
        self.parent._set_status(f"saved · {path}")

    # ── menu hooks ──
    def refresh_canvas(self): self.canvas.queue_draw()
    def reset_zoom(self): self.zoom = 0.6; self.canvas.queue_draw()
    def show_panel(self, name: str): self.parent._set_status(f"panel · {name}")
    def filter(self, name: str): self.parent._set_status("layout · no raster filter on pages")
    def adjust(self, kind, val): pass
    def layer_add(self): self._add_page()
    def layer_del(self): self._del_page()
    def layer_merge(self): pass
    def layer_flatten(self): pass
