"""
NYXUS Studio — m08 Type
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Typography lab:
  • live preview of any installed font family
  • size, weight, slant, letter-spacing, line-height
  • alignment (left/center/right)
  • color, stroke, shadow, gradient
  • font picker (queries Pango font map)
  • export PNG / SVG
"""
from __future__ import annotations

from pathlib import Path

import gi

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────

gi.require_version("Gtk", "4.0")
gi.require_version("Pango", "1.0")
gi.require_version("PangoCairo", "1.0")
from gi.repository import Gtk, Pango, PangoCairo    # noqa: E402
import cairo

from studio import ui


def build(doc, parent_window):
    mod = TypeModule(doc, parent_window)
    return mod.widget, mod


class TypeModule:
    def __init__(self, doc, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.text = "NYXUS\nstudio"
        self.font_family = "Caveat"
        self.font_size = 96
        self.weight = 700
        self.slant = "normal"
        self.letter_spacing = 0
        self.line_height = 1.0
        self.align = "center"
        self.color = (1.0, 0.84, 0.20, 1.0)
        self.stroke_on = False
        self.stroke_color = (1.0, 0.24, 0.65, 1.0)
        self.stroke_w = 2.0
        self.shadow_on = True
        self.shadow_color = (0.0, 0.0, 0.0, 0.55)
        self.shadow_dx = 4
        self.shadow_dy = 4
        self.gradient = False

        self.canvas = Gtk.DrawingArea()
        self.canvas.set_hexpand(True); self.canvas.set_vexpand(True)
        self.canvas.set_draw_func(self._draw)

        # ── text editor
        self.entry = Gtk.TextView()
        self.entry.set_size_request(-1, 110)
        self.entry.get_buffer().set_text(self.text)
        self.entry.get_buffer().connect("changed", self._on_text_changed)

        text_panel = ui.Panel("text", ui.NYX["pink"])
        sw = Gtk.ScrolledWindow(); sw.set_child(self.entry); sw.set_size_request(-1, 100)
        text_panel.body.append(sw)

        # ── font picker
        font_panel = ui.Panel("font", ui.NYX["purple"])
        self.font_btn = Gtk.FontDialogButton.new(Gtk.FontDialog())
        self.font_btn.set_use_size(True); self.font_btn.set_use_font(True)
        try:
            self.font_btn.set_font_desc(Pango.FontDescription.from_string(
                f"{self.font_family} Bold {self.font_size}"))
        except Exception:
            pass
        self.font_btn.connect("notify::font-desc", self._on_font_change)
        font_panel.body.append(self.font_btn)

        # ── style sliders
        style_panel = ui.Panel("style", ui.NYX["blue"])
        style_panel.body.append(ui.SketchSlider("size", 12, 320, self.font_size,
                                                 color=ui.NYX["pink"], step=1,
                                                 on_change=lambda v: self._set("font_size", int(v))))
        style_panel.body.append(ui.SketchSlider("weight", 100, 900, self.weight,
                                                 color=ui.NYX["blue"], step=100,
                                                 on_change=lambda v: self._set("weight", int(v))))
        style_panel.body.append(ui.SketchSlider("letter spacing", -10, 30, 0,
                                                 color=ui.NYX["green"], step=1,
                                                 on_change=lambda v: self._set("letter_spacing", int(v))))
        style_panel.body.append(ui.SketchSlider("line height", 0.7, 2.2, 1.0,
                                                 color=ui.NYX["purple"],
                                                 on_change=lambda v: self._set("line_height", float(v))))

        align_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, homogeneous=True)
        for label, color, val in [
            ("left",   ui.NYX["pink"],  "left"),
            ("center", ui.NYX["green"], "center"),
            ("right",  ui.NYX["blue"],  "right"),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _v=val: self._set("align", _v))
            align_row.append(b)
        style_panel.body.append(align_row)

        slant_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, homogeneous=True)
        for label, color, val in [
            ("normal", ui.NYX["pink"], "normal"),
            ("italic", ui.NYX["gold"], "italic"),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _v=val: self._set("slant", _v))
            slant_row.append(b)
        style_panel.body.append(slant_row)

        # ── color panel
        col_panel = ui.Panel("color", ui.NYX["gold"])
        col_panel.body.append(Gtk.Label(label="fill", xalign=0.0))
        col_panel.body.append(ui.ColorPalette(
            lambda c: self._set("color", (*c, 1.0)), columns=6))
        col_panel.body.append(Gtk.Label(label="stroke", xalign=0.0))
        col_panel.body.append(ui.ColorPalette(
            lambda c: self._set("stroke_color", (*c, 1.0)), columns=6))
        col_panel.body.append(Gtk.Label(label="shadow", xalign=0.0))
        col_panel.body.append(ui.ColorPalette(
            lambda c: self._set("shadow_color", (*c, 0.55)), columns=6))

        # ── effect toggles
        fx = ui.Panel("effects", ui.NYX["red"])
        for label, color, fn in [
            ("toggle stroke",  ui.NYX["pink"],   lambda: self._toggle("stroke_on")),
            ("toggle shadow",  ui.NYX["blue"],   lambda: self._toggle("shadow_on")),
            ("toggle gradient", ui.NYX["green"], lambda: self._toggle("gradient")),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            fx.body.append(b)
        fx.body.append(ui.SketchSlider("stroke width", 0.5, 12, self.stroke_w,
                                        color=ui.NYX["pink"],
                                        on_change=lambda v: self._set("stroke_w", float(v))))
        fx.body.append(ui.SketchSlider("shadow X", -20, 20, self.shadow_dx,
                                        color=ui.NYX["blue"], step=1,
                                        on_change=lambda v: self._set("shadow_dx", int(v))))
        fx.body.append(ui.SketchSlider("shadow Y", -20, 20, self.shadow_dy,
                                        color=ui.NYX["green"], step=1,
                                        on_change=lambda v: self._set("shadow_dy", int(v))))

        # ── export
        exp = ui.Panel("export", ui.NYX["cyan"])
        for label, color, fn in [
            ("export PNG", ui.NYX["pink"], self._export_png),
            ("export SVG", ui.NYX["blue"], self._export_svg),
        ]:
            b = ui.SketchButton(label, color, height=28, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            exp.body.append(b)

        # ── compose
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(220, -1)
        left.append(ui.TiltedHeader("type lab", ui.NYX["red"]))
        left.append(text_panel); left.append(font_panel); left.append(style_panel)

        center = Gtk.ScrolledWindow()
        center.set_hexpand(True); center.set_vexpand(True)
        center.set_child(self.canvas)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(240, -1)
        right.append(col_panel); right.append(fx); right.append(exp)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

    def _set(self, k, v):
        setattr(self, k, v); self.canvas.queue_draw()

    def _toggle(self, k):
        setattr(self, k, not getattr(self, k)); self.canvas.queue_draw()

    def _on_text_changed(self, buf):
        s = buf.get_start_iter(); e = buf.get_end_iter()
        self.text = buf.get_text(s, e, True)
        self.canvas.queue_draw()

    def _on_font_change(self, *_):
        desc = self.font_btn.get_font_desc()
        if desc:
            self.font_family = desc.get_family()
            self.font_size = max(12, int(desc.get_size() / Pango.SCALE)) if desc.get_size() > 0 else self.font_size
        self.canvas.queue_draw()

    # ── drawing ──
    def _font_desc(self) -> Pango.FontDescription:
        d = Pango.FontDescription()
        d.set_family(self.font_family)
        d.set_weight(self.weight)
        d.set_style(Pango.Style.ITALIC if self.slant == "italic" else Pango.Style.NORMAL)
        d.set_absolute_size(self.font_size * Pango.SCALE)
        return d

    def _make_layout(self, cr) -> Pango.Layout:
        layout = PangoCairo.create_layout(cr)
        layout.set_font_description(self._font_desc())
        layout.set_text(self.text)
        layout.set_spacing(int((self.line_height - 1.0) * self.font_size * Pango.SCALE))
        attrs = Pango.AttrList()
        if self.letter_spacing:
            attrs.insert(Pango.attr_letter_spacing_new(self.letter_spacing * Pango.SCALE))
        layout.set_attributes(attrs)
        if self.align == "center":
            layout.set_alignment(Pango.Alignment.CENTER)
        elif self.align == "right":
            layout.set_alignment(Pango.Alignment.RIGHT)
        else:
            layout.set_alignment(Pango.Alignment.LEFT)
        return layout

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        layout = self._make_layout(cr)
        layout.set_width(int((w - 80) * Pango.SCALE))
        ext_ink, ext_log = layout.get_pixel_extents()
        # center vertically
        x = 40
        y = (h - ext_log.height) / 2
        # shadow
        if self.shadow_on:
            cr.save(); cr.translate(x + self.shadow_dx, y + self.shadow_dy)
            cr.set_source_rgba(*self.shadow_color)
            PangoCairo.show_layout(cr, layout)
            cr.restore()
        # gradient or solid fill
        cr.save(); cr.translate(x, y)
        if self.gradient:
            grad = cairo.LinearGradient(0, 0, 0, ext_log.height)
            grad.add_color_stop_rgba(0.0, *self.color)
            grad.add_color_stop_rgba(1.0,
                                     self.color[0] * 0.4,
                                     self.color[1] * 0.4,
                                     self.color[2] * 0.4,
                                     self.color[3])
            cr.set_source(grad)
        else:
            cr.set_source_rgba(*self.color)
        PangoCairo.layout_path(cr, layout); cr.fill_preserve() if self.stroke_on else cr.fill()
        # stroke
        if self.stroke_on:
            cr.set_source_rgba(*self.stroke_color)
            cr.set_line_width(self.stroke_w)
            cr.stroke()
        cr.restore()
        # frame
        ui.sketch_rect(cr, 20, 20, w - 40, h - 40, ui.NYX["red"] + (0.85,), 2.2)

    def _export_png(self):
        ui.save_file(self.parent, "export PNG", "nyxus-type.png", self._do_png)

    def _do_png(self, path: str):
        if not path.lower().endswith(".png"):
            path += ".png"
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.doc.width, self.doc.height)
        cr = cairo.Context(s)
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        # rebuild a Pango layout against this surface
        layout = self._make_layout(cr)
        layout.set_width(int((self.doc.width - 80) * Pango.SCALE))
        _, ext = layout.get_pixel_extents()
        x = 40; y = (self.doc.height - ext.height) / 2
        if self.shadow_on:
            cr.save(); cr.translate(x + self.shadow_dx, y + self.shadow_dy)
            cr.set_source_rgba(*self.shadow_color); PangoCairo.show_layout(cr, layout); cr.restore()
        cr.save(); cr.translate(x, y); cr.set_source_rgba(*self.color)
        PangoCairo.layout_path(cr, layout); cr.fill_preserve() if self.stroke_on else cr.fill()
        if self.stroke_on:
            cr.set_source_rgba(*self.stroke_color); cr.set_line_width(self.stroke_w); cr.stroke()
        cr.restore()
        s.write_to_png(path)
        self.parent._set_status(f"saved · {path}")

    def _export_svg(self):
        ui.save_file(self.parent, "export SVG", "nyxus-type.svg", self._do_svg)

    def _do_svg(self, path: str):
        if not path.lower().endswith(".svg"):
            path += ".svg"
        surf = cairo.SVGSurface(path, self.doc.width, self.doc.height)
        cr = cairo.Context(surf)
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        layout = self._make_layout(cr)
        layout.set_width(int((self.doc.width - 80) * Pango.SCALE))
        _, ext = layout.get_pixel_extents()
        x = 40; y = (self.doc.height - ext.height) / 2
        if self.shadow_on:
            cr.save(); cr.translate(x + self.shadow_dx, y + self.shadow_dy)
            cr.set_source_rgba(*self.shadow_color); PangoCairo.show_layout(cr, layout); cr.restore()
        cr.save(); cr.translate(x, y); cr.set_source_rgba(*self.color)
        PangoCairo.layout_path(cr, layout); cr.fill_preserve() if self.stroke_on else cr.fill()
        if self.stroke_on:
            cr.set_source_rgba(*self.stroke_color); cr.set_line_width(self.stroke_w); cr.stroke()
        cr.restore(); surf.finish()
        self.parent._set_status(f"saved · {path}")

    # menu hooks
    def refresh_canvas(self): self.canvas.queue_draw()
    def reset_zoom(self): pass
    def show_panel(self, name): self.parent._set_status(f"panel · {name}")
    def filter(self, name): pass
    def adjust(self, kind, val): pass
    def layer_add(self): pass
    def layer_del(self): pass
    def layer_merge(self): pass
    def layer_flatten(self): pass
