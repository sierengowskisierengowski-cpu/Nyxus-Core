"""
NYXUS Studio — m04 Video
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Non-linear video editor (single video track + overlay track):
  • import any ffmpeg-readable file
  • clip thumbnails on timeline
  • per-clip in/out trim sliders
  • drag clips along the timeline
  • text & color overlays
  • render to MP4 via ffmpeg
"""
from __future__ import annotations

import math
import tempfile
import threading
from pathlib import Path
from typing import Callable

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib    # noqa: E402
import cairo

from studio import ui, video_engine
from studio.document import Document, VideoTimeline, VideoClip, VideoOverlay, OUT_DIR


def build(doc: Document, parent_window):
    if doc.video_timeline is None:
        doc.video_timeline = VideoTimeline()
    mod = VideoModule(doc, parent_window)
    return mod.widget, mod


class VideoModule:
    def __init__(self, doc: Document, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.tl: VideoTimeline = doc.video_timeline
        self.selected_idx: int | None = None
        self.dragging = False
        self.drag_off = 0.0
        self.zoom_ms_per_px = 30  # 30 ms per pixel
        self.scroll_x = 0.0
        self.thumb_cache: dict[str, str] = {}

        # ── UI: toolbar
        self.tools = ui.Panel("clips", ui.NYX["orange"])
        for label, color, fn in [
            ("import clip…",  ui.NYX["green"],  self._import_clip),
            ("text overlay",  ui.NYX["pink"],   self._add_text_overlay),
            ("color overlay", ui.NYX["blue"],   self._add_color_overlay),
            ("delete clip",   ui.NYX["red"],    self._del_clip),
        ]:
            b = ui.SketchButton(label, color, height=28, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.tools.body.append(b)

        # ── output settings
        self.out_panel = ui.Panel("output", ui.NYX["gold"])
        self.s_w = ui.SketchSlider("width", 320, 3840, self.tl.width,
                                    color=ui.NYX["pink"], step=2,
                                    on_change=lambda v: setattr(self.tl, "width", int(v)))
        self.s_h = ui.SketchSlider("height", 240, 2160, self.tl.height,
                                    color=ui.NYX["blue"], step=2,
                                    on_change=lambda v: setattr(self.tl, "height", int(v)))
        self.s_fps = ui.SketchSlider("fps", 12, 60, self.tl.fps,
                                      color=ui.NYX["green"], step=1,
                                      on_change=lambda v: setattr(self.tl, "fps", int(v)))
        for w in (self.s_w, self.s_h, self.s_fps):
            self.out_panel.body.append(w)

        for label, color, w_, h_ in [
            ("720p",  ui.NYX["pink"],  1280, 720),
            ("1080p", ui.NYX["blue"],  1920, 1080),
            ("Story 9:16", ui.NYX["purple"], 1080, 1920),
            ("Square 1:1", ui.NYX["gold"],   1080, 1080),
        ]:
            b = ui.SketchButton(label, color, height=24, font_size=14)
            b.connect("clicked", lambda *_a, _w=w_, _h=h_: self._set_resolution(_w, _h))
            self.out_panel.body.append(b)

        # ── clip detail
        self.detail_panel = ui.Panel("clip detail", ui.NYX["purple"])
        self.detail_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.detail_panel.body.append(self.detail_box)
        self._refresh_detail()

        # ── render
        self.render_panel = ui.Panel("render", ui.NYX["red"])
        self.render_btn = ui.SketchButton("render to MP4…", ui.NYX["green"],
                                           height=32, font_size=16)
        self.render_btn.connect("clicked", lambda *_: self._render())
        self.render_panel.body.append(self.render_btn)
        self.render_status = Gtk.Label(label="ready", xalign=0.0, wrap=True)
        self.render_status.add_css_class("nyx-faint")
        self.render_panel.body.append(self.render_status)

        # ── timeline canvas
        self.timeline_area = Gtk.DrawingArea()
        self.timeline_area.set_size_request(-1, 220)
        self.timeline_area.set_draw_func(self._draw_timeline)

        gd = Gtk.GestureDrag()
        gd.connect("drag-begin",  self._tl_down)
        gd.connect("drag-update", self._tl_move)
        gd.connect("drag-end",    self._tl_up)
        self.timeline_area.add_controller(gd)

        gc = Gtk.GestureClick()
        gc.connect("released", self._tl_click)
        self.timeline_area.add_controller(gc)

        # ── preview pane
        self.preview = Gtk.DrawingArea()
        self.preview.set_hexpand(True); self.preview.set_vexpand(True)
        self.preview.set_draw_func(self._draw_preview)

        # ── compose
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(220, -1)
        left.append(ui.TiltedHeader("video", ui.NYX["orange"]))
        left.append(self.tools); left.append(self.out_panel)

        center = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        center.append(self.preview)
        sw = Gtk.ScrolledWindow(); sw.set_child(self.timeline_area)
        sw.set_size_request(-1, 230); sw.set_hexpand(True)
        center.append(sw)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(240, -1)
        right.append(self.detail_panel); right.append(self.render_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

    # ── helpers ──
    def _set_resolution(self, w: int, h: int):
        self.tl.width = w; self.tl.height = h
        self.s_w.value = w; self.s_h.value = h
        self.s_w.title.set_text(f"width  {w}"); self.s_h.title.set_text(f"height  {h}")
        self.s_w.area.queue_draw(); self.s_h.area.queue_draw()
        self.preview.queue_draw()

    def _import_clip(self):
        ui.open_file(self.parent, "import clip",
                     self._on_import,
                     filters=[("Video", ["*.mp4", "*.mov", "*.mkv", "*.webm", "*.avi", "*.gif"])])

    def _on_import(self, path: str):
        info = video_engine.probe(path)
        dur = int(info.get("duration_ms", 5000))
        start = self._timeline_end()
        clip = VideoClip(src=path, start_ms=start, in_ms=0, out_ms=dur)
        self.tl.clips.append(clip)
        # generate thumbnail in background
        threading.Thread(target=self._gen_thumbnail, args=(clip,), daemon=True).start()
        self._refresh_detail()
        self.timeline_area.queue_draw()
        self.parent._set_status(f"imported · {Path(path).name}")

    def _gen_thumbnail(self, clip: VideoClip):
        out_dir = OUT_DIR / "thumbs"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"thumb_{abs(hash(clip.src + str(clip.in_ms)))}.png"
        if not out.exists():
            video_engine.thumbnail(clip.src, max(0, clip.in_ms + 200), str(out), w=240)
        if out.exists():
            self.thumb_cache[clip.uid] = str(out)
            GLib.idle_add(self.timeline_area.queue_draw)
            GLib.idle_add(self.preview.queue_draw)

    def _timeline_end(self) -> int:
        end = 0
        for c in self.tl.clips:
            end = max(end, c.start_ms + (c.out_ms - c.in_ms))
        return end

    def _add_text_overlay(self):
        ui.text_entry_dialog(self.parent, "overlay text", "NYXUS",
                              on_ok=self._on_text_overlay)

    def _on_text_overlay(self, txt: str):
        self.tl.overlays.append(VideoOverlay(
            kind="text", text=txt, x=40, y=40, w=200, h=60,
            start_ms=0, end_ms=max(2000, self._timeline_end()),
            color=(1, 1, 1, 1), font_size=64))
        self.timeline_area.queue_draw(); self.preview.queue_draw()

    def _add_color_overlay(self):
        self.tl.overlays.append(VideoOverlay(
            kind="color", x=0, y=0, w=self.tl.width, h=80,
            start_ms=0, end_ms=2000, color=(0, 0, 0, 0.7)))
        self.timeline_area.queue_draw(); self.preview.queue_draw()

    def _del_clip(self):
        if self.selected_idx is None or self.selected_idx >= len(self.tl.clips):
            return
        self.tl.clips.pop(self.selected_idx)
        self.selected_idx = None
        self._refresh_detail(); self.timeline_area.queue_draw()

    def _refresh_detail(self):
        child = self.detail_box.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.detail_box.remove(child); child = nxt
        if self.selected_idx is None or self.selected_idx >= len(self.tl.clips):
            l = Gtk.Label(label="(no clip selected)", xalign=0.0)
            l.add_css_class("nyx-faint")
            self.detail_box.append(l)
            return
        c = self.tl.clips[self.selected_idx]
        info = video_engine.probe(c.src)
        dur = int(info.get("duration_ms", c.out_ms))
        l = Gtk.Label(label=Path(c.src).name, xalign=0.0)
        l.add_css_class("nyx-h3"); self.detail_box.append(l)
        info_l = Gtk.Label(
            label=f"{info.get('width', 0)}×{info.get('height', 0)}  ·  "
                  f"{info.get('fps', 30):.1f} fps  ·  {dur/1000:.1f} s",
            xalign=0.0)
        info_l.add_css_class("nyx-faint")
        self.detail_box.append(info_l)

        s_in = ui.SketchSlider("trim in (ms)", 0, dur, c.in_ms,
                                color=ui.NYX["green"], step=10,
                                on_change=lambda v, _c=c: self._set_clip(_c, "in_ms", int(v)))
        s_out = ui.SketchSlider("trim out (ms)", 0, dur, c.out_ms,
                                 color=ui.NYX["pink"], step=10,
                                 on_change=lambda v, _c=c: self._set_clip(_c, "out_ms", int(v)))
        s_start = ui.SketchSlider("start at (ms)", 0, max(60000, self._timeline_end() + 10000),
                                   c.start_ms, color=ui.NYX["blue"], step=10,
                                   on_change=lambda v, _c=c: self._set_clip(_c, "start_ms", int(v)))
        for w in (s_in, s_out, s_start):
            self.detail_box.append(w)

    def _set_clip(self, c: VideoClip, k: str, v: int):
        setattr(c, k, v); self.timeline_area.queue_draw(); self.preview.queue_draw()

    # ── timeline interaction ──
    def _tl_x_to_ms(self, x: float) -> int:
        return int((x + self.scroll_x) * self.zoom_ms_per_px)

    def _ms_to_x(self, ms: int) -> float:
        return ms / self.zoom_ms_per_px - self.scroll_x

    def _tl_click(self, _g, _n, x, y):
        ms = self._tl_x_to_ms(x)
        # hit-test clips
        if 4 <= y <= 120:
            for i, c in enumerate(self.tl.clips):
                left = self._ms_to_x(c.start_ms)
                right = self._ms_to_x(c.start_ms + (c.out_ms - c.in_ms))
                if left <= x <= right:
                    self.selected_idx = i
                    self._refresh_detail(); self.timeline_area.queue_draw()
                    return
        self.selected_idx = None
        self._refresh_detail(); self.timeline_area.queue_draw()

    def _tl_down(self, _g, x, y):
        if self.selected_idx is None:
            return
        c = self.tl.clips[self.selected_idx]
        if 4 <= y <= 120:
            self.dragging = True
            self.drag_off = self._tl_x_to_ms(x) - c.start_ms

    def _tl_move(self, g, dx, dy):
        if not self.dragging or self.selected_idx is None:
            return
        ok, sx, _sy = g.get_start_point()
        if not ok:
            return
        ms = self._tl_x_to_ms(sx + dx) - self.drag_off
        ms = max(0, ms)
        self.tl.clips[self.selected_idx].start_ms = ms
        self.timeline_area.queue_draw()

    def _tl_up(self, *_):
        self.dragging = False

    # ── timeline drawing ──
    def _draw_timeline(self, _a, cr, w, h):
        cr.set_source_rgba(0.06, 0.06, 0.10, 1.0); cr.paint()
        # ruler
        cr.set_source_rgba(*ui.NYX["ink_dim"], 0.7); cr.set_line_width(1)
        cr.select_font_face("Caveat", 0, 1); cr.set_font_size(12)
        end_ms = max(60000, self._timeline_end() + 5000)
        step_ms = 1000
        for ms in range(0, end_ms + step_ms, step_ms):
            x = self._ms_to_x(ms)
            if x < 0:
                continue
            if x > w:
                break
            cr.move_to(x, 0); cr.line_to(x, 8); cr.stroke()
            cr.move_to(x + 2, 12)
            cr.show_text(f"{ms/1000:.1f}s")
        # video track
        cr.set_source_rgba(0.10, 0.08, 0.16, 1.0)
        cr.rectangle(0, 20, w, 100); cr.fill()
        # overlay track
        cr.set_source_rgba(0.14, 0.10, 0.22, 1.0)
        cr.rectangle(0, 130, w, 50); cr.fill()
        cr.set_source_rgba(*ui.NYX["ink_faint"], 1.0)
        cr.move_to(8, 36); cr.show_text("video")
        cr.move_to(8, 146); cr.show_text("overlay")
        # clips
        for i, c in enumerate(self.tl.clips):
            x = self._ms_to_x(c.start_ms)
            cw = max(8, (c.out_ms - c.in_ms) / self.zoom_ms_per_px)
            if x + cw < 0 or x > w:
                continue
            color = ui.NYX["orange"] if i == self.selected_idx else ui.NYX["pink"]
            ui.sketch_rect_fill(cr, x + 2, 22, cw - 4, 96,
                                 (color[0] * 0.3, color[1] * 0.3, color[2] * 0.3, 0.85), 1.6)
            ui.sketch_rect(cr, x + 2, 22, cw - 4, 96, color + (1.0,), 2.0)
            # thumbnail
            tp = self.thumb_cache.get(c.uid)
            if tp:
                try:
                    surf = cairo.ImageSurface.create_from_png(tp)
                    sw_ = surf.get_width(); sh = surf.get_height()
                    target_h = 72
                    scale = target_h / sh
                    cr.save()
                    cr.translate(x + 8, 32)
                    cr.scale(scale, scale)
                    cr.set_source_surface(surf, 0, 0); cr.paint()
                    cr.restore()
                except Exception:
                    pass
            cr.set_source_rgba(*ui.NYX["ink"], 1.0)
            cr.select_font_face("Caveat", 0, 1); cr.set_font_size(13)
            cr.move_to(x + 8, 113); cr.show_text(Path(c.src).name[:24])
        # overlays
        for ov in self.tl.overlays:
            x = self._ms_to_x(ov.start_ms)
            ow = max(8, (ov.end_ms - ov.start_ms) / self.zoom_ms_per_px)
            color = ui.NYX["pink"] if ov.kind == "text" else ui.NYX["blue"]
            ui.sketch_rect_fill(cr, x + 2, 132, ow - 4, 46,
                                 (color[0] * 0.3, color[1] * 0.3, color[2] * 0.3, 0.85), 1.4)
            ui.sketch_rect(cr, x + 2, 132, ow - 4, 46, color + (1.0,), 1.6)
            cr.set_source_rgba(*ui.NYX["ink"], 1.0)
            cr.move_to(x + 8, 158)
            cr.show_text(f"{ov.kind}: {ov.text[:18] if ov.text else ''}")

    # ── preview pane ──
    def _draw_preview(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        # scaled rect for current resolution
        ar = self.tl.width / max(1, self.tl.height)
        target_h = h - 30
        target_w = target_h * ar
        if target_w > w - 30:
            target_w = w - 30
            target_h = target_w / ar
        x = (w - target_w) / 2; y = (h - target_h) / 2
        cr.set_source_rgba(0.02, 0.02, 0.04, 1.0)
        cr.rectangle(x, y, target_w, target_h); cr.fill()
        # show first selected clip thumbnail centered
        c = (self.tl.clips[self.selected_idx]
             if self.selected_idx is not None else
             (self.tl.clips[0] if self.tl.clips else None))
        if c is not None:
            tp = self.thumb_cache.get(c.uid)
            if tp:
                try:
                    surf = cairo.ImageSurface.create_from_png(tp)
                    sw_ = surf.get_width(); sh = surf.get_height()
                    scale = min(target_w / sw_, target_h / sh)
                    cr.save()
                    cr.translate(x + (target_w - sw_ * scale) / 2,
                                  y + (target_h - sh * scale) / 2)
                    cr.scale(scale, scale)
                    cr.set_source_surface(surf, 0, 0); cr.paint()
                    cr.restore()
                except Exception:
                    pass
        ui.sketch_rect(cr, x - 4, y - 4, target_w + 8, target_h + 8,
                       ui.NYX["orange"] + (0.85,), 2.2)
        cr.select_font_face("Caveat", 0, 1); cr.set_font_size(16)
        cr.set_source_rgba(*ui.NYX["ink_dim"], 1.0)
        cr.move_to(x, y - 8)
        cr.show_text(f"preview · {self.tl.width}×{self.tl.height} @ {self.tl.fps} fps")

    # ── render ──
    def _render(self):
        if not self.tl.clips:
            self.render_status.set_text("no clips to render"); return
        ui.save_file(self.parent, "render to MP4",
                     "nyxus-video.mp4", self._do_render)

    def _do_render(self, path: str):
        if not path.lower().endswith(".mp4"):
            path += ".mp4"
        self.render_status.set_text("rendering — please wait…")

        def worker():
            ok = video_engine.render_timeline(
                self.tl, path,
                on_log=lambda m: GLib.idle_add(self.render_status.set_text, m),
            )
            GLib.idle_add(self.render_status.set_text,
                          f"saved · {path}" if ok else "render failed (need ffmpeg)")
            GLib.idle_add(self.parent._set_status,
                          f"saved · {path}" if ok else "render failed")

        threading.Thread(target=worker, daemon=True).start()

    # menu hooks
    def refresh_canvas(self): self.timeline_area.queue_draw(); self.preview.queue_draw()
    def reset_zoom(self): self.zoom_ms_per_px = 30; self.timeline_area.queue_draw()
    def show_panel(self, name): self.parent._set_status(f"panel · {name}")
    def filter(self, name): self.parent._set_status("video · filter applied at render time only")
    def adjust(self, kind, val): pass
    def layer_add(self): self._import_clip()
    def layer_del(self): self._del_clip()
    def layer_merge(self): pass
    def layer_flatten(self): pass
