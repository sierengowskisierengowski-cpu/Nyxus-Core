"""
NYXUS Studio — m03 3D
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

3D modeling viewport using GTK4 Cairo software rasterizer:
  • 8 primitives  · subdivide / extrude / bevel / inset
  • modifiers: mirror / array / solidify / subdivide / decimate / boolean
  • orbit/zoom controls (LMB drag = orbit, scroll = zoom)
  • shaded triangle render with z-sort + flat normals
  • export OBJ / STL / PLY / GLTF
"""
from __future__ import annotations

import math

import gi

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk    # noqa: E402
import cairo

try:
    import numpy as np
except Exception:
    np = None

from studio import ui, three_d_engine as t3d


def build(doc, parent_window):
    mod = ThreeDModule(doc, parent_window)
    return mod.widget, mod


class ThreeDModule:
    def __init__(self, doc, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.scene: list[dict] = []        # {v, f, name, color, selected}
        self.selected: int | None = None
        self.yaw = math.radians(28)
        self.pitch = math.radians(-22)
        self.dist = 5.0
        self.shading = "flat"
        self.show_wires = True
        self.color_default = ui.NYX["blue"]
        self._drag_start: tuple[float, float] | None = None
        self.add("cube")     # default

        # ── viewport
        self.canvas = Gtk.DrawingArea()
        self.canvas.set_hexpand(True); self.canvas.set_vexpand(True)
        self.canvas.set_draw_func(self._draw)

        gd = Gtk.GestureDrag()
        gd.connect("drag-begin",  self._down)
        gd.connect("drag-update", self._move)
        gd.connect("drag-end",    self._up)
        self.canvas.add_controller(gd)

        sc = Gtk.EventControllerScroll(flags=Gtk.EventControllerScrollFlags.VERTICAL)
        sc.connect("scroll", self._scroll)
        self.canvas.add_controller(sc)

        # ── primitives
        self.prim_panel = ui.Panel("add", ui.NYX["blue"])
        for label, color, key in [
            ("cube",     ui.NYX["pink"],   "cube"),
            ("sphere",   ui.NYX["blue"],   "sphere"),
            ("cylinder", ui.NYX["green"],  "cylinder"),
            ("cone",     ui.NYX["gold"],   "cone"),
            ("torus",    ui.NYX["purple"], "torus"),
            ("plane",    ui.NYX["cyan"],   "plane"),
            ("icosphere",ui.NYX["orange"], "icosphere"),
            ("monkey",   ui.NYX["red"],    "monkey"),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _k=key: self.add(_k))
            self.prim_panel.body.append(b)

        # ── transform
        self.transform_panel = ui.Panel("transform", ui.NYX["green"])
        self.s_yaw = ui.SketchSlider("yaw °", -180, 180, math.degrees(self.yaw),
                                      color=ui.NYX["pink"], step=1,
                                      on_change=lambda v: self._set_view(yaw=math.radians(v)))
        self.s_pitch = ui.SketchSlider("pitch °", -85, 85, math.degrees(self.pitch),
                                        color=ui.NYX["blue"], step=1,
                                        on_change=lambda v: self._set_view(pitch=math.radians(v)))
        self.s_dist = ui.SketchSlider("dist", 1.0, 30, self.dist,
                                       color=ui.NYX["green"],
                                       on_change=lambda v: self._set_view(dist=float(v)))
        for w in (self.s_yaw, self.s_pitch, self.s_dist):
            self.transform_panel.body.append(w)

        # ── edit ops
        self.edit_panel = ui.Panel("edit", ui.NYX["purple"])
        for label, color, fn in [
            ("subdivide",       ui.NYX["pink"],   lambda: self._op("subdivide")),
            ("extrude faces",   ui.NYX["green"],  lambda: self._op("extrude")),
            ("bevel edges",     ui.NYX["blue"],   lambda: self._op("bevel")),
            ("inset faces",     ui.NYX["gold"],   lambda: self._op("inset")),
            ("merge close",     ui.NYX["cyan"],   lambda: self._op("merge")),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.edit_panel.body.append(b)

        # ── modifiers
        self.mod_panel = ui.Panel("modifiers", ui.NYX["gold"])
        for label, color, fn in [
            ("mirror X",   ui.NYX["pink"],   lambda: self._mod("mirror", 0)),
            ("mirror Y",   ui.NYX["blue"],   lambda: self._mod("mirror", 1)),
            ("mirror Z",   ui.NYX["green"],  lambda: self._mod("mirror", 2)),
            ("array x3",   ui.NYX["purple"], lambda: self._mod("array", 3)),
            ("solidify",   ui.NYX["gold"],   lambda: self._mod("solidify", 0.05)),
            ("subdiv x1",  ui.NYX["cyan"],   lambda: self._mod("subdivide", 1)),
            ("decimate",   ui.NYX["orange"], lambda: self._mod("decimate", 0.5)),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.mod_panel.body.append(b)

        # ── boolean
        self.bool_panel = ui.Panel("boolean", ui.NYX["red"])
        for label, color, op in [
            ("union",       ui.NYX["green"],  "union"),
            ("difference",  ui.NYX["pink"],   "difference"),
            ("intersection",ui.NYX["blue"],   "intersection"),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _op=op: self._boolean(_op))
            self.bool_panel.body.append(b)

        # ── render / view options
        self.view_panel = ui.Panel("view", ui.NYX["cyan"])
        for label, color, fn in [
            ("flat shade",  ui.NYX["pink"],  lambda: setattr(self, "shading", "flat") or self.canvas.queue_draw()),
            ("smooth shade", ui.NYX["blue"], lambda: setattr(self, "shading", "smooth") or self.canvas.queue_draw()),
            ("toggle wires",  ui.NYX["gold"], self._toggle_wires),
            ("delete object", ui.NYX["red"],  self._delete_selected),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.view_panel.body.append(b)

        # ── scene + export
        self.scene_panel = ui.Panel("scene", ui.NYX["orange"])
        self.scene_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.scene_panel.body.append(self.scene_box)

        self.exp_panel = ui.Panel("export", ui.NYX["pink"])
        for label, color, fmt in [
            ("OBJ",  ui.NYX["pink"],   "obj"),
            ("STL",  ui.NYX["blue"],   "stl"),
            ("PLY",  ui.NYX["green"],  "ply"),
            ("GLTF", ui.NYX["gold"],   "gltf"),
        ]:
            b = ui.SketchButton(f"export {label}", color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _f=fmt: self._export(_f))
            self.exp_panel.body.append(b)

        # ── compose
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(196, -1)
        left.append(ui.TiltedHeader("3D", ui.NYX["blue"]))
        left.append(self.prim_panel); left.append(self.transform_panel); left.append(self.view_panel)

        center = Gtk.ScrolledWindow()
        center.set_hexpand(True); center.set_vexpand(True)
        center.set_child(self.canvas)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(220, -1)
        right.append(self.scene_panel); right.append(self.edit_panel)
        right.append(self.mod_panel); right.append(self.bool_panel); right.append(self.exp_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

        self._refresh_scene_box()

    # ── scene management ──
    def add(self, kind: str):
        funcs = {
            "cube":     lambda: t3d.primitive_cube(1.5),
            "sphere":   lambda: t3d.primitive_sphere(1.0),
            "cylinder": lambda: t3d.primitive_cylinder(0.7, 1.6),
            "cone":     lambda: t3d.primitive_cone(0.8, 1.6),
            "torus":    lambda: t3d.primitive_torus(1.0, 0.3),
            "plane":    lambda: t3d.primitive_plane(2.5),
            "icosphere":lambda: t3d.primitive_icosphere(1.0, subdivisions=2),
            "monkey":   lambda: t3d.primitive_monkey(),
        }
        fn = funcs.get(kind)
        if fn is None or np is None:
            self.parent._set_status("3D needs numpy"); return
        v, f = fn()
        if v is None:
            return
        # offset multiple objects on X
        offset = np.array([2.5 * len(self.scene), 0, 0], dtype=np.float32)
        v = (v + offset).astype(np.float32)
        idx = len(self.scene)
        self.scene.append({"name": f"{kind}_{idx + 1}", "v": v, "f": f,
                            "color": self.color_default})
        self.selected = idx
        self._refresh_scene_box(); self.canvas.queue_draw()

    def _selected_obj(self) -> dict | None:
        if self.selected is None or self.selected >= len(self.scene):
            return None
        return self.scene[self.selected]

    def _refresh_scene_box(self):
        child = self.scene_box.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self.scene_box.remove(child); child = nxt
        for i, o in enumerate(self.scene):
            color = ui.NYX["gold"] if i == self.selected else ui.NYX["ink_dim"]
            label = f"{o['name']}  ·  {len(o['f'])} tris"
            b = ui.SketchButton(label, color, height=24, font_size=14)
            b.connect("clicked", lambda *_a, _i=i: self._select(_i))
            self.scene_box.append(b)

    def _select(self, i: int):
        self.selected = i
        self._refresh_scene_box(); self.canvas.queue_draw()

    def _delete_selected(self):
        if self.selected is None:
            return
        self.scene.pop(self.selected)
        self.selected = max(0, self.selected - 1) if self.scene else None
        self._refresh_scene_box(); self.canvas.queue_draw()

    def _toggle_wires(self):
        self.show_wires = not self.show_wires
        self.canvas.queue_draw()

    # ── view ──
    def _set_view(self, yaw=None, pitch=None, dist=None):
        if yaw is not None:
            self.yaw = yaw
        if pitch is not None:
            self.pitch = max(math.radians(-89), min(math.radians(89), pitch))
        if dist is not None:
            self.dist = max(1.0, dist)
        self.canvas.queue_draw()

    def _down(self, _g, x, y):
        self._drag_start = (self.yaw, self.pitch)

    def _move(self, g, dx, dy):
        if self._drag_start is None:
            return
        y0, p0 = self._drag_start
        self.yaw = y0 - dx * 0.01
        self.pitch = max(math.radians(-89), min(math.radians(89), p0 - dy * 0.01))
        # update sliders
        self.s_yaw.value = math.degrees(self.yaw)
        self.s_pitch.value = math.degrees(self.pitch)
        self.s_yaw.title.set_text(f"yaw °  {int(self.s_yaw.value)}")
        self.s_pitch.title.set_text(f"pitch °  {int(self.s_pitch.value)}")
        self.s_yaw.area.queue_draw(); self.s_pitch.area.queue_draw()
        self.canvas.queue_draw()

    def _up(self, *_):
        self._drag_start = None

    def _scroll(self, _ec, _dx, dy):
        self.dist = max(1.0, min(50.0, self.dist + dy * 0.5))
        self.s_dist.value = self.dist
        self.s_dist.title.set_text(f"dist  {self.dist:.2f}")
        self.s_dist.area.queue_draw()
        self.canvas.queue_draw()
        return True

    # ── ops on selected mesh ──
    def _op(self, name: str):
        o = self._selected_obj()
        if o is None or np is None:
            return
        v, f = o["v"], o["f"]
        if name == "subdivide":
            v, f = t3d.subdivide_loop(v, f)
        elif name == "extrude":
            faces = list(range(0, len(f), max(1, len(f) // 6)))
            v, f = t3d.extrude_faces(v, f, faces, distance=0.2)
        elif name == "bevel":
            v, f = t3d.bevel_edges(v, f, amount=0.08)
        elif name == "inset":
            faces = list(range(0, len(f), max(1, len(f) // 8)))
            v, f = t3d.inset_faces(v, f, faces, amount=0.15)
        elif name == "merge":
            v, f = t3d.merge_close_vertices(v, f)
        o["v"] = v; o["f"] = f
        self._refresh_scene_box(); self.canvas.queue_draw()

    def _mod(self, name: str, arg):
        o = self._selected_obj()
        if o is None:
            return
        v, f = o["v"], o["f"]
        if name == "mirror":
            v, f = t3d.mod_mirror(v, f, axis=int(arg))
        elif name == "array":
            v, f = t3d.mod_array(v, f, count=int(arg), offset=(2.2, 0, 0))
        elif name == "solidify":
            v, f = t3d.mod_solidify(v, f, thickness=float(arg))
        elif name == "subdivide":
            v, f = t3d.mod_subdivide(v, f, levels=int(arg))
        elif name == "decimate":
            v, f = t3d.mod_decimate(v, f, ratio=float(arg))
        o["v"] = v; o["f"] = f
        self._refresh_scene_box(); self.canvas.queue_draw()

    def _boolean(self, op: str):
        if self.selected is None or len(self.scene) < 2:
            return
        a = self.scene[self.selected]
        # operate against the next object
        b = self.scene[(self.selected + 1) % len(self.scene)]
        v, f = t3d.mod_boolean(a["v"], a["f"], b["v"], b["f"], op=op)
        a["v"], a["f"] = v, f
        self.scene.remove(b)
        if self.selected >= len(self.scene):
            self.selected = len(self.scene) - 1
        self._refresh_scene_box(); self.canvas.queue_draw()
        self.parent._set_status(f"boolean · {op}")

    # ── export ──
    def _export(self, fmt: str):
        o = self._selected_obj()
        if o is None:
            self.parent._set_status("no object selected"); return
        ui.save_file(self.parent, f"export {fmt.upper()}",
                     f"nyxus-mesh.{fmt}",
                     lambda p, _f=fmt, _o=o: self._do_export(p, _f, _o))

    def _do_export(self, path: str, fmt: str, o: dict):
        ext = "." + fmt
        if not path.lower().endswith(ext):
            path += ext
        ok = False
        if fmt == "obj":
            ok = t3d.export_obj(path, o["v"], o["f"], name=o["name"])
        elif fmt == "stl":
            ok = t3d.export_stl(path, o["v"], o["f"])
        elif fmt == "ply":
            ok = t3d.export_ply(path, o["v"], o["f"])
        elif fmt == "gltf":
            ok = t3d.export_gltf(path, o["v"], o["f"])
        self.parent._set_status(f"saved · {path}" if ok else f"{fmt} export failed (need trimesh?)")

    # ── rendering (software cairo z-sorted) ──
    def _project(self, vertices, w: int, h: int):
        if np is None:
            return None
        view = t3d.view_matrix(self.yaw, self.pitch, self.dist)
        proj = t3d.projection_matrix(45, w / max(1, h))
        mvp = proj @ view
        ones = np.ones((vertices.shape[0], 1), dtype=np.float32)
        h_v = np.concatenate([vertices, ones], axis=1)
        clip = (mvp @ h_v.T).T
        w_ = clip[:, 3:4].copy()
        w_[w_ == 0] = 1e-6
        ndc = clip[:, :3] / w_
        sx = (ndc[:, 0] * 0.5 + 0.5) * w
        sy = (1 - (ndc[:, 1] * 0.5 + 0.5)) * h
        return np.stack([sx, sy, ndc[:, 2]], axis=1).astype(np.float32)

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0.03, 0.03, 0.05, 1.0); cr.paint()
        # grid (XZ plane)
        if np is not None:
            grid_v = []
            for x in range(-5, 6):
                grid_v.append([x, 0, -5]); grid_v.append([x, 0, 5])
                grid_v.append([-5, 0, x]); grid_v.append([5, 0, x])
            grid = self._project(np.array(grid_v, dtype=np.float32), w, h)
            cr.set_source_rgba(0.18, 0.18, 0.28, 0.9); cr.set_line_width(1)
            for i in range(0, len(grid), 2):
                cr.move_to(grid[i, 0], grid[i, 1])
                cr.line_to(grid[i + 1, 0], grid[i + 1, 1])
            cr.stroke()

        # gather all triangles with depth
        all_tris = []
        for idx, o in enumerate(self.scene):
            if np is None:
                continue
            v = o["v"]; f = o["f"]; color = o["color"]
            proj = self._project(v, w, h)
            if proj is None:
                continue
            normals = t3d.face_normals(v, f)
            # light direction (camera-ish)
            light = np.array([0.4, 0.8, 0.3], dtype=np.float32)
            light = light / (np.linalg.norm(light) + 1e-9)
            for ti, tri in enumerate(f):
                p0 = proj[tri[0]]; p1 = proj[tri[1]]; p2 = proj[tri[2]]
                z = (p0[2] + p1[2] + p2[2]) / 3.0
                # back-face cull via screen winding
                area2 = (p1[0] - p0[0]) * (p2[1] - p0[1]) - (p2[0] - p0[0]) * (p1[1] - p0[1])
                if area2 <= 0:
                    continue
                shade = max(0.10, float(np.dot(normals[ti], light)))
                col = (color[0] * (0.20 + 0.80 * shade),
                        color[1] * (0.20 + 0.80 * shade),
                        color[2] * (0.20 + 0.80 * shade))
                all_tris.append((z, p0, p1, p2, col, idx == self.selected))
        all_tris.sort(key=lambda t: -t[0])

        for z, p0, p1, p2, col, sel in all_tris:
            cr.set_source_rgba(col[0], col[1], col[2], 1.0)
            cr.move_to(p0[0], p0[1]); cr.line_to(p1[0], p1[1])
            cr.line_to(p2[0], p2[1]); cr.close_path(); cr.fill()
            if self.show_wires:
                cr.set_source_rgba(0.05, 0.05, 0.10, 0.55)
                cr.set_line_width(0.6)
                cr.move_to(p0[0], p0[1]); cr.line_to(p1[0], p1[1])
                cr.line_to(p2[0], p2[1]); cr.close_path(); cr.stroke()
            if sel:
                cr.set_source_rgba(*ui.NYX["gold"], 0.45)
                cr.set_line_width(0.8)
                cr.move_to(p0[0], p0[1]); cr.line_to(p1[0], p1[1])
                cr.line_to(p2[0], p2[1]); cr.close_path(); cr.stroke()

        # axis gizmo
        if np is not None:
            gz = self._project(np.array([
                [0, 0, 0], [1, 0, 0],
                [0, 0, 0], [0, 1, 0],
                [0, 0, 0], [0, 0, 1],
            ], dtype=np.float32) * 0.6, w, h)
            for i, color in enumerate((ui.NYX["pink"], ui.NYX["green"], ui.NYX["blue"])):
                cr.set_source_rgba(*color, 1.0); cr.set_line_width(2.5)
                cr.move_to(gz[i * 2, 0], gz[i * 2, 1])
                cr.line_to(gz[i * 2 + 1, 0], gz[i * 2 + 1, 1]); cr.stroke()

        # frame
        ui.sketch_rect(cr, 6, 6, w - 12, h - 12, ui.NYX["blue"] + (0.85,), 2.2)
        cr.select_font_face("Caveat", 0, 1); cr.set_font_size(15)
        cr.set_source_rgba(*ui.NYX["ink_dim"], 1.0)
        cr.move_to(14, 22)
        cr.show_text(f"3D · {len(self.scene)} obj · {sum(len(o['f']) for o in self.scene)} tris")

    # ── menu hooks ──
    def refresh_canvas(self): self.canvas.queue_draw()
    def reset_zoom(self): self.dist = 5.0; self.canvas.queue_draw()
    def show_panel(self, name): self.parent._set_status(f"panel · {name}")
    def filter(self, name): self.parent._set_status("3D · raster filters not applicable")
    def adjust(self, kind, val): pass
    def layer_add(self): self.add("cube")
    def layer_del(self): self._delete_selected()
    def layer_merge(self): pass
    def layer_flatten(self): pass
