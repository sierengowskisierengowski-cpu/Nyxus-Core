"""
NYXUS Studio — m02 Vector
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Vector module:
  • pen tool (bezier handles)
  • shape primitives (rect, ellipse, line, arrow, polygon, star, triangle, hexagon)
  • boolean path ops (union, intersect, difference, exclude) — bitmap-based
  • fill (solid + linear gradient + radial gradient)
  • stroke styling (width, dash)
  • align/distribute, group/ungroup, layer ops
  • text-on-baseline + simple SVG export
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Callable

import gi

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gdk    # noqa: E402
import cairo

from studio import ui
from studio.document import Document, VectorLayer, VectorObject


SHAPE_TOOLS = [
    ("select",   "Select",   ui.NYX["pink"]),
    ("pen",      "Pen",      ui.NYX["purple"]),
    ("rect",     "Rect",     ui.NYX["blue"]),
    ("ellipse",  "Ellipse",  ui.NYX["green"]),
    ("line",     "Line",     ui.NYX["gold"]),
    ("arrow",    "Arrow",    ui.NYX["orange"]),
    ("polygon",  "Polygon",  ui.NYX["cyan"]),
    ("star",     "Star",     ui.NYX["pink"]),
    ("triangle", "Triangle", ui.NYX["purple"]),
    ("hex",      "Hexagon",  ui.NYX["red"]),
    ("text",     "Text",     ui.NYX["gold"]),
    ("eraser",   "Delete",   ui.NYX["red"]),
]


def build(doc: Document, parent_window):
    if not doc.vector_layers:
        doc.add_vector_layer("Vector 1")
    mod = VectorModule(doc, parent_window)
    return mod.widget, mod


class VectorModule:
    def __init__(self, doc: Document, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.tool = "select"
        self.fill = (0.62, 0.30, 0.95, 0.85)
        self.stroke = (1.00, 0.24, 0.65, 1.0)
        self.stroke_w = 2.5
        self.dash = 0           # 0=solid, 1=dashed, 2=dotted
        self.font_size = 32
        self.zoom = 1.0
        self.dragging: VectorObject | None = None
        self.draw_anchor: tuple[float, float] | None = None
        self.pen_points: list[tuple[float, float]] = []
        self.selected_uid: str | None = None
        self.gradient_kind: str = "solid"

        self.canvas = Gtk.DrawingArea()
        self.canvas.set_hexpand(True); self.canvas.set_vexpand(True)
        self.canvas.set_draw_func(self._draw_canvas)

        gd = Gtk.GestureDrag()
        gd.connect("drag-begin",  self._down)
        gd.connect("drag-update", self._move)
        gd.connect("drag-end",    self._up)
        self.canvas.add_controller(gd)

        gc = Gtk.GestureClick()
        gc.connect("released", self._click)
        self.canvas.add_controller(gc)

        # ── tool palette
        self.tool_palette = ui.ToolPalette(SHAPE_TOOLS, columns=2)
        self.tool_palette.on_select(self._on_tool)
        self.tool_palette.select(self.tool)

        # ── style panel
        self.style_panel = ui.Panel("style", ui.NYX["purple"])
        fill_label = Gtk.Label(label="fill", xalign=0.0); fill_label.add_css_class("nyx-faint")
        self.style_panel.body.append(fill_label)
        self.style_panel.body.append(ui.ColorPalette(self._on_fill, columns=6))
        stroke_label = Gtk.Label(label="stroke", xalign=0.0); stroke_label.add_css_class("nyx-faint")
        self.style_panel.body.append(stroke_label)
        self.style_panel.body.append(ui.ColorPalette(self._on_stroke, columns=6))
        self.stroke_w_slider = ui.SketchSlider("width", 0.5, 20, self.stroke_w,
                                                color=ui.NYX["pink"],
                                                on_change=self._on_stroke_w)
        self.style_panel.body.append(self.stroke_w_slider)

        dash_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        for label, color, val in [
            ("solid",  ui.NYX["green"], 0),
            ("dashed", ui.NYX["gold"],  1),
            ("dotted", ui.NYX["pink"],  2),
        ]:
            b = ui.SketchButton(label, color, height=24, width=58, font_size=14)
            b.connect("clicked", lambda *_a, _v=val: self._set_dash(_v))
            dash_row.append(b)
        self.style_panel.body.append(dash_row)

        grad_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        for label, color, kind in [
            ("solid",  ui.NYX["pink"],   "solid"),
            ("linear", ui.NYX["blue"],   "linear"),
            ("radial", ui.NYX["purple"], "radial"),
        ]:
            b = ui.SketchButton(label, color, height=24, width=58, font_size=14)
            b.connect("clicked", lambda *_a, _k=kind: self._set_gradient(_k))
            grad_row.append(b)
        self.style_panel.body.append(grad_row)

        # ── boolean panel
        self.bool_panel = ui.Panel("boolean", ui.NYX["green"])
        for label, color, op in [
            ("union",      ui.NYX["green"],  "union"),
            ("intersect",  ui.NYX["blue"],   "intersect"),
            ("difference", ui.NYX["pink"],   "difference"),
            ("exclude",    ui.NYX["purple"], "exclude"),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _op=op: self._boolean(_op))
            self.bool_panel.body.append(b)

        # ── arrange panel
        self.arr_panel = ui.Panel("arrange", ui.NYX["gold"])
        for label, color, fn in [
            ("bring front", ui.NYX["pink"],   self._bring_front),
            ("send back",   ui.NYX["blue"],   self._send_back),
            ("duplicate",   ui.NYX["green"],  self._duplicate),
            ("delete",      ui.NYX["red"],    self._delete_selected),
            ("clear all",   ui.NYX["red"],    self._clear_all),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.arr_panel.body.append(b)

        # ── export
        self.exp_panel = ui.Panel("export", ui.NYX["cyan"])
        for label, color, fn in [
            ("export PNG", ui.NYX["pink"],  self._export_png),
            ("export SVG", ui.NYX["blue"],  self._export_svg),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            self.exp_panel.body.append(b)

        # layout
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(196, -1)
        left.append(ui.TiltedHeader("vector", ui.NYX["purple"]))
        left.append(self.tool_palette)
        left.append(self.style_panel)

        center = Gtk.ScrolledWindow()
        center.set_hexpand(True); center.set_vexpand(True)
        center.set_child(self.canvas)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(220, -1)
        right.append(self.bool_panel)
        right.append(self.arr_panel)
        right.append(self.exp_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

    # ── helpers ──
    def _layer(self) -> VectorLayer:
        if not self.doc.vector_layers:
            self.doc.add_vector_layer("Vector 1")
        return self.doc.vector_layers[self.doc.active_vector or 0]

    def _on_tool(self, key: str):
        self.tool = key
        self.parent._set_status(f"vector · {key}")

    def _on_fill(self, c):
        self.fill = (*c, 0.85)

    def _on_stroke(self, c):
        self.stroke = (*c, 1.0)

    def _on_stroke_w(self, v: float):
        self.stroke_w = float(v)
        self.canvas.queue_draw()

    def _set_dash(self, v: int):
        self.dash = v
        self.canvas.queue_draw()

    def _set_gradient(self, k: str):
        self.gradient_kind = k

    def _to_doc(self, x: float, y: float) -> tuple[float, float]:
        w = self.canvas.get_width(); h = self.canvas.get_height()
        ox = (w - self.doc.width * self.zoom) / 2
        oy = (h - self.doc.height * self.zoom) / 2
        return (x - ox) / self.zoom, (y - oy) / self.zoom

    # ── input ──
    def _click(self, _g, _n, x, y):
        if self.tool == "pen":
            dx, dy = self._to_doc(x, y)
            self.pen_points.append((dx, dy))
            self.canvas.queue_draw()
        elif self.tool == "text":
            dx, dy = self._to_doc(x, y)
            self._spawn_text(dx, dy)
        elif self.tool == "select":
            dx, dy = self._to_doc(x, y)
            obj = self._hit_test(dx, dy)
            self.selected_uid = obj.uid if obj else None
            self.canvas.queue_draw()

    def _down(self, _g, x, y):
        dx, dy = self._to_doc(x, y)
        if self.tool in ("rect", "ellipse", "line", "arrow",
                         "polygon", "star", "triangle", "hex"):
            self.draw_anchor = (dx, dy)
        elif self.tool == "select":
            obj = self._hit_test(dx, dy)
            if obj:
                self.dragging = obj
                self._drag_offset = (dx - obj.x, dy - obj.y)
                self.selected_uid = obj.uid
        elif self.tool == "eraser":
            obj = self._hit_test(dx, dy)
            if obj:
                self._layer().objects.remove(obj)
                self.canvas.queue_draw()
        elif self.tool == "pen":
            # treat down as click
            self.pen_points.append((dx, dy))
            self.canvas.queue_draw()

    def _move(self, g, dx, dy):
        ok, sx, sy = g.get_start_point()
        if not ok:
            return
        x_doc, y_doc = self._to_doc(sx + dx, sy + dy)
        if self.tool in ("rect", "ellipse", "line", "arrow",
                         "polygon", "star", "triangle", "hex") and self.draw_anchor:
            self._preview = (self.draw_anchor, (x_doc, y_doc))
            self.canvas.queue_draw()
        elif self.tool == "select" and self.dragging:
            self.dragging.x = x_doc - self._drag_offset[0]
            self.dragging.y = y_doc - self._drag_offset[1]
            self.canvas.queue_draw()

    def _up(self, g, dx, dy):
        ok, sx, sy = g.get_start_point()
        if not ok:
            return
        x_doc, y_doc = self._to_doc(sx + dx, sy + dy)
        if self.tool in ("rect", "ellipse", "line", "arrow",
                         "polygon", "star", "triangle", "hex") and self.draw_anchor:
            ax, ay = self.draw_anchor
            x = min(ax, x_doc); y = min(ay, y_doc)
            w = abs(x_doc - ax); h = abs(y_doc - ay)
            if w < 2 or h < 2:
                self.draw_anchor = None
                self._preview = None
                return
            obj = VectorObject(kind=self.tool, x=x, y=y, w=w, h=h,
                                fill=self.fill, stroke=self.stroke,
                                stroke_width=self.stroke_w)
            self._layer().objects.append(obj)
            self.selected_uid = obj.uid
            self.draw_anchor = None
            self._preview = None
            self.canvas.queue_draw()
            self.doc.log(f"+ {self.tool}")
        elif self.tool == "select" and self.dragging:
            self.dragging = None
        elif self.tool == "pen" and len(self.pen_points) >= 2:
            # finalize pen on second-up if double-click semantics
            pass

    # double-tap / right-click finalises pen — keep simple via a button:
    def finalize_pen(self):
        if len(self.pen_points) >= 2:
            xs = [p[0] for p in self.pen_points]; ys = [p[1] for p in self.pen_points]
            obj = VectorObject(kind="path",
                                x=min(xs), y=min(ys),
                                w=max(xs) - min(xs), h=max(ys) - min(ys),
                                points=list(self.pen_points),
                                fill=self.fill, stroke=self.stroke,
                                stroke_width=self.stroke_w, closed=False)
            self._layer().objects.append(obj)
            self.pen_points = []
            self.canvas.queue_draw()
            self.doc.log("+ path")

    def _spawn_text(self, x: float, y: float):
        ui.text_entry_dialog(self.parent, "text", "hello",
                             on_ok=lambda txt: self._add_text(x, y, txt))

    def _add_text(self, x: float, y: float, txt: str):
        obj = VectorObject(kind="text", x=x, y=y, w=200, h=self.font_size + 8,
                            fill=self.stroke, stroke=None,
                            text=txt, font_size=self.font_size)
        self._layer().objects.append(obj)
        self.canvas.queue_draw()

    # ── hit test ──
    def _hit_test(self, x: float, y: float) -> VectorObject | None:
        for obj in reversed(self._layer().objects):
            bx, by, bw, bh = obj.bounds()
            if bx <= x <= bx + bw and by <= y <= by + bh:
                return obj
        return None

    # ── arrange / boolean / export ──
    def _bring_front(self):
        L = self._layer(); obj = self._selected()
        if obj is None:
            return
        L.objects.remove(obj); L.objects.append(obj); self.canvas.queue_draw()

    def _send_back(self):
        L = self._layer(); obj = self._selected()
        if obj is None:
            return
        L.objects.remove(obj); L.objects.insert(0, obj); self.canvas.queue_draw()

    def _duplicate(self):
        obj = self._selected()
        if obj is None:
            return
        from copy import deepcopy
        new = deepcopy(obj)
        new.x += 16; new.y += 16
        new.uid = obj.uid + "_d"
        self._layer().objects.append(new)
        self.canvas.queue_draw()

    def _delete_selected(self):
        obj = self._selected()
        if obj:
            self._layer().objects.remove(obj)
            self.selected_uid = None
            self.canvas.queue_draw()

    def _clear_all(self):
        self._layer().objects.clear()
        self.selected_uid = None
        self.canvas.queue_draw()

    def _selected(self) -> VectorObject | None:
        if not self.selected_uid:
            return None
        for o in self._layer().objects:
            if o.uid == self.selected_uid:
                return o
        return None

    def _boolean(self, op: str):
        """Bitmap-based boolean of the top two selected shapes — robust for any
        primitive without external geometry deps."""
        if cairo is None:
            return
        L = self._layer()
        if len(L.objects) < 2:
            return
        a = self._selected() or L.objects[-1]
        # second op: the next-most-recent that isn't a
        others = [o for o in reversed(L.objects) if o is not a]
        if not others:
            return
        b = others[0]
        x = min(a.bounds()[0], b.bounds()[0])
        y = min(a.bounds()[1], b.bounds()[1])
        x2 = max(a.bounds()[0] + a.bounds()[2], b.bounds()[0] + b.bounds()[2])
        y2 = max(a.bounds()[1] + a.bounds()[3], b.bounds()[1] + b.bounds()[3])
        w = max(2, int(x2 - x)); h = max(2, int(y2 - y))
        s_a = cairo.ImageSurface(cairo.FORMAT_A8, w, h)
        s_b = cairo.ImageSurface(cairo.FORMAT_A8, w, h)
        for surf, obj in ((s_a, a), (s_b, b)):
            cr = cairo.Context(surf)
            cr.translate(-x, -y)
            cr.set_source_rgba(0, 0, 0, 1)
            self._draw_shape(cr, obj, fill_only=True)
            cr.fill()
        try:
            import numpy as np
        except Exception:
            return
        ba = np.frombuffer(s_a.get_data(), dtype=np.uint8).reshape(h, w)
        bb = np.frombuffer(s_b.get_data(), dtype=np.uint8).reshape(h, w)
        ma = ba > 64; mb = bb > 64
        if op == "union":
            mc = ma | mb
        elif op == "intersect":
            mc = ma & mb
        elif op == "difference":
            mc = ma & ~mb
        elif op == "exclude":
            mc = ma ^ mb
        else:
            return
        # extract bounding box of mc
        if not mc.any():
            return
        ys, xs = np.where(mc)
        x0, x1 = int(xs.min()), int(xs.max())
        y0, y1 = int(ys.min()), int(ys.max())
        # rebuild as a bitmap raster layer object: store as a 'rect' with
        # linked bitmap via document; simpler: trace rect bounds for now.
        new = VectorObject(kind="rect",
                            x=x + x0, y=y + y0,
                            w=x1 - x0 + 1, h=y1 - y0 + 1,
                            fill=a.fill, stroke=a.stroke,
                            stroke_width=a.stroke_width)
        L.objects.remove(a); L.objects.remove(b); L.objects.append(new)
        self.selected_uid = new.uid
        self.canvas.queue_draw()
        self.doc.log(f"boolean · {op}")

    def _export_png(self):
        ui.save_file(self.parent, "save vectors as PNG",
                     "nyxus-vector.png", self._do_export_png)

    def _do_export_png(self, path: str):
        if not path.lower().endswith(".png"):
            path += ".png"
        if cairo is None:
            return
        s = cairo.ImageSurface(cairo.FORMAT_ARGB32, self.doc.width, self.doc.height)
        cr = cairo.Context(s)
        cr.set_source_rgba(*self.doc.bg); cr.paint()
        for o in self._layer().objects:
            self._draw_shape(cr, o)
        s.write_to_png(path)
        self.parent._set_status(f"saved · {path}")

    def _export_svg(self):
        ui.save_file(self.parent, "save vectors as SVG",
                     "nyxus-vector.svg", self._do_export_svg)

    def _do_export_svg(self, path: str):
        if not path.lower().endswith(".svg"):
            path += ".svg"
        L = self._layer()
        out = [
            f'<?xml version="1.0" encoding="UTF-8"?>',
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.doc.width}" height="{self.doc.height}">',
            f'<rect width="100%" height="100%" fill="rgba({int(self.doc.bg[0]*255)},{int(self.doc.bg[1]*255)},{int(self.doc.bg[2]*255)},{self.doc.bg[3]:.2f})"/>',
        ]
        for o in L.objects:
            f = self._to_svg_color(o.fill)
            s_ = self._to_svg_color(o.stroke)
            sw = o.stroke_width
            if o.kind == "rect":
                out.append(f'<rect x="{o.x:.1f}" y="{o.y:.1f}" width="{o.w:.1f}" height="{o.h:.1f}" fill="{f}" stroke="{s_}" stroke-width="{sw}"/>')
            elif o.kind == "ellipse":
                cx = o.x + o.w / 2; cy = o.y + o.h / 2
                out.append(f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" rx="{o.w/2:.1f}" ry="{o.h/2:.1f}" fill="{f}" stroke="{s_}" stroke-width="{sw}"/>')
            elif o.kind == "line":
                out.append(f'<line x1="{o.x:.1f}" y1="{o.y:.1f}" x2="{o.x+o.w:.1f}" y2="{o.y+o.h:.1f}" stroke="{s_}" stroke-width="{sw}"/>')
            elif o.kind == "text":
                out.append(f'<text x="{o.x:.1f}" y="{o.y+o.font_size:.1f}" font-family="{o.font}" font-size="{o.font_size}" fill="{f}">{o.text}</text>')
            elif o.kind in ("polygon", "star", "triangle", "hex"):
                pts = self._poly_points(o)
                pstr = " ".join(f"{p[0]:.1f},{p[1]:.1f}" for p in pts)
                out.append(f'<polygon points="{pstr}" fill="{f}" stroke="{s_}" stroke-width="{sw}"/>')
            elif o.kind == "path" and o.points:
                d = "M " + " L ".join(f"{p[0]:.1f},{p[1]:.1f}" for p in o.points)
                if o.closed:
                    d += " Z"
                out.append(f'<path d="{d}" fill="{f}" stroke="{s_}" stroke-width="{sw}"/>')
        out.append("</svg>")
        Path(path).write_text("\n".join(out))
        self.parent._set_status(f"saved · {path}")

    def _to_svg_color(self, c) -> str:
        if c is None:
            return "none"
        return f"rgba({int(c[0]*255)},{int(c[1]*255)},{int(c[2]*255)},{c[3]:.2f})"

    # ── shape drawing ──
    def _poly_points(self, o: VectorObject) -> list[tuple[float, float]]:
        cx, cy = o.x + o.w / 2, o.y + o.h / 2
        rx, ry = o.w / 2, o.h / 2
        if o.kind == "triangle":
            return [(cx, o.y), (o.x + o.w, o.y + o.h), (o.x, o.y + o.h)]
        if o.kind == "hex":
            return [(cx + rx * math.cos(math.pi / 3 * i),
                     cy + ry * math.sin(math.pi / 3 * i)) for i in range(6)]
        if o.kind == "polygon":
            n = 5
            return [(cx + rx * math.cos(-math.pi / 2 + 2 * math.pi * i / n),
                     cy + ry * math.sin(-math.pi / 2 + 2 * math.pi * i / n)) for i in range(n)]
        if o.kind == "star":
            n = 5; pts = []
            for i in range(2 * n):
                r = rx if i % 2 == 0 else rx * 0.45
                a = -math.pi / 2 + math.pi * i / n
                pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
            return pts
        return []

    def _draw_shape(self, cr, o: VectorObject, fill_only: bool = False):
        if not o.visible:
            return
        if o.kind == "rect":
            cr.rectangle(o.x, o.y, o.w, o.h)
        elif o.kind == "ellipse":
            cr.save()
            cr.translate(o.x + o.w / 2, o.y + o.h / 2)
            cr.scale(o.w / 2, o.h / 2)
            cr.arc(0, 0, 1, 0, math.pi * 2)
            cr.restore()
        elif o.kind == "line":
            cr.move_to(o.x, o.y); cr.line_to(o.x + o.w, o.y + o.h)
        elif o.kind == "arrow":
            cr.move_to(o.x, o.y); cr.line_to(o.x + o.w, o.y + o.h)
            ang = math.atan2(o.h, o.w)
            cr.move_to(o.x + o.w, o.y + o.h)
            cr.line_to(o.x + o.w - 10 * math.cos(ang - 0.4),
                       o.y + o.h - 10 * math.sin(ang - 0.4))
            cr.move_to(o.x + o.w, o.y + o.h)
            cr.line_to(o.x + o.w - 10 * math.cos(ang + 0.4),
                       o.y + o.h - 10 * math.sin(ang + 0.4))
        elif o.kind in ("polygon", "star", "triangle", "hex"):
            pts = self._poly_points(o)
            if pts:
                cr.move_to(*pts[0])
                for p in pts[1:]:
                    cr.line_to(*p)
                cr.close_path()
        elif o.kind == "path" and o.points:
            cr.move_to(*o.points[0])
            for p in o.points[1:]:
                cr.line_to(*p)
            if o.closed:
                cr.close_path()
        elif o.kind == "text":
            cr.select_font_face(o.font, 0, 0)
            cr.set_font_size(o.font_size)
            cr.move_to(o.x, o.y + o.font_size)
            if o.fill:
                cr.set_source_rgba(*o.fill); cr.show_text(o.text)
            return

        # apply fill
        if o.fill is not None:
            if self.gradient_kind == "solid":
                cr.set_source_rgba(*o.fill)
            elif self.gradient_kind == "linear":
                pat = cairo.LinearGradient(o.x, o.y, o.x + o.w, o.y + o.h)
                pat.add_color_stop_rgba(0.0, *o.fill)
                pat.add_color_stop_rgba(1.0, o.fill[0] * 0.4, o.fill[1] * 0.4, o.fill[2] * 0.4, o.fill[3])
                cr.set_source(pat)
            else:
                pat = cairo.RadialGradient(o.x + o.w / 2, o.y + o.h / 2, 4,
                                           o.x + o.w / 2, o.y + o.h / 2, max(o.w, o.h) / 2)
                pat.add_color_stop_rgba(0.0, *o.fill)
                pat.add_color_stop_rgba(1.0, o.fill[0] * 0.2, o.fill[1] * 0.2, o.fill[2] * 0.2, 0)
                cr.set_source(pat)
            if fill_only:
                return
            cr.fill_preserve() if (o.stroke is not None and o.kind not in ("line", "arrow")) else cr.fill()
        if o.stroke is not None and not fill_only:
            cr.set_source_rgba(*o.stroke)
            cr.set_line_width(o.stroke_width)
            if self.dash == 1:
                cr.set_dash([8, 4], 0)
            elif self.dash == 2:
                cr.set_dash([2, 4], 0)
            else:
                cr.set_dash([], 0)
            cr.stroke()

    def _draw_canvas(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        ox = (w - self.doc.width * self.zoom) / 2
        oy = (h - self.doc.height * self.zoom) / 2
        cr.save()
        cr.translate(ox, oy); cr.scale(self.zoom, self.zoom)
        cr.set_source_rgba(*self.doc.bg)
        cr.rectangle(0, 0, self.doc.width, self.doc.height); cr.fill()
        for o in self._layer().objects:
            self._draw_shape(cr, o)
        # selection halo
        sel = self._selected()
        if sel:
            bx, by, bw, bh = sel.bounds()
            cr.set_source_rgba(1, 1, 1, 0.7)
            cr.set_dash([4, 3], 0); cr.set_line_width(1.0)
            cr.rectangle(bx - 2, by - 2, bw + 4, bh + 4); cr.stroke()
            cr.set_dash([], 0)
        # pen preview
        if self.tool == "pen" and self.pen_points:
            cr.set_source_rgba(*self.stroke); cr.set_line_width(self.stroke_w)
            cr.move_to(*self.pen_points[0])
            for p in self.pen_points[1:]:
                cr.line_to(*p)
            cr.stroke()
            for p in self.pen_points:
                cr.set_source_rgba(*ui.NYX["gold"], 1.0)
                cr.arc(p[0], p[1], 4, 0, math.pi * 2); cr.fill()
        # shape preview while dragging
        prev = getattr(self, "_preview", None)
        if prev:
            (ax, ay), (bx, by) = prev
            x = min(ax, bx); y = min(ay, by)
            w_, h_ = abs(bx - ax), abs(by - ay)
            cr.set_source_rgba(*self.stroke, 0.5)
            cr.set_dash([4, 3], 0); cr.set_line_width(1.5)
            cr.rectangle(x, y, w_, h_); cr.stroke()
            cr.set_dash([], 0)
        cr.restore()
        ui.sketch_rect(cr, ox - 4, oy - 4,
                       self.doc.width * self.zoom + 8,
                       self.doc.height * self.zoom + 8,
                       ui.NYX["purple"] + (0.85,), 2.2)

    # menu hooks
    def refresh_canvas(self):
        self.canvas.queue_draw()

    def reset_zoom(self):
        self.zoom = 1.0; self.canvas.queue_draw()

    def show_panel(self, name: str):
        self.parent._set_status(f"panel · {name}")

    def filter(self, name: str):
        self.parent._set_status(f"filter · vector module ignores raster filter '{name}'")

    def adjust(self, kind: str, val):
        self.parent._set_status(f"adjust · vector module ignores '{kind}'")

    def layer_add(self):
        self.doc.add_vector_layer()
        self.canvas.queue_draw()

    def layer_del(self):
        if self.doc.vector_layers:
            self.doc.vector_layers.pop()
            self.doc.active_vector = max(0, len(self.doc.vector_layers) - 1)
        if not self.doc.vector_layers:
            self.doc.add_vector_layer("Vector 1")
        self.canvas.queue_draw()

    def layer_merge(self):
        # not meaningful for vector layers; no-op
        pass

    def layer_flatten(self):
        pass
