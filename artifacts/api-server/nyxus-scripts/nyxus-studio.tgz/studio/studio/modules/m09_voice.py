"""
NYXUS Studio — m09 Voice
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Voice-changer studio:
  • record from microphone (sounddevice)
  • load any audio file (wav/flac/mp3/ogg via ffmpeg)
  • voice presets: robot · demon · chipmunk · deep · telephone · alien
  • free pitch shift (semitones)
  • effects: reverb · delay · distortion · normalize · fade · reverse
  • waveform display
  • save WAV / MP3
"""
from __future__ import annotations

import threading

import gi

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib    # noqa: E402
import cairo

try:
    import numpy as np
except Exception:
    np = None

from studio import ui, audio_engine as ae


def build(doc, parent_window):
    mod = VoiceModule(doc, parent_window)
    return mod.widget, mod


class VoiceModule:
    def __init__(self, doc, parent_window):
        self.doc = doc
        self.parent = parent_window
        self.samples = None       # np.ndarray
        self.sr = ae.SR
        self.processed = None     # most recent processed buffer
        self.recorder: ae.Recorder | None = None
        self.is_recording = False
        self.level = 0.0
        self.semitones = 0.0
        self.last_action = "idle"

        # ── waveform area
        self.wave = Gtk.DrawingArea()
        self.wave.set_size_request(-1, 220)
        self.wave.set_draw_func(self._draw_wave)

        # ── transport buttons
        rec_panel = ui.Panel("transport", ui.NYX["pink"])
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4, homogeneous=True)
        for label, color, fn in [
            ("● record", ui.NYX["red"],   self.record),
            ("◼ stop",   ui.NYX["pink"],  self.stop),
            ("▶ play",   ui.NYX["green"], self.play),
            ("⟲ load…", ui.NYX["blue"],   self._load),
        ]:
            b = ui.SketchButton(label, color, height=32, font_size=15)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            row.append(b)
        rec_panel.body.append(row)
        # capability badges
        cap = []
        if ae.have_record(): cap.append("rec ●")
        else: cap.append("rec ✗ (no sounddevice)")
        if ae.have_play(): cap.append("play ●")
        else: cap.append("play ✗")
        if ae.have_ffmpeg(): cap.append("mp3 ●")
        else: cap.append("mp3 ✗ (no ffmpeg)")
        cap_l = Gtk.Label(label="  ·  ".join(cap), xalign=0.0)
        cap_l.add_css_class("nyx-faint")
        rec_panel.body.append(cap_l)

        # ── presets
        preset_panel = ui.Panel("voice presets", ui.NYX["purple"])
        for label, color, key in [
            ("ROBOT",     ui.NYX["pink"],   "robot"),
            ("DEMON",     ui.NYX["red"],    "demon"),
            ("CHIPMUNK",  ui.NYX["gold"],   "chipmunk"),
            ("DEEP",      ui.NYX["blue"],   "deep"),
            ("TELEPHONE", ui.NYX["cyan"],   "telephone"),
            ("ALIEN",     ui.NYX["green"],  "alien"),
        ]:
            b = ui.SketchButton(label, color, height=30, font_size=15)
            b.connect("clicked", lambda *_a, _k=key: self._apply_preset(_k))
            preset_panel.body.append(b)

        # ── pitch + effects
        fx_panel = ui.Panel("free pitch", ui.NYX["blue"])
        self.s_pitch = ui.SketchSlider("semitones", -24, 24, self.semitones,
                                        color=ui.NYX["blue"], step=1,
                                        on_change=lambda v: setattr(self, "semitones", float(v)))
        fx_panel.body.append(self.s_pitch)
        b = ui.SketchButton("apply pitch", ui.NYX["blue"], height=28, font_size=14)
        b.connect("clicked", lambda *_: self._apply_pitch())
        fx_panel.body.append(b)

        eff_panel = ui.Panel("effects", ui.NYX["green"])
        for label, color, fn in [
            ("reverb",    ui.NYX["purple"], lambda: self._apply_effect("reverb")),
            ("delay",     ui.NYX["blue"],   lambda: self._apply_effect("delay")),
            ("distortion",ui.NYX["red"],    lambda: self._apply_effect("distortion")),
            ("normalize", ui.NYX["green"],  lambda: self._apply_effect("normalize")),
            ("fade in/out", ui.NYX["gold"], lambda: self._apply_effect("fade")),
            ("reverse",   ui.NYX["pink"],   lambda: self._apply_effect("reverse")),
            ("revert original", ui.NYX["cyan"], self._revert),
        ]:
            b = ui.SketchButton(label, color, height=26, font_size=14)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            eff_panel.body.append(b)

        # ── save
        save_panel = ui.Panel("save", ui.NYX["gold"])
        for label, color, fn in [
            ("save WAV…", ui.NYX["blue"], self.save_wav),
            ("save MP3…", ui.NYX["pink"], self.save_mp3),
        ]:
            b = ui.SketchButton(label, color, height=28, font_size=15)
            b.connect("clicked", lambda *_a, _fn=fn: _fn())
            save_panel.body.append(b)

        self.status = Gtk.Label(label="ready  ·  no audio loaded", xalign=0.0)
        self.status.add_css_class("nyx-faint")

        # ── compose
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                       margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        left.set_size_request(220, -1)
        left.append(ui.TiltedHeader("voice", ui.NYX["pink"]))
        left.append(rec_panel); left.append(preset_panel)

        center = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6,
                         margin_top=12, margin_bottom=12, margin_start=12, margin_end=12)
        center.append(self.wave)
        center.append(self.status)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                        margin_top=6, margin_bottom=6, margin_start=6, margin_end=6)
        right.set_size_request(240, -1)
        right.append(fx_panel); right.append(eff_panel); right.append(save_panel)

        self.widget = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.widget.append(left); self.widget.append(center); self.widget.append(right)

    # ── transport ──
    def record(self):
        if self.is_recording:
            return
        if not ae.have_record():
            self._set_status("recording unavailable (install python-sounddevice + numpy)")
            return
        self.recorder = ae.Recorder(on_level=self._on_level)
        try:
            self.recorder.start()
        except Exception as exc:
            self._set_status(f"could not start recording: {exc}")
            self.recorder = None
            return
        self.is_recording = True
        self._set_status("recording…  ●")
        # poll level for waveform redraw
        GLib.timeout_add(50, self._poll_level)

    def stop(self):
        if not self.is_recording:
            ae.stop_playback()
            return
        if self.recorder is None:
            return
        data = self.recorder.stop()
        self.recorder = None
        self.is_recording = False
        if data is None or len(data) == 0:
            self._set_status("no audio captured")
            return
        self.samples = data
        self.processed = data.copy() if np is not None else None
        self._set_status(f"recorded · {len(data)/self.sr:.2f}s")
        self.wave.queue_draw()

    def play(self):
        buf = self.processed if self.processed is not None else self.samples
        if buf is None:
            self._set_status("nothing to play"); return
        ae.play(buf, self.sr)
        self._set_status("playing…  ▶")

    def _load(self):
        ui.open_file(self.parent, "load audio",
                     self._on_load,
                     filters=[("Audio", ["*.wav", "*.flac", "*.ogg", "*.mp3", "*.m4a", "*.aac"])])

    def _on_load(self, path: str):
        data = ae.load_audio(path, target_sr=self.sr)
        if data is None:
            self._set_status(f"could not load · {path}")
            return
        self.samples = data
        self.processed = data.copy() if np is not None else None
        self._set_status(f"loaded · {path}  ·  {len(data)/self.sr:.2f}s")
        self.wave.queue_draw()

    def _on_level(self, rms: float):
        self.level = float(rms)

    def _poll_level(self):
        if not self.is_recording:
            return False
        # accumulate buffer for waveform preview
        if self.recorder is not None and self.recorder.buf and np is not None:
            try:
                self.samples = np.concatenate(self.recorder.buf, axis=0)
                if self.samples.ndim > 1:
                    self.samples = self.samples[:, 0]
            except Exception:
                pass
        self.wave.queue_draw()
        return True

    # ── DSP ──
    def _ensure_processed(self):
        if self.samples is None:
            self._set_status("no audio loaded — record or load a file first")
            return False
        if self.processed is None and np is not None:
            self.processed = self.samples.copy()
        return self.processed is not None

    def _apply_preset(self, key: str):
        if not self._ensure_processed():
            return
        self._set_status(f"applying · {key}…")
        def worker():
            try:
                src = self.processed
                if key == "robot":     out = ae.voice_robot(src, self.sr)
                elif key == "demon":   out = ae.voice_demon(src, self.sr)
                elif key == "chipmunk": out = ae.voice_chipmunk(src, self.sr)
                elif key == "deep":    out = ae.voice_deep(src, self.sr)
                elif key == "telephone": out = ae.voice_telephone(src, self.sr)
                elif key == "alien":   out = ae.voice_alien(src, self.sr)
                else: out = src
                self.processed = out
            except Exception as exc:
                GLib.idle_add(self._set_status, f"failed: {exc}")
                return
            GLib.idle_add(self._after_dsp, key)
        threading.Thread(target=worker, daemon=True).start()

    def _apply_pitch(self):
        if not self._ensure_processed():
            return
        st = self.semitones
        def worker():
            self.processed = ae.pitch_shift_semitones(self.processed, st, self.sr)
            GLib.idle_add(self._after_dsp, f"pitch {st:+.0f}")
        threading.Thread(target=worker, daemon=True).start()

    def _apply_effect(self, name: str):
        if not self._ensure_processed():
            return
        def worker():
            try:
                if name == "reverb":     self.processed = ae.reverb(self.processed, self.sr)
                elif name == "delay":    self.processed = ae.delay(self.processed, sr=self.sr)
                elif name == "distortion": self.processed = ae.distortion(self.processed)
                elif name == "normalize":  self.processed = ae.normalize(self.processed)
                elif name == "fade":
                    self.processed = ae.fade_in(self.processed, ms=120, sr=self.sr)
                    self.processed = ae.fade_out(self.processed, ms=120, sr=self.sr)
                elif name == "reverse":  self.processed = ae.reverse(self.processed)
            except Exception as exc:
                GLib.idle_add(self._set_status, f"failed: {exc}")
                return
            GLib.idle_add(self._after_dsp, name)
        threading.Thread(target=worker, daemon=True).start()

    def _revert(self):
        if self.samples is None or np is None:
            return
        self.processed = self.samples.copy()
        self._after_dsp("revert")

    def _after_dsp(self, label: str):
        self._set_status(f"applied · {label}  ·  {len(self.processed)/self.sr:.2f}s")
        self.wave.queue_draw()
        return False

    # ── save ──
    def save_wav(self):
        if self.processed is None and self.samples is None:
            self._set_status("nothing to save"); return
        ui.save_file(self.parent, "save WAV", "nyxus-voice.wav", self._do_save_wav)

    def _do_save_wav(self, path: str):
        if not path.lower().endswith(".wav"):
            path += ".wav"
        buf = self.processed if self.processed is not None else self.samples
        ok = ae.save_wav(path, buf, self.sr)
        self._set_status(f"saved · {path}" if ok else "save failed (need soundfile)")

    def save_mp3(self):
        if self.processed is None and self.samples is None:
            self._set_status("nothing to save"); return
        ui.save_file(self.parent, "save MP3", "nyxus-voice.mp3", self._do_save_mp3)

    def _do_save_mp3(self, path: str):
        if not path.lower().endswith(".mp3"):
            path += ".mp3"
        buf = self.processed if self.processed is not None else self.samples
        ok = ae.save_mp3(path, buf, self.sr)
        self._set_status(f"saved · {path}" if ok else "MP3 export failed (need ffmpeg)")

    # ── waveform draw ──
    def _draw_wave(self, _a, cr, w, h):
        cr.set_source_rgba(0.04, 0.04, 0.06, 1.0); cr.paint()
        ui.sketch_rect(cr, 4, 4, w - 8, h - 8, ui.NYX["pink"] + (0.85,), 2.2)
        if self.samples is None or np is None or len(self.samples) < 2:
            cr.select_font_face("Inter Display", 0, 1); cr.set_font_size(20)
            cr.set_source_rgba(*ui.NYX["ink_dim"], 1.0)
            cr.move_to(20, h / 2 + 8)
            cr.show_text("record or load audio to see waveform")
            return
        # downsample
        target = max(200, w - 40)
        step = max(1, len(self.samples) // target)
        chunks = self.samples[:step * target].reshape(target, step)
        mins = chunks.min(axis=1); maxs = chunks.max(axis=1)
        center = h / 2
        amp = (h - 50) / 2

        # original
        if self.processed is not None and self.processed is not self.samples:
            cr.set_source_rgba(*ui.NYX["ink_faint"], 0.55); cr.set_line_width(1.0)
            for i in range(target):
                x = 20 + i
                cr.move_to(x, center + mins[i] * amp)
                cr.line_to(x, center + maxs[i] * amp)
            cr.stroke()

        # processed (or original if nothing processed)
        buf = self.processed if self.processed is not None else self.samples
        chunks = buf[:step * target].reshape(target, step) if len(buf) >= step * target else buf.reshape(-1, 1)
        if chunks.shape[0] < target:
            target = chunks.shape[0]
        mins = chunks.min(axis=1); maxs = chunks.max(axis=1)
        cr.set_source_rgba(*ui.NYX["pink"], 0.92); cr.set_line_width(1.2)
        for i in range(target):
            x = 20 + i
            cr.move_to(x, center + mins[i] * amp)
            cr.line_to(x, center + maxs[i] * amp)
        cr.stroke()

        # level dot while recording
        if self.is_recording:
            cr.set_source_rgba(*ui.NYX["red"], 1.0)
            cr.arc(w - 20, 20, 6 + self.level * 30, 0, 6.28); cr.fill()

    def _set_status(self, msg: str):
        self.status.set_text(msg)
        self.parent._set_status(f"voice · {msg}")

    # menu hooks
    def refresh_canvas(self): self.wave.queue_draw()
    def reset_zoom(self): pass
    def show_panel(self, name): self._set_status(f"panel · {name}")
    def filter(self, name): pass
    def adjust(self, kind, val): pass
    def layer_add(self): pass
    def layer_del(self): pass
    def layer_merge(self): pass
    def layer_flatten(self): pass
