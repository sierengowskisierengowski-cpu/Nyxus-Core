"""
NYXUS Studio — sketch UI library.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Hand-drawn / wobbly button, slider, dial, color swatch, dock panel,
tilted window decoration. Built on GTK4 + Cairo.
"""
from __future__ import annotations

import math
import random
from typing import Callable

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib, Gio, Pango   # noqa: E402


# ────────────────────────────────────────────────────────────────────────────
# palette
# ────────────────────────────────────────────────────────────────────────────

NYX = {
    "bg":        (0.039, 0.039, 0.071),
    "panel":     (0.071, 0.063, 0.106),
    "panel_h":   (0.094, 0.082, 0.137),
    "ink":       (0.94, 0.92, 0.97),
    "ink_dim":   (0.62, 0.58, 0.70),
    "ink_faint": (0.36, 0.34, 0.42),
    "pink":      (1.00, 0.24, 0.65),
    "blue":      (0.30, 0.70, 1.00),
    "green":     (0.30, 1.00, 0.55),
    "purple":    (0.62, 0.30, 0.95),
    "gold":      (1.00, 0.84, 0.20),
    "red":       (1.00, 0.30, 0.40),
    "cyan":      (0.30, 0.95, 0.95),
    "orange":    (1.00, 0.55, 0.20),
}


# ────────────────────────────────────────────────────────────────────────────
# global CSS — sketch-neon
# ────────────────────────────────────────────────────────────────────────────

GLOBAL_CSS = b"""
* { font-family: "Caveat", "Patrick Hand", "Comic Neue", sans-serif; }
window { background-color: #0a0a12; color: #efefee; }
.nyx-shell { background-color: #0a0a12; }
.nyx-panel { background-color: #11111c; border-radius: 6px; padding: 6px; }
.nyx-panel-h { background-color: #18182a; }
.nyx-menubar { background-color: #0a0a12; padding: 4px; border-bottom: 2px solid #2a1d3d; }
.nyx-menubar > button { background: transparent; color: #efefee; padding: 2px 12px; border: none; font-size: 16px; }
.nyx-menubar > button:hover { background-color: #2a1d3d; color: #ff3ea5; border-radius: 4px; }
.nyx-toolbar { background-color: #0e0e18; padding: 4px; border-bottom: 1px solid #1a1a2a; }
.nyx-statusbar { background-color: #0a0a12; padding: 3px 8px; border-top: 1px solid #1a1a2a; color: #9c8caa; font-size: 14px; }
.nyx-tab { background: transparent; color: #9c8caa; padding: 6px 14px; border: none; font-size: 16px; }
.nyx-tab:checked { color: #ffd700; background-color: #1a1a2a; border-radius: 4px; }
.nyx-tool { background: transparent; padding: 6px; border-radius: 6px; }
.nyx-tool:hover { background-color: #2a1d3d; }
.nyx-tool:checked { background-color: #4a2d6d; color: #ffd700; }
.nyx-h1 { font-size: 28px; color: #ffd700; }
.nyx-h2 { font-size: 22px; color: #ff3ea5; }
.nyx-h3 { font-size: 18px; color: #c4607a; }
.nyx-faint { color: #6a5a6a; font-size: 14px; }
entry, spinbutton {
  background-color: #14091a; color: #efefee; border: 1px solid #2a1d3d;
  border-radius: 4px; padding: 4px 8px; font-size: 16px;
}
entry:focus { border-color: #ff3ea5; }
button { font-size: 16px; }
scrollbar { background: #11111c; }
scrollbar slider { background: #4a2d6d; border-radius: 3px; min-width: 8px; min-height: 8px; }
scrollbar slider:hover { background: #ff3ea5; }
combobox button { background-color: #14091a; color: #efefee; border: 1px solid #2a1d3d; }
"""


def install_global_css(display) -> None:
    prov = Gtk.CssProvider()
    prov.load_from_data(GLOBAL_CSS)
    Gtk.StyleContext.add_provider_for_display(
        display, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )


# ────────────────────────────────────────────────────────────────────────────
# sketch helpers
# ────────────────────────────────────────────────────────────────────────────

def jitter(seed: int, amp: float = 1.6) -> Callable[[float], float]:
    rng = random.Random(seed)
    return lambda s=1.0: rng.uniform(-amp * s, amp * s)


def sketch_rect(cr, x, y, w, h, rgba, thick=2.4, seed=None):
    j = jitter(seed if seed is not None else int(x * 7 + y * 13 + w * 3 + h * 5), 1.3)
    cr.set_source_rgba(*rgba)
    cr.set_line_width(thick)
    cr.set_line_cap(1); cr.set_line_join(1)
    cr.move_to(x + j(.4), y + j(.4))
    cr.curve_to(x + w * .33 + j(), y + j(),
                x + w * .67 + j(), y + j(),
                x + w + j(.4), y + j(.4))
    cr.curve_to(x + w + j(), y + h * .33 + j(),
                x + w + j(), y + h * .67 + j(),
                x + w + j(.4), y + h + j(.4))
    cr.curve_to(x + w * .67 + j(), y + h + j(),
                x + w * .33 + j(), y + h + j(),
                x + j(.4), y + h + j(.4))
    cr.curve_to(x + j(), y + h * .67 + j(),
                x + j(), y + h * .33 + j(),
                x + j(.4), y + j(.4))
    cr.close_path()
    cr.stroke()


def sketch_rect_fill(cr, x, y, w, h, rgba, thick=2.0, seed=None):
    cr.save()
    cr.set_source_rgba(rgba[0], rgba[1], rgba[2], rgba[3] if len(rgba) == 4 else 1.0)
    cr.rectangle(x + 1, y + 1, w - 2, h - 2)
    cr.fill()
    cr.restore()
    sketch_rect(cr, x, y, w, h, (rgba[0], rgba[1], rgba[2], 0.85), thick, seed)


# ────────────────────────────────────────────────────────────────────────────
# SketchButton — wobbly hand-drawn button with optional toggle
# ────────────────────────────────────────────────────────────────────────────

class SketchButton(Gtk.Button):
    def __init__(self, label: str, color=NYX["pink"], *,
                 toggleable: bool = False, height: int = 36,
                 width: int = -1, font_size: int = 18):
        super().__init__()
        self.add_css_class("nyx-tool")
        self.label = label
        self.color = color
        self.toggleable = toggleable
        self.toggled = False
        self._font = font_size
        self.set_size_request(width, height)
        self.set_has_frame(False)

        self.area = Gtk.DrawingArea()
        self.area.set_draw_func(self._draw)
        self.set_child(self.area)
        self.connect("clicked", self._clicked)

    def _clicked(self, *_):
        if self.toggleable:
            self.toggled = not self.toggled
            self.area.queue_draw()

    def set_toggled(self, on: bool) -> None:
        self.toggled = bool(on)
        self.area.queue_draw()

    def _draw(self, _area, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        col = self.color
        bg = (col[0] * 0.25, col[1] * 0.25, col[2] * 0.25, 0.55) if self.toggled else (0.10, 0.08, 0.16, 0.0)
        if self.toggled:
            sketch_rect_fill(cr, 3, 3, w - 6, h - 6, bg, 2.0, seed=hash(self.label) & 0xFFFF)
        sketch_rect(cr, 3, 3, w - 6, h - 6,
                    (col[0], col[1], col[2], 0.95), 2.4,
                    seed=hash(self.label) & 0xFFFF)
        cr.select_font_face("Caveat", 0, 1)
        cr.set_font_size(self._font)
        ext = cr.text_extents(self.label)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.move_to((w - ext.width) / 2 - ext.x_bearing,
                   (h + ext.height) / 2 - 2)
        cr.show_text(self.label)


# ────────────────────────────────────────────────────────────────────────────
# SketchSlider
# ────────────────────────────────────────────────────────────────────────────

class SketchSlider(Gtk.Box):
    def __init__(self, label: str, lo: float, hi: float, value: float,
                 color=NYX["blue"], on_change: Callable[[float], None] | None = None,
                 step: float | None = None, width: int = 200):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.label = label
        self.lo = lo
        self.hi = hi
        self.value = value
        self.color = color
        self.on_change = on_change
        self.step = step
        self.dragging = False

        self.title = Gtk.Label(label=f"{label}  {self._fmt(value)}", xalign=0.0)
        self.title.add_css_class("nyx-faint")
        self.append(self.title)

        self.area = Gtk.DrawingArea()
        self.area.set_size_request(width, 26)
        self.area.set_draw_func(self._draw)
        self.append(self.area)

        gc = Gtk.GestureClick()
        gc.connect("pressed", self._press)
        gc.connect("released", self._release)
        self.area.add_controller(gc)

        gd = Gtk.GestureDrag()
        gd.connect("drag-update", self._drag)
        self.area.add_controller(gd)

    def _fmt(self, v):
        if abs(self.hi - self.lo) > 100:
            return f"{int(round(v))}"
        return f"{v:.2f}"

    def _set_from_x(self, x: float, w: int):
        x = max(8, min(w - 8, x))
        t = (x - 8) / max(1, w - 16)
        v = self.lo + t * (self.hi - self.lo)
        if self.step:
            v = round(v / self.step) * self.step
        self.value = v
        self.title.set_text(f"{self.label}  {self._fmt(v)}")
        self.area.queue_draw()
        if self.on_change:
            self.on_change(v)

    def _press(self, _g, _n, x, _y):
        self.dragging = True
        w = self.area.get_width()
        self._set_from_x(x, w)

    def _release(self, *_):
        self.dragging = False

    def _drag(self, g, dx, _dy):
        ok, sx, _ = g.get_start_point()
        if not ok:
            return
        w = self.area.get_width()
        self._set_from_x(sx + dx, w)

    def _draw(self, _area, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        sketch_rect(cr, 4, h / 2 - 4, w - 8, 8, (0.20, 0.18, 0.28, 0.9), 1.6,
                    seed=hash(self.label) & 0xFFFF)
        t = (self.value - self.lo) / max(1e-9, self.hi - self.lo)
        x = 8 + t * (w - 16)
        cr.set_source_rgba(*self.color, 0.85)
        cr.arc(x, h / 2, 8, 0, math.pi * 2)
        cr.fill()
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.set_line_width(1.6)
        cr.arc(x, h / 2, 8, 0, math.pi * 2)
        cr.stroke()


# ────────────────────────────────────────────────────────────────────────────
# Color swatch + palette
# ────────────────────────────────────────────────────────────────────────────

PALETTE = [
    (1.00, 0.24, 0.65), (1.00, 0.55, 0.20), (1.00, 0.84, 0.20),
    (0.30, 1.00, 0.55), (0.30, 0.95, 0.95), (0.30, 0.70, 1.00),
    (0.62, 0.30, 0.95), (1.00, 0.30, 0.40), (1.00, 1.00, 1.00),
    (0.70, 0.70, 0.70), (0.40, 0.40, 0.40), (0.05, 0.05, 0.07),
]


class ColorSwatch(Gtk.Button):
    def __init__(self, color, on_pick: Callable[[tuple[float, float, float]], None]):
        super().__init__()
        self.color = color
        self.on_pick = on_pick
        self.set_has_frame(False)
        self.set_size_request(24, 24)
        area = Gtk.DrawingArea()
        area.set_draw_func(self._draw)
        self.set_child(area)
        self.connect("clicked", lambda *_: on_pick(color))

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(*self.color, 1.0)
        cr.rectangle(2, 2, w - 4, h - 4)
        cr.fill()
        sketch_rect(cr, 1, 1, w - 2, h - 2, (0.97, 0.95, 0.99, 0.7), 1.4)


class ColorPalette(Gtk.FlowBox):
    def __init__(self, on_pick: Callable[[tuple[float, float, float]], None],
                 colors=None, columns: int = 6):
        super().__init__()
        self.set_max_children_per_line(columns)
        self.set_min_children_per_line(columns)
        self.set_selection_mode(Gtk.SelectionMode.NONE)
        self.set_homogeneous(True)
        self.set_column_spacing(4)
        self.set_row_spacing(4)
        for c in (colors or PALETTE):
            self.append(ColorSwatch(c, on_pick))


# ────────────────────────────────────────────────────────────────────────────
# Panel — titled card with tilted header for "hand drawn" feel
# ────────────────────────────────────────────────────────────────────────────

class Panel(Gtk.Box):
    def __init__(self, title: str, color=NYX["pink"], *, scroll: bool = False):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add_css_class("nyx-panel")

        head = Gtk.DrawingArea()
        head.set_size_request(-1, 28)
        head.set_draw_func(lambda a, c, w, h: self._draw_head(c, w, h))
        self._title = title
        self._title_color = color
        self.append(head)

        if scroll:
            sw = Gtk.ScrolledWindow()
            sw.set_vexpand(True)
            self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            sw.set_child(self.body)
            self.append(sw)
        else:
            self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            self.append(self.body)

    def _draw_head(self, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        cr.save()
        cr.translate(w / 2, h / 2)
        cr.rotate(-0.04)
        cr.translate(-w / 2, -h / 2)
        c = self._title_color
        sketch_rect_fill(cr, 2, 4, w - 4, h - 8, (c[0] * 0.30, c[1] * 0.30, c[2] * 0.30, 0.85), 1.6)
        cr.select_font_face("Caveat", 0, 1)
        cr.set_font_size(18)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        ext = cr.text_extents(self._title)
        cr.move_to(10, h / 2 + ext.height / 2 - 2)
        cr.show_text(self._title)
        cr.restore()


# ────────────────────────────────────────────────────────────────────────────
# Tool palette grid (vertical strip of toggle SketchButtons)
# ────────────────────────────────────────────────────────────────────────────

class ToolPalette(Gtk.Box):
    def __init__(self, tools: list[tuple[str, str, Callable[[str], None]]],
                 columns: int = 2):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        grid = Gtk.Grid()
        grid.set_row_spacing(4)
        grid.set_column_spacing(4)
        self.buttons: dict[str, SketchButton] = {}
        self._on_select: Callable[[str], None] | None = None
        for i, (key, label, color) in enumerate(tools):
            color_t = color if isinstance(color, tuple) else NYX.get(str(color), NYX["pink"])
            btn = SketchButton(label, color_t, toggleable=True, height=32,
                               width=86, font_size=15)
            btn.connect("clicked", lambda b, k=key: self._select(k))
            self.buttons[key] = btn
            grid.attach(btn, i % columns, i // columns, 1, 1)
        self.append(grid)

    def on_select(self, fn):
        self._on_select = fn

    def _select(self, key: str):
        for k, b in self.buttons.items():
            b.set_toggled(k == key)
        if self._on_select:
            self._on_select(key)

    def select(self, key: str):
        self._select(key)


# ────────────────────────────────────────────────────────────────────────────
# Tilted titlebar overlay (hand-drawn header for child windows)
# ────────────────────────────────────────────────────────────────────────────

class TiltedHeader(Gtk.DrawingArea):
    def __init__(self, text: str, color=NYX["gold"], height: int = 38, tilt: float = -0.03):
        super().__init__()
        self.text = text
        self.color = color
        self.tilt = tilt
        self.set_size_request(-1, height)
        self.set_draw_func(self._draw)

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        cr.save()
        cr.translate(w / 2, h / 2); cr.rotate(self.tilt); cr.translate(-w / 2, -h / 2)
        c = self.color
        sketch_rect_fill(cr, 4, 4, w - 8, h - 8, (c[0] * 0.18, c[1] * 0.18, c[2] * 0.18, 0.85), 2.0)
        sketch_rect(cr, 4, 4, w - 8, h - 8, (*c, 1.0), 2.4)
        cr.select_font_face("Caveat", 0, 1)
        cr.set_font_size(24)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        ext = cr.text_extents(self.text)
        cr.move_to(14, h / 2 + ext.height / 2 - 3)
        cr.show_text(self.text)
        cr.restore()


# ────────────────────────────────────────────────────────────────────────────
# simple text-entry dialog
# ────────────────────────────────────────────────────────────────────────────

def text_entry_dialog(parent, title: str, initial: str = "",
                       on_ok: Callable[[str], None] | None = None) -> None:
    dlg = Gtk.Window(title=title, transient_for=parent, modal=True)
    dlg.set_default_size(360, 120)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_top=12,
                  margin_bottom=12, margin_start=12, margin_end=12)
    box.append(TiltedHeader(title, NYX["gold"]))
    entry = Gtk.Entry()
    entry.set_text(initial)
    box.append(entry)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8, halign=Gtk.Align.END)
    cancel = SketchButton("cancel", NYX["ink_dim"], width=80, height=32)
    ok = SketchButton("ok", NYX["green"], width=80, height=32)
    row.append(cancel); row.append(ok)
    box.append(row)
    dlg.set_child(box)
    cancel.connect("clicked", lambda *_: dlg.close())
    def _ok(*_):
        if on_ok:
            on_ok(entry.get_text())
        dlg.close()
    ok.connect("clicked", _ok)
    dlg.present()


# ────────────────────────────────────────────────────────────────────────────
# file chooser helpers (GTK4 native)
# ────────────────────────────────────────────────────────────────────────────

def open_file(parent, title: str, on_file: Callable[[str], None],
              filters: list[tuple[str, list[str]]] | None = None) -> None:
    dlg = Gtk.FileDialog()
    dlg.set_title(title)
    if filters:
        flist = Gio.ListStore.new(Gtk.FileFilter)
        for name, patterns in filters:
            f = Gtk.FileFilter()
            f.set_name(name)
            for p in patterns:
                f.add_pattern(p)
            flist.append(f)
        dlg.set_filters(flist)
    def _done(d, result):
        try:
            f = d.open_finish(result)
            if f:
                on_file(f.get_path())
        except Exception:
            pass
    dlg.open(parent, None, _done)


def save_file(parent, title: str, suggested: str,
              on_file: Callable[[str], None]) -> None:
    dlg = Gtk.FileDialog()
    dlg.set_title(title)
    dlg.set_initial_name(suggested)
    def _done(d, result):
        try:
            f = d.save_finish(result)
            if f:
                on_file(f.get_path())
        except Exception:
            pass
    dlg.save(parent, None, _done)
