"""
NYXUS Studio — sketch UI library.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Hand-drawn / wobbly button, slider, dial, color swatch, dock panel,
tilted window decoration. Built on GTK4 + Cairo.
"""
from __future__ import annotations

import math
import random
from typing import Callable

import gi

# ── NYXUS palette (single source of truth · rev r13) ────────────────
try:
    from nyxus_palette import (
        WHITE_PURE, WHITE_OFF, GREY_LIGHT, GREY_MID, GREY_TERTIARY,
        INK_FADED, INK_BLACK,
        GLASS_DARK, GLASS_DEEPER, GLASS_DEEPEST,
        HAIRLINE_WHITE, HAIRLINE_INK,
        SHADOW_INK_ACTIVE, SHADOW_INK_INACTIVE,
        RADIUS_CARD, RADIUS_PILL, RADIUS_INPUT,
        FONT_UI, FONT_MONO, FONT_DISPLAY,
        format_css, assert_no_forbidden,
    )
except Exception:
    # palette module is shipped alongside every NYXUS app via
    # nyxus_install.sh; if it's missing, fall back to literals so
    # the app still launches.
    WHITE_PURE='#ffffff'; WHITE_OFF='#e8edf5'; GREY_LIGHT='#c8ccd6'
    GREY_MID='#9aa0ad'; GREY_TERTIARY='#6a6e78'
    INK_FADED='#0a0a0a'; INK_BLACK='#000000'
    GLASS_DARK='rgba(8, 12, 20, 0.55)'
    GLASS_DEEPER='rgba(15, 20, 32, 0.72)'
    GLASS_DEEPEST='rgba(5, 7, 12, 0.92)'
    HAIRLINE_WHITE='rgba(255, 255, 255, 0.10)'
    HAIRLINE_INK='rgba(0, 0, 0, 0.45)'
    SHADOW_INK_ACTIVE='rgba(0, 0, 0, 0.65)'
    SHADOW_INK_INACTIVE='rgba(0, 0, 0, 0.20)'
    RADIUS_CARD=14; RADIUS_PILL=12; RADIUS_INPUT=10
    FONT_UI='Inter'; FONT_MONO='JetBrains Mono'; FONT_DISPLAY='Inter Display'
    def format_css(t):
        _d = {
            'WHITE_PURE': WHITE_PURE, 'WHITE_OFF': WHITE_OFF,
            'GREY_LIGHT': GREY_LIGHT, 'GREY_MID': GREY_MID,
            'GREY_TERTIARY': GREY_TERTIARY,
            'INK_FADED': INK_FADED, 'INK_BLACK': INK_BLACK,
            'GLASS_DARK': GLASS_DARK, 'GLASS_DEEPER': GLASS_DEEPER,
            'GLASS_DEEPEST': GLASS_DEEPEST,
            'HAIRLINE_WHITE': HAIRLINE_WHITE, 'HAIRLINE_INK': HAIRLINE_INK,
            'SHADOW_INK_ACTIVE': SHADOW_INK_ACTIVE,
            'SHADOW_INK_INACTIVE': SHADOW_INK_INACTIVE,
            'RADIUS_CARD': RADIUS_CARD, 'RADIUS_PILL': RADIUS_PILL,
            'RADIUS_INPUT': RADIUS_INPUT,
            'FONT_UI': FONT_UI, 'FONT_MONO': FONT_MONO,
            'FONT_DISPLAY': FONT_DISPLAY,
        }
        return t.format_map(_d)
    def assert_no_forbidden(*a, **k): pass
# ─────────────────────────────────────────────────────────────────────

gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib, Gio, Pango   # noqa: E402


# ────────────────────────────────────────────────────────────────────────────
# palette
# ────────────────────────────────────────────────────────────────────────────

NYX = {
    "bg":        (0.039, 0.039, 0.071),
    "panel":     (0.071, 0.063, 0.106),
    "panel_h":   (0.094, 0.082, 0.137),
    "ink":       (0.94, 0.92, 0.97),
    "ink_dim":   (0.62, 0.58, 0.70),
    "ink_faint": (0.36, 0.34, 0.42),
    "pink":      (1.00, 0.24, 0.65),
    "blue":      (0.30, 0.70, 1.00),
    "green":     (0.30, 1.00, 0.55),
    "purple":    (0.62, 0.30, 0.95),
    "gold":      (1.00, 0.84, 0.20),
    "red":       (1.00, 0.30, 0.40),
    "cyan":      (0.30, 0.95, 0.95),
    "orange":    (1.00, 0.55, 0.20),
}


# ────────────────────────────────────────────────────────────────────────────
# global CSS — sketch-neon
# ────────────────────────────────────────────────────────────────────────────

GLOBAL_CSS = b"""
* { font-family: "Inter Display", "Inter Display", "Inter", sans-serif; }
window { background-color: transparent; color: #e8edf5; }
.nyx-shell { background-color: transparent; }
.nyx-panel { background-color: rgba(248,248,252,0.62); border-radius: 12px; padding: 8px; border: 1px solid rgba(255,255,255,0.55); color: #0a0a12; }
.nyx-panel label, .nyx-panel > * { color: #0a0a12; }
.nyx-panel-h { background-color: rgba(245,245,250,0.92); border-radius: 12px; color: #0a0a12; }
.nyx-panel-h label, .nyx-panel-h > * { color: #0a0a12; }
.nyx-menubar { background-color: rgba(6,6,10,0.78); padding: 8px 8px; border-bottom: 2px solid rgba(255,0,180,0.45); }
.nyx-menubar button { background: transparent; color: #e8edf5; padding: 6px 18px; border: none; font-size: 22px; border-radius: 5px; }
.nyx-menubar button:hover { background-color: rgba(255,0,180,0.20); color: #ff3ea5; box-shadow: 0 0 10px rgba(255,0,180,0.45); }
.nyx-menubar button:active { background-color: rgba(255,215,0,0.20); color: #e8edf5; box-shadow: 0 0 12px rgba(255,215,0,0.55); }
.nyx-toolbar { background-color: rgba(8,8,12,0.65); padding: 6px; border-bottom: 1px solid rgba(255,0,180,0.30); }
.nyx-statusbar { background-color: rgba(6,6,10,0.78); padding: 4px 10px; border-top: 1px solid rgba(255,0,180,0.30); color: #b9a4cc; font-size: 16px; }
.nyx-tab { background: transparent; color: #b9a4cc; padding: 8px 16px; border: none; font-size: 18px; }
.nyx-tab:checked { color: #e8edf5; background-color: rgba(255,215,0,0.18); border-radius: 6px; box-shadow: 0 0 10px rgba(255,215,0,0.40); }
.nyx-tool { background: transparent; padding: 6px; border-radius: 6px; }
.nyx-tool:hover { background-color: rgba(255,62,165,0.20); box-shadow: 0 0 8px rgba(255,62,165,0.45); }
.nyx-tool:checked { background-color: rgba(255,215,0,0.22); color: #e8edf5; box-shadow: 0 0 10px rgba(255,215,0,0.55); }
.nyx-h1 { font-size: 30px; color: #e8edf5; text-shadow: 0 0 12px rgba(255,215,0,0.55); }
.nyx-h2 { font-size: 24px; color: #ff3ea5; text-shadow: 0 0 8px rgba(255,62,165,0.45); }
.nyx-h3 { font-size: 20px; color: #c4607a; }
.nyx-faint { color: #b9a4cc; font-size: 16px; }
.nyx-doc-title { color: #c8b2db; font-size: 18px; }
entry, spinbutton {
  background-color: rgba(8,8,12,0.65); color: #e8edf5; border: 1px solid rgba(255,0,180,0.55);
  border-radius: 8px; padding: 6px 12px; font-size: 18px;
}
entry:focus, spinbutton:focus { border-color: rgba(0,220,255,0.85); box-shadow: 0 0 12px rgba(0,220,255,0.45); }
button { font-size: 18px; }
popover, popover contents { background-color: rgba(8,8,12,0.88); color: #e8edf5; border: 1px solid rgba(255,0,180,0.55); border-radius: 10px; }
popover modelbutton { color: #e8edf5; padding: 6px 14px; font-size: 18px; }
popover modelbutton:hover { background-color: rgba(255,0,180,0.20); color: #ff3ea5; }
dropdown > button {
  background-color: rgba(8,8,12,0.65); color: #e8edf5; border: 1px solid rgba(255,0,180,0.55);
  border-radius: 8px; padding: 4px 10px; font-size: 17px;
}
scrollbar { background: transparent; }
scrollbar slider { background: rgba(255,0,180,0.55); border-radius: 4px; min-width: 10px; min-height: 10px; }
scrollbar slider:hover { background: rgba(0,220,255,0.85); box-shadow: 0 0 8px rgba(0,220,255,0.55); }
combobox button { background-color: rgba(8,8,12,0.65); color: #e8edf5; border: 1px solid rgba(255,0,180,0.55); border-radius: 8px; }
"""


def install_global_css(display) -> None:
    prov = Gtk.CssProvider()
    prov.load_from_data(GLOBAL_CSS)
    Gtk.StyleContext.add_provider_for_display(
        display, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )


# ────────────────────────────────────────────────────────────────────────────
# sketch helpers
# ────────────────────────────────────────────────────────────────────────────

def jitter(seed: int, amp: float = 1.6) -> Callable[[float], float]:
    rng = random.Random(seed)
    return lambda s=1.0: rng.uniform(-amp * s, amp * s)


def _sketch_path(cr, x, y, w, h, j_amp: float, seed: int) -> None:
    """Trace a single wobbly closed rectangle path."""
    j = jitter(seed, j_amp)
    cr.move_to(x + j(.4), y + j(.4))
    cr.curve_to(x + w * .33 + j(), y + j(),
                x + w * .67 + j(), y + j(),
                x + w + j(.4), y + j(.4))
    cr.curve_to(x + w + j(), y + h * .33 + j(),
                x + w + j(), y + h * .67 + j(),
                x + w + j(.4), y + h + j(.4))
    cr.curve_to(x + w * .67 + j(), y + h + j(),
                x + w * .33 + j(), y + h + j(),
                x + j(.4), y + h + j(.4))
    cr.curve_to(x + j(), y + h * .67 + j(),
                x + j(), y + h * .33 + j(),
                x + j(.4), y + j(.4))
    cr.close_path()


def sketch_rect(cr, x, y, w, h, rgba, thick=2.4, seed=None, *,
                shadow: bool = True, double_stroke: bool = True):
    """Premium hand-drawn rectangle: ink shadow + main stroke + faint accent stroke.

    shadow=True draws a soft dark drop-shadow underneath for depth.
    double_stroke=True adds a thinner offset accent stroke to mimic
    a second ink pass, the way real hand drawn marks layer.
    """
    s = seed if seed is not None else int(x * 7 + y * 13 + w * 3 + h * 5)
    cr.set_line_cap(1); cr.set_line_join(1)

    # 1) soft drop-shadow underneath (gives depth without changing color)
    if shadow:
        cr.save()
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.45)
        cr.set_line_width(thick + 1.6)
        _sketch_path(cr, x + 1.2, y + 1.6, w, h, 1.0, s ^ 0xA5A5)
        cr.stroke()
        cr.restore()

    # 2) main ink stroke
    cr.set_source_rgba(*rgba if len(rgba) == 4 else (*rgba, 0.95))
    cr.set_line_width(thick)
    _sketch_path(cr, x, y, w, h, 1.1, s)
    cr.stroke()

    # 3) faint second pass — slightly offset, thinner, more transparent
    if double_stroke:
        col = rgba
        cr.set_source_rgba(col[0], col[1], col[2],
                           (col[3] if len(col) == 4 else 0.95) * 0.45)
        cr.set_line_width(max(1.0, thick * 0.55))
        _sketch_path(cr, x + 0.6, y + 0.4, w - 0.2, h - 0.2, 1.4, s ^ 0x5A5A)
        cr.stroke()


def sketch_rect_fill(cr, x, y, w, h, rgba, thick=2.0, seed=None):
    """Filled hand-drawn rectangle. Adds an inner highlight band so the
    fill reads like ink wash rather than a flat block."""
    s = seed if seed is not None else int(x * 7 + y * 13 + w * 3 + h * 5)
    a = rgba[3] if len(rgba) == 4 else 1.0
    # soft fill body
    cr.save()
    cr.set_source_rgba(rgba[0], rgba[1], rgba[2], a)
    cr.rectangle(x + 1, y + 1, w - 2, h - 2)
    cr.fill()
    # inner darker rim — gives it dimension
    cr.set_source_rgba(0.0, 0.0, 0.0, 0.28)
    cr.set_line_width(1.2)
    cr.rectangle(x + 2.5, y + 2.5, w - 5, h - 5)
    cr.stroke()
    cr.restore()
    # premium border on top
    sketch_rect(cr, x, y, w, h,
                (rgba[0], rgba[1], rgba[2], 0.95),
                thick, s, shadow=True, double_stroke=True)


# ────────────────────────────────────────────────────────────────────────────
# hand-drawn icon system — Cairo strokes, never Unicode glyphs
# ────────────────────────────────────────────────────────────────────────────

def _stroke(cr, color, thick: float = 2.0):
    cr.set_source_rgba(*color if len(color) == 4 else (*color, 0.95))
    cr.set_line_width(thick)
    cr.set_line_cap(1); cr.set_line_join(1)


def sketch_icon(cr, name: str, x: float, y: float, size: float = 18,
                color=(0.94, 0.92, 0.97, 0.95), thick: float = 1.8) -> None:
    """Hand-drawn icon at (x, y) sized `size` px. Strokes only — no fills.
    Supported names: eye, eye_off, plus, minus, x, check, trash, save,
    folder, layers, lock, unlock, brush, gear, dot."""
    cx, cy = x + size / 2, y + size / 2
    r = size * 0.42
    # tiny per-icon jitter for hand-drawn feel
    j = jitter(hash(name) & 0xFFFF, 0.6)

    if name == "eye":
        _stroke(cr, color, thick)
        cr.move_to(x + j(), cy + j())
        cr.curve_to(x + size * .25, cy - r * .9 + j(),
                    x + size * .75, cy - r * .9 + j(),
                    x + size + j(), cy + j())
        cr.curve_to(x + size * .75, cy + r * .9 + j(),
                    x + size * .25, cy + r * .9 + j(),
                    x + j(), cy + j())
        cr.stroke()
        cr.arc(cx, cy, r * .35, 0, math.pi * 2); cr.stroke()
    elif name == "eye_off":
        sketch_icon(cr, "eye", x, y, size, color, thick)
        _stroke(cr, color, thick)
        cr.move_to(x + size * .1 + j(), y + size * .1 + j())
        cr.line_to(x + size * .9 + j(), y + size * .9 + j())
        cr.stroke()
    elif name == "plus":
        _stroke(cr, color, thick)
        cr.move_to(cx + j(), y + size * .15 + j())
        cr.line_to(cx + j(), y + size * .85 + j()); cr.stroke()
        cr.move_to(x + size * .15 + j(), cy + j())
        cr.line_to(x + size * .85 + j(), cy + j()); cr.stroke()
    elif name == "minus":
        _stroke(cr, color, thick)
        cr.move_to(x + size * .15 + j(), cy + j())
        cr.line_to(x + size * .85 + j(), cy + j()); cr.stroke()
    elif name == "x":
        _stroke(cr, color, thick)
        cr.move_to(x + size * .2 + j(), y + size * .2 + j())
        cr.line_to(x + size * .8 + j(), y + size * .8 + j()); cr.stroke()
        cr.move_to(x + size * .8 + j(), y + size * .2 + j())
        cr.line_to(x + size * .2 + j(), y + size * .8 + j()); cr.stroke()
    elif name == "check":
        _stroke(cr, color, thick)
        cr.move_to(x + size * .15 + j(), cy + j())
        cr.line_to(x + size * .42 + j(), y + size * .80 + j())
        cr.line_to(x + size * .85 + j(), y + size * .20 + j()); cr.stroke()
    elif name == "trash":
        _stroke(cr, color, thick)
        # lid
        cr.move_to(x + size * .15 + j(), y + size * .25 + j())
        cr.line_to(x + size * .85 + j(), y + size * .25 + j()); cr.stroke()
        # handle
        cr.move_to(x + size * .38 + j(), y + size * .12 + j())
        cr.line_to(x + size * .62 + j(), y + size * .12 + j())
        cr.line_to(x + size * .62 + j(), y + size * .25 + j())
        cr.line_to(x + size * .38 + j(), y + size * .25 + j())
        cr.close_path(); cr.stroke()
        # body
        cr.move_to(x + size * .22 + j(), y + size * .28 + j())
        cr.line_to(x + size * .30 + j(), y + size * .88 + j())
        cr.line_to(x + size * .70 + j(), y + size * .88 + j())
        cr.line_to(x + size * .78 + j(), y + size * .28 + j()); cr.stroke()
    elif name == "save":
        _stroke(cr, color, thick)
        # outer floppy
        sketch_rect(cr, x + 1, y + 1, size - 2, size - 2,
                    color, thick, seed=hash("save") & 0xFFFF,
                    shadow=False, double_stroke=False)
        # label slot
        cr.move_to(x + size * .25, y + size * .55)
        cr.line_to(x + size * .75, y + size * .55)
        cr.line_to(x + size * .75, y + size * .85)
        cr.line_to(x + size * .25, y + size * .85)
        cr.close_path(); cr.stroke()
    elif name == "folder":
        _stroke(cr, color, thick)
        cr.move_to(x + j(), y + size * .35 + j())
        cr.line_to(x + size * .35 + j(), y + size * .35 + j())
        cr.line_to(x + size * .45 + j(), y + size * .22 + j())
        cr.line_to(x + size * .95 + j(), y + size * .22 + j())
        cr.line_to(x + size * .95 + j(), y + size * .82 + j())
        cr.line_to(x + j(), y + size * .82 + j())
        cr.close_path(); cr.stroke()
    elif name == "layers":
        _stroke(cr, color, thick)
        for dy in (-size * .18, 0, size * .18):
            cr.move_to(cx - size * .35 + j(), cy + dy + j())
            cr.line_to(cx + j(), cy + dy - size * .12 + j())
            cr.line_to(cx + size * .35 + j(), cy + dy + j())
            cr.line_to(cx + j(), cy + dy + size * .12 + j())
            cr.close_path(); cr.stroke()
    elif name == "lock":
        _stroke(cr, color, thick)
        # shackle
        cr.arc(cx, cy - size * .05, size * .25, math.pi, math.pi * 2); cr.stroke()
        # body
        sketch_rect(cr, cx - size * .32, cy, size * .64, size * .42,
                    color, thick, seed=hash("lock") & 0xFFFF,
                    shadow=False, double_stroke=False)
    elif name == "unlock":
        _stroke(cr, color, thick)
        cr.arc(cx + size * .15, cy - size * .05,
               size * .25, math.pi, math.pi * 1.5); cr.stroke()
        sketch_rect(cr, cx - size * .32, cy, size * .64, size * .42,
                    color, thick, seed=hash("unlock") & 0xFFFF,
                    shadow=False, double_stroke=False)
    elif name == "brush":
        _stroke(cr, color, thick)
        cr.move_to(x + size * .1 + j(), y + size * .9 + j())
        cr.line_to(x + size * .55 + j(), y + size * .45 + j())
        cr.line_to(x + size * .80 + j(), y + size * .70 + j())
        cr.line_to(x + size * .35 + j(), y + size * .9 + j())
        cr.close_path(); cr.stroke()
        cr.move_to(x + size * .55 + j(), y + size * .45 + j())
        cr.line_to(x + size * .85 + j(), y + size * .15 + j()); cr.stroke()
    elif name == "gear":
        _stroke(cr, color, thick)
        for k in range(8):
            ang = k * math.pi / 4
            x1 = cx + math.cos(ang) * r * .65
            y1 = cy + math.sin(ang) * r * .65
            x2 = cx + math.cos(ang) * r * 1.05
            y2 = cy + math.sin(ang) * r * 1.05
            cr.move_to(x1, y1); cr.line_to(x2, y2); cr.stroke()
        cr.arc(cx, cy, r * .55, 0, math.pi * 2); cr.stroke()
    else:  # "dot" / fallback
        cr.set_source_rgba(*color if len(color) == 4 else (*color, 0.95))
        cr.arc(cx, cy, r * .55, 0, math.pi * 2); cr.fill()


class IconButton(Gtk.Button):
    """Square button rendering a hand-drawn icon (no text)."""

    def __init__(self, icon: str, color=None, *,
                 size: int = 28, tooltip: str | None = None,
                 on_click: Callable[[], None] | None = None):
        super().__init__()
        self.add_css_class("nyx-tool")
        self.set_has_frame(False)
        self.set_size_request(size + 8, size + 8)
        self._icon = icon
        self._color = color or NYX["ink"]
        self._size = size
        if tooltip:
            self.set_tooltip_text(tooltip)
        area = Gtk.DrawingArea()
        area.set_draw_func(self._draw)
        self.set_child(area)
        if on_click:
            self.connect("clicked", lambda *_: on_click())

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        ix = (w - self._size) / 2
        iy = (h - self._size) / 2
        sketch_icon(cr, self._icon, ix, iy, self._size,
                    color=(*self._color[:3], 0.95), thick=1.8)


# ────────────────────────────────────────────────────────────────────────────
# SketchButton — wobbly hand-drawn button with optional toggle
# ────────────────────────────────────────────────────────────────────────────

class SketchButton(Gtk.Button):
    def __init__(self, label: str, color=NYX["pink"], *,
                 toggleable: bool = False, height: int = 42,
                 width: int = -1, font_size: int = 20):
        super().__init__()
        self.add_css_class("nyx-tool")
        self.label = label
        self.color = color
        self.toggleable = toggleable
        self.toggled = False
        self._font = font_size
        self.set_size_request(width, height)
        self.set_has_frame(False)

        self.area = Gtk.DrawingArea()
        self.area.set_draw_func(self._draw)
        self.set_child(self.area)
        self.connect("clicked", self._clicked)

    def _clicked(self, *_):
        if self.toggleable:
            self.toggled = not self.toggled
            self.area.queue_draw()

    def set_toggled(self, on: bool) -> None:
        self.toggled = bool(on)
        self.area.queue_draw()

    def _draw(self, _area, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        col = self.color
        seed = hash(self.label) & 0xFFFF

        # toggled state: sketched ink-wash fill behind the border
        if self.toggled:
            bg = (col[0] * 0.30, col[1] * 0.30, col[2] * 0.30, 0.65)
            sketch_rect_fill(cr, 4, 4, w - 8, h - 8, bg, 1.8, seed=seed)

        sketch_rect(cr, 4, 4, w - 8, h - 8,
                    (col[0], col[1], col[2], 0.96), 2.4,
                    seed=seed,
                    shadow=True, double_stroke=True)

        # text — handwritten with a faint ink-shadow for depth
        cr.select_font_face("Inter Display", 0, 1)
        cr.set_font_size(self._font)
        ext = cr.text_extents(self.label)
        tx = (w - ext.width) / 2 - ext.x_bearing
        ty = (h + ext.height) / 2 - 2
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.move_to(tx + 0.8, ty + 1.0); cr.show_text(self.label)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.move_to(tx, ty); cr.show_text(self.label)

        # toggled accent — hand-drawn underline beneath text
        if self.toggled:
            j = jitter(seed ^ 0xCAFE, 0.5)
            cr.set_source_rgba(col[0], col[1], col[2], 0.85)
            cr.set_line_width(1.6)
            cr.set_line_cap(1)
            ux1 = tx + j(); uy = ty + 3 + j()
            ux2 = tx + ext.width + j()
            cr.move_to(ux1, uy)
            cr.curve_to((ux1 * 2 + ux2) / 3 + j(), uy + j(),
                        (ux1 + ux2 * 2) / 3 + j(), uy + j(),
                        ux2, uy + j())
            cr.stroke()


# ────────────────────────────────────────────────────────────────────────────
# SketchSlider
# ────────────────────────────────────────────────────────────────────────────

class SketchSlider(Gtk.Box):
    def __init__(self, label: str, lo: float, hi: float, value: float,
                 color=NYX["blue"], on_change: Callable[[float], None] | None = None,
                 step: float | None = None, width: int = 200):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.label = label
        self.lo = lo
        self.hi = hi
        self.value = value
        self.color = color
        self.on_change = on_change
        self.step = step
        self.dragging = False

        self.title = Gtk.Label(label=f"{label}  {self._fmt(value)}", xalign=0.0)
        self.title.add_css_class("nyx-faint")
        self.append(self.title)

        self.area = Gtk.DrawingArea()
        self.area.set_size_request(width, 26)
        self.area.set_draw_func(self._draw)
        self.append(self.area)

        gc = Gtk.GestureClick()
        gc.connect("pressed", self._press)
        gc.connect("released", self._release)
        self.area.add_controller(gc)

        gd = Gtk.GestureDrag()
        gd.connect("drag-update", self._drag)
        self.area.add_controller(gd)

    def _fmt(self, v):
        if abs(self.hi - self.lo) > 100:
            return f"{int(round(v))}"
        return f"{v:.2f}"

    def _set_from_x(self, x: float, w: int):
        x = max(8, min(w - 8, x))
        t = (x - 8) / max(1, w - 16)
        v = self.lo + t * (self.hi - self.lo)
        if self.step:
            v = round(v / self.step) * self.step
        self.value = v
        self.title.set_text(f"{self.label}  {self._fmt(v)}")
        self.area.queue_draw()
        if self.on_change:
            self.on_change(v)

    def _press(self, _g, _n, x, _y):
        self.dragging = True
        w = self.area.get_width()
        self._set_from_x(x, w)

    def _release(self, *_):
        self.dragging = False

    def _drag(self, g, dx, _dy):
        ok, sx, _ = g.get_start_point()
        if not ok:
            return
        w = self.area.get_width()
        self._set_from_x(sx + dx, w)

    def _draw(self, _area, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        seed = hash(self.label) & 0xFFFF

        # sketched groove track with shadow underneath
        sketch_rect(cr, 4, h / 2 - 4, w - 8, 8,
                    (0.18, 0.16, 0.26, 0.95), 1.5, seed=seed,
                    shadow=False, double_stroke=False)

        # filled portion behind handle — like ink filling a trough
        t = (self.value - self.lo) / max(1e-9, self.hi - self.lo)
        x = 8 + t * (w - 16)
        cr.save()
        cr.set_source_rgba(*self.color, 0.55)
        cr.rectangle(5, h / 2 - 3, max(0, x - 5), 6); cr.fill()
        cr.restore()

        # handle: ink shadow + filled disc + outer hand-drawn ring
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.arc(x + 0.8, h / 2 + 1.0, 8.5, 0, math.pi * 2); cr.fill()
        cr.set_source_rgba(*self.color, 0.92)
        cr.arc(x, h / 2, 8, 0, math.pi * 2); cr.fill()
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.set_line_width(1.8)
        cr.set_line_cap(1)
        # slightly wobbly ring — 12 short arcs offset by tiny jitter
        j = jitter(seed ^ 0xBADD, 0.6)
        steps = 18
        for k in range(steps):
            a0 = (k / steps) * math.pi * 2
            a1 = ((k + 1) / steps) * math.pi * 2
            cr.arc(x + j(.3), h / 2 + j(.3), 8 + j(.3), a0, a1)
            cr.stroke()


# ────────────────────────────────────────────────────────────────────────────
# Color swatch + palette
# ────────────────────────────────────────────────────────────────────────────

PALETTE = [
    (1.00, 0.24, 0.65), (1.00, 0.55, 0.20), (1.00, 0.84, 0.20),
    (0.30, 1.00, 0.55), (0.30, 0.95, 0.95), (0.30, 0.70, 1.00),
    (0.62, 0.30, 0.95), (1.00, 0.30, 0.40), (1.00, 1.00, 1.00),
    (0.70, 0.70, 0.70), (0.40, 0.40, 0.40), (0.05, 0.05, 0.07),
]


class ColorSwatch(Gtk.Button):
    def __init__(self, color, on_pick: Callable[[tuple[float, float, float]], None]):
        super().__init__()
        self.color = color
        self.on_pick = on_pick
        self.set_has_frame(False)
        self.set_size_request(34, 34)
        area = Gtk.DrawingArea()
        area.set_draw_func(self._draw)
        self.set_child(area)
        self.connect("clicked", lambda *_: on_pick(color))

    def _draw(self, _a, cr, w, h):
        # ink-shadow underneath
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.rectangle(3, 4, w - 4, h - 4); cr.fill()
        # color body
        cr.set_source_rgba(*self.color, 1.0)
        cr.rectangle(3, 3, w - 6, h - 6); cr.fill()
        # hand-drawn light border
        sketch_rect(cr, 2, 2, w - 4, h - 4,
                    (0.97, 0.95, 0.99, 0.85), 1.4,
                    seed=hash(tuple(self.color)) & 0xFFFF,
                    shadow=False, double_stroke=False)


class ColorPalette(Gtk.FlowBox):
    def __init__(self, on_pick: Callable[[tuple[float, float, float]], None],
                 colors=None, columns: int = 6):
        super().__init__()
        self.set_max_children_per_line(columns)
        self.set_min_children_per_line(columns)
        self.set_selection_mode(Gtk.SelectionMode.NONE)
        self.set_homogeneous(True)
        self.set_column_spacing(4)
        self.set_row_spacing(4)
        for c in (colors or PALETTE):
            self.append(ColorSwatch(c, on_pick))


# ────────────────────────────────────────────────────────────────────────────
# Panel — titled card with tilted header for "hand drawn" feel
# ────────────────────────────────────────────────────────────────────────────

class Panel(Gtk.Box):
    def __init__(self, title: str, color=NYX["pink"], *, scroll: bool = False):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.add_css_class("nyx-panel")

        head = Gtk.DrawingArea()
        head.set_size_request(-1, 36)
        head.set_draw_func(lambda a, c, w, h: self._draw_head(c, w, h))
        self._title = title
        self._title_color = color
        self.append(head)

        if scroll:
            sw = Gtk.ScrolledWindow()
            sw.set_vexpand(True)
            self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            sw.set_child(self.body)
            self.append(sw)
        else:
            self.body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            self.append(self.body)

    def _draw_head(self, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        cr.save()
        cr.translate(w / 2, h / 2)
        cr.rotate(-0.025)
        cr.translate(-w / 2, -h / 2)
        c = self._title_color
        sketch_rect_fill(cr, 2, 4, w - 4, h - 8,
                         (c[0] * 0.32, c[1] * 0.32, c[2] * 0.32, 0.92), 1.8,
                         seed=hash(self._title) & 0xFFFF)
        cr.select_font_face("Inter Display", 0, 1)
        cr.set_font_size(24)
        ext = cr.text_extents(self._title)
        # ink-shadow text
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.move_to(13, h / 2 + ext.height / 2 - 1)
        cr.show_text(self._title)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.move_to(12, h / 2 + ext.height / 2 - 2)
        cr.show_text(self._title)
        cr.restore()


# ────────────────────────────────────────────────────────────────────────────
# Tool palette grid (vertical strip of toggle SketchButtons)
# ────────────────────────────────────────────────────────────────────────────

class ToolPalette(Gtk.Box):
    def __init__(self, tools: list[tuple[str, str, Callable[[str], None]]],
                 columns: int = 2):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        grid = Gtk.Grid()
        grid.set_row_spacing(4)
        grid.set_column_spacing(4)
        self.buttons: dict[str, SketchButton] = {}
        self._on_select: Callable[[str], None] | None = None
        for i, (key, label, color) in enumerate(tools):
            color_t = color if isinstance(color, tuple) else NYX.get(str(color), NYX["pink"])
            btn = SketchButton(label, color_t, toggleable=True, height=46,
                               width=110, font_size=19)
            btn.set_hexpand(True)
            btn.connect("clicked", lambda b, k=key: self._select(k))
            self.buttons[key] = btn
            grid.attach(btn, i % columns, i // columns, 1, 1)
        grid.set_column_homogeneous(True)
        self.append(grid)

    def on_select(self, fn):
        self._on_select = fn

    def _select(self, key: str):
        for k, b in self.buttons.items():
            b.set_toggled(k == key)
        if self._on_select:
            self._on_select(key)

    def select(self, key: str):
        self._select(key)


# ────────────────────────────────────────────────────────────────────────────
# Tilted titlebar overlay (hand-drawn header for child windows)
# ────────────────────────────────────────────────────────────────────────────

class TiltedHeader(Gtk.DrawingArea):
    def __init__(self, text: str, color=NYX["gold"], height: int = 38, tilt: float = -0.03):
        super().__init__()
        self.text = text
        self.color = color
        self.tilt = tilt
        self.set_size_request(-1, height)
        self.set_draw_func(self._draw)

    def _draw(self, _a, cr, w, h):
        cr.set_source_rgba(0, 0, 0, 0); cr.paint()
        cr.save()
        cr.translate(w / 2, h / 2); cr.rotate(self.tilt); cr.translate(-w / 2, -h / 2)
        c = self.color
        seed = hash(self.text) & 0xFFFF
        sketch_rect_fill(cr, 4, 4, w - 8, h - 8,
                         (c[0] * 0.20, c[1] * 0.20, c[2] * 0.20, 0.92), 2.0, seed=seed)
        sketch_rect(cr, 4, 4, w - 8, h - 8, (*c, 1.0), 2.6, seed=seed,
                    shadow=True, double_stroke=True)
        cr.select_font_face("Inter Display", 0, 1)
        cr.set_font_size(26)
        ext = cr.text_extents(self.text)
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
        cr.move_to(15, h / 2 + ext.height / 2 - 2); cr.show_text(self.text)
        cr.set_source_rgba(0.97, 0.95, 0.99, 1.0)
        cr.move_to(14, h / 2 + ext.height / 2 - 3); cr.show_text(self.text)
        cr.restore()


# ────────────────────────────────────────────────────────────────────────────
# simple text-entry dialog
# ────────────────────────────────────────────────────────────────────────────

def text_entry_dialog(parent, title: str, initial: str = "",
                       on_ok: Callable[[str], None] | None = None) -> None:
    dlg = Gtk.Window(title=title, transient_for=parent, modal=True)
    dlg.set_default_size(360, 120)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin_top=12,
                  margin_bottom=12, margin_start=12, margin_end=12)
    box.append(TiltedHeader(title, NYX["gold"]))
    entry = Gtk.Entry()
    entry.set_text(initial)
    box.append(entry)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8, halign=Gtk.Align.END)
    cancel = SketchButton("cancel", NYX["ink_dim"], width=80, height=32)
    ok = SketchButton("ok", NYX["green"], width=80, height=32)
    row.append(cancel); row.append(ok)
    box.append(row)
    dlg.set_child(box)
    cancel.connect("clicked", lambda *_: dlg.close())
    def _ok(*_):
        if on_ok:
            on_ok(entry.get_text())
        dlg.close()
    ok.connect("clicked", _ok)
    dlg.present()


# ────────────────────────────────────────────────────────────────────────────
# file chooser helpers (GTK4 native)
# ────────────────────────────────────────────────────────────────────────────

def open_file(parent, title: str, on_file: Callable[[str], None],
              filters: list[tuple[str, list[str]]] | None = None) -> None:
    dlg = Gtk.FileDialog()
    dlg.set_title(title)
    if filters:
        flist = Gio.ListStore.new(Gtk.FileFilter)
        for name, patterns in filters:
            f = Gtk.FileFilter()
            f.set_name(name)
            for p in patterns:
                f.add_pattern(p)
            flist.append(f)
        dlg.set_filters(flist)
    def _done(d, result):
        try:
            f = d.open_finish(result)
            if f:
                on_file(f.get_path())
        except Exception:
            pass
    dlg.open(parent, None, _done)


def save_file(parent, title: str, suggested: str,
              on_file: Callable[[str], None]) -> None:
    dlg = Gtk.FileDialog()
    dlg.set_title(title)
    dlg.set_initial_name(suggested)
    def _done(d, result):
        try:
            f = d.save_finish(result)
            if f:
                on_file(f.get_path())
        except Exception:
            pass
    dlg.save(parent, None, _done)


# ────────────────────────────────────────────────────────────────────────────
# native color picker dialog (GTK4)
# ────────────────────────────────────────────────────────────────────────────

def color_picker_dialog(parent, current: tuple[float, float, float],
                        on_pick: Callable[[tuple[float, float, float]], None]) -> None:
    """Show GTK4 native color chooser; calls on_pick(rgb) on confirm."""
    try:
        dlg = Gtk.ColorDialog()
        dlg.set_title("Pick Color")
        dlg.set_with_alpha(False)
        rgba = Gdk.RGBA()
        rgba.red, rgba.green, rgba.blue, rgba.alpha = (*current[:3], 1.0)
        def _done(d, result):
            try:
                col = d.choose_rgba_finish(result)
                if col is not None:
                    on_pick((col.red, col.green, col.blue))
            except Exception:
                pass
        dlg.choose_rgba(parent, rgba, None, _done)
    except Exception:
        # graceful fallback if Gtk.ColorDialog is unavailable
        on_pick(current)


# ────────────────────────────────────────────────────────────────────────────
# styled dropdown helper (Gtk.DropDown of strings)
# ────────────────────────────────────────────────────────────────────────────

class SketchDropDown(Gtk.Box):
    """Labelled GTK dropdown that fits the NYX visual language."""

    def __init__(self, label: str, options: list[str], current: str | None = None,
                 on_change: Callable[[str], None] | None = None,
                 color=NYX["pink"]):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.options = list(options)
        self.on_change = on_change

        title = Gtk.Label(label=label, xalign=0.0)
        title.add_css_class("nyx-faint")
        self.append(title)

        model = Gtk.StringList.new(self.options)
        self.dd = Gtk.DropDown(model=model)
        self.dd.set_hexpand(True)
        if current and current in self.options:
            self.dd.set_selected(self.options.index(current))
        self.dd.connect("notify::selected", self._on_sel)
        self.append(self.dd)

    def _on_sel(self, *_):
        idx = self.dd.get_selected()
        if 0 <= idx < len(self.options) and self.on_change:
            self.on_change(self.options[idx])

    def set_value(self, value: str) -> None:
        if value in self.options:
            self.dd.set_selected(self.options.index(value))
