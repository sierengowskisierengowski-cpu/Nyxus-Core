"""
NYXUS Studio — 3D engine.
© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED

Mesh primitives, mesh editing (extrude/bevel/inset/subdivide), modifiers
(mirror/array/solidify/boolean/decimate), and an OBJ/STL/PLY/GLTF exporter.

Geometry stored as (vertices Nx3 float32, faces Mx3 int32) for triangle
meshes. Quad meshes are auto-triangulated on load.

Hard rendering happens on the GTK4 GLArea (modules/m03_3d.py); this file
is the math + topology + i/o layer.
"""
from __future__ import annotations

import math
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

try:
    import numpy as np
except Exception:
    np = None

try:
    import trimesh
    HAVE_TRIMESH = True
except Exception:
    trimesh = None
    HAVE_TRIMESH = False


# ────────────────────────────────────────────────────────────────────────────
# primitives
# ────────────────────────────────────────────────────────────────────────────

def primitive_cube(size: float = 1.0):
    if np is None:
        return None, None
    s = size / 2
    v = np.array([
        [-s, -s, -s], [s, -s, -s], [s, s, -s], [-s, s, -s],
        [-s, -s,  s], [s, -s,  s], [s, s,  s], [-s, s,  s],
    ], dtype=np.float32)
    f = np.array([
        [0, 1, 2], [0, 2, 3],
        [4, 5, 6], [4, 6, 7],
        [0, 1, 5], [0, 5, 4],
        [2, 3, 7], [2, 7, 6],
        [1, 2, 6], [1, 6, 5],
        [0, 3, 7], [0, 7, 4],
    ], dtype=np.int32)
    return v, f


def primitive_plane(size: float = 1.0):
    if np is None:
        return None, None
    s = size / 2
    v = np.array([[-s, 0, -s], [s, 0, -s], [s, 0, s], [-s, 0, s]],
                 dtype=np.float32)
    f = np.array([[0, 1, 2], [0, 2, 3]], dtype=np.int32)
    return v, f


def primitive_sphere(radius: float = 1.0, lat: int = 16, lon: int = 24):
    if np is None:
        return None, None
    verts = []
    for i in range(lat + 1):
        theta = math.pi * i / lat
        for j in range(lon):
            phi = 2 * math.pi * j / lon
            x = radius * math.sin(theta) * math.cos(phi)
            y = radius * math.cos(theta)
            z = radius * math.sin(theta) * math.sin(phi)
            verts.append((x, y, z))
    faces = []
    for i in range(lat):
        for j in range(lon):
            a = i * lon + j
            b = i * lon + (j + 1) % lon
            c = (i + 1) * lon + (j + 1) % lon
            d = (i + 1) * lon + j
            faces.append((a, b, c))
            faces.append((a, c, d))
    return (np.array(verts, dtype=np.float32),
            np.array(faces, dtype=np.int32))


def primitive_cylinder(radius: float = 0.5, height: float = 1.0, seg: int = 24):
    if np is None:
        return None, None
    h = height / 2
    verts = [(0, h, 0), (0, -h, 0)]
    for i in range(seg):
        a = 2 * math.pi * i / seg
        x = radius * math.cos(a)
        z = radius * math.sin(a)
        verts.append((x, h, z))
        verts.append((x, -h, z))
    faces = []
    for i in range(seg):
        top1 = 2 + i * 2
        top2 = 2 + ((i + 1) % seg) * 2
        bot1 = top1 + 1
        bot2 = top2 + 1
        faces.append((top1, top2, bot2))
        faces.append((top1, bot2, bot1))
        faces.append((0, top2, top1))
        faces.append((1, bot1, bot2))
    return (np.array(verts, dtype=np.float32),
            np.array(faces, dtype=np.int32))


def primitive_cone(radius: float = 0.5, height: float = 1.0, seg: int = 24):
    if np is None:
        return None, None
    h = height / 2
    verts = [(0, h, 0), (0, -h, 0)]
    for i in range(seg):
        a = 2 * math.pi * i / seg
        verts.append((radius * math.cos(a), -h, radius * math.sin(a)))
    faces = []
    for i in range(seg):
        b1 = 2 + i
        b2 = 2 + ((i + 1) % seg)
        faces.append((0, b1, b2))
        faces.append((1, b2, b1))
    return (np.array(verts, dtype=np.float32),
            np.array(faces, dtype=np.int32))


def primitive_torus(major: float = 1.0, minor: float = 0.3,
                    rseg: int = 24, mseg: int = 16):
    if np is None:
        return None, None
    verts = []
    for i in range(rseg):
        u = 2 * math.pi * i / rseg
        for j in range(mseg):
            v = 2 * math.pi * j / mseg
            x = (major + minor * math.cos(v)) * math.cos(u)
            y = minor * math.sin(v)
            z = (major + minor * math.cos(v)) * math.sin(u)
            verts.append((x, y, z))
    faces = []
    for i in range(rseg):
        for j in range(mseg):
            a = i * mseg + j
            b = ((i + 1) % rseg) * mseg + j
            c = ((i + 1) % rseg) * mseg + (j + 1) % mseg
            d = i * mseg + (j + 1) % mseg
            faces.append((a, b, c))
            faces.append((a, c, d))
    return (np.array(verts, dtype=np.float32),
            np.array(faces, dtype=np.int32))


def primitive_icosphere(radius: float = 1.0, subdivisions: int = 2):
    if np is None:
        return None, None
    t = (1.0 + math.sqrt(5.0)) / 2.0
    verts = [
        (-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0),
        (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t),
        (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1),
    ]
    faces = [
        (0, 11, 5), (0, 5, 1), (0, 1, 7), (0, 7, 10), (0, 10, 11),
        (1, 5, 9), (5, 11, 4), (11, 10, 2), (10, 7, 6), (7, 1, 8),
        (3, 9, 4), (3, 4, 2), (3, 2, 6), (3, 6, 8), (3, 8, 9),
        (4, 9, 5), (2, 4, 11), (6, 2, 10), (8, 6, 7), (9, 8, 1),
    ]
    v_arr = np.array(verts, dtype=np.float32)
    f_arr = np.array(faces, dtype=np.int32)
    for _ in range(max(0, subdivisions)):
        v_arr, f_arr = subdivide_loop(v_arr, f_arr)
    # normalize to sphere
    norms = np.linalg.norm(v_arr, axis=1, keepdims=True) + 1e-9
    v_arr = (v_arr / norms * radius).astype(np.float32)
    return v_arr, f_arr


def primitive_monkey():
    """A low-poly stylized 'face' built procedurally."""
    return primitive_icosphere(radius=1.0, subdivisions=1)


# ────────────────────────────────────────────────────────────────────────────
# normals + bounds
# ────────────────────────────────────────────────────────────────────────────

def face_normals(v, f):
    if np is None or v is None or f is None or len(f) == 0:
        return None
    a = v[f[:, 0]]
    b = v[f[:, 1]]
    c = v[f[:, 2]]
    n = np.cross(b - a, c - a)
    nn = np.linalg.norm(n, axis=1, keepdims=True) + 1e-9
    return (n / nn).astype(np.float32)


def vertex_normals(v, f):
    if np is None or v is None or f is None:
        return None
    fn = face_normals(v, f)
    out = np.zeros_like(v)
    for i, tri in enumerate(f):
        for k in range(3):
            out[tri[k]] += fn[i]
    nn = np.linalg.norm(out, axis=1, keepdims=True) + 1e-9
    return (out / nn).astype(np.float32)


# ────────────────────────────────────────────────────────────────────────────
# topology editing
# ────────────────────────────────────────────────────────────────────────────

def subdivide_loop(v, f):
    """One iteration of (simplified) Loop subdivision."""
    if np is None or v is None or f is None:
        return v, f
    edge_to_mid: dict[tuple[int, int], int] = {}
    new_v = list(map(tuple, v.tolist()))
    new_f = []

    def midpoint(a: int, b: int) -> int:
        key = (a, b) if a < b else (b, a)
        if key in edge_to_mid:
            return edge_to_mid[key]
        mp = ((v[a] + v[b]) / 2.0).tolist()
        idx = len(new_v)
        new_v.append(tuple(mp))
        edge_to_mid[key] = idx
        return idx

    for tri in f:
        a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
        ab = midpoint(a, b)
        bc = midpoint(b, c)
        ca = midpoint(c, a)
        new_f.append((a, ab, ca))
        new_f.append((b, bc, ab))
        new_f.append((c, ca, bc))
        new_f.append((ab, bc, ca))
    return (np.array(new_v, dtype=np.float32),
            np.array(new_f, dtype=np.int32))


def extrude_faces(v, f, face_indices: list[int], distance: float = 0.5):
    """Extrude the given faces along their normal by `distance`."""
    if np is None:
        return v, f
    fn = face_normals(v, f)
    new_v = v.tolist()
    new_f = f.tolist()
    for fi in face_indices:
        if fi < 0 or fi >= len(f):
            continue
        normal = fn[fi]
        old_tri = f[fi].tolist()
        new_idx = []
        for vi in old_tri:
            new_p = (v[vi] + normal * distance).tolist()
            new_v.append(new_p)
            new_idx.append(len(new_v) - 1)
        new_f[fi] = new_idx
        for k in range(3):
            a = old_tri[k]
            b = old_tri[(k + 1) % 3]
            na = new_idx[k]
            nb = new_idx[(k + 1) % 3]
            new_f.append([a, b, nb])
            new_f.append([a, nb, na])
    return (np.array(new_v, dtype=np.float32),
            np.array(new_f, dtype=np.int32))


def bevel_edges(v, f, amount: float = 0.05):
    """Cheap bevel: shrink every face slightly toward its centroid + add quads.
    Approximation suitable for visual feedback."""
    if np is None:
        return v, f
    new_v = v.tolist()
    new_f = []
    for tri in f:
        a, b, c = v[tri[0]], v[tri[1]], v[tri[2]]
        cen = (a + b + c) / 3.0
        ai = len(new_v); new_v.append((a + (cen - a) * amount).tolist())
        bi = len(new_v); new_v.append((b + (cen - b) * amount).tolist())
        ci = len(new_v); new_v.append((c + (cen - c) * amount).tolist())
        new_f.append([ai, bi, ci])
        new_f.append([int(tri[0]), int(tri[1]), bi])
        new_f.append([int(tri[0]), bi, ai])
        new_f.append([int(tri[1]), int(tri[2]), ci])
        new_f.append([int(tri[1]), ci, bi])
        new_f.append([int(tri[2]), int(tri[0]), ai])
        new_f.append([int(tri[2]), ai, ci])
    return (np.array(new_v, dtype=np.float32),
            np.array(new_f, dtype=np.int32))


def inset_faces(v, f, face_indices: list[int], amount: float = 0.15):
    if np is None:
        return v, f
    new_v = v.tolist()
    new_f = f.tolist()
    for fi in face_indices:
        if fi < 0 or fi >= len(f):
            continue
        old = f[fi].tolist()
        a, b, c = v[old[0]], v[old[1]], v[old[2]]
        cen = (a + b + c) / 3.0
        ai = len(new_v); new_v.append((a + (cen - a) * amount).tolist())
        bi = len(new_v); new_v.append((b + (cen - b) * amount).tolist())
        ci = len(new_v); new_v.append((c + (cen - c) * amount).tolist())
        new_f[fi] = [ai, bi, ci]
        new_f.append([old[0], old[1], bi])
        new_f.append([old[0], bi, ai])
        new_f.append([old[1], old[2], ci])
        new_f.append([old[1], ci, bi])
        new_f.append([old[2], old[0], ai])
        new_f.append([old[2], ai, ci])
    return (np.array(new_v, dtype=np.float32),
            np.array(new_f, dtype=np.int32))


def merge_close_vertices(v, f, eps: float = 1e-4):
    if np is None:
        return v, f
    rounded = np.round(v / eps).astype(np.int64)
    keys = [tuple(r) for r in rounded.tolist()]
    table: dict[tuple, int] = {}
    remap = np.zeros(len(v), dtype=np.int64)
    new_v = []
    for i, k in enumerate(keys):
        if k in table:
            remap[i] = table[k]
        else:
            table[k] = len(new_v)
            remap[i] = len(new_v)
            new_v.append(v[i])
    new_f = remap[f]
    return np.array(new_v, dtype=np.float32), new_f.astype(np.int32)


# ────────────────────────────────────────────────────────────────────────────
# modifiers
# ────────────────────────────────────────────────────────────────────────────

def mod_mirror(v, f, axis: int = 0):
    if np is None:
        return v, f
    flipped = v.copy()
    flipped[:, axis] *= -1
    new_v = np.concatenate([v, flipped], axis=0).astype(np.float32)
    offset = len(v)
    flipped_f = f[:, [0, 2, 1]] + offset    # reverse winding
    new_f = np.concatenate([f, flipped_f], axis=0).astype(np.int32)
    return merge_close_vertices(new_v, new_f)


def mod_array(v, f, count: int = 3, offset=(2.2, 0, 0)):
    if np is None:
        return v, f
    count = max(1, int(count))
    off = np.array(offset, dtype=np.float32)
    parts_v = [v + off * i for i in range(count)]
    parts_f = [f + i * len(v) for i in range(count)]
    return (np.concatenate(parts_v, axis=0).astype(np.float32),
            np.concatenate(parts_f, axis=0).astype(np.int32))


def mod_solidify(v, f, thickness: float = 0.05):
    """Add an inner shell offset by -thickness along vertex normals."""
    if np is None:
        return v, f
    n = vertex_normals(v, f)
    inner = (v - n * thickness).astype(np.float32)
    new_v = np.concatenate([v, inner], axis=0)
    inner_f = f[:, [0, 2, 1]] + len(v)
    new_f = np.concatenate([f, inner_f], axis=0).astype(np.int32)
    return new_v, new_f


def mod_subdivide(v, f, levels: int = 1):
    for _ in range(max(0, int(levels))):
        v, f = subdivide_loop(v, f)
    return v, f


def mod_decimate(v, f, ratio: float = 0.5):
    """Decimate by trimesh if available; otherwise drop random triangles."""
    if HAVE_TRIMESH and v is not None:
        try:
            mesh = trimesh.Trimesh(vertices=v, faces=f, process=False)
            target = max(8, int(len(f) * max(0.05, min(0.95, ratio))))
            simp = mesh.simplify_quadric_decimation(target)
            return (np.asarray(simp.vertices, dtype=np.float32),
                    np.asarray(simp.faces, dtype=np.int32))
        except Exception:
            pass
    if np is None:
        return v, f
    keep = max(1, int(len(f) * max(0.05, min(0.95, ratio))))
    idx = np.random.choice(len(f), keep, replace=False)
    return v, f[idx].astype(np.int32)


def mod_boolean(v1, f1, v2, f2, op: str = "union"):
    """Boolean op via trimesh + manifold/blender backend (best available)."""
    if not HAVE_TRIMESH:
        return v1, f1
    try:
        a = trimesh.Trimesh(vertices=v1, faces=f1, process=True)
        b = trimesh.Trimesh(vertices=v2, faces=f2, process=True)
        if op == "union":
            r = a.union(b)
        elif op == "difference":
            r = a.difference(b)
        elif op == "intersection":
            r = a.intersection(b)
        else:
            return v1, f1
        if r is None or not hasattr(r, "vertices"):
            return v1, f1
        return (np.asarray(r.vertices, dtype=np.float32),
                np.asarray(r.faces, dtype=np.int32))
    except Exception:
        return v1, f1


# ────────────────────────────────────────────────────────────────────────────
# i/o — obj / stl / ply / gltf  (read + write)
# ────────────────────────────────────────────────────────────────────────────

def export_obj(path: str, v, f, name: str = "mesh") -> bool:
    if np is None or v is None:
        return False
    lines = [f"o {name}"]
    for vert in v:
        lines.append(f"v {vert[0]:.6f} {vert[1]:.6f} {vert[2]:.6f}")
    for tri in f:
        lines.append(f"f {tri[0]+1} {tri[1]+1} {tri[2]+1}")
    Path(path).write_text("\n".join(lines))
    return True


def import_obj(path: str):
    if np is None or not Path(path).exists():
        return None, None
    verts = []
    faces = []
    for raw in Path(path).read_text().splitlines():
        if raw.startswith("v "):
            parts = raw.split()
            verts.append([float(parts[1]), float(parts[2]), float(parts[3])])
        elif raw.startswith("f "):
            parts = raw.split()[1:]
            ids = [int(p.split("/")[0]) - 1 for p in parts]
            for k in range(1, len(ids) - 1):
                faces.append([ids[0], ids[k], ids[k + 1]])
    if not verts:
        return None, None
    return (np.array(verts, dtype=np.float32),
            np.array(faces, dtype=np.int32))


def export_stl(path: str, v, f) -> bool:
    if HAVE_TRIMESH and v is not None:
        try:
            trimesh.Trimesh(vertices=v, faces=f, process=False).export(path)
            return True
        except Exception:
            pass
    if np is None:
        return False
    fn = face_normals(v, f)
    lines = ["solid mesh"]
    for i, tri in enumerate(f):
        n = fn[i]
        lines.append(f"  facet normal {n[0]:.6f} {n[1]:.6f} {n[2]:.6f}")
        lines.append("    outer loop")
        for k in range(3):
            p = v[tri[k]]
            lines.append(f"      vertex {p[0]:.6f} {p[1]:.6f} {p[2]:.6f}")
        lines.append("    endloop")
        lines.append("  endfacet")
    lines.append("endsolid mesh")
    Path(path).write_text("\n".join(lines))
    return True


def export_ply(path: str, v, f) -> bool:
    if HAVE_TRIMESH and v is not None:
        try:
            trimesh.Trimesh(vertices=v, faces=f, process=False).export(path)
            return True
        except Exception:
            pass
    if np is None:
        return False
    head = [
        "ply", "format ascii 1.0",
        f"element vertex {len(v)}",
        "property float x", "property float y", "property float z",
        f"element face {len(f)}",
        "property list uchar int vertex_indices",
        "end_header",
    ]
    body = [f"{p[0]:.6f} {p[1]:.6f} {p[2]:.6f}" for p in v]
    body += [f"3 {tri[0]} {tri[1]} {tri[2]}" for tri in f]
    Path(path).write_text("\n".join(head + body))
    return True


def export_gltf(path: str, v, f) -> bool:
    if not HAVE_TRIMESH or v is None:
        return False
    try:
        trimesh.Trimesh(vertices=v, faces=f, process=False).export(path)
        return True
    except Exception:
        return False


# ────────────────────────────────────────────────────────────────────────────
# camera math
# ────────────────────────────────────────────────────────────────────────────

def view_matrix(yaw: float, pitch: float, dist: float):
    if np is None:
        return None
    cy, sy = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)
    eye = np.array([dist * cp * sy, dist * sp, dist * cp * cy], dtype=np.float32)
    target = np.zeros(3, dtype=np.float32)
    up = np.array([0, 1, 0], dtype=np.float32)
    f = (target - eye); f /= (np.linalg.norm(f) + 1e-9)
    s = np.cross(f, up); s /= (np.linalg.norm(s) + 1e-9)
    u = np.cross(s, f)
    M = np.eye(4, dtype=np.float32)
    M[0, :3] = s
    M[1, :3] = u
    M[2, :3] = -f
    M[0, 3] = -np.dot(s, eye)
    M[1, 3] = -np.dot(u, eye)
    M[2, 3] = np.dot(f, eye)
    return M


def projection_matrix(fov: float, aspect: float, near: float = 0.1, far: float = 100.0):
    if np is None:
        return None
    f = 1.0 / math.tan(math.radians(fov) / 2.0)
    M = np.zeros((4, 4), dtype=np.float32)
    M[0, 0] = f / aspect
    M[1, 1] = f
    M[2, 2] = (far + near) / (near - far)
    M[2, 3] = (2 * far * near) / (near - far)
    M[3, 2] = -1
    return M
