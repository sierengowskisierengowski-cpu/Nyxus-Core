#!/usr/bin/env python3
"""NYXUS Studio — modular design suite.

Eight modules: Paint · Vector · 3D · Video · Animate · Photo · Layout · Type.
Modules live in ./modules/ and are loaded dynamically by importlib.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import importlib
import logging
import os
import sys
from pathlib import Path

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib, GObject  # noqa: E402
import cairo  # noqa: E402

# locate ourselves on path so `from document import …` and `import modules.*` work
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

# add shared NYXUS theme search paths
for p in (Path("/usr/share/nyxus/theme"),
          Path("/usr/local/share/nyxus/theme"),
          Path.home() / ".local/share/nyxus/theme",
          HERE.parent / "theme"):
    if p.exists():
        sys.path.insert(0, str(p))

try:
    from nyxus_theme import apply_theme as _apply_shared_theme
except Exception:
    _apply_shared_theme = None

from document import Document  # noqa: E402
from ui import (SketchButton, build_studio_css,  # noqa: E402
                NEON_PINK, NEON_BLUE, NEON_GREEN, INK_DIM)

APP_ID = "com.nyxus.studio"
APP_NAME = "NYXUS Studio"
WIN_W, WIN_H = 1400, 900

logging.basicConfig(
    level=os.environ.get("NYXUS_LOG", "INFO"),
    format="%(asctime)s [%(levelname)s] nyxus-studio: %(message)s")
log = logging.getLogger("nyxus-studio")

MODULES_ORDER = [
    "m01_paint", "m02_vector", "m03_3d", "m04_video",
    "m05_animate", "m06_photo", "m07_layout", "m08_type",
]


# ── module rail button ───────────────────────────────────────────────────────
class ModuleRailButton(Gtk.DrawingArea):
    __gsignals__ = {"clicked": (GObject.SignalFlags.RUN_FIRST, None, ())}

    def __init__(self, module):
        super().__init__()
        self.module = module
        w, h = 56, 60
        self.set_size_request(w, h)
        try:
            self.set_content_width(w); self.set_content_height(h)
        except Exception:
            pass
        self._hover = False
        self._active = False
        self.set_draw_func(self._draw)
        desc = getattr(module, "DESC", "")
        enabled = getattr(module, "ENABLED", True)
        tip = f"{module.TITLE} — {desc}"
        if not enabled:
            tip += "\n(coming soon)"
        self.set_tooltip_text(tip)
        self.set_cursor(Gdk.Cursor.new_from_name("pointer"))
        gc = Gtk.GestureClick()
        gc.set_button(1)
        gc.connect("released", lambda *a: self.emit("clicked"))
        self.add_controller(gc)
        mc = Gtk.EventControllerMotion()
        mc.connect("enter", lambda *a: (setattr(self, "_hover", True),
                                        self.queue_draw()))
        mc.connect("leave", lambda *a: (setattr(self, "_hover", False),
                                        self.queue_draw()))
        self.add_controller(mc)

    def set_active(self, on: bool):
        if self._active != on:
            self._active = on
            self.queue_draw()

    def _draw(self, area, cr, w, h, _=None):
        from gi.repository import Pango, PangoCairo
        c = self.module.ACCENT
        enabled = getattr(self.module, "ENABLED", True)
        if self._active:
            cr.set_source_rgba(*c, 0.20)
            cr.rectangle(2, 2, w - 4, h - 4); cr.fill()
        elif self._hover:
            cr.set_source_rgba(*c, 0.10)
            cr.rectangle(2, 2, w - 4, h - 4); cr.fill()
        if self._active:
            cr.set_source_rgba(*c, 0.95)
            cr.rectangle(0, 4, 3, h - 8); cr.fill()
        # glyph
        layout = PangoCairo.create_layout(cr)
        fd = Pango.FontDescription()
        fd.set_size(int(22 * Pango.SCALE))
        layout.set_font_description(fd)
        layout.set_text(getattr(self.module, "GLYPH", "?"), -1)
        tw, th = layout.get_pixel_size()
        if enabled:
            cr.set_source_rgba(*c,
                               1.0 if self._active else
                               (0.85 if self._hover else 0.72))
        else:
            cr.set_source_rgba(0.5, 0.45, 0.55, 0.45)
        cr.move_to((w - tw) / 2, (h - th) / 2 - 6)
        PangoCairo.show_layout(cr, layout)
        # tiny caption
        layout = PangoCairo.create_layout(cr)
        fd = Pango.FontDescription()
        fd.set_family("Caveat")
        fd.set_size(int(10 * Pango.SCALE))
        layout.set_font_description(fd)
        layout.set_text(self.module.TITLE.lower(), -1)
        tw, th = layout.get_pixel_size()
        cr.set_source_rgba(0.92, 0.88, 0.96,
                           0.78 if enabled else 0.42)
        cr.move_to((w - tw) / 2, h - th - 4)
        PangoCairo.show_layout(cr, layout)


# ── main window ──────────────────────────────────────────────────────────────
class StudioWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app, title=APP_NAME)
        self.set_default_size(WIN_W, WIN_H)
        self.modules = {}
        self.module_keys = []
        self.active_module_key = None
        self.document = Document(1200, 800, "Untitled")
        self._setup_css()
        self._load_modules()
        self._build_ui()
        if self.module_keys:
            # default to the first ENABLED module
            for k in self.module_keys:
                if getattr(self.modules[k], "ENABLED", True):
                    self.activate_module(k)
                    break
            else:
                self.activate_module(self.module_keys[0])

    def _setup_css(self):
        if _apply_shared_theme:
            try:
                _apply_shared_theme(Gdk.Display.get_default())
            except Exception as e:
                log.warning("shared theme: %s", e)
        prov = Gtk.CssProvider()
        css = build_studio_css().encode()
        try:
            prov.load_from_data(css)
        except TypeError:
            prov.load_from_data(css.decode())
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), prov,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 10)

    def _load_modules(self):
        for key in MODULES_ORDER:
            try:
                mod = importlib.import_module(f"modules.{key}")
                cls = getattr(mod, "Module", None)
                if not cls:
                    log.warning("module %s has no Module class", key)
                    continue
                instance = cls(self)
                self.modules[cls.KEY] = instance
                self.module_keys.append(cls.KEY)
                log.info("loaded module: %s", cls.KEY)
            except Exception as e:
                log.error("failed to load %s: %s", key, e)

    def _build_ui(self):
        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.set_child(root)

        # ── left rail ──
        rail = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        rail.add_css_class("nyx-studio-rail")
        rail.set_margin_top(8); rail.set_margin_bottom(8)
        rail.set_margin_start(6); rail.set_margin_end(6)
        rail.set_size_request(64, -1)
        root.append(rail)
        for key in self.module_keys:
            m = self.modules[key]
            btn = ModuleRailButton(m)
            btn.connect("clicked", lambda b, k=key: self.activate_module(k))
            m._rail_btn = btn
            rail.append(btn)
        sp = Gtk.Box(); sp.set_vexpand(True); rail.append(sp)
        logo = Gtk.Label(label="N\nY\nX")
        logo.add_css_class("nyx-studio-logo")
        rail.append(logo)

        # ── main column ──
        main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        main.set_hexpand(True)
        root.append(main)

        # header
        header = Gtk.Box(spacing=10)
        header.add_css_class("nyx-studio-header")
        header.set_margin_start(14); header.set_margin_end(10)
        header.set_margin_top(4); header.set_margin_bottom(4)
        main.append(header)
        self.title_lbl = Gtk.Label(label=APP_NAME)
        self.title_lbl.add_css_class("nyx-studio-headline")
        header.append(self.title_lbl)
        sep = Gtk.Label(label="·"); sep.add_css_class("nyx-meta")
        header.append(sep)
        self.module_lbl = Gtk.Label(label="")
        self.module_lbl.add_css_class("nyx-studio-module-lbl")
        header.append(self.module_lbl)
        # tools area populated by active module
        self.tools_box = Gtk.Box(spacing=6)
        self.tools_box.set_hexpand(True)
        self.tools_box.set_margin_start(20)
        header.append(self.tools_box)
        # right-side controls
        new_btn = SketchButton("new", width=56, height=26, color=NEON_BLUE)
        new_btn.connect("clicked", lambda *_: self._on_new())
        header.append(new_btn)
        save_btn = SketchButton("save", width=60, height=26, color=NEON_GREEN)
        save_btn.connect("clicked", lambda *_: self._on_save())
        header.append(save_btn)
        export_btn = SketchButton("export", width=80, height=26,
                                  color=NEON_PINK, primary=True)
        export_btn.connect("clicked", lambda *_: self._on_export())
        header.append(export_btn)

        # body: workspace + right panel
        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        body.set_vexpand(True)
        main.append(body)
        self.workspace = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                 spacing=0)
        self.workspace.set_hexpand(True); self.workspace.set_vexpand(True)
        self.workspace.add_css_class("nyx-studio-workspace")
        body.append(self.workspace)
        self.right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                    spacing=0)
        self.right_panel.set_size_request(280, -1)
        self.right_panel.add_css_class("nyx-studio-right")
        body.append(self.right_panel)

        # status bar
        status = Gtk.Box(spacing=12)
        status.add_css_class("nyx-studio-status")
        status.set_margin_start(14); status.set_margin_end(10)
        status.set_margin_top(2); status.set_margin_bottom(2)
        main.append(status)
        self.status_doc = Gtk.Label(
            label=f"{self.document.name}  ·  "
                  f"{self.document.w}×{self.document.h}")
        self.status_doc.add_css_class("nyx-meta")
        status.append(self.status_doc)
        sp = Gtk.Box(); sp.set_hexpand(True); status.append(sp)
        self.status_msg = Gtk.Label(label="ready")
        self.status_msg.add_css_class("nyx-meta")
        status.append(self.status_msg)

    # ── module switching ─
    def activate_module(self, key):
        if key not in self.modules:
            return
        if self.active_module_key == key:
            return
        if self.active_module_key:
            try:
                self.modules[self.active_module_key].on_deactivate()
            except Exception as e:
                log.warning("deactivate %s: %s", self.active_module_key, e)
        self._clear(self.workspace)
        self._clear(self.tools_box)
        self._clear(self.right_panel)
        self.active_module_key = key
        m = self.modules[key]
        self.module_lbl.set_text(m.TITLE)
        for k, mod in self.modules.items():
            if hasattr(mod, "_rail_btn"):
                mod._rail_btn.set_active(k == key)
        try:
            ws = m.build_workspace()
            if ws is not None:
                self.workspace.append(ws)
        except Exception as e:
            log.error("workspace: %s", e)
        try:
            tools = m.build_top_tools()
            if tools is not None:
                self.tools_box.append(tools)
        except Exception as e:
            log.error("top tools: %s", e)
        try:
            right = m.build_right_panel()
            if right is not None:
                self.right_panel.append(right)
        except Exception as e:
            log.error("right panel: %s", e)
        try:
            m.on_activate()
        except Exception as e:
            log.warning("activate: %s", e)
        self._refresh_status()

    def _clear(self, box):
        c = box.get_first_child()
        while c:
            n = c.get_next_sibling()
            box.remove(c)
            c = n

    def set_status(self, msg: str):
        self.status_msg.set_text(msg)

    def _refresh_status(self):
        self.status_doc.set_text(
            f"{self.document.name}  ·  "
            f"{self.document.w}×{self.document.h}  ·  "
            f"{len(self.document.layers)} layers")

    # ── file ops ──
    def _on_new(self):
        self.document = Document(1200, 800, "Untitled")
        # let the active module re-init against the new doc
        cur = self.active_module_key
        self.active_module_key = None
        for m in self.modules.values():
            try:
                m.doc = self.document
            except Exception:
                pass
        if cur:
            self.activate_module(cur)
        self.set_status("new document")
        self._refresh_status()

    def _on_save(self):
        m = self.modules.get(self.active_module_key)
        if m and hasattr(m, "save_native"):
            try:
                m.save_native()
            except Exception as e:
                log.error("save: %s", e)
                self.set_status(f"save failed: {e}")

    def _on_export(self):
        m = self.modules.get(self.active_module_key)
        if m and hasattr(m, "export"):
            try:
                m.export()
            except Exception as e:
                log.error("export: %s", e)
                self.set_status(f"export failed: {e}")
        else:
            p = Path.home() / f"{self.document.name}.png"
            self.document.export_png(str(p))
            self.set_status(f"exported → {p}")


class StudioApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID)

    def do_activate(self):
        win = self.props.active_window
        if not win:
            win = StudioWindow(self)
        win.present()


def main():
    sys.exit(StudioApp().run(sys.argv))


if __name__ == "__main__":
    main()
