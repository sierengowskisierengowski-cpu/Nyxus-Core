#!/usr/bin/env bash
# ============================================================================
# NYXUS Studio — installer
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
#
#   sudo bash install.sh
# ============================================================================
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    echo "[NYXUS Studio] elevating with sudo …"
    exec sudo -E bash "$0" "$@"
  fi
  echo "ERROR: must be run as root (sudo not available)" >&2
  exit 1
fi

INSTALL_DIR="/opt/nyxus-studio"
THEME_DIR="/usr/share/nyxus/theme"
BIN_LINK="/usr/local/bin/nyxus-studio"
DESKTOP_FILE="/usr/share/applications/nyxus-studio.desktop"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "──────────────────────────────────────────────────────────────"
echo "  NYXUS Studio · install"
echo "──────────────────────────────────────────────────────────────"

echo "[1/6] system packages …"
if [[ -f "$HERE/packages.txt" ]]; then
  if command -v pacman >/dev/null 2>&1; then
    pacman -Sy --needed --noconfirm $(grep -v '^#' "$HERE/packages.txt" | grep -v '^$' | tr '\n' ' ') || true
  elif command -v apt-get >/dev/null 2>&1; then
    apt-get update
    apt-get install -y $(grep -v '^#' "$HERE/packages.txt" | grep -v '^$' | tr '\n' ' ') || true
  fi
fi

echo "[2/6] python deps …"
python3 -m pip install --break-system-packages --quiet \
    -r "$HERE/requirements.txt" 2>/dev/null || \
python3 -m pip install --quiet -r "$HERE/requirements.txt" || true

echo "[3/6] install app …"
mkdir -p "$INSTALL_DIR/modules"
install -m 0755 "$HERE/main.py"             "$INSTALL_DIR/main.py"
install -m 0644 "$HERE/ui.py"               "$INSTALL_DIR/ui.py"
install -m 0644 "$HERE/document.py"         "$INSTALL_DIR/document.py"
install -m 0644 "$HERE/modules/__init__.py" "$INSTALL_DIR/modules/__init__.py"
install -m 0644 "$HERE/modules/"m*.py       "$INSTALL_DIR/modules/"
[[ -f "$HERE/README.md" ]] && install -m 0644 "$HERE/README.md" "$INSTALL_DIR/README.md" || true

echo "[4/6] theme assets …"
mkdir -p "$THEME_DIR"
install -m 0644 "$HERE/../theme/nyxus_theme.css" "$THEME_DIR/nyxus_theme.css" 2>/dev/null \
  || install -m 0644 "$HERE/nyxus_theme.css"     "$THEME_DIR/nyxus_theme.css" 2>/dev/null \
  || echo "  (theme css not in payload — using built-in studio css)"
install -m 0644 "$HERE/../theme/nyxus_theme.py"  "$THEME_DIR/nyxus_theme.py"  2>/dev/null \
  || install -m 0644 "$HERE/nyxus_theme.py"      "$THEME_DIR/nyxus_theme.py"  2>/dev/null || true

echo "[5/6] launcher + .desktop …"
ln -sf "$INSTALL_DIR/main.py" "$BIN_LINK"
chmod +x "$BIN_LINK"
cat > "$DESKTOP_FILE" <<'DESK'
[Desktop Entry]
Type=Application
Name=NYXUS Studio
Comment=Modular design suite — paint, vector, 3D, video, animate
Exec=python3 /opt/nyxus-studio/main.py
Icon=applications-graphics
Terminal=false
Categories=Graphics;2DGraphics;VectorGraphics;
StartupNotify=true
DESK

echo "[6/6] done."
echo
echo "  launch with:   nyxus-studio"
echo "  install dir:   $INSTALL_DIR"
echo "  modules:       Paint · Vector  (active)"
echo "                 3D · Video · Animate · Photo · Layout · Type  (slots wired)"
echo
