#!/usr/bin/env bash
# ============================================================================
#  NYXUS Studio — installer
#  © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
#
#  Installs:
#    /opt/nyxus-studio/                         ← python package
#    /usr/local/bin/nyxus-studio                ← launcher
#    ~/.local/share/applications/nyxus-studio.desktop
#    ~/.local/share/icons/hicolor/512x512/apps/nyxus-studio.png
#
#  System packages (Arch):
#    gtk4, libadwaita, python-gobject, python-cairo, python-numpy, python-pillow
#    ffmpeg (for mp3/mp4 export and recording fallback)
#    ttf-caveat (sketchbook handwriting font for the whole UI)
#  Optional (auto-installed via pip if missing):
#    sounddevice, soundfile, scipy, trimesh
# ============================================================================
set -uo pipefail

if [[ -t 1 ]]; then
  R="\033[0m"; B="\033[1m"; DIM="\033[2m"
  PINK="\033[38;5;213m"; GREEN="\033[38;5;120m"; GOLD="\033[38;5;220m"
  PURPLE="\033[38;5;177m"; RED="\033[38;5;203m"; BLUE="\033[38;5;111m"
else
  R="";B="";DIM="";PINK="";GREEN="";GOLD="";PURPLE="";RED="";BLUE=""
fi
ok()   { printf "  ${GREEN}✓${R}  %s\n" "$*"; }
warn() { printf "  ${GOLD}!${R}  %s\n" "$*"; }
fail() { printf "  ${RED}✗${R}  %s\n" "$*"; }
step() { printf "\n${PURPLE}${B}── %s ──${R}\n" "$*"; }

# resolve invoking user (so user-scope files land in their home)
TARGET_USER="${SUDO_USER:-$USER}"
TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6 || echo "$HOME")"

# self-elevate
if [[ $EUID -ne 0 ]]; then
  if command -v sudo >/dev/null 2>&1; then
    printf "  ${DIM}elevating with sudo (you'll be prompted)…${R}\n\n"
    if [[ -f "$0" && -r "$0" ]]; then
      exec sudo -E bash "$0" "$@"
    else
      fail "must be run as root"; exit 1
    fi
  fi
  fail "must be run as root (sudo not available)"; exit 1
fi

clear 2>/dev/null || true
cat <<EOF
${PINK}${B}
   ███╗   ██╗██╗   ██╗██╗  ██╗██╗   ██╗███████╗
   ████╗  ██║╚██╗ ██╔╝╚██╗██╔╝██║   ██║██╔════╝
   ██╔██╗ ██║ ╚████╔╝  ╚███╔╝ ██║   ██║███████╗
   ██║╚██╗██║  ╚██╔╝   ██╔██╗ ██║   ██║╚════██║
   ██║ ╚████║   ██║   ██╔╝ ██╗╚██████╔╝███████║
   ╚═╝  ╚═══╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚══════╝
${R}${GOLD}                    S T U D I O${R}
${DIM}     paint · vector · 3D · video · animate ·
        photo · layout · type · voice${R}

EOF

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
ok "source: $SRC_DIR"

# ── system packages ─────────────────────────────────────────────────────────
step "system packages"
# required = MUST be installed or we abort; optional = nice-to-have, warn only
REQUIRED_PKGS=(gtk4 libadwaita python-gobject python-cairo python-numpy python-pillow ffmpeg)
OPTIONAL_PKGS=(ttf-caveat)
if command -v pacman >/dev/null 2>&1; then
  # required first
  REQ_MISSING=()
  for p in "${REQUIRED_PKGS[@]}"; do
    pacman -Qi "$p" >/dev/null 2>&1 || REQ_MISSING+=("$p")
  done
  if (( ${#REQ_MISSING[@]} )); then
    printf "  ${DIM}installing required: ${REQ_MISSING[*]}${R}\n"
    pacman -S --noconfirm --needed "${REQ_MISSING[@]}" || true
  fi
  # re-verify required — abort hard on any miss so we don't ship a broken install
  STILL_MISSING=()
  for p in "${REQUIRED_PKGS[@]}"; do
    pacman -Qi "$p" >/dev/null 2>&1 || STILL_MISSING+=("$p")
  done
  if (( ${#STILL_MISSING[@]} )); then
    fail "required packages failed to install: ${STILL_MISSING[*]}"
    fail "fix repo/network and re-run.  aborting."
    exit 1
  fi
  ok "required system packages installed"

  # optional — warn only
  OPT_MISSING=()
  for p in "${OPTIONAL_PKGS[@]}"; do
    pacman -Qi "$p" >/dev/null 2>&1 || OPT_MISSING+=("$p")
  done
  if (( ${#OPT_MISSING[@]} )); then
    printf "  ${DIM}installing optional: ${OPT_MISSING[*]}${R}\n"
    pacman -S --noconfirm --needed "${OPT_MISSING[@]}" >/dev/null 2>&1 \
      || warn "optional packages skipped (UI font may fall back): ${OPT_MISSING[*]}"
  fi
else
  warn "pacman not found — install manually: ${REQUIRED_PKGS[*]} ${OPTIONAL_PKGS[*]}"
fi

# ── optional pip packages (per-user, ignore failures) ───────────────────────
step "optional Python packages"
PIP="$(command -v pip3 || command -v pip || true)"
if [[ -n "$PIP" ]]; then
  for pkg in sounddevice soundfile scipy trimesh; do
    if ! sudo -u "$TARGET_USER" python3 -c "import ${pkg/-/_}" >/dev/null 2>&1; then
      printf "  ${DIM}pip install --user ${pkg}…${R}\n"
      sudo -u "$TARGET_USER" "$PIP" install --user --break-system-packages "$pkg" \
        >/dev/null 2>&1 \
        || sudo -u "$TARGET_USER" "$PIP" install --user "$pkg" >/dev/null 2>&1 \
        || warn "${pkg} not installed (feature degraded)"
    fi
  done
  ok "python extras attempted"
else
  warn "pip not found — sounddevice/soundfile/scipy/trimesh skipped"
fi

# ── deploy the python package ───────────────────────────────────────────────
step "deploy"
INSTALL_DIR="/opt/nyxus-studio"
mkdir -p "$INSTALL_DIR"
rm -rf "$INSTALL_DIR/studio"
cp -r "$SRC_DIR/studio" "$INSTALL_DIR/studio"
chmod -R a+rX "$INSTALL_DIR"
ok "installed → $INSTALL_DIR"

# ── launcher ────────────────────────────────────────────────────────────────
LAUNCHER="/usr/local/bin/nyxus-studio"
cat > "$LAUNCHER" <<'LAUNCH'
#!/usr/bin/env bash
# NYXUS Studio launcher
export PYTHONPATH="/opt/nyxus-studio:${PYTHONPATH:-}"
export NYXUS_STUDIO_HOME="/opt/nyxus-studio"
# force libadwaita's bundled theme so a stale @import in the user's
# ~/.config/gtk-4.0/gtk.css can't trigger "resource not found" warnings
export GTK_THEME="${GTK_THEME:-Adwaita:dark}"
# silence noisy non-fatal GTK warnings unless user opted in via NYXUS_DEBUG
if [[ -z "${NYXUS_DEBUG:-}" ]]; then
  exec python3 -m studio.main "$@" 2> >(grep -vE "Theme parser error|gtk-dark\.css|adwaita.*does not exist" >&2)
else
  exec python3 -m studio.main "$@"
fi
LAUNCH
chmod 0755 "$LAUNCHER"
ok "launcher → $LAUNCHER"

# ── icon ────────────────────────────────────────────────────────────────────
ICON_DIR="$TARGET_HOME/.local/share/icons/hicolor/512x512/apps"
sudo -u "$TARGET_USER" mkdir -p "$ICON_DIR"
ICON_PATH="$ICON_DIR/nyxus-studio.png"
if [[ -f "$SRC_DIR/icons/nyxus-studio.png" ]]; then
  install -m 0644 -o "$TARGET_USER" -g "$(id -gn "$TARGET_USER")" \
    "$SRC_DIR/icons/nyxus-studio.png" "$ICON_PATH"
  ok "icon → $ICON_PATH"
else
  # generate a paint-splatter studio icon if pillow is present
  sudo -u "$TARGET_USER" python3 - "$ICON_PATH" <<'PY' 2>/dev/null || true
import sys
try:
    from PIL import Image, ImageDraw, ImageFont
    import math, random
except Exception:
    sys.exit(0)
out = sys.argv[1]
W = 512
img = Image.new("RGBA", (W, W), (10, 10, 18, 255))
d = ImageDraw.Draw(img, "RGBA")
random.seed(42)
colors = [(255, 60, 165), (255, 215, 50), (110, 230, 130), (110, 195, 255), (190, 130, 255)]
for c in colors:
    cx = random.randint(120, 392); cy = random.randint(120, 392)
    r = random.randint(60, 130)
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(*c, 220))
    for _ in range(20):
        a = random.uniform(0, math.pi * 2)
        rr = random.randint(40, 200)
        x = int(cx + math.cos(a) * rr); y = int(cy + math.sin(a) * rr)
        sz = random.randint(8, 22)
        d.ellipse((x - sz, y - sz, x + sz, y + sz), fill=(*c, 200))
try:
    f = ImageFont.truetype("/usr/share/fonts/TTF/Caveat-Bold.ttf", 240)
except Exception:
    try:
        f = ImageFont.truetype("DejaVuSans-Bold", 240)
    except Exception:
        f = ImageFont.load_default()
txt = "S"
bb = d.textbbox((0, 0), txt, font=f)
tw = bb[2] - bb[0]; th = bb[3] - bb[1]
x = (W - tw) // 2 - bb[0]; y = (W - th) // 2 - bb[1]
d.text((x + 6, y + 6), txt, font=f, fill=(0, 0, 0, 200))
d.text((x, y), txt, font=f, fill=(255, 240, 220, 255))
img.save(out)
PY
  if [[ -f "$ICON_PATH" ]]; then
    ok "icon (generated) → $ICON_PATH"
  else
    warn "icon generation skipped (Pillow needed)"
  fi
fi

# ── desktop file ────────────────────────────────────────────────────────────
DESK_DIR="$TARGET_HOME/.local/share/applications"
sudo -u "$TARGET_USER" mkdir -p "$DESK_DIR"
DESK_PATH="$DESK_DIR/nyxus-studio.desktop"
cat > "$DESK_PATH" <<DESK
[Desktop Entry]
Type=Application
Name=NYXUS Studio
GenericName=Creative Suite
Comment=Paint · Vector · 3D · Video · Animate · Photo · Layout · Type · Voice
Exec=nyxus-studio
Icon=nyxus-studio
Terminal=false
Categories=Graphics;AudioVideo;2DGraphics;3DGraphics;
StartupNotify=true
StartupWMClass=nyxus-studio
DESK
chown "$TARGET_USER":"$(id -gn "$TARGET_USER")" "$DESK_PATH"
chmod 0644 "$DESK_PATH"
ok "desktop entry → $DESK_PATH"

# refresh icon cache (best-effort)
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  sudo -u "$TARGET_USER" gtk-update-icon-cache -t \
    "$TARGET_HOME/.local/share/icons/hicolor" >/dev/null 2>&1 || true
fi
if command -v update-desktop-database >/dev/null 2>&1; then
  sudo -u "$TARGET_USER" update-desktop-database "$DESK_DIR" >/dev/null 2>&1 || true
fi

# ── done ────────────────────────────────────────────────────────────────────
step "done"
ok "launch with:  ${B}nyxus-studio${R}"
ok "or open from your application launcher (NYXUS Studio)"
printf "\n${DIM}© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED${R}\n"
