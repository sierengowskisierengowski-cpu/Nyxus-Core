"""
NYXUS Home - palette + CSS
Mirrors HomeDashboard.tsx + waybar-style.css color scheme.
Caveat for hand-drawn UI text, JetBrains Mono for code/data.
(c) 2026 Joseph Sierengowski - NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from gi.repository import Gtk, Gdk

PALETTE = {
    "pink":   "#ff00ff",
    "cyan":   "#22d3ee",
    "purple": "#cc00ff",
    "gold":   "#ffff00",
    "indigo": "#8800ff",
    "green":  "#39ff14",
    "orange": "#ff5500",
    "blue":   "#0088ff",
    "red":    "#ff3344",
    "white":  "#ffffff",
    "text":   "#f0e8fa",
    "dim":    "#b0a3c8",
    "void":   "#080808",
}

NEONS = ["#ff00ff", "#22d3ee", "#ffff00", "#39ff14", "#cc00ff",
         "#ff5500", "#0088ff", "#8800ff", "#ff3344"]


def _card_css(name, color):
    return f"""
.card-{name} {{
    background: rgba(6, 4, 12, 0.62);
    border: 1px dashed alpha({color}, 0.66);
    border-top: 2px solid {color};
    border-radius: 8px;
    padding: 12px 14px;
    box-shadow: 0 0 18px alpha({color}, 0.34),
                0 6px 22px rgba(0,0,0,0.55),
                inset 0 0 24px rgba(0,0,0,0.18);
}}
.card-{name}-header-glyph {{
    color: {color};
    font-size: 18px;
    text-shadow: 0 0 10px {color}, 0 0 18px alpha({color}, 0.55);
}}
.card-{name}-header-title {{
    font-family: "Caveat", cursive;
    font-size: 22px;
    font-weight: 700;
    color: {color};
    text-shadow: 0 0 8px alpha({color}, 0.40);
    letter-spacing: 0.02em;
}}
.card-{name}-header-stamp {{
    font-family: "JetBrains Mono", monospace;
    font-size: 8px;
    color: alpha({color}, 0.47);
    letter-spacing: 0.22em;
}}
.card-{name}-header-rule {{
    background: alpha({color}, 0.20);
    min-height: 1px;
}}
.card-{name}-footer {{
    font-family: "JetBrains Mono", monospace;
    font-size: 9px;
    color: alpha({color}, 0.55);
    letter-spacing: 0.16em;
    padding-top: 6px;
    border-top: 1px dashed alpha({color}, 0.13);
}}
.btn-nav-{name} {{
    background: transparent;
    border: 1px solid alpha({color}, 0.34);
    color: {color};
    font-family: "JetBrains Mono", monospace;
    font-size: 9px;
    letter-spacing: 0.18em;
    padding: 4px 9px;
    border-radius: 2px;
}}
.btn-nav-{name}:hover {{
    background: alpha({color}, 0.13);
    border-color: {color};
}}
.btn-primary-{name} {{
    background: alpha({color}, 0.13);
    border: 1px solid {color};
    color: {color};
    font-family: "JetBrains Mono", monospace;
    font-size: 10px;
    letter-spacing: 0.18em;
    font-weight: 700;
    padding: 6px 11px;
    border-radius: 3px;
    text-shadow: 0 0 6px alpha({color}, 0.55);
}}
.btn-primary-{name}:hover {{
    background: alpha({color}, 0.25);
    box-shadow: 0 0 14px alpha({color}, 0.55);
}}
.btn-icon-{name} {{
    background: transparent;
    border: 1px solid alpha({color}, 0.34);
    color: {color};
    font-size: 11px;
    padding: 3px 7px;
    border-radius: 2px;
    min-width: 0;
    min-height: 0;
}}
.btn-icon-{name}:hover {{
    background: alpha({color}, 0.13);
}}
.input-{name} {{
    background: rgba(0, 0, 0, 0.45);
    border: 1px dashed alpha({color}, 0.34);
    border-radius: 3px;
    color: #f0e8fa;
    padding: 5px 8px;
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    min-height: 0;
}}
.input-{name}:focus {{
    border-color: {color};
    box-shadow: 0 0 12px alpha({color}, 0.40);
}}
.notif-{name} {{
    border: 1px dashed alpha({color}, 0.20);
    border-left: 3px solid {color};
    background: alpha({color}, 0.06);
    padding: 7px 9px;
    border-radius: 3px;
}}
"""


def build_css():
    css = """
window, .home-root {
    background: rgba(6, 0, 16, 0.65);
    color: #f0e8fa;
    font-family: "Caveat", "JetBrains Mono", sans-serif;
}
.header-tag {
    font-family: "JetBrains Mono", monospace;
    font-size: 9px;
    color: alpha(#ff00ff, 0.66);
    letter-spacing: 0.28em;
}
.header-title {
    font-family: "Caveat", cursive;
    font-size: 30px;
    color: #f0e8fa;
    text-shadow: 0 0 14px alpha(#ff00ff, 0.40),
                 0 0 28px alpha(#cc00ff, 0.20);
    letter-spacing: 0.02em;
}
.header-title-pink  { color: #ff00ff; }
.header-title-gold  { color: #ffff00; }
.header-stamp {
    font-family: "JetBrains Mono", monospace;
    font-size: 8px;
    color: #444444;
    letter-spacing: 0.22em;
}
.clock-time {
    font-family: "JetBrains Mono", monospace;
    font-size: 42px;
    font-weight: 700;
    color: #f0e8fa;
    letter-spacing: 0.05em;
    text-shadow: 0 0 14px alpha(#ff00ff, 0.55),
                 0 0 28px alpha(#ff00ff, 0.27);
}
.clock-colon       { color: #ff00ff; }
.clock-colon-dim   { color: #ff00ff; opacity: 0.4; }
.clock-secs {
    font-family: "JetBrains Mono", monospace;
    font-size: 18px;
    color: #b0a3c8;
}
.clock-day {
    font-family: "Caveat", cursive;
    font-size: 22px;
    color: #22d3ee;
    text-shadow: 0 0 8px alpha(#22d3ee, 0.40);
    letter-spacing: 0.04em;
}
.clock-date {
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    color: #b0a3c8;
    letter-spacing: 0.10em;
}
.wx-glyph {
    font-size: 36px;
    color: #ffff00;
    text-shadow: 0 0 12px alpha(#ffff00, 0.55);
}
.wx-temp {
    font-family: "JetBrains Mono", monospace;
    font-size: 34px;
    font-weight: 700;
    color: #f0e8fa;
    text-shadow: 0 0 10px alpha(#ffff00, 0.40);
}
.wx-unit {
    font-family: "JetBrains Mono", monospace;
    font-size: 16px;
    color: #b0a3c8;
}
.wx-label {
    font-family: "Caveat", cursive;
    font-size: 17px;
    color: #ffff00;
    letter-spacing: 0.02em;
}
.wx-stats {
    font-family: "JetBrains Mono", monospace;
    font-size: 10px;
    color: #b0a3c8;
    letter-spacing: 0.05em;
}
.wx-loc {
    font-family: "Caveat", cursive;
    font-size: 15px;
    color: #22d3ee;
    letter-spacing: 0.03em;
}
.cal-month {
    font-family: "Caveat", cursive;
    font-size: 20px;
    color: #cc00ff;
    text-shadow: 0 0 8px alpha(#cc00ff, 0.34);
    letter-spacing: 0.04em;
}
.cal-dow {
    font-family: "JetBrains Mono", monospace;
    font-size: 9px;
    color: alpha(#cc00ff, 0.66);
    letter-spacing: 0.18em;
}
.cal-day {
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    color: #f0e8fa;
    padding: 3px 0;
}
.cal-day-today {
    font-family: "Caveat", cursive;
    font-size: 14px;
    font-weight: 800;
    color: #0a0612;
    background: radial-gradient(circle at 35% 35%, #cc00ff, #ff00ff 80%);
    border-radius: 50%;
    box-shadow: 0 0 12px #cc00ff, 0 0 20px alpha(#ff00ff, 0.40);
    min-width: 22px;
    min-height: 22px;
    padding: 2px;
}
.notif-title {
    font-family: "Caveat", cursive;
    font-size: 15px;
    letter-spacing: 0.03em;
}
.notif-time {
    font-family: "JetBrains Mono", monospace;
    font-size: 8px;
    color: #b0a3c8;
    letter-spacing: 0.10em;
}
.notif-body {
    font-size: 10px;
    color: #b0a3c8;
}
.notif-glyph {
    font-size: 14px;
}
.np-textarea {
    font-family: "Caveat", cursive;
    font-size: 18px;
    letter-spacing: 0.02em;
    color: #f0e8fa;
    background: rgba(0, 0, 0, 0.55);
    border: 1px dashed alpha(#22d3ee, 0.27);
    border-radius: 4px;
    padding: 10px 13px;
}
.np-textarea text {
    background: transparent;
    color: #f0e8fa;
}
.np-textarea:focus {
    border-color: alpha(#22d3ee, 0.66);
    box-shadow: inset 0 0 16px alpha(#22d3ee, 0.13),
                0 0 18px alpha(#22d3ee, 0.27);
}
.pw-section {
    border: 1px dashed alpha(#ff5500, 0.27);
    border-radius: 4px;
    background: alpha(#ff5500, 0.04);
    padding: 9px 11px;
}
.pw-gen-label {
    font-family: "Caveat", cursive;
    font-size: 15px;
    color: #ff5500;
}
.pw-gen-len {
    font-family: "JetBrains Mono", monospace;
    font-size: 8px;
    color: alpha(#ff5500, 0.55);
    letter-spacing: 0.18em;
}
.pw-gen-preview {
    font-family: "JetBrains Mono", monospace;
    font-size: 12px;
    color: #f0e8fa;
    background: rgba(0, 0, 0, 0.55);
    padding: 6px 9px;
    border: 1px dashed alpha(#ff5500, 0.34);
    border-radius: 3px;
    letter-spacing: 0.02em;
}
.pw-row {
    border: 1px dashed alpha(#ff5500, 0.20);
    background: rgba(0, 0, 0, 0.35);
    border-radius: 3px;
    padding: 6px 9px;
}
.pw-row-site {
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    color: #ff5500;
    letter-spacing: 0.04em;
}
.pw-row-user {
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    color: #b0a3c8;
}
.pw-row-pass {
    font-family: "JetBrains Mono", monospace;
    font-size: 11px;
    color: #f0e8fa;
}
.pw-row-pass-hidden {
    color: #b0a3c8;
}
checkbutton {
    color: #b0a3c8;
    font-family: "JetBrains Mono", monospace;
    font-size: 9px;
    letter-spacing: 0.08em;
}
scale trough {
    background: rgba(255, 85, 0, 0.20);
    border-radius: 2px;
    min-height: 4px;
}
scale highlight {
    background: #ff5500;
    border-radius: 2px;
}
scale slider {
    background: #ff5500;
    border: 1px solid #ff5500;
    box-shadow: 0 0 10px alpha(#ff5500, 0.55);
    min-width: 12px;
    min-height: 12px;
    border-radius: 50%;
}
"""
    for name in ("pink", "cyan", "purple", "gold", "green", "orange", "red"):
        css += _card_css(name, PALETTE[name])
    return css


def install_css():
    provider = Gtk.CssProvider()
    provider.load_from_data(build_css().encode("utf-8"))
    display = Gdk.Display.get_default()
    if display is not None:
        Gtk.StyleContext.add_provider_for_display(
            display, provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )
