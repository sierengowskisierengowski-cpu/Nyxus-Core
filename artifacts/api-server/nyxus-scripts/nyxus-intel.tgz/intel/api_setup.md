# NYXUS INTEL — API key setup

Every API key is **optional**. Modules without a configured key will report
`set <SERVICE> API key in Settings` instead of returning fake data.

Open the app → click the gear icon (top right) → **API Keys**. Paste the key
into the matching field and click **Save**, then **Test** to verify.

| Service        | Free tier?           | Where to get a key |
|----------------|----------------------|--------------------|
| HaveIBeenPwned | ❌ paid (~$4/mo)     | https://haveibeenpwned.com/API/Key |
| DeHashed       | ❌ paid              | https://dehashed.com/ — also enter your DeHashed account email |
| Shodan         | ✅ membership        | https://account.shodan.io/ |
| VirusTotal     | ✅ 500 lookups/day   | https://virustotal.com/gui/my-apikey |
| AbuseIPDB      | ✅ 1,000 lookups/day | https://www.abuseipdb.com/account/api |
| IPinfo         | ✅ 50,000 lookups/mo | https://ipinfo.io/account/token |
| Etherscan      | ✅ free tier         | https://etherscan.io/myapikey |
| FEC            | ✅ free, instant     | https://api.data.gov/signup/ |
| Google CSE     | ✅ 100 queries/day   | https://developers.google.com/custom-search/v1/overview — also create a Programmable Search Engine and copy its `cx` id |
| GitHub token   | optional             | https://github.com/settings/tokens — raises rate limit from 60 to 5,000/hr |

## Modules that need NO key
* `holehe` (account discovery from email)
* `sherlock` (username scan across 400+ sites)
* `crt.sh` (TLS certificate transparency)
* `blockchain.info` (BTC address lookups)
* `Wayback Machine`
* `python-whois` + `dnspython`
* `Reddit` public JSON
* `Tor exit-node list`
* `OpenSanctions` (rate-limited, generous)
* `OpenStreetMap Nominatim` (reverse geocoding)
* `FCC` open-data phone lookups
* `EXIF` extraction (piexif)

## Privacy

All keys are stored in `~/.config/nyxus-intel/config.json` with `chmod 600`.
This file lives only on your machine and is never transmitted to NYXUS.
Any time a module makes a network call it goes directly from your machine to
the third-party API — there is no NYXUS-side proxy.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
