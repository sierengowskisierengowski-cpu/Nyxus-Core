"""
NYXUS INTEL · search_coordinator.py
Auto-detects subject type and dispatches the right intel modules in parallel.

The coordinator returns a structured `findings` dict that can be:
   • saved straight into a case envelope (case_manager.save_case)
   • rendered by case_viewer
   • exported to PDF by report_generator

Detection rules:
   • email      → contains "@" and a "."
   • phone      → mostly digits + (), - and . , 7+ digits
   • ip_v4/v6   → ipaddress.ip_address parses
   • domain     → has a "." and a TLD-ish suffix, no @
   • btc        → starts with 1, 3 (legacy) or "bc1" (bech32)
   • eth        → starts with "0x" + 40 hex chars
   • image      → looks like a path with .jpg/.jpeg/.png/.tiff
   • username   → no spaces, no special chars except _ . -
   • person     → everything else (free text — first/last name)

All modules are called concurrently in a thread pool. Progress is reported
to a callback that you should marshal to the GTK main loop with
`GLib.idle_add`. The coordinator never touches GTK directly.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import os
import re
import time
import ipaddress
import threading
import concurrent.futures
from typing import Callable, Dict, Any, List, Tuple, Optional

# Lazy imports of the intel modules so a single broken module doesn't take
# the whole coordinator down with it.
_INTEL_MODULES = (
    "email_intel", "username_intel", "person_intel", "ip_intel",
    "domain_intel", "crypto_intel", "photo_intel", "records_intel",
)

EMAIL_RE   = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")
PHONE_RE   = re.compile(r"^[\+\(\)\-\.\s\d]{7,}$")
DOMAIN_RE  = re.compile(r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?:\.[A-Za-z0-9-]{1,63})+$")
ETH_RE     = re.compile(r"^0x[a-fA-F0-9]{40}$")
BTC_RE     = re.compile(r"^(bc1[a-z0-9]{6,90}|[13][A-HJ-NP-Za-km-z1-9]{25,39})$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{2,32}$")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".tif", ".tiff", ".webp", ".bmp")


def detect_type(raw: str) -> str:
    """Return one of:
       email, phone, ipv4, ipv6, domain, btc, eth, image,
       username, person, plain
    """
    s = (raw or "").strip()
    if not s:
        return "plain"
    if os.path.isfile(s) and s.lower().endswith(IMAGE_EXTS):
        return "image"
    if EMAIL_RE.match(s):
        return "email"
    if BTC_RE.match(s):
        return "btc"
    if ETH_RE.match(s):
        return "eth"
    try:
        ip = ipaddress.ip_address(s)
        return "ipv6" if ip.version == 6 else "ipv4"
    except ValueError:
        pass
    if DOMAIN_RE.match(s):
        return "domain"
    if PHONE_RE.match(s) and sum(1 for c in s if c.isdigit()) >= 7:
        return "phone"
    if " " in s:
        return "person"
    if USERNAME_RE.match(s):
        return "username"
    return "plain"


# ── dispatch table: detected_type → list of (label, callable) tasks ─────
def _build_dispatch(api_keys: Dict[str, str]) -> Dict[str, List[Tuple[str, Callable]]]:
    """Returns { detected_type: [(human_label, callable(subject) → dict), ...] }.
    Modules are imported lazily."""

    def _imp(mod):
        return __import__(mod)

    table: Dict[str, List[Tuple[str, Callable]]] = {}

    def add(t, label, fn):
        table.setdefault(t, []).append((label, fn))

    # email
    add("email", "Holehe account discovery",
        lambda s: _imp("email_intel").holehe_lookup(s))
    add("email", "HaveIBeenPwned breaches",
        lambda s: _imp("email_intel").hibp_lookup(s, api_keys.get("hibp")))
    add("email", "DeHashed breaches",
        lambda s: _imp("email_intel").dehashed_lookup(s, api_keys.get("dehashed_email"),
                                                     api_keys.get("dehashed")))
    add("email", "Gravatar profile",
        lambda s: _imp("email_intel").gravatar_lookup(s))
    add("email", "Domain context",
        lambda s: _imp("email_intel").domain_context(s, api_keys.get("virustotal")))

    # username
    add("username", "Sherlock cross-platform scan",
        lambda s: _imp("username_intel").sherlock_lookup(s))
    add("username", "GitHub profile",
        lambda s: _imp("username_intel").github_lookup(s, api_keys.get("github")))
    add("username", "Reddit profile (Pushshift)",
        lambda s: _imp("username_intel").reddit_lookup(s))

    # person  (free text; treat as both name and possible username)
    add("person", "Sherlock cross-platform scan",
        lambda s: _imp("username_intel").sherlock_lookup(s.replace(" ", "")))
    add("person", "Public records (FEC, OpenSanctions)",
        lambda s: _imp("records_intel").person_records(s, api_keys))
    add("person", "Google CSE web mentions",
        lambda s: _imp("person_intel").google_cse(s, api_keys.get("google_cse"),
                                                  api_keys.get("google_cse_id")))

    # plain (very short free text — treat like username AND person, lighter)
    add("plain", "Sherlock cross-platform scan",
        lambda s: _imp("username_intel").sherlock_lookup(s.replace(" ", "")))
    add("plain", "Google CSE web mentions",
        lambda s: _imp("person_intel").google_cse(s, api_keys.get("google_cse"),
                                                  api_keys.get("google_cse_id")))

    # phone
    add("phone", "FCC phone-number lookup",
        lambda s: _imp("records_intel").fcc_phone(s))

    # ip
    for t in ("ipv4", "ipv6"):
        add(t, "IPinfo geolocation",
            lambda s: _imp("ip_intel").ipinfo_lookup(s, api_keys.get("ipinfo")))
        add(t, "AbuseIPDB reputation",
            lambda s: _imp("ip_intel").abuseipdb_lookup(s, api_keys.get("abuseipdb")))
        add(t, "Shodan exposure",
            lambda s: _imp("ip_intel").shodan_lookup(s, api_keys.get("shodan")))
        add(t, "VirusTotal IP report",
            lambda s: _imp("ip_intel").virustotal_ip(s, api_keys.get("virustotal")))
        add(t, "Tor exit node check",
            lambda s: _imp("ip_intel").tor_check(s))
        add(t, "Reverse DNS",
            lambda s: _imp("ip_intel").reverse_dns(s))

    # domain
    add("domain", "WHOIS",
        lambda s: _imp("domain_intel").whois_lookup(s))
    add("domain", "DNS records (A/MX/NS/TXT/SOA)",
        lambda s: _imp("domain_intel").dns_records(s))
    add("domain", "crt.sh certificate transparency",
        lambda s: _imp("domain_intel").crtsh_lookup(s))
    add("domain", "Wayback Machine first-seen",
        lambda s: _imp("domain_intel").wayback_first_seen(s))
    add("domain", "VirusTotal domain reputation",
        lambda s: _imp("domain_intel").virustotal_domain(s, api_keys.get("virustotal")))

    # crypto
    add("btc", "blockchain.info BTC address",
        lambda s: _imp("crypto_intel").btc_address(s))
    add("eth", "Etherscan ETH address",
        lambda s: _imp("crypto_intel").eth_address(s, api_keys.get("etherscan")))

    # image
    add("image", "EXIF + GPS analysis",
        lambda s: _imp("photo_intel").analyse_image(s))

    return table


# ── coordinator ──────────────────────────────────────────────────────────
ProgressFn = Callable[[str, str, Optional[Dict[str, Any]]], None]
# (event, message, data?)  events: 'start', 'task_start', 'task_done',
#                                  'task_error', 'done'


def run_search(subject: str, api_keys: Dict[str, str],
               on_progress: ProgressFn,
               max_workers: int = 8) -> Dict[str, Any]:
    """Blocking. Run from a worker thread; the on_progress callback should
    marshal to the GTK main loop via GLib.idle_add.

    Returns the `findings` dict that you can stuff into a case payload.
    """
    detected = detect_type(subject)
    dispatch = _build_dispatch(api_keys)
    tasks = list(dispatch.get(detected, []))
    started_at = time.time()

    on_progress("start", f"detected: {detected}",
                {"subject": subject, "type": detected, "task_count": len(tasks)})

    findings: Dict[str, Any] = {
        "subject":         subject,
        "detected_type":   detected,
        "started_at":      int(started_at),
        "modules":         {},     # label → result dict
        "errors":          {},     # label → error str
        "summary":         "",
    }

    if not tasks:
        on_progress("done", "no modules registered for this subject type",
                    {"elapsed": 0.0})
        return findings

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers,
                                               thread_name_prefix="nyx-intel") as ex:
        futures = {}
        for label, fn in tasks:
            on_progress("task_start", label, None)
            futures[ex.submit(_safe_call, fn, subject)] = label
        for fut in concurrent.futures.as_completed(futures):
            label = futures[fut]
            try:
                result = fut.result()
                if isinstance(result, dict) and result.get("__error__"):
                    findings["errors"][label] = result["__error__"]
                    on_progress("task_error", label, {"error": result["__error__"]})
                else:
                    findings["modules"][label] = result
                    on_progress("task_done", label, {"result": result})
            except Exception as e:
                findings["errors"][label] = repr(e)
                on_progress("task_error", label, {"error": repr(e)})

    findings["finished_at"] = int(time.time())
    findings["elapsed"]     = round(findings["finished_at"] - started_at, 2)
    findings["summary"]     = _summarise(findings)

    on_progress("done", findings["summary"],
                {"elapsed": findings["elapsed"]})
    return findings


def _safe_call(fn, arg):
    try:
        return fn(arg)
    except Exception as e:
        return {"__error__": f"{type(e).__name__}: {e}"}


def _summarise(findings: Dict[str, Any]) -> str:
    bits = []
    n_mod = len(findings["modules"])
    n_err = len(findings["errors"])
    bits.append(f"{n_mod} modules returned data")
    if n_err: bits.append(f"{n_err} errors / missing keys")

    # Domain-specific highlights
    for label, data in findings["modules"].items():
        if not isinstance(data, dict): continue
        if "breach_count" in data and data["breach_count"]:
            bits.append(f"{data['breach_count']} breaches via {label}")
        if "country" in data and data["country"]:
            bits.append(f"located in {data['country']}")
        if "subdomains_count" in data and data["subdomains_count"]:
            bits.append(f"{data['subdomains_count']} subdomains")
        if "balance_btc" in data:
            bits.append(f"BTC balance {data['balance_btc']}")
        if "balance_eth" in data:
            bits.append(f"ETH balance {data['balance_eth']}")
        if "exif_gps" in data and data["exif_gps"]:
            bits.append("EXIF GPS present")

    return " · ".join(bits[:6])
