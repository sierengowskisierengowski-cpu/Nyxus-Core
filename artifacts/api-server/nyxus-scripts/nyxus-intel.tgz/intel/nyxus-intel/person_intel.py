# ============================================
# NYXUS — nyx-2026.05.02-x86_64.iso
# Copyright © 2026 Joseph Sierengowski
# All Rights Reserved
# Unauthorized use or distribution prohibited
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
NYXUS INTEL · person_intel.py
Free-text / name searches via Google Programmable Search Engine.

The user must configure both:
   • google_cse    — API key  (https://developers.google.com/custom-search/v1/overview)
   • google_cse_id — engine identifier (cx)

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

from typing import Dict, Any, Optional

import requests

UA = "NYXUS-INTEL/1.0 (research/OSINT)"
TIMEOUT = 20


def _err(msg: str) -> Dict[str, Any]:
    return {"__error__": msg}


def google_cse(query: str, api_key: Optional[str],
               cx: Optional[str]) -> Dict[str, Any]:
    if not api_key or not cx:
        return _err("set Google CSE API key + engine id in Settings")
    url = "https://www.googleapis.com/customsearch/v1"
    params = {"key": api_key, "cx": cx, "q": query, "num": 10}
    r = requests.get(url, params=params, timeout=TIMEOUT,
                     headers={"User-Agent": UA})
    if r.status_code == 403:
        return _err("Google CSE quota exhausted or key invalid")
    if r.status_code != 200:
        return _err(f"Google CSE HTTP {r.status_code}")

    data = r.json()
    items = data.get("items") or []
    return {
        "query":        query,
        "total":        int((data.get("searchInformation") or {}).get("totalResults", 0) or 0),
        "search_time":  (data.get("searchInformation") or {}).get("searchTime"),
        "results":      [{"title":   it.get("title"),
                          "link":    it.get("link"),
                          "snippet": it.get("snippet"),
                          "source":  it.get("displayLink")}
                         for it in items],
    }
