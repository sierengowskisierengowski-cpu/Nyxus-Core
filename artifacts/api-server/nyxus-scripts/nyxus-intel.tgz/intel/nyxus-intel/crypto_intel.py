"""
NYXUS INTEL · crypto_intel.py
Cryptocurrency address investigation.

  • BTC  → blockchain.info public REST (no key)
  • ETH  → Etherscan v2 (key required, free tier OK)

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

from typing import Dict, Any, Optional

import requests

UA = "NYXUS-INTEL/1.0 (research/OSINT)"
TIMEOUT = 25


def _err(msg): return {"__error__": msg}


def btc_address(address: str) -> Dict[str, Any]:
    # Address summary
    r = requests.get(f"https://blockchain.info/rawaddr/{address}",
                     params={"limit": 50},
                     timeout=TIMEOUT, headers={"User-Agent": UA})
    if r.status_code == 404:
        return {"address": address, "found": False}
    if r.status_code != 200:
        return _err(f"blockchain.info HTTP {r.status_code}")
    d = r.json()

    txs = []
    for tx in (d.get("txs") or [])[:25]:
        txs.append({
            "hash":    tx.get("hash"),
            "time":    tx.get("time"),
            "size":    tx.get("size"),
            "result":  tx.get("result"),     # net change in sat for this addr
            "fee":     tx.get("fee"),
            "block_height": tx.get("block_height"),
            "n_inputs":  len(tx.get("inputs") or []),
            "n_outputs": len(tx.get("out") or []),
        })

    return {
        "address":        d.get("address"),
        "found":          True,
        "n_tx":           d.get("n_tx"),
        "total_received_sat": d.get("total_received"),
        "total_sent_sat":     d.get("total_sent"),
        "balance_sat":    d.get("final_balance"),
        "balance_btc":    (d.get("final_balance") or 0) / 1e8,
        "received_btc":   (d.get("total_received") or 0) / 1e8,
        "sent_btc":       (d.get("total_sent") or 0) / 1e8,
        "first_seen":     (d.get("txs") or [{}])[-1].get("time")
                          if d.get("txs") else None,
        "transactions":   txs,
        "explorer":       f"https://www.blockchain.com/btc/address/{address}",
    }


def eth_address(address: str, key: Optional[str]) -> Dict[str, Any]:
    if not key:
        return _err("set Etherscan API key in Settings")

    base = "https://api.etherscan.io/api"
    common = {"address": address, "apikey": key}
    H = {"User-Agent": UA}

    # 1. Balance (in wei)
    r = requests.get(base, params={**common, "module": "account",
                                   "action": "balance", "tag": "latest"},
                     timeout=TIMEOUT, headers=H)
    if r.status_code != 200:
        return _err(f"Etherscan HTTP {r.status_code}")
    bdata = r.json()
    if str(bdata.get("status")) == "0" and (bdata.get("message") or "").lower().startswith("notok"):
        return _err(f"Etherscan: {bdata.get('result') or bdata.get('message')}")
    wei = int(bdata.get("result") or 0)
    eth = wei / 1e18

    # 2. Recent normal transactions
    r2 = requests.get(base, params={**common, "module": "account",
                                    "action": "txlist", "startblock": 0,
                                    "endblock": 99999999, "page": 1,
                                    "offset": 25, "sort": "desc"},
                      timeout=TIMEOUT, headers=H)
    txs_raw = (r2.json().get("result") or []) if r2.status_code == 200 else []
    txs = []
    if isinstance(txs_raw, list):
        for t in txs_raw:
            txs.append({
                "hash":   t.get("hash"),
                "block":  t.get("blockNumber"),
                "time":   int(t.get("timeStamp") or 0),
                "from":   t.get("from"),
                "to":     t.get("to"),
                "value_eth": int(t.get("value") or 0) / 1e18,
                "gas_used":  int(t.get("gasUsed") or 0),
                "is_error":  t.get("isError"),
            })

    # 3. Token transfers (ERC-20)
    r3 = requests.get(base, params={**common, "module": "account",
                                    "action": "tokentx", "page": 1,
                                    "offset": 25, "sort": "desc"},
                      timeout=TIMEOUT, headers=H)
    tokens = []
    if r3.status_code == 200:
        for t in (r3.json().get("result") or [])[:25]:
            try:
                dec = int(t.get("tokenDecimal") or 0)
                amt = int(t.get("value") or 0) / (10 ** dec) if dec else int(t.get("value") or 0)
            except Exception:
                amt = None
            tokens.append({
                "hash":     t.get("hash"),
                "time":     int(t.get("timeStamp") or 0),
                "from":     t.get("from"),
                "to":       t.get("to"),
                "token":    t.get("tokenSymbol"),
                "token_name": t.get("tokenName"),
                "amount":   amt,
            })

    return {
        "address":     address,
        "balance_wei": wei,
        "balance_eth": eth,
        "tx_count":    len(txs),
        "transactions": txs,
        "token_transfers": tokens,
        "explorer":    f"https://etherscan.io/address/{address}",
    }
