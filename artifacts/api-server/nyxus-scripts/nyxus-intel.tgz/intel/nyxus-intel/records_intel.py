"""
NYXUS INTEL · records_intel.py
Public records helpers: FCC phone-number lookup, FEC donor search,
OpenSanctions person screening.

Most US-public-records APIs are either heavily key-gated, geo-restricted, or
behind enterprise contracts. This module ships the few that have completely
public free APIs we can call from any IP without auth headers, plus a couple
of opt-in keyed APIs (FEC) where we surface a clear "set key" hint.

  • FCC      — public, no key (fcc.gov number lookups)
  • FEC      — open data, key required (free, instant via api.data.gov)
  • OpenSanctions — public, no key (rate-limited but generous)

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import re
from typing import Dict, Any, Optional

import requests

UA = "NYXUS-INTEL/1.0 (research/OSINT)"
TIMEOUT = 25


def _err(msg): return {"__error__": msg}


def _digits(s: str) -> str:
    return "".join(c for c in s if c.isdigit())


# ── FCC phone lookup ────────────────────────────────────────────────────
def fcc_phone(phone: str) -> Dict[str, Any]:
    """FCC's NPA-NXX query gives carrier + rate centre for US numbers."""
    d = _digits(phone)
    if len(d) == 11 and d.startswith("1"):
        d = d[1:]
    if len(d) != 10:
        return {"phone": phone, "error": "expected a 10-digit US number"}
    npa, nxx = d[:3], d[3:6]
    url = "https://opendata.fcc.gov/resource/n4w7-a8b8.json"
    try:
        r = requests.get(url, params={"npa": npa, "nxx": nxx},
                         timeout=TIMEOUT, headers={"User-Agent": UA})
        if r.status_code != 200:
            return _err(f"FCC HTTP {r.status_code}")
        rows = r.json() if r.headers.get("Content-Type", "").startswith("application/json") else []
    except Exception as e:
        return _err(f"FCC: {e}")

    return {
        "phone":        phone,
        "npa":          npa,
        "nxx":          nxx,
        "country":      "US (NANP)" if d[0] in "23456789" else "non-NANP",
        "rows":         rows[:25],
        "row_count":    len(rows),
    }


# ── FEC donor search ────────────────────────────────────────────────────
def _fec_search(name: str, key: Optional[str]) -> Dict[str, Any]:
    if not key:
        return _err("set FEC API key in Settings (free at api.data.gov)")
    r = requests.get(
        "https://api.open.fec.gov/v1/schedules/schedule_a/",
        params={"contributor_name": name, "api_key": key, "per_page": 30,
                "sort": "-contribution_receipt_date"},
        headers={"User-Agent": UA, "Accept": "application/json"},
        timeout=TIMEOUT,
    )
    if r.status_code == 401 or r.status_code == 403:
        return _err("FEC rejected the API key")
    if r.status_code != 200:
        return _err(f"FEC HTTP {r.status_code}")
    data = r.json()
    results = []
    for row in data.get("results") or []:
        results.append({
            "contributor": row.get("contributor_name"),
            "city":        row.get("contributor_city"),
            "state":       row.get("contributor_state"),
            "employer":    row.get("contributor_employer"),
            "occupation":  row.get("contributor_occupation"),
            "amount":      row.get("contribution_receipt_amount"),
            "date":        row.get("contribution_receipt_date"),
            "committee":   (row.get("committee") or {}).get("name"),
            "memo":        row.get("memo_text"),
        })
    return {
        "query":        name,
        "total":        (data.get("pagination") or {}).get("count"),
        "result_count": len(results),
        "results":      results,
    }


# ── OpenSanctions ───────────────────────────────────────────────────────
def _opensanctions_search(name: str) -> Dict[str, Any]:
    r = requests.get(
        "https://api.opensanctions.org/search/default",
        params={"q": name, "limit": 25},
        headers={"User-Agent": UA, "Accept": "application/json"},
        timeout=TIMEOUT,
    )
    if r.status_code == 429:
        return _err("OpenSanctions rate-limited")
    if r.status_code != 200:
        return _err(f"OpenSanctions HTTP {r.status_code}")
    d = r.json()
    results = []
    for r0 in d.get("results") or []:
        props = r0.get("properties") or {}
        results.append({
            "id":          r0.get("id"),
            "schema":      r0.get("schema"),
            "caption":     r0.get("caption"),
            "score":       r0.get("score"),
            "datasets":    r0.get("datasets"),
            "topics":      props.get("topics"),
            "countries":   props.get("country"),
            "birth_date":  props.get("birthDate"),
            "url":         "https://www.opensanctions.org/entities/" + (r0.get("id") or ""),
        })
    return {
        "query":        name,
        "total":        d.get("total"),
        "result_count": len(results),
        "results":      results,
    }


def person_records(name: str, api_keys: Dict[str, str]) -> Dict[str, Any]:
    """Combined helper used by the search coordinator."""
    return {
        "fec":           _fec_search(name, api_keys.get("fec")),
        "opensanctions": _opensanctions_search(name),
    }
