"""
NYXUS INTEL · photo_intel.py
EXIF + GPS extraction with integrity warnings.

We use piexif (lightweight, pure-python) so we get raw EXIF tags without
Pillow's normalization losing data. GPS coordinates are converted to
decimal degrees and reverse-geocoded via OpenStreetMap Nominatim (no key
needed; we identify with a NYXUS UA per their TOS).

Integrity warnings:
   • software field mentions "photoshop" / "lightroom" → likely edited
   • DateTimeDigitized != DateTimeOriginal → possibly re-saved
   • no EXIF at all → metadata stripped (often a screenshot or social media)

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import os
import hashlib
from typing import Dict, Any, Tuple, Optional

import requests

UA = "NYXUS-INTEL/1.0 (research/OSINT)"
TIMEOUT = 25


def _err(msg): return {"__error__": msg}


def analyse_image(path: str) -> Dict[str, Any]:
    if not os.path.isfile(path):
        return _err(f"file not found: {path}")
    try:
        sha = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                sha.update(chunk)
    except OSError as e:
        return _err(f"read error: {e}")

    info: Dict[str, Any] = {
        "path":       path,
        "size_bytes": os.path.getsize(path),
        "sha256":     sha.hexdigest(),
    }

    # Pillow: dimensions, format, mode
    try:
        from PIL import Image
        with Image.open(path) as img:
            info["format"]     = img.format
            info["mode"]       = img.mode
            info["width"]      = img.width
            info["height"]     = img.height
    except Exception as e:
        info["pillow_error"] = str(e)

    # piexif: full raw EXIF
    exif_present = False
    exif: Dict[str, Any] = {}
    try:
        import piexif
        try:
            raw = piexif.load(path)
            exif_present = any(raw.get(k) for k in ("0th", "Exif", "GPS", "1st"))
            for ifd in ("0th", "Exif", "GPS", "1st"):
                tagdict = raw.get(ifd) or {}
                exif[ifd] = {
                    piexif.TAGS[ifd][tag]["name"]: _safe_val(v)
                    for tag, v in tagdict.items()
                    if tag in piexif.TAGS.get(ifd, {})
                }
        except piexif.InvalidImageDataError:
            exif_present = False
        except Exception as e:
            info["piexif_error"] = str(e)
    except ImportError:
        info["piexif_error"] = "piexif not installed"

    info["exif_present"] = exif_present
    info["exif"] = exif

    # GPS → decimal + reverse geocode
    gps = exif.get("GPS") or {}
    if gps:
        coords = _gps_to_decimal(gps)
        if coords:
            info["exif_gps"] = {"lat": coords[0], "lng": coords[1]}
            info["map_url"] = f"https://www.openstreetmap.org/?mlat={coords[0]}&mlon={coords[1]}#map=15/{coords[0]}/{coords[1]}"
            info["geocode"] = _reverse_geocode(coords[0], coords[1])

    # Integrity warnings
    warns = []
    if not exif_present:
        warns.append("no EXIF — metadata likely stripped (screenshot, social repost, edit)")
    sw = (exif.get("0th", {}) or {}).get("Software", "") or ""
    if isinstance(sw, str) and sw:
        low = sw.lower()
        if any(t in low for t in ("photoshop", "lightroom", "gimp", "affinity")):
            warns.append(f"software tag suggests editing: {sw!r}")
    dto = (exif.get("Exif", {}) or {}).get("DateTimeOriginal")
    dtd = (exif.get("Exif", {}) or {}).get("DateTimeDigitized")
    if dto and dtd and dto != dtd:
        warns.append(f"DateTimeOriginal ({dto}) != DateTimeDigitized ({dtd}) — re-saved?")
    info["integrity_warnings"] = warns

    return info


def _safe_val(v):
    if isinstance(v, bytes):
        try:    return v.decode("utf-8", errors="replace").strip("\x00")
        except: return repr(v)
    if isinstance(v, tuple):
        return [list(x) if isinstance(x, tuple) else x for x in v]
    return v


def _gps_to_decimal(gps_ifd: Dict[str, Any]) -> Optional[Tuple[float, float]]:
    """Convert piexif GPS IFD to (lat, lng) decimal degrees."""
    try:
        lat = gps_ifd.get("GPSLatitude")
        lon = gps_ifd.get("GPSLongitude")
        latref = gps_ifd.get("GPSLatitudeRef") or "N"
        lonref = gps_ifd.get("GPSLongitudeRef") or "E"
        if not lat or not lon: return None

        def to_deg(part):
            d, m, s = part
            deg = d[0] / d[1] if isinstance(d, (list, tuple)) else float(d)
            mn  = m[0] / m[1] if isinstance(m, (list, tuple)) else float(m)
            sc  = s[0] / s[1] if isinstance(s, (list, tuple)) else float(s)
            return deg + mn/60 + sc/3600

        latd = to_deg(lat)
        lond = to_deg(lon)
        if str(latref).upper().startswith("S"): latd = -latd
        if str(lonref).upper().startswith("W"): lond = -lond
        return latd, lond
    except Exception:
        return None


def _reverse_geocode(lat: float, lng: float) -> Dict[str, Any]:
    try:
        r = requests.get(
            "https://nominatim.openstreetmap.org/reverse",
            params={"lat": lat, "lon": lng, "format": "jsonv2", "zoom": 18},
            headers={"User-Agent": UA},
            timeout=TIMEOUT,
        )
        if r.status_code != 200:
            return {"error": f"Nominatim HTTP {r.status_code}"}
        d = r.json()
        return {
            "display_name": d.get("display_name"),
            "address":      d.get("address"),
            "osm_type":     d.get("osm_type"),
            "osm_id":       d.get("osm_id"),
        }
    except Exception as e:
        return {"error": str(e)}
