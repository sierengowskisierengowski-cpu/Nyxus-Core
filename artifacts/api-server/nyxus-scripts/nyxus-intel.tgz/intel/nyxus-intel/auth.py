"""
NYXUS INTEL · auth.py
Master password lock + session management.

The master password is stored as a bcrypt hash. The same password is also the
KEY material used by `encryption.py` to derive per-case KEKs — so it is NEVER
written to disk in any form other than the bcrypt verifier. We keep the
plaintext only in process memory while the session is unlocked.

3 consecutive wrong attempts → process exits (SystemExit, no soft return).
Auto-lock timer wipes the in-memory password and presents the lock screen.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import os
import json
import time
import bcrypt
from pathlib import Path
from typing import Optional, Callable, List

CONFIG_DIR  = Path.home() / ".config" / "nyxus-intel"
CONFIG_FILE = CONFIG_DIR / "config.json"
AUTH_FILE   = CONFIG_DIR / "auth.json"

DEFAULT_LOCK_MIN  = 5
DEFAULT_FAIL_LIMIT = 3


def _load(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text("utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _save(path: Path, data: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2), "utf-8")
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def load_config() -> dict:
    cfg = _load(CONFIG_FILE)
    cfg.setdefault("lock_minutes",  DEFAULT_LOCK_MIN)
    cfg.setdefault("fail_limit",    DEFAULT_FAIL_LIMIT)
    cfg.setdefault("disclaimer_accepted_at", 0)
    cfg.setdefault("api_keys", {})           # encrypted at rest? See below.
    cfg.setdefault("autostart_search", True)
    cfg.setdefault("auto_pdf",         True)
    cfg.setdefault("show_raw_tab",     False)
    cfg.setdefault("default_depth",    "thorough")  # 'quick' | 'thorough'
    cfg.setdefault("backup_schedule",  "manual")    # 'manual' | 'daily' | 'weekly'
    return cfg


def save_config(cfg: dict) -> None:
    _save(CONFIG_FILE, cfg)


def is_password_set() -> bool:
    a = _load(AUTH_FILE)
    return bool(a.get("hash"))


def set_password(plaintext: str) -> None:
    if not plaintext or len(plaintext) < 4:
        raise ValueError("password must be at least 4 characters")
    h = bcrypt.hashpw(plaintext.encode("utf-8"), bcrypt.gensalt(rounds=12))
    _save(AUTH_FILE, {"hash": h.decode("ascii"), "set_at": int(time.time())})


def verify_password(plaintext: str) -> bool:
    a = _load(AUTH_FILE)
    h = a.get("hash")
    if not h:
        return False
    try:
        return bcrypt.checkpw(plaintext.encode("utf-8"), h.encode("ascii"))
    except (ValueError, TypeError):
        return False


def change_password(old_plain: str, new_plain: str) -> bool:
    """Verify old then set new. Returns False if old wrong."""
    if not verify_password(old_plain):
        return False
    set_password(new_plain)
    return True


# ── session ───────────────────────────────────────────────────────────────
class Session:
    """Holds the in-memory plaintext password (needed for case decryption),
    runs the auto-lock timer, and tracks failed-attempt count."""

    def __init__(self, on_lock: Callable[[], None]):
        self._password: Optional[str] = None
        self._unlocked_at: float = 0
        self._on_lock = on_lock
        self._listeners: List[Callable[[bool], None]] = []
        self._fail_count = 0
        self._cfg = load_config()

    # ── pwd ──────────────────────────────────────────────────────────────
    def attempt_unlock(self, plaintext: str) -> bool:
        """Try to unlock. Returns True on success. After fail_limit
        consecutive failures the process is killed via SystemExit."""
        if verify_password(plaintext):
            self._password = plaintext
            self._unlocked_at = time.time()
            self._fail_count = 0
            self._notify(True)
            return True
        self._fail_count += 1
        limit = max(1, int(self._cfg.get("fail_limit", DEFAULT_FAIL_LIMIT)))
        if self._fail_count >= limit:
            # Hard exit — no GUI cleanup. Required by spec.
            raise SystemExit(2)
        return False

    def lock(self) -> None:
        """Wipe the password and call the lock callback."""
        self._password = None
        self._unlocked_at = 0
        self._notify(False)
        try:
            self._on_lock()
        except Exception:
            pass

    def is_unlocked(self) -> bool:
        return self._password is not None

    def password(self) -> str:
        if self._password is None:
            raise RuntimeError("session is locked")
        return self._password

    # ── auto-lock ────────────────────────────────────────────────────────
    def touch(self) -> None:
        """Reset the auto-lock timer (call on user activity)."""
        if self._password is not None:
            self._unlocked_at = time.time()

    def check_auto_lock(self) -> bool:
        """Returns True and locks if the timer has elapsed."""
        if self._password is None:
            return False
        mins = max(1, int(self._cfg.get("lock_minutes", DEFAULT_LOCK_MIN)))
        if time.time() - self._unlocked_at >= mins * 60:
            self.lock()
            return True
        return False

    def reload_config(self) -> None:
        self._cfg = load_config()

    # ── observer ─────────────────────────────────────────────────────────
    def add_listener(self, fn: Callable[[bool], None]) -> None:
        self._listeners.append(fn)

    def _notify(self, unlocked: bool) -> None:
        for fn in list(self._listeners):
            try: fn(unlocked)
            except Exception: pass

    # ── disclaimer ───────────────────────────────────────────────────────
    def disclaimer_accepted(self) -> bool:
        return bool(self._cfg.get("disclaimer_accepted_at"))

    def accept_disclaimer(self) -> None:
        self._cfg["disclaimer_accepted_at"] = int(time.time())
        save_config(self._cfg)

    @property
    def fail_count(self) -> int:
        return self._fail_count

    @property
    def fail_limit(self) -> int:
        return max(1, int(self._cfg.get("fail_limit", DEFAULT_FAIL_LIMIT)))
