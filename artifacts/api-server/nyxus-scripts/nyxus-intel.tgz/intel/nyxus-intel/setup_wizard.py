"""
NYXUS INTEL · setup_wizard.py
First-launch flow:
   1. Legal disclaimer (must accept)
   2. Master password creation (with confirmation)

Returns True if the user successfully completes both steps. Anything else
(closing the window, refusing the disclaimer, mismatched passwords without
retry) leaves the wizard in an unfinished state and the caller should NOT
allow the app to proceed.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib, Gdk

from auth import set_password, save_config, load_config

DISCLAIMER_TEXT = (
    "NYXUS INTEL is a professional grade Open Source Intelligence (OSINT) "
    "investigation workstation. It queries publicly available data sources "
    "and aggregates the results into encrypted case files on your machine.\n\n"
    "By continuing, you certify that:\n\n"
    "  •  You will only investigate subjects you are legally authorised to "
    "investigate (yourself, persons who have given consent, or as part of "
    "lawful work).\n\n"
    "  •  You will comply with the Computer Fraud and Abuse Act (US), "
    "GDPR (EU), and any other privacy and surveillance laws that apply to "
    "you and your subject.\n\n"
    "  •  You will not use this tool for stalking, harassment, doxxing, "
    "discrimination, or any other malicious purpose.\n\n"
    "  •  You understand that aggregated open-source data, even when each "
    "individual datum is public, can be highly sensitive in combination "
    "and you will protect your case files accordingly.\n\n"
    "All cases are stored AES-256-GCM encrypted on this device only — "
    "nothing is ever transmitted to NYXUS or any third party other than the "
    "specific OSINT API you choose to invoke.\n\n"
    "© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED"
)


class SetupWizard(Gtk.Window):
    """Modal-style window. Calls `on_done(True)` once the user has accepted
    the disclaimer AND set a master password. Calls `on_done(False)` if the
    window is closed without finishing."""

    def __init__(self, on_done):
        super().__init__(title="NYXUS INTEL — Setup")
        self.set_default_size(720, 620)
        self._on_done = on_done
        self._finished = False

        self.connect("close-request", self._on_close)

        self._stack = Gtk.Stack()
        self._stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT)
        self.set_child(self._stack)

        self._stack.add_named(self._build_disclaimer(), "disclaimer")
        self._stack.add_named(self._build_password(),  "password")
        self._stack.set_visible_child_name("disclaimer")

        self.add_css_class("nx-window")

    # ── disclaimer page ─────────────────────────────────────────────────
    def _build_disclaimer(self) -> Gtk.Widget:
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                        margin_top=20, margin_bottom=20,
                        margin_start=24, margin_end=24)

        title = Gtk.Label(label="Legal Disclaimer")
        title.add_css_class("nx-h1")
        title.set_xalign(0)
        outer.append(title)

        sub = Gtk.Label(label="Please read carefully — required once.")
        sub.add_css_class("nx-dim")
        sub.set_xalign(0)
        outer.append(sub)

        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        body = Gtk.Label(label=DISCLAIMER_TEXT, wrap=True, xalign=0, yalign=0,
                         margin_top=8, margin_bottom=8,
                         margin_start=8, margin_end=8)
        body.add_css_class("nx-body")
        scroll.set_child(body)
        outer.append(scroll)

        chk = Gtk.CheckButton(label="I understand and accept these terms")
        chk.add_css_class("nx-check")
        outer.append(chk)

        btnrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12,
                         halign=Gtk.Align.END, margin_top=8)
        cancel = Gtk.Button(label="Quit")
        cancel.connect("clicked", lambda *_: self.close())
        btnrow.append(cancel)

        cont = Gtk.Button(label="Continue")
        cont.add_css_class("suggested-action")
        cont.add_css_class("nx-primary")
        cont.set_sensitive(False)
        chk.connect("toggled", lambda c: cont.set_sensitive(c.get_active()))
        cont.connect("clicked", lambda *_: self._stack.set_visible_child_name("password"))
        btnrow.append(cont)
        outer.append(btnrow)

        return outer

    # ── password page ───────────────────────────────────────────────────
    def _build_password(self) -> Gtk.Widget:
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                        margin_top=24, margin_bottom=24,
                        margin_start=32, margin_end=32)

        title = Gtk.Label(label="Set Master Password")
        title.add_css_class("nx-h1")
        title.set_xalign(0)
        outer.append(title)

        sub = Gtk.Label(label=(
            "This password locks the workstation AND derives the key that "
            "encrypts every case file on this device. There is NO recovery — "
            "if you forget it, your cases are unrecoverable. Choose carefully."))
        sub.set_wrap(True); sub.set_xalign(0)
        sub.add_css_class("nx-dim")
        outer.append(sub)

        grid = Gtk.Grid(column_spacing=12, row_spacing=10, margin_top=12)

        l1 = Gtk.Label(label="Password",        xalign=1)
        l2 = Gtk.Label(label="Confirm",         xalign=1)
        self._p1 = Gtk.PasswordEntry(show_peek_icon=True, hexpand=True)
        self._p2 = Gtk.PasswordEntry(show_peek_icon=True, hexpand=True)

        grid.attach(l1, 0, 0, 1, 1); grid.attach(self._p1, 1, 0, 1, 1)
        grid.attach(l2, 0, 1, 1, 1); grid.attach(self._p2, 1, 1, 1, 1)
        outer.append(grid)

        self._strength = Gtk.LevelBar(min_value=0, max_value=4, value=0,
                                      mode=Gtk.LevelBarMode.DISCRETE)
        outer.append(self._strength)

        self._msg = Gtk.Label(label="At least 4 characters. 12+ recommended.",
                              xalign=0)
        self._msg.add_css_class("nx-dim")
        outer.append(self._msg)

        self._p1.connect("changed", self._on_pw_changed)
        self._p2.connect("changed", self._on_pw_changed)

        btnrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12,
                         halign=Gtk.Align.END, margin_top=12, vexpand=True,
                         valign=Gtk.Align.END)
        back = Gtk.Button(label="Back")
        back.connect("clicked", lambda *_: self._stack.set_visible_child_name("disclaimer"))
        btnrow.append(back)

        self._save_btn = Gtk.Button(label="Set Password & Continue")
        self._save_btn.add_css_class("suggested-action")
        self._save_btn.add_css_class("nx-primary")
        self._save_btn.set_sensitive(False)
        self._save_btn.connect("clicked", self._on_save)
        btnrow.append(self._save_btn)
        outer.append(btnrow)

        return outer

    def _password_strength(self, pw: str) -> int:
        score = 0
        if len(pw) >= 8:  score += 1
        if len(pw) >= 12: score += 1
        if any(c.isdigit() for c in pw) and any(c.isalpha() for c in pw): score += 1
        if any(not c.isalnum() for c in pw): score += 1
        return score

    def _on_pw_changed(self, *_):
        p1 = self._p1.get_text()
        p2 = self._p2.get_text()
        s = self._password_strength(p1)
        self._strength.set_value(s)
        if not p1:
            self._msg.set_label("At least 4 characters. 12+ recommended.")
            self._save_btn.set_sensitive(False); return
        if len(p1) < 4:
            self._msg.set_label("Too short — minimum 4 characters.")
            self._save_btn.set_sensitive(False); return
        if p1 != p2:
            self._msg.set_label("Passwords do not match.")
            self._save_btn.set_sensitive(False); return
        self._msg.set_label({0:"weak", 1:"weak", 2:"ok", 3:"strong", 4:"very strong"}[s])
        self._save_btn.set_sensitive(True)

    def _on_save(self, *_):
        try:
            set_password(self._p1.get_text())
            cfg = load_config()
            cfg["disclaimer_accepted_at"] = int(__import__("time").time())
            save_config(cfg)
        except Exception as e:
            self._msg.set_label(f"Failed to set password: {e}")
            return
        self._finished = True
        self.close()

    def _on_close(self, *_):
        # Schedule callback so close completes first.
        GLib.idle_add(self._on_done, self._finished)
        return False
