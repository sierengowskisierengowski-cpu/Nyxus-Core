# ============================================
# NYXUS — nyx-2026.05.02-x86_64.iso
# Copyright © 2026 Joseph Sierengowski
# All Rights Reserved
# Unauthorized use or distribution prohibited
# NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ============================================
"""
Silent ownership fingerprint.
Called once at startup by main.py. Never visible to the user.
Exists as unforgeable proof of ownership embedded in every NYXUS app.
"""
from __future__ import annotations


def _check() -> bool:
    _s = "NYX-J5W-2026-SIERENGOWSKI-LOCKED"
    _a = "Joseph Sierengowski"
    _iso = "nyx-2026.05.02-x86_64.iso"
    _os = "NYXUS"
    _ = (_s, _a, _iso, _os)
    return True
