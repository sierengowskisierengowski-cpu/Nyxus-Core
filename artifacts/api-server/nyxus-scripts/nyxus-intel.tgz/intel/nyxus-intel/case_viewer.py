"""
NYXUS INTEL · case_viewer.py
Tabbed display for an opened case payload.

Tabs (in order):
   Overview · Identity · Breach Data · Public Records · Digital Footprint
   Historical · Financial · Photos · Crypto · Network · Notes · Raw Data

Each tab pulls from the `findings.modules` dict by inspecting the keys of
each module result, so we don't tie the viewer to a specific module name.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Dict, List, Iterable, Tuple

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, GLib, Gdk

from ui_components import (
    GLYPH, PALETTE, hand_label, glyph_button, divider, wrap_sketch, card,
)


def _kv_grid(items: Iterable[Tuple[str, Any]]) -> Gtk.Widget:
    grid = Gtk.Grid(column_spacing=18, row_spacing=4)
    for r, (k, v) in enumerate(items):
        kl = Gtk.Label(label=str(k), xalign=1)
        kl.add_css_class("nx-dim"); kl.add_css_class("nx-mono")
        vl = Gtk.Label(label=_fmt_value(v), xalign=0, wrap=True,
                       wrap_mode=2, selectable=True)
        vl.add_css_class("nx-mono")
        grid.attach(kl, 0, r, 1, 1)
        grid.attach(vl, 1, r, 1, 1)
    return grid


def _fmt_value(v: Any) -> str:
    if v is None: return "—"
    if isinstance(v, bool): return "yes" if v else "no"
    if isinstance(v, (int, float, str)): return str(v)
    if isinstance(v, (list, tuple)):
        if not v: return "[]"
        if all(isinstance(x, (str, int, float)) for x in v):
            return ", ".join(str(x) for x in v[:25]) + (f"  (+{len(v)-25} more)" if len(v) > 25 else "")
        return f"{len(v)} items"
    if isinstance(v, dict):
        return f"{len(v)} fields"
    return repr(v)


def _section(title: str, glyph: str, body: Gtk.Widget) -> Gtk.Widget:
    return card(title, body, glyph=glyph)


def _items_list(items: List[Dict[str, Any]], cols: List[Tuple[str, str]]) -> Gtk.Widget:
    """Render a list of dicts as a small table using a Grid."""
    grid = Gtk.Grid(column_spacing=18, row_spacing=4)
    for ci, (label, _key) in enumerate(cols):
        h = Gtk.Label(label=label, xalign=0)
        h.add_css_class("nx-h3"); h.add_css_class("nx-accent")
        grid.attach(h, ci, 0, 1, 1)
    for ri, row in enumerate(items, start=1):
        for ci, (_label, key) in enumerate(cols):
            v = row.get(key)
            l = Gtk.Label(label=_fmt_value(v), xalign=0, wrap=True,
                          wrap_mode=2, selectable=True)
            l.add_css_class("nx-mono")
            grid.attach(l, ci, ri, 1, 1)
    return grid


# ── viewer ──────────────────────────────────────────────────────────────
class CaseViewer(Gtk.Box):
    def __init__(self, payload: Dict[str, Any], app):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8,
                         margin_top=10, margin_bottom=10,
                         margin_start=12, margin_end=12)
        self.payload = payload
        self.app = app
        self.findings = payload.get("findings") or {}

        self.append(self._build_header())
        self.append(divider())

        self.notebook = Gtk.Notebook(scrollable=True, vexpand=True)
        self.append(self.notebook)

        self._add_tab("Overview",          GLYPH.INFO,     self._tab_overview())
        self._add_tab("Identity",          GLYPH.USER,     self._tab_identity())
        self._add_tab("Breach Data",       GLYPH.SHIELD,   self._tab_breach())
        self._add_tab("Public Records",    GLYPH.DOCUMENT, self._tab_records())
        self._add_tab("Digital Footprint", GLYPH.GLOBE,    self._tab_footprint())
        self._add_tab("Historical",        GLYPH.CLOCK,    self._tab_historical())
        self._add_tab("Financial",         GLYPH.CHART,    self._tab_financial())
        self._add_tab("Photos",            GLYPH.PHOTO,    self._tab_photos())
        self._add_tab("Crypto",            GLYPH.CRYPTO,   self._tab_crypto())
        self._add_tab("Network",           GLYPH.SERVER,   self._tab_network())
        self._add_tab("Notes",             GLYPH.NOTES,    self._tab_notes())
        self._add_tab("Raw Data",          GLYPH.DATABASE, self._tab_raw())

    def _add_tab(self, title: str, glyph: str, child: Gtk.Widget):
        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        wrap = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12,
                       margin_top=12, margin_bottom=12,
                       margin_start=14, margin_end=14)
        wrap.append(child)
        scroll.set_child(wrap)

        label = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        g = Gtk.Label(label=glyph); g.add_css_class("nx-glyph")
        label.append(g)
        label.append(Gtk.Label(label=title))
        self.notebook.append_page(scroll, label)

    # ── header ──────────────────────────────────────────────────────
    def _build_header(self) -> Gtk.Widget:
        outer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2,
                      hexpand=True)
        col.append(hand_label(self.findings.get("subject")
                              or self.payload.get("subject", "(unnamed)"),
                              size="h1"))
        sub = Gtk.Label(
            label=f"detected: {self.findings.get('detected_type','?')}  "
                  f"·  {self.findings.get('summary','')}",
            xalign=0, wrap=True)
        sub.add_css_class("nx-dim"); sub.add_css_class("nx-body")
        col.append(sub)
        outer.append(col)

        export = Gtk.Button(label=f"{GLYPH.EXPORT}   Export PDF")
        export.add_css_class("nx-primary")
        export.connect("clicked", self._on_export)
        outer.append(export)
        return outer

    def _on_export(self, *_):
        from report_generator import generate_pdf
        case_dir_str = ""
        # Best effort: pull case folder from index by subject — but easier
        # to just write next to the case file via the app's case manager.
        # We dump to the user's home if we can't resolve the folder.
        target = Path.home() / f"nyxus-intel-{self.payload.get('subject','case')}.pdf"
        # If the app exposes the case folder for us, prefer that.
        try:
            for row in self.app.cases.alpha():
                if row["subject"] == self.payload.get("subject"):
                    target = Path(row["folder"]) / "report.pdf"
                    break
        except Exception:
            pass

        def worker():
            try:
                generate_pdf(self.payload, target)
                GLib.idle_add(lambda: self._toast(f"PDF saved → {target}"))
            except Exception as e:
                GLib.idle_add(lambda: self._toast(f"PDF failed: {e}", warn=True))
        threading.Thread(target=worker, daemon=True).start()
        self._toast(f"writing PDF…")

    def _toast(self, msg, warn=False):
        # Cheap status line at the top of the viewer
        if not hasattr(self, "_toast_lbl"):
            self._toast_lbl = Gtk.Label(label="", xalign=1)
            self._toast_lbl.add_css_class("nx-dim"); self._toast_lbl.add_css_class("nx-mono")
            self.append(self._toast_lbl)
        self._toast_lbl.set_label(msg)
        if warn: self._toast_lbl.add_css_class("nx-warn")
        else:    self._toast_lbl.remove_css_class("nx-warn")

    # ── per-tab builders ────────────────────────────────────────────
    def _modules(self):  return self.findings.get("modules") or {}
    def _errors(self):   return self.findings.get("errors") or {}

    def _module_by_keys(self, *keys) -> List[Tuple[str, Dict[str, Any]]]:
        """Return [(label, data)] for modules whose result contains ANY of
        the given keys."""
        out = []
        for label, data in self._modules().items():
            if isinstance(data, dict) and any(k in data for k in keys):
                out.append((label, data))
        return out

    def _tab_overview(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.append(_section("Summary", GLYPH.INFO, _kv_grid([
            ("Subject",       self.findings.get("subject")),
            ("Detected type", self.findings.get("detected_type")),
            ("Modules run",   len(self._modules())),
            ("Errors",        len(self._errors())),
            ("Started",       self.findings.get("started_at")),
            ("Finished",      self.findings.get("finished_at")),
            ("Elapsed (s)",   self.findings.get("elapsed")),
        ])))

        # Errors / missing keys list
        if self._errors():
            err_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            for lab, msg in self._errors().items():
                row = Gtk.Box(spacing=6)
                g = Gtk.Label(label=GLYPH.WARNING); g.add_css_class("nx-glyph"); g.add_css_class("nx-warn")
                row.append(g)
                row.append(Gtk.Label(label=f"{lab}: {msg}", xalign=0, wrap=True,
                                     wrap_mode=2, selectable=True))
                err_box.append(row)
            box.append(_section("Errors / Missing API Keys", GLYPH.WARNING, err_box))
        return box

    def _tab_identity(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._module_by_keys("name", "display_name", "preferred_username",
                                                "twitter", "bio", "company"):
            box.append(_section(label, GLYPH.USER, _kv_grid([
                ("name",       data.get("name") or data.get("display_name")),
                ("username",   data.get("username") or data.get("preferred_username")),
                ("bio",        data.get("bio") or data.get("about")),
                ("company",    data.get("company")),
                ("location",   data.get("location")),
                ("blog",       data.get("blog")),
                ("twitter",    data.get("twitter")),
                ("created",    data.get("created_at") or data.get("created_utc")),
                ("profile",    data.get("html_url") or data.get("profile_url") or data.get("url")),
            ])))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No identity data collected.", xalign=0))
        return box

    def _tab_breach(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._module_by_keys("breach_count", "breaches", "entries"):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            inner.append(_kv_grid([
                ("breaches",    data.get("breach_count")),
                ("entries",     data.get("result_count")),
            ]))
            if data.get("breaches"):
                inner.append(_items_list(data["breaches"],
                    [("name","name"),("date","breach_date"),("pwn count","pwn_count"),
                     ("data classes","data_classes")]))
            if data.get("entries"):
                inner.append(_items_list(data["entries"],
                    [("db","db_name"),("username","username"),("ip","ip"),
                     ("name","name"),("phone","phone")]))
            box.append(_section(label, GLYPH.SHIELD, inner))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No breach data found.", xalign=0))
        return box

    def _tab_records(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._modules().items():
            if not isinstance(data, dict): continue
            if not any(k in data for k in ("fec", "opensanctions", "rows", "row_count")):
                continue
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            if "fec" in data and isinstance(data["fec"], dict) and data["fec"].get("results"):
                inner.append(hand_label("FEC contributions", size="h3"))
                inner.append(_items_list(data["fec"]["results"],
                    [("contributor","contributor"),("city","city"),("state","state"),
                     ("amount","amount"),("date","date"),("committee","committee")]))
            if "opensanctions" in data and isinstance(data["opensanctions"], dict) \
                    and data["opensanctions"].get("results"):
                inner.append(hand_label("OpenSanctions matches", size="h3"))
                inner.append(_items_list(data["opensanctions"]["results"],
                    [("name","caption"),("score","score"),("schema","schema"),
                     ("countries","countries"),("topics","topics")]))
            if "rows" in data and data.get("rows"):
                inner.append(hand_label("FCC rows", size="h3"))
                inner.append(Gtk.Label(label=json.dumps(data["rows"], indent=2),
                                       xalign=0, selectable=True, wrap=True, wrap_mode=2))
            if inner.get_first_child():
                box.append(_section(label, GLYPH.DOCUMENT, inner))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No public-records hits.", xalign=0))
        return box

    def _tab_footprint(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        # Sherlock + Holehe
        for label, data in self._module_by_keys("sites", "found_count"):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            inner.append(_kv_grid([("found", data.get("found_count"))]))
            for s in (data.get("sites") or [])[:200]:
                row = Gtk.Box(spacing=8)
                g = Gtk.Label(label=GLYPH.LINK); g.add_css_class("nx-glyph"); g.add_css_class("nx-accent")
                row.append(g)
                t = (s.get("site") or "") + ("  " + s.get("url","") if s.get("url") else "")
                lbl = Gtk.Label(label=t, xalign=0, wrap=True, wrap_mode=2, selectable=True)
                row.append(lbl)
                inner.append(row)
            box.append(_section(label, GLYPH.GLOBE, inner))
        # Google CSE
        for label, data in self._module_by_keys("results"):
            if not isinstance(data.get("results"), list): continue
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            for r in data["results"][:50]:
                inner.append(Gtk.Label(label=f"• {r.get('title')}\n  {r.get('link')}\n  {r.get('snippet')}",
                                       xalign=0, wrap=True, wrap_mode=2, selectable=True))
                inner.append(divider())
            box.append(_section(label, GLYPH.SEARCH, inner))
        # Reddit comments
        for label, data in self._module_by_keys("recent_comments"):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            for c in (data.get("recent_comments") or [])[:30]:
                inner.append(Gtk.Label(
                    label=f"r/{c.get('subreddit')}  ·  score {c.get('score')}\n{c.get('body')}\n{c.get('permalink')}",
                    xalign=0, wrap=True, wrap_mode=2, selectable=True))
                inner.append(divider())
            box.append(_section(label, GLYPH.NOTES, inner))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No digital footprint data collected.", xalign=0))
        return box

    def _tab_historical(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._module_by_keys("first_seen", "creation_date",
                                                "snapshots", "examples"):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            inner.append(_kv_grid([
                ("first seen",   data.get("first_seen")),
                ("creation",     data.get("creation_date")),
                ("expiration",   data.get("expiration_date")),
                ("snapshots",    data.get("snapshots")),
                ("registrar",    data.get("registrar")),
            ]))
            for ex in (data.get("examples") or [])[:8]:
                inner.append(Gtk.Label(label=f"  {ex.get('timestamp')}  →  {ex.get('url')}",
                                       xalign=0, selectable=True))
            box.append(_section(label, GLYPH.CLOCK, inner))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No historical data collected.", xalign=0))
        return box

    def _tab_financial(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._module_by_keys("balance_btc", "balance_eth"):
            box.append(_section(label, GLYPH.CHART, _kv_grid([
                ("balance BTC",  data.get("balance_btc")),
                ("balance ETH",  data.get("balance_eth")),
                ("received BTC", data.get("received_btc")),
                ("sent BTC",     data.get("sent_btc")),
                ("tx count",     data.get("n_tx") or data.get("tx_count")),
            ])))
        # FEC contributions (if any)
        for label, data in self._modules().items():
            if isinstance(data, dict) and isinstance(data.get("fec"), dict) \
                    and data["fec"].get("results"):
                amount = sum((r.get("amount") or 0) for r in data["fec"]["results"])
                box.append(_section(f"{label} (FEC)", GLYPH.CHART, _kv_grid([
                    ("contributions count", len(data["fec"]["results"])),
                    ("total reported $",    f"{amount:,.2f}"),
                ])))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No financial data collected.", xalign=0))
        return box

    def _tab_photos(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._module_by_keys("exif_present", "exif_gps", "sha256"):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            inner.append(_kv_grid([
                ("path",        data.get("path")),
                ("size",        data.get("size_bytes")),
                ("sha-256",     data.get("sha256")),
                ("dimensions",  f"{data.get('width','?')}x{data.get('height','?')}"),
                ("format",      data.get("format")),
                ("exif present",data.get("exif_present")),
            ]))
            if data.get("exif_gps"):
                gps = data["exif_gps"]
                inner.append(_kv_grid([
                    ("lat",      gps.get("lat")),
                    ("lng",      gps.get("lng")),
                    ("map",      data.get("map_url")),
                    ("address",  (data.get("geocode") or {}).get("display_name")),
                ]))
            for w in data.get("integrity_warnings") or []:
                row = Gtk.Box(spacing=6)
                g = Gtk.Label(label=GLYPH.WARNING); g.add_css_class("nx-glyph"); g.add_css_class("nx-warn")
                row.append(g)
                row.append(Gtk.Label(label=w, xalign=0, wrap=True, wrap_mode=2, selectable=True))
                inner.append(row)
            box.append(_section(label, GLYPH.PHOTO, inner))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No photo data collected.", xalign=0))
        return box

    def _tab_crypto(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._module_by_keys("balance_btc", "balance_eth", "transactions"):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            inner.append(_kv_grid([
                ("address",   data.get("address")),
                ("explorer",  data.get("explorer")),
                ("balance",   data.get("balance_btc") or data.get("balance_eth")),
                ("tx count",  data.get("n_tx") or data.get("tx_count")),
            ]))
            txs = data.get("transactions") or []
            if txs:
                inner.append(hand_label("Transactions", size="h3"))
                cols = ([("hash","hash"),("time","time"),("result","result"),("fee","fee")]
                        if "result" in (txs[0] if txs else {})
                        else [("hash","hash"),("time","time"),("from","from"),("to","to"),
                              ("value ETH","value_eth")])
                inner.append(_items_list(txs, cols))
            tt = data.get("token_transfers") or []
            if tt:
                inner.append(hand_label("Token transfers", size="h3"))
                inner.append(_items_list(tt,
                    [("token","token"),("amount","amount"),("from","from"),
                     ("to","to"),("time","time")]))
            box.append(_section(label, GLYPH.CRYPTO, inner))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No crypto data collected.", xalign=0))
        return box

    def _tab_network(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for label, data in self._module_by_keys("ports", "asn", "country", "ptr",
                                                "is_tor_exit", "subdomains_count",
                                                "A", "MX", "NS"):
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            inner.append(_kv_grid([
                ("ip",         data.get("ip")),
                ("hostname",   data.get("hostname") or data.get("ptr")),
                ("city",       data.get("city")),
                ("country",    data.get("country")),
                ("asn",        data.get("asn") or data.get("as_owner")),
                ("isp/org",    data.get("isp") or data.get("org")),
                ("tor exit",   data.get("is_tor_exit")),
                ("ports",      data.get("ports")),
                ("vulns",      data.get("vulns")),
                ("abuse score",data.get("abuse_score")),
                ("subdomains", data.get("subdomains_count")),
            ]))
            for rt in ("A","AAAA","MX","NS","TXT","SOA","CNAME"):
                if data.get(rt):
                    inner.append(Gtk.Label(label=f"{rt}: " + ", ".join(data[rt]),
                                           xalign=0, wrap=True, wrap_mode=2, selectable=True))
            services = data.get("services") or []
            if services:
                inner.append(hand_label("Exposed services", size="h3"))
                inner.append(_items_list(services,
                    [("port","port"),("transport","transport"),("product","product"),
                     ("version","version")]))
            box.append(_section(label, GLYPH.SERVER, inner))
        if not box.get_first_child():
            box.append(Gtk.Label(label="No network data collected.", xalign=0))
        return box

    def _tab_notes(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.append(hand_label("Investigator notes", size="h2"))
        view = Gtk.TextView(wrap_mode=Gtk.WrapMode.WORD_CHAR, vexpand=True)
        view.set_size_request(-1, 240)
        view.add_css_class("nx-body")
        buf = view.get_buffer()
        buf.set_text(self.payload.get("notes", ""))
        scroll = Gtk.ScrolledWindow(vexpand=True)
        scroll.set_child(view)
        box.append(scroll)

        save = Gtk.Button(label="Save notes")
        save.add_css_class("nx-primary")

        def _save(*_):
            txt = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), True)
            try:
                # Find case_id by subject
                cid = None
                for row in self.app.cases.alpha():
                    if row["folder"] and row["subject"] == self.payload.get("subject"):
                        cid = row["id"]; break
                if cid is None: return
                def mut(p): p["notes"] = txt
                self.app.cases.update(cid, mut)
                self._toast("notes saved")
            except Exception as e:
                self._toast(f"save failed: {e}", warn=True)
        save.connect("clicked", _save)
        box.append(save)
        return box

    def _tab_raw(self) -> Gtk.Widget:
        view = Gtk.TextView(editable=False, monospace=True,
                            wrap_mode=Gtk.WrapMode.NONE, vexpand=True)
        view.add_css_class("nx-mono")
        try:
            txt = json.dumps(self.payload, indent=2, default=str)
        except Exception as e:
            txt = f"render failed: {e}"
        view.get_buffer().set_text(txt)
        scroll = Gtk.ScrolledWindow(vexpand=True, hexpand=True)
        scroll.set_child(view)
        return scroll
