"""
NYXUS INTEL · domain_intel.py
Domain investigation — WHOIS, DNS, certificate transparency, web archive.

  • python-whois          — no key
  • dnspython             — no key
  • crt.sh                — public, no key
  • Internet Archive CDX  — public, no key
  • VirusTotal v3 domains — key required (free tier OK)

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

from typing import Dict, Any, Optional, List

import requests

UA = "NYXUS-INTEL/1.0 (research/OSINT)"
TIMEOUT = 30


def _err(msg): return {"__error__": msg}


def whois_lookup(domain: str) -> Dict[str, Any]:
    try:
        import whois  # python-whois
    except ImportError:
        return _err("python-whois not installed")
    try:
        w = whois.whois(domain)
    except Exception as e:
        return _err(f"WHOIS: {e}")

    def _to_str(v):
        if v is None: return None
        if isinstance(v, list):
            return [_to_str(x) for x in v]
        try:
            return v.isoformat() if hasattr(v, "isoformat") else str(v)
        except Exception:
            return str(v)

    return {
        "domain":         _to_str(w.domain_name) if hasattr(w, "domain_name") else domain,
        "registrar":      _to_str(w.registrar)        if hasattr(w, "registrar") else None,
        "creation_date":  _to_str(w.creation_date)    if hasattr(w, "creation_date") else None,
        "expiration_date":_to_str(w.expiration_date)  if hasattr(w, "expiration_date") else None,
        "updated_date":   _to_str(w.updated_date)     if hasattr(w, "updated_date") else None,
        "name_servers":   _to_str(w.name_servers)     if hasattr(w, "name_servers") else None,
        "status":         _to_str(w.status)           if hasattr(w, "status") else None,
        "emails":         _to_str(w.emails)           if hasattr(w, "emails") else None,
        "country":        _to_str(w.country)          if hasattr(w, "country") else None,
        "org":            _to_str(w.org)              if hasattr(w, "org") else None,
        "raw":            (str(w.text)[:4000] if getattr(w, "text", None) else None),
    }


def dns_records(domain: str) -> Dict[str, Any]:
    try:
        import dns.resolver
    except ImportError:
        return _err("dnspython not installed")
    out: Dict[str, Any] = {"domain": domain}
    for rtype in ("A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME"):
        try:
            ans = dns.resolver.resolve(domain, rtype, lifetime=10)
            out[rtype] = [r.to_text() for r in ans]
        except Exception as e:
            out[rtype + "_error"] = str(e)
    return out


def crtsh_lookup(domain: str) -> Dict[str, Any]:
    """certificate-transparency log search — also yields subdomains."""
    r = requests.get("https://crt.sh/", params={"q": f"%.{domain}", "output": "json"},
                     timeout=TIMEOUT, headers={"User-Agent": UA})
    if r.status_code != 200:
        return _err(f"crt.sh HTTP {r.status_code}")
    try:
        rows = r.json()
    except Exception:
        return _err("crt.sh returned non-JSON")
    subs = set()
    certs: List[Dict[str, Any]] = []
    for row in rows[:500]:
        for n in (row.get("name_value") or "").splitlines():
            n = n.strip().lower()
            if n.endswith(domain.lower()):
                subs.add(n)
        certs.append({
            "issuer":     row.get("issuer_name"),
            "not_before": row.get("not_before"),
            "not_after":  row.get("not_after"),
            "serial":     row.get("serial_number"),
            "id":         row.get("id"),
        })
    subs = sorted(subs)
    return {
        "domain":            domain,
        "subdomains_count":  len(subs),
        "subdomains":        subs[:500],
        "cert_count":        len(certs),
        "certs":             certs[:200],
    }


def wayback_first_seen(domain: str) -> Dict[str, Any]:
    r = requests.get(
        "http://web.archive.org/cdx/search/cdx",
        params={"url": domain, "limit": "5", "from": "1996", "output": "json"},
        timeout=TIMEOUT, headers={"User-Agent": UA},
    )
    if r.status_code != 200:
        return _err(f"Wayback HTTP {r.status_code}")
    try:
        data = r.json()
    except Exception:
        return _err("Wayback returned non-JSON")
    if not data or len(data) < 2:
        return {"domain": domain, "first_seen": None, "snapshots": 0}

    rows = data[1:]
    first_ts = rows[0][1] if rows[0] else None

    # total snapshot count
    rc = requests.get(
        "http://web.archive.org/cdx/search/cdx",
        params={"url": domain, "showNumPages": "true"},
        timeout=TIMEOUT, headers={"User-Agent": UA})
    pages = 0
    try: pages = int(rc.text.strip())
    except Exception: pass

    return {
        "domain":     domain,
        "first_seen": first_ts,
        "snapshots":  pages,
        "examples":   [{"timestamp": r[1], "url": r[2]} for r in rows],
    }


def virustotal_domain(domain: str, key: Optional[str]) -> Dict[str, Any]:
    if not key:
        return _err("set VirusTotal API key in Settings")
    r = requests.get(
        f"https://www.virustotal.com/api/v3/domains/{domain}",
        headers={"x-apikey": key, "User-Agent": UA},
        timeout=TIMEOUT,
    )
    if r.status_code == 401: return _err("VirusTotal rejected the API key")
    if r.status_code == 429: return _err("VirusTotal rate-limited")
    if r.status_code == 404: return {"domain": domain, "found": False}
    if r.status_code != 200: return _err(f"VirusTotal HTTP {r.status_code}")
    a = (r.json().get("data") or {}).get("attributes") or {}
    return {
        "domain":      domain,
        "reputation":  a.get("reputation"),
        "categories":  a.get("categories"),
        "last_analysis_stats": a.get("last_analysis_stats"),
        "creation_date":       a.get("creation_date"),
        "registrar":           a.get("registrar"),
        "tags":                a.get("tags"),
    }
