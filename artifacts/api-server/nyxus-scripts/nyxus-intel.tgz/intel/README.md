# NYXUS INTEL

Professional grade native GTK4 Open Source Intelligence (OSINT)
investigation workstation. Encrypted case storage, hand-drawn aesthetic,
real APIs only — no mock data, no telemetry.

```
curl -fsSL https://nyxus-core.replit.app/api/download/nyxus/nyxus_intel_install.sh | bash
nyxus-intel
```

## What it does

Type any of the following into the search box and we auto-detect the
subject type and dispatch the right intel modules in parallel:

* email address (e.g. `someone@example.com`)
* phone number  (e.g. `+1 415 555 0123`)
* IPv4 / IPv6   (e.g. `8.8.8.8`)
* domain        (e.g. `example.com`)
* BTC address   (`1…`, `3…`, `bc1…`)
* ETH address   (`0x` + 40 hex)
* image path    (drop a .jpg, .png, .tiff, …)
* username      (single token, no spaces)
* free text     (treated as a person's name)

Results are filed automatically into

```
~/.config/nyxus-intel/cases/<LASTNAME>_<FIRSTNAME>_<DATE>/
   identity/  breach_data/  public_records/  digital_footprint/
   historical/ financial/ photos/ crypto/ communications/
   location/  network/  notes/
   case.nxc      ← AES-256-GCM encrypted envelope
```

## Security

* Master password (bcrypt, 12 rounds) gates the entire app.
* 3 wrong attempts → process exits with code `2`.
* `Ctrl+L` re-locks. Auto-lock kicks in after `lock_minutes` (default 5).
* PBKDF2-HMAC-SHA256 (200,000 iterations) derives the encryption key from
  the master password. AES-256-GCM with per-case nonces and authenticated
  associated data.
* All API keys live in `~/.config/nyxus-intel/config.json` (`chmod 600`).
* Nothing is ever transmitted to NYXUS — every API call goes directly from
  your machine to the third party.

## API keys

See `api_setup.md`.

## License & copyright

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
