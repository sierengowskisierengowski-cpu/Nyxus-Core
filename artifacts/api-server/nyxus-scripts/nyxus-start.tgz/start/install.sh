#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────
# NYXUS Start — sub-app installer
#
# Called by the top-level nyxus_start_install.sh after the tarball is
# extracted.  Lays files into ~/.nyxus/nyxus-start/, installs Python +
# system deps, drops a launcher script, .desktop entry, and patches
# Waybar config (config + style) to add Start + Panel buttons.
#
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ──────────────────────────────────────────────────────────────────────
set -euo pipefail

B=$'\e[1m'; R=$'\e[0m'; PINK=$'\e[38;5;201m'; CYAN=$'\e[38;5;51m'
GOLD=$'\e[38;5;220m'; PURPLE=$'\e[38;5;177m'; DIM=$'\e[2m'

step() { printf "\n${PURPLE}▌${R} ${B}%s${R}\n" "$*"; }
ok()   { printf "  ${CYAN}✓${R}  %s\n" "$*"; }
warn() { printf "  ${GOLD}!${R}  %s\n" "$*"; }
fail() { printf "  ${PINK}✗${R}  %s\n" "$*" >&2; }

# ── resolve real user (script may run as root via sudo)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6)"
[[ -z "$REAL_HOME" || ! -d "$REAL_HOME" ]] && REAL_HOME="$HOME"

INSTALL_DIR="${REAL_HOME}/.nyxus/nyxus-start"
BIN_DIR="${REAL_HOME}/.local/bin"
APP_DIR="${REAL_HOME}/.local/share/applications"
WAYBAR_DIR="${REAL_HOME}/.config/waybar"

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

step "preflight"
for cmd in python3 install; do
  command -v "$cmd" >/dev/null || { fail "$cmd not found"; exit 1; }
done
ok "python3 / install present"

# ── system packages
step "system packages (pacman)"
if command -v pacman >/dev/null; then
  pacman -S --noconfirm --needed \
    gtk4 python-gobject python-cairo python-psutil \
    2>/dev/null \
    && ok "gtk4 / python-gobject / python-cairo / psutil" \
    || warn "pacman: some core packages failed (re-run: sudo pacman -S gtk4 python-gobject python-psutil)"

  pacman -S --noconfirm --needed gtk4-layer-shell 2>/dev/null \
    && ok "gtk4-layer-shell (Start anchors above taskbar)" \
    || warn "gtk4-layer-shell missing — falls back to centered floating window"

  pacman -S --noconfirm --needed jq 2>/dev/null \
    && ok "jq (used to patch Waybar config safely)" \
    || warn "jq missing — Waybar config patching may be skipped"
else
  warn "pacman not found — install GTK4 + python-gobject manually"
fi

# ── lay down files
step "deploy files → ${INSTALL_DIR}"
install -d -o "$REAL_USER" "${INSTALL_DIR}" "${BIN_DIR}" "${APP_DIR}" \
        "${REAL_HOME}/.config/nyxus-start" "${REAL_HOME}/.cache/nyxus-start"
cp -r "${SRC_DIR}/nyxus-start/." "${INSTALL_DIR}/"
chown -R "$REAL_USER":"$REAL_USER" "${INSTALL_DIR}"
chmod -R u+rw,go+r "${INSTALL_DIR}"
ok "deployed $(find "${INSTALL_DIR}" -maxdepth 1 -type f | wc -l) files"

# ── launcher script
step "launcher script"
cat > "${BIN_DIR}/nyxus-start" <<EOF
#!/usr/bin/env bash
exec python3 "${INSTALL_DIR}/main.py" "\$@"
EOF
chmod +x "${BIN_DIR}/nyxus-start"
chown "$REAL_USER":"$REAL_USER" "${BIN_DIR}/nyxus-start"
ok "${BIN_DIR}/nyxus-start"

# ── waybar state helper (emits JSON for the custom modules)
install -m 0755 -o "$REAL_USER" -g "$REAL_USER" \
        "${SRC_DIR}/nyxus-waybar-state" "${BIN_DIR}/nyxus-waybar-state"
ok "${BIN_DIR}/nyxus-waybar-state"

# ── notifications launcher placeholder.
# Lays down ${BIN_DIR}/nyxus-notifications as a thin shell stub that pops
# a polite "coming soon" toast (via notify-send when available, otherwise
# a silent no-op). The Waybar Notifications button's on-click points here,
# so clicks always resolve to a valid binary; when the real flyout ships
# in a follow-up release it will overwrite this script in place.
# The file is created ONLY if it does not already exist, so a real
# nyxus-notifications binary delivered later won't be clobbered.
if [[ ! -f "${BIN_DIR}/nyxus-notifications" ]]; then
  cat > "${BIN_DIR}/nyxus-notifications" <<'STUB'
#!/usr/bin/env bash
# NYXUS Notifications — placeholder launcher.
# Replaced by the real flyout binary in a future release.
if command -v notify-send >/dev/null 2>&1; then
  notify-send -a 'NYXUS' 'NYXUS · Notifications' \
    'Coming soon — flyout backend ships in a follow-up release.'
fi
exit 0
STUB
  chmod +x "${BIN_DIR}/nyxus-notifications"
  chown "$REAL_USER":"$REAL_USER" "${BIN_DIR}/nyxus-notifications"
  ok "${BIN_DIR}/nyxus-notifications (placeholder stub)"
else
  ok "${BIN_DIR}/nyxus-notifications already present — left unchanged"
fi

# ── handwritten font (Caveat) — required for the Start/Panel button text.
# Drop into the user's font dir (no root needed) so it's available system-wide
# for fontconfig consumers like Waybar/Pango. fc-cache rebuilds the index.
step "fonts (Caveat — handwritten button labels)"
FONT_DIR="${REAL_HOME}/.local/share/fonts/nyxus"
install -d -o "$REAL_USER" -g "$REAL_USER" "$FONT_DIR"
if [[ -f "${SRC_DIR}/fonts/Caveat.ttf" ]]; then
  install -m 0644 -o "$REAL_USER" -g "$REAL_USER" \
          "${SRC_DIR}/fonts/Caveat.ttf" "${FONT_DIR}/Caveat.ttf"
  install -m 0644 -o "$REAL_USER" -g "$REAL_USER" \
          "${SRC_DIR}/fonts/OFL.txt" "${FONT_DIR}/OFL.txt"
  if command -v fc-cache >/dev/null; then
    sudo -u "$REAL_USER" fc-cache -f "${REAL_HOME}/.local/share/fonts" >/dev/null 2>&1 \
      && ok "Caveat installed + font cache rebuilt" \
      || warn "Caveat installed but fc-cache failed (font may need a relog)"
  else
    ok "Caveat installed (fc-cache missing; relog to refresh)"
  fi
else
  warn "Caveat.ttf not bundled — handwritten button text will fall back"
fi

# ── .desktop file
cat > "${APP_DIR}/io.nyxus.start.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=NYXUS Start
GenericName=Start Menu Flyout
Comment=Left-side flyout — search · pinned apps · recent · power
Exec=${BIN_DIR}/nyxus-start
Icon=io.nyxus.start
Terminal=false
Categories=Utility;System;
StartupNotify=false
EOF
chown "$REAL_USER":"$REAL_USER" "${APP_DIR}/io.nyxus.start.desktop"
ok ".desktop entry"

sudo -u "$REAL_USER" update-desktop-database "${APP_DIR}" 2>/dev/null || true

# ──────────────────────────────────────────────────────────────────────
# Waybar integration — add Start (left) + Panel (right) buttons
# ──────────────────────────────────────────────────────────────────────
step "waybar integration"

WAYBAR_CFG="${WAYBAR_DIR}/config"
WAYBAR_CSS="${WAYBAR_DIR}/style.css"

if [[ -f "$WAYBAR_CFG" ]] && command -v jq >/dev/null; then
  cp "$WAYBAR_CFG" "${WAYBAR_CFG}.bak.nyxus-start.$(date +%s)"

  # The patcher must work whether the config is a single object OR an array
  # of bar definitions. We branch on .type and apply the same patch to either
  # the lone object (when its .position is "bottom") or every "bottom" element
  # of an array. Empty `.position` defaults to "bottom" in Waybar, so we treat
  # missing/null .position as "bottom" too.
  # The patch:
  #   • Replaces both buttons with exec-driven custom modules — they get
  #     their text + open/closed class from `nyxus-waybar-state`. The label
  #     is hand-drawn (Caveat) Pango markup; the glow is in style.css.
  #   • Drops the legacy rofi "custom/start" entry entirely (key + module
  #     references) — the new Start button's search bar replaces Rofi.
  #   • Pins custom/nyxus-start as the FIRST left module and custom/nyxus-panel
  #     as the LAST right module.
  PATCH_EXPR='
    def patch_bar:
      .["custom/nyxus-start"] = {
        "exec":        ($helper + " start"),
        "interval":    1,
        "return-type": "json",
        "format":      "{}",
        "escape":      false,
        "tooltip":     true,
        "on-click":    $launcher_start
      }
      | .["custom/nyxus-panel"] = {
          "exec":        ($helper + " panel"),
          "interval":    1,
          "return-type": "json",
          "format":      "{}",
          "escape":      false,
          "tooltip":     true,
          "on-click":    $launcher_panel
        }
      | .["custom/nyxus-notifications"] = {
          "exec":        ($helper + " notifications"),
          "interval":    1,
          "return-type": "json",
          "format":      "{}",
          "escape":      false,
          "tooltip":     true,
          "on-click":    $launcher_notifications
        }
      # Drop the legacy rofi entry entirely
      | del(.["custom/start"])
      | ."modules-left" =
          ( ["custom/nyxus-start"] +
            ((."modules-left" // [])
              | map(select(. != "custom/nyxus-start" and . != "custom/start"))) )
      | ."modules-right" =
          ( ((."modules-right" // [])
              | map(select(. != "custom/nyxus-panel"
                       and  . != "custom/nyxus-notifications"
                       and  . != "custom/start"))) +
            ["custom/nyxus-panel", "custom/nyxus-notifications"] );

    def is_bottom: (.position == "bottom") or (.position == null) or (.position == "");

    if type == "array" then
      map(if is_bottom then patch_bar else . end)
    elif type == "object" and is_bottom then
      patch_bar
    else
      .
    end
  '

  if sudo -u "$REAL_USER" jq \
       --arg launcher_start         "${BIN_DIR}/nyxus-start" \
       --arg launcher_panel         "${BIN_DIR}/nyxus-panel" \
       --arg launcher_notifications "${BIN_DIR}/nyxus-notifications" \
       --arg helper                 "${BIN_DIR}/nyxus-waybar-state" \
       "$PATCH_EXPR" "$WAYBAR_CFG" > "${WAYBAR_CFG}.tmp"; then
    mv "${WAYBAR_CFG}.tmp" "$WAYBAR_CFG"
    chown "$REAL_USER":"$REAL_USER" "$WAYBAR_CFG"
    ok "patched ${WAYBAR_CFG} (Start far-left, Panel + Notifications far-right)"
  else
    rm -f "${WAYBAR_CFG}.tmp"
    warn "jq patch failed — original config unchanged. See waybar_additions.json to merge by hand."
  fi
else
  warn "Waybar config not found OR jq missing — see waybar_additions.json"
fi

# Replace the NYXUS-managed CSS block in Waybar's style.css (upgrade-safe).
# The shipped waybar_styles.css is wrapped in BEGIN/END markers; we delete any
# existing managed block (and any legacy sentinel block from prior installs)
# then append the freshest version. This way users who already have an older
# Start/Panel-only block automatically get the new Notifications rules too.
if [[ -f "$WAYBAR_CSS" ]]; then
  TMP_CSS="$(mktemp)"
  # 1. Drop the current managed block (idempotent — does nothing on first run)
  sed '/NYXUS-WAYBAR-MANAGED-BLOCK BEGIN/,/NYXUS-WAYBAR-MANAGED-BLOCK END/d' \
      "$WAYBAR_CSS" > "$TMP_CSS"
  # 2. Drop the legacy sentinel-only block from the previous installer version
  #    (a single comment header beginning with "NYXUS-START-BUTTON-STYLE"
  #    through to the end of file — that prior format had no closing marker,
  #    so we rely on the fact that nothing else lives below it).
  if grep -q 'NYXUS-START-BUTTON-STYLE' "$TMP_CSS"; then
    sed -i '/NYXUS-START-BUTTON-STYLE/,$d' "$TMP_CSS"
  fi
  # 3. Append the fresh managed block (already wrapped in BEGIN/END markers)
  cat "${SRC_DIR}/waybar_styles.css" >> "$TMP_CSS"
  mv "$TMP_CSS" "$WAYBAR_CSS"
  chown "$REAL_USER":"$REAL_USER" "$WAYBAR_CSS"
  ok "refreshed NYXUS Waybar CSS block in ${WAYBAR_CSS}"
else
  warn "Waybar style.css missing — see waybar_styles.css"
fi

# Restart waybar so changes take effect
if command -v pkill >/dev/null; then
  sudo -u "$REAL_USER" pkill -SIGUSR2 waybar 2>/dev/null \
    && ok "waybar reloaded (SIGUSR2)" \
    || warn "waybar not running — restart it manually to see the buttons"
fi

cat <<EOF

──────────────────────────────────────────────────────────────────────
${B}NYXUS Start installed.${R}

${B}launch:${R}    ${GOLD}nyxus-start${R}                  ${DIM}(toggles open / close)${R}
${B}pinned:${R}    ${REAL_HOME}/.config/nyxus-start/pins.json
${B}recent:${R}    ${REAL_HOME}/.config/nyxus-start/recent.json
${B}config:${R}    ${REAL_HOME}/.config/nyxus-start/config.json
${B}install:${R}   ${INSTALL_DIR}

${B}waybar:${R}    Start button is now on the FAR LEFT,
           Panel button is on the FAR RIGHT.
──────────────────────────────────────────────────────────────────────
EOF
