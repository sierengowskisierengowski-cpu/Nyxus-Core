#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────
# NYXUS Start — sub-app installer
#
# Called by the top-level nyxus_start_install.sh after the tarball is
# extracted.  Lays files into ~/.nyxus/nyxus-start/, installs Python +
# system deps, drops a launcher script, .desktop entry, and patches
# Waybar config (config + style) to add Start + Panel buttons.
#
# © 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
# ──────────────────────────────────────────────────────────────────────
set -euo pipefail

B=$'\e[1m'; R=$'\e[0m'; PINK=$'\e[38;5;201m'; CYAN=$'\e[38;5;51m'
GOLD=$'\e[38;5;220m'; PURPLE=$'\e[38;5;177m'; DIM=$'\e[2m'

step() { printf "\n${PURPLE}▌${R} ${B}%s${R}\n" "$*"; }
ok()   { printf "  ${CYAN}✓${R}  %s\n" "$*"; }
warn() { printf "  ${GOLD}!${R}  %s\n" "$*"; }
fail() { printf "  ${PINK}✗${R}  %s\n" "$*" >&2; }

# ── resolve real user (script may run as root via sudo)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6)"
[[ -z "$REAL_HOME" || ! -d "$REAL_HOME" ]] && REAL_HOME="$HOME"

INSTALL_DIR="${REAL_HOME}/.nyxus/nyxus-start"
BIN_DIR="${REAL_HOME}/.local/bin"
APP_DIR="${REAL_HOME}/.local/share/applications"
WAYBAR_DIR="${REAL_HOME}/.config/waybar"

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

step "preflight"
for cmd in python3 install; do
  command -v "$cmd" >/dev/null || { fail "$cmd not found"; exit 1; }
done
ok "python3 / install present"

# ── system packages
step "system packages (pacman)"
if command -v pacman >/dev/null; then
  pacman -S --noconfirm --needed \
    gtk4 python-gobject python-cairo python-psutil \
    2>/dev/null \
    && ok "gtk4 / python-gobject / python-cairo / psutil" \
    || warn "pacman: some core packages failed (re-run: sudo pacman -S gtk4 python-gobject python-psutil)"

  pacman -S --noconfirm --needed gtk4-layer-shell 2>/dev/null \
    && ok "gtk4-layer-shell (Start anchors above taskbar)" \
    || warn "gtk4-layer-shell missing — falls back to centered floating window"

  pacman -S --noconfirm --needed jq 2>/dev/null \
    && ok "jq (used to patch Waybar config safely)" \
    || warn "jq missing — Waybar config patching may be skipped"
else
  warn "pacman not found — install GTK4 + python-gobject manually"
fi

# ── lay down files
step "deploy files → ${INSTALL_DIR}"
install -d -o "$REAL_USER" "${INSTALL_DIR}" "${BIN_DIR}" "${APP_DIR}" \
        "${REAL_HOME}/.config/nyxus-start" "${REAL_HOME}/.cache/nyxus-start"
cp -r "${SRC_DIR}/nyxus-start/." "${INSTALL_DIR}/"
chown -R "$REAL_USER":"$REAL_USER" "${INSTALL_DIR}"
chmod -R u+rw,go+r "${INSTALL_DIR}"
ok "deployed $(find "${INSTALL_DIR}" -maxdepth 1 -type f | wc -l) files"

# ── launcher script
step "launcher script"
cat > "${BIN_DIR}/nyxus-start" <<EOF
#!/usr/bin/env bash
exec python3 "${INSTALL_DIR}/main.py" "\$@"
EOF
chmod +x "${BIN_DIR}/nyxus-start"
chown "$REAL_USER":"$REAL_USER" "${BIN_DIR}/nyxus-start"
ok "${BIN_DIR}/nyxus-start"

# ── .desktop file
cat > "${APP_DIR}/io.nyxus.start.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=NYXUS Start
GenericName=Start Menu Flyout
Comment=Left-side flyout — search · pinned apps · recent · power
Exec=${BIN_DIR}/nyxus-start
Icon=io.nyxus.start
Terminal=false
Categories=Utility;System;
StartupNotify=false
EOF
chown "$REAL_USER":"$REAL_USER" "${APP_DIR}/io.nyxus.start.desktop"
ok ".desktop entry"

sudo -u "$REAL_USER" update-desktop-database "${APP_DIR}" 2>/dev/null || true

# ──────────────────────────────────────────────────────────────────────
# Waybar integration — add Start (left) + Panel (right) buttons
# ──────────────────────────────────────────────────────────────────────
step "waybar integration"

WAYBAR_CFG="${WAYBAR_DIR}/config"
WAYBAR_CSS="${WAYBAR_DIR}/style.css"

if [[ -f "$WAYBAR_CFG" ]] && command -v jq >/dev/null; then
  cp "$WAYBAR_CFG" "${WAYBAR_CFG}.bak.nyxus-start.$(date +%s)"

  # The patcher must work whether the config is a single object OR an array
  # of bar definitions. We branch on .type and apply the same patch to either
  # the lone object (when its .position is "bottom") or every "bottom" element
  # of an array. Empty `.position` defaults to "bottom" in Waybar, so we treat
  # missing/null .position as "bottom" too.
  PATCH_EXPR='
    def patch_bar:
      .["custom/nyxus-start"] = {
        "format":   "\uf0c9",
        "escape":   false,
        "tooltip":  true,
        "on-click": $launcher_start,
        "tooltip-format":
          "<span size=\"x-large\" weight=\"bold\" foreground=\"#ff00ff\">NYXUS · Start</span>\n<span size=\"small\" foreground=\"#b8a8d0\">Search · Pinned · Recent · Power</span>"
      }
      | (if (.["custom/nyxus-panel"]?) then . else
            .["custom/nyxus-panel"] = {
              "format":   "\uf013",
              "escape":   false,
              "tooltip":  true,
              "on-click": $launcher_panel,
              "tooltip-format":
                "<span size=\"x-large\" weight=\"bold\" foreground=\"#a78bfa\">NYXUS · Panel</span>\n<span size=\"small\" foreground=\"#b8a8d0\">Weather · News · System · Settings</span>"
            }
         end)
      | (if (.["custom/start"]?) then
            .["custom/start"]["on-click"] = $launcher_start
         else . end)
      | ."modules-left" =
          ( ["custom/nyxus-start"] +
            ((."modules-left" // [])
              | map(select(. != "custom/nyxus-start" and . != "custom/start"))) )
      | ."modules-right" =
          ( ((."modules-right" // [])
              | map(select(. != "custom/nyxus-panel"))) +
            ["custom/nyxus-panel"] );

    def is_bottom: (.position == "bottom") or (.position == null) or (.position == "");

    if type == "array" then
      map(if is_bottom then patch_bar else . end)
    elif type == "object" and is_bottom then
      patch_bar
    else
      .
    end
  '

  if sudo -u "$REAL_USER" jq \
       --arg launcher_start "${BIN_DIR}/nyxus-start" \
       --arg launcher_panel "${BIN_DIR}/nyxus-panel" \
       "$PATCH_EXPR" "$WAYBAR_CFG" > "${WAYBAR_CFG}.tmp"; then
    mv "${WAYBAR_CFG}.tmp" "$WAYBAR_CFG"
    chown "$REAL_USER":"$REAL_USER" "$WAYBAR_CFG"
    ok "patched ${WAYBAR_CFG} (Start far-left, Panel far-right)"
  else
    rm -f "${WAYBAR_CFG}.tmp"
    warn "jq patch failed — original config unchanged. See waybar_additions.json to merge by hand."
  fi
else
  warn "Waybar config not found OR jq missing — see waybar_additions.json"
fi

# Append CSS for Start + Panel buttons (idempotent — guarded by sentinel)
if [[ -f "$WAYBAR_CSS" ]] && ! grep -q 'NYXUS-START-BUTTON-STYLE' "$WAYBAR_CSS"; then
  cat "${SRC_DIR}/waybar_styles.css" >> "$WAYBAR_CSS"
  chown "$REAL_USER":"$REAL_USER" "$WAYBAR_CSS"
  ok "appended Start/Panel button CSS to ${WAYBAR_CSS}"
elif [[ ! -f "$WAYBAR_CSS" ]]; then
  warn "Waybar style.css missing — see waybar_styles.css"
else
  ok "Waybar CSS already contains Start/Panel button styles"
fi

# Restart waybar so changes take effect
if command -v pkill >/dev/null; then
  sudo -u "$REAL_USER" pkill -SIGUSR2 waybar 2>/dev/null \
    && ok "waybar reloaded (SIGUSR2)" \
    || warn "waybar not running — restart it manually to see the buttons"
fi

cat <<EOF

──────────────────────────────────────────────────────────────────────
${B}NYXUS Start installed.${R}

${B}launch:${R}    ${GOLD}nyxus-start${R}                  ${DIM}(toggles open / close)${R}
${B}pinned:${R}    ${REAL_HOME}/.config/nyxus-start/pins.json
${B}recent:${R}    ${REAL_HOME}/.config/nyxus-start/recent.json
${B}config:${R}    ${REAL_HOME}/.config/nyxus-start/config.json
${B}install:${R}   ${INSTALL_DIR}

${B}waybar:${R}    Start button is now on the FAR LEFT,
           Panel button is on the FAR RIGHT.
──────────────────────────────────────────────────────────────────────
EOF
