"""
NYXUS App Store — flyout/window for discovering and installing NYXUS apps.

A GTK4 window styled to match the Start / Panel / Notifications aesthetic:
dark sketched plates, Caveat handwritten font, neon glow accents, NO emojis
(Font Awesome / Nerd Font glyphs only).

Behavior
────────
  • Lists every NYXUS sub-app with a card: glyph + title + tagline + button
  • Card button is "Install" if the launcher binary is missing, "Update" if
    it's already present, and "Open" for an extra "launch now" affordance
  • Install/Update spawns the appropriate installer in a new terminal so
    the user sees pacman/sudo prompts and progress
  • Lightweight search filter
  • Esc closes; second invocation toggles (single-instance via PID file)

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, GLib, Gio, Pango  # noqa: E402

# ──────────────────────────────────────────────── constants
APP_ID    = "io.nyxus.store"
WIN_W     = 760
WIN_H     = 580
PID_FILE  = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "nyxus-store.pid"

NYXUS_BASE = "https://nyxus-core.replit.app/api/download/nyxus"
HOME       = Path(os.environ.get("HOME", "/"))
BIN_DIR    = HOME / ".local" / "bin"

# Brand palette
C_TEXT   = "#e8e6f4"
C_DIM    = "#9aa0bd"
C_PINK   = "#ff5cf2"
C_PURPLE = "#cc44ff"
C_CYAN   = "#7ae0ff"
C_GOLD   = "#ffd76a"

# ── catalog ────────────────────────────────────────────────────────────
# Each entry describes an installable NYXUS sub-app. `installer` is the
# install-script slug under nyxus-scripts/. `binary` is the launcher we
# expect on PATH after install — we use its presence to decide whether
# the card shows "Install" or "Update".
CATALOG: List[Dict[str, str]] = [
    {
        "key":       "start",
        "title":     "NYXUS Start",
        "tagline":   "Hand-drawn left-side flyout — search · pinned apps · scratchpad · power",
        "glyph":     "\uf0c9",   # bars
        "color":     C_PINK,
        "installer": "nyxus_start_install.sh",
        "binary":    "nyxus-start",
    },
    {
        "key":       "panel",
        "title":     "NYXUS Panel",
        "tagline":   "Right-side info flyout — weather · system stats · news · settings",
        "glyph":     "\uf0a1",   # bullhorn
        "color":     C_PURPLE,
        "installer": "nyxus_panel_install.sh",
        "binary":    "nyxus-panel",
    },
    {
        "key":       "notifications",
        "title":     "NYXUS Notifications",
        "tagline":   "Bottom-right notifications flyout with calendar and DND toggle",
        "glyph":     "\uf0f3",   # bell
        "color":     C_CYAN,
        "installer": "nyxus_start_install.sh",
        "binary":    "nyxus-notifications",
    },
    {
        "key":       "godsapp",
        "title":     "GodsApp",
        "tagline":   "The NYXUS launcher's mother-app — handwritten everything",
        "glyph":     "\uf005",   # star
        "color":     C_GOLD,
        "installer": "nyxus_godsapp_install.sh",
        "binary":    "godsapp",
    },
    {
        "key":       "sage",
        "title":     "NYXUS Sage",
        "tagline":   "AI assistant + system co-pilot baked into your desktop",
        "glyph":     "\uf544",   # robot
        "color":     C_CYAN,
        "installer": "nyxus_sage_install.sh",
        "binary":    "nyxus-sage",
    },
    {
        "key":       "shield",
        "title":     "NYXUS Shield",
        "tagline":   "Hardening · firewall · audit dashboards for the NYXUS box",
        "glyph":     "\uf3ed",   # shield-alt
        "color":     C_PURPLE,
        "installer": "nyxus_security_install.sh",
        "binary":    "nyxus-shield",
    },
    {
        "key":       "studio",
        "title":     "NYXUS Studio",
        "tagline":   "Creative suite preset — audio, video and ComfyUI launchers",
        "glyph":     "\uf03d",   # video
        "color":     C_PINK,
        "installer": "nyxus_studio_install.sh",
        "binary":    "nyxus-studio",
    },
]


# ──────────────────────────────────────────────── single-instance toggle
def _toggle_singleton() -> bool:
    if not PID_FILE.exists():
        return False
    try:
        pid = int(PID_FILE.read_text().strip() or "0")
    except Exception:
        pid = 0
    if pid > 0:
        try:
            os.kill(pid, 0)
            os.kill(pid, signal.SIGTERM)
            time.sleep(0.05)
            try: PID_FILE.unlink(missing_ok=True)
            except Exception: pass
            return True
        except ProcessLookupError:
            try: PID_FILE.unlink(missing_ok=True)
            except Exception: pass
    return False

def _write_pid() -> None:
    try:
        PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(os.getpid()))
    except Exception:
        pass

def _clear_pid() -> None:
    try: PID_FILE.unlink(missing_ok=True)
    except Exception: pass


# ──────────────────────────────────────────────── CSS
def _install_css() -> None:
    css = f"""
    * {{
        font-family: Caveat, "Comic Sans MS", cursive;
        font-size:   14px;
        color:       {C_TEXT};
    }}
    .nyxus-store-root {{
        background-color: rgba(8, 4, 22, 0.96);
    }}
    .nyxus-store-header {{
        background-color: rgba(8, 4, 22, 0.92);
        border-bottom:    2px solid rgba(255, 0, 255, 0.40);
        padding:          12px 18px;
    }}
    .nyxus-store-title {{
        font-family: Caveat, "Comic Sans MS", cursive;
        font-size:   28px;
        font-weight: bold;
        color:       {C_PINK};
        text-shadow: 0 0 12px rgba(255, 0, 255, 0.65);
    }}
    .nyxus-store-glyph {{
        font-family: "JetBrains Mono Nerd Font", "Symbols Nerd Font", monospace;
        font-size:   18px;
    }}
    .nyxus-store-tagline {{
        font-size: 13px;
        color:     {C_DIM};
    }}
    .nyxus-store-card {{
        background-color: rgba(15, 8, 32, 0.92);
        border:           1.5px solid rgba(204, 68, 255, 0.40);
        border-radius:    10px;
        margin:           6px 12px;
        padding:          10px 12px;
    }}
    .nyxus-store-card:hover {{
        border-color: rgba(122, 224, 255, 0.85);
    }}
    .nyxus-store-card-title {{
        font-family: Caveat, "Comic Sans MS", cursive;
        font-size:   20px;
        font-weight: bold;
    }}
    .nyxus-store-card-body {{
        font-family: Caveat, "Comic Sans MS", cursive;
        font-size:   13px;
        color:       {C_TEXT};
    }}
    .nyxus-store-installed {{
        color: {C_GOLD};
    }}
    button {{
        font-family:   Caveat, "Comic Sans MS", cursive;
        font-size:     14px;
        background:    rgba(15, 8, 32, 0.90);
        color:         {C_TEXT};
        border:        1.5px solid rgba(204, 68, 255, 0.45);
        border-radius: 8px;
        padding:       6px 14px;
    }}
    button:hover {{
        border-color: rgba(122, 224, 255, 0.85);
        color:        {C_CYAN};
    }}
    .nyxus-store-search entry {{
        background:    rgba(15, 8, 32, 0.90);
        color:         {C_TEXT};
        border:        1.5px solid rgba(204, 68, 255, 0.45);
        border-radius: 8px;
        padding:       6px 10px;
    }}
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css.encode("utf-8"))
    display = Gdk.Display.get_default()
    if display is not None:
        Gtk.StyleContext.add_provider_for_display(
            display, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )


# ──────────────────────────────────────────────── helpers
def _is_installed(entry: Dict[str, str]) -> bool:
    if shutil.which(entry["binary"]) is not None:
        return True
    if (BIN_DIR / entry["binary"]).exists():
        return True
    return False

def _spawn_installer(entry: Dict[str, str]) -> None:
    """
    Spawn the installer in a new terminal window so the user sees pacman /
    sudo prompts. Falls back through several common terminals; if none are
    found, runs detached and surfaces a notify-send breadcrumb.
    """
    url = f"{NYXUS_BASE}/{entry['installer']}"
    cmd = f"curl -fsSL {url} | sudo bash; echo; echo 'Press Enter to close'; read"
    for term in (
        ["alacritty", "-T", f"NYXUS · Installing {entry['title']}", "-e", "bash", "-lc", cmd],
        ["kitty",     "-T", f"NYXUS · Installing {entry['title']}", "bash", "-lc", cmd],
        ["foot",      "-T", f"NYXUS · Installing {entry['title']}",  "bash", "-lc", cmd],
        ["wezterm",   "start", "--", "bash", "-lc", cmd],
        ["xterm",     "-T", f"NYXUS · Installing {entry['title']}", "-e", "bash", "-lc", cmd],
    ):
        if shutil.which(term[0]):
            try:
                subprocess.Popen(term, start_new_session=True)
                return
            except Exception:
                continue
    # No terminal found — run silently and notify
    try:
        subprocess.Popen(["bash", "-lc", cmd], start_new_session=True)
        if shutil.which("notify-send"):
            subprocess.Popen(
                ["notify-send", "-a", "NYXUS Store",
                 f"Installing {entry['title']}",
                 "Running headless — check `journalctl --user -f` for output."],
                start_new_session=True,
            )
    except Exception:
        pass


# ──────────────────────────────────────────────── card widget
def _build_card(entry: Dict[str, str], on_action) -> Gtk.Widget:
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
    row.add_css_class("nyxus-store-card")

    # glyph
    glyph = Gtk.Label(label=entry["glyph"])
    glyph.add_css_class("nyxus-store-glyph")
    attrs = Pango.AttrList()
    color = entry["color"].lstrip("#")
    r = int(color[0:2], 16) * 257
    g = int(color[2:4], 16) * 257
    b = int(color[4:6], 16) * 257
    attrs.insert(Pango.attr_foreground_new(r, g, b))
    attrs.insert(Pango.attr_size_new(20 * Pango.SCALE))
    glyph.set_attributes(attrs)
    glyph.set_valign(Gtk.Align.START)
    glyph.set_margin_top(2)
    row.append(glyph)

    # text column
    col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
    col.set_hexpand(True)

    title = Gtk.Label(label=entry["title"])
    title.add_css_class("nyxus-store-card-title")
    title.set_xalign(0)
    col.append(title)

    body = Gtk.Label(label=entry["tagline"])
    body.add_css_class("nyxus-store-card-body")
    body.set_xalign(0); body.set_wrap(True)
    body.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    col.append(body)

    if _is_installed(entry):
        status = Gtk.Label(label="\uf00c  Installed")
        status.add_css_class("nyxus-store-installed")
        status.set_xalign(0)
        col.append(status)

    row.append(col)

    # action button
    btn_lbl = "\uf019  Update" if _is_installed(entry) else "\uf019  Install"
    btn = Gtk.Button(label=btn_lbl)
    btn.set_valign(Gtk.Align.CENTER)
    btn.connect("clicked", lambda *_: on_action(entry))
    row.append(btn)

    return row


# ──────────────────────────────────────────────── main window
class StoreWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title="NYXUS App Store")
        self.set_default_size(WIN_W, WIN_H)
        self.add_css_class("nyxus-store-root")

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        root.append(self._build_header())
        root.append(self._build_body())
        self.set_child(root)

        # Esc to close
        esc = Gtk.EventControllerKey()
        def _on_key(_c, keyval, _kc, _mod):
            if keyval == Gdk.KEY_Escape:
                self.close()
                return True
            return False
        esc.connect("key-pressed", _on_key)
        self.add_controller(esc)

        self.connect("close-request", lambda *_: (_clear_pid(), False)[1])

    # ─── header
    def _build_header(self) -> Gtk.Widget:
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        head.add_css_class("nyxus-store-header")

        glyph = Gtk.Label(label="\uf07a")  # FA shopping-cart
        glyph.add_css_class("nyxus-store-glyph")
        head.append(glyph)

        title = Gtk.Label(label="NYXUS App Store")
        title.add_css_class("nyxus-store-title")
        title.set_xalign(0); title.set_hexpand(True)
        head.append(title)

        self._search = Gtk.SearchEntry()
        self._search.set_placeholder_text("Filter…")
        self._search.add_css_class("nyxus-store-search")
        self._search.set_size_request(200, -1)
        self._search.connect("search-changed", lambda *_: self._refresh_list())
        head.append(self._search)

        return head

    # ─── body
    def _build_body(self) -> Gtk.Widget:
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_vexpand(True); scroller.set_hexpand(True)

        self._list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self._list.set_margin_top(8); self._list.set_margin_bottom(8)
        scroller.set_child(self._list)

        self._refresh_list()
        return scroller

    def _refresh_list(self) -> None:
        # clear
        child = self._list.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self._list.remove(child)
            child = nxt

        q = (self._search.get_text() or "").strip().lower() if hasattr(self, "_search") else ""
        for entry in CATALOG:
            if q and q not in entry["title"].lower() and q not in entry["tagline"].lower():
                continue
            self._list.append(_build_card(entry, self._on_action))

    def _on_action(self, entry: Dict[str, str]) -> None:
        _spawn_installer(entry)
        # Refresh card states a few seconds later in case the installer is
        # already done (rare for fresh installs but possible for re-runs).
        GLib.timeout_add_seconds(8, self._refresh_list_once_and_stop)

    def _refresh_list_once_and_stop(self) -> bool:
        self._refresh_list()
        return False


# ──────────────────────────────────────────────── entry point
def main() -> int:
    if _toggle_singleton():
        return 0

    _write_pid()
    try:
        signal.signal(signal.SIGTERM, lambda *_: (_clear_pid(), os._exit(0)))

        app = Gtk.Application(application_id=APP_ID,
                              flags=Gio.ApplicationFlags.NON_UNIQUE)

        def _on_activate(_a):
            _install_css()
            win = StoreWindow(app)
            win.present()

        app.connect("activate", _on_activate)
        return app.run(None)
    finally:
        _clear_pid()


if __name__ == "__main__":
    sys.exit(main())
