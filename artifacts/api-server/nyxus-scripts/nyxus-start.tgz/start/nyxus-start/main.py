"""
NYXUS Start — left-side flyout entry point.

A GTK4 flyout menu modeled on Windows 11 Start, fully NYXUS-themed:
graffiti collage background, hand-drawn Caveat font, neon glow accents,
no emojis (Font Awesome / Nerd Font glyphs only).

Behavior
────────
  • Fixed 460 × 680 floating window
  • Anchored bottom-LEFT via gtk4-layer-shell (above the Start button)
  • PID toggle — re-running the script kills the running instance
    so binding to the Waybar custom module gives a click-to-toggle button
  • Auto-closes on Escape and on focus-out
  • Slides up on open

Layout
──────
  ┌──────────────────────────────────────────────┐
  │  ◉ NYXUS  Joey            [search]  09:42 PM │
  ├──────────────────────────────────────────────┤
  │  PINNED                                       │
  │  [grid 4 columns of icons]                    │
  ├──────────────────────────────────────────────┤
  │  RECENTLY USED                       ⌫ Clear │
  │  app · 2 min ago                              │
  ├──────────────────────────────────────────────┤
  │  ALL APPS                  [System]…   ▾     │
  │  (alphabetical scroll list)                   │
  ├──────────────────────────────────────────────┤
  │  GowskiNet  · Phantom: ✓ · Honeypot 0 · …   │
  ├──────────────────────────────────────────────┤
  │  [ Joey ]   ⏻  ↻  ⏾  ⎋  🔒                   │
  └──────────────────────────────────────────────┘

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import math
import os
import random
import shlex
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Gdk", "4.0")
from gi.repository import Gtk, Gdk, Gio, GLib, GObject, Pango  # noqa: E402

try:
    gi.require_version("Gtk4LayerShell", "1.0")
    from gi.repository import Gtk4LayerShell as LayerShell  # type: ignore
    _HAS_LAYER_SHELL = True
except (ValueError, ImportError):
    _HAS_LAYER_SHELL = False

import cairo  # type: ignore

from settings import (
    CFG_DIR, load_config, save_config,
    load_pins, save_pins, push_recent, clear_recent,
)
from apps import list_installed_apps, search_apps, find_app_by_id, NYXUS_CATEGORIES
from recent import list_recent, humanize_ts, remove_from_recent
from status import gather as gather_status
from power  import POWER_ACTIONS, perform as perform_power


# ──────────────────────────────────────────────── constants
APP_ID    = "io.nyxus.start"
PANEL_W   = 460
PANEL_H   = 680
PID_FILE  = Path("/tmp/nyxus-start.pid")
BG_DIR    = Path(os.path.expanduser("~/.cache/nyxus-start"))
BG_DIR.mkdir(parents=True, exist_ok=True)
BG_PATH   = BG_DIR / f"bg-{PANEL_W}x{PANEL_H}.png"

C_TEXT    = "#ece4f5"
C_DIM     = "#9d8fb8"
C_PINK    = "#ff00ff"
C_PURPLE  = "#cc44ff"
C_CYAN    = "#22d3ee"
C_GOLD    = "#ffd700"
C_GREEN   = "#39ff14"
C_RED     = "#ff4d6d"


# ──────────────────────────────────────────────── PID toggle
def _running_pid() -> Optional[int]:
    if not PID_FILE.exists():
        return None
    try:
        pid = int(PID_FILE.read_text().strip())
    except (ValueError, OSError):
        return None
    try:
        os.kill(pid, 0)
        return pid
    except OSError:
        try:
            PID_FILE.unlink()
        except OSError:
            pass
        return None


def _write_pid() -> None:
    try:
        PID_FILE.write_text(str(os.getpid()))
    except OSError:
        pass


def _clear_pid() -> None:
    try:
        if PID_FILE.exists() and PID_FILE.read_text().strip() == str(os.getpid()):
            PID_FILE.unlink()
    except OSError:
        pass


# ──────────────────────────────────────────────── graffiti background
def _render_background(width: int = PANEL_W, height: int = PANEL_H,
                       seed: int = 0xC0FFEE) -> str:
    if BG_PATH.exists():
        return str(BG_PATH)

    rng = random.Random(seed)
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, width, height)
    cr   = cairo.Context(surf)

    # ── dark wall base
    grad = cairo.LinearGradient(0, 0, 0, height)
    grad.add_color_stop_rgb(0.0, 0.045, 0.020, 0.090)
    grad.add_color_stop_rgb(1.0, 0.012, 0.005, 0.040)
    cr.set_source(grad)
    cr.rectangle(0, 0, width, height); cr.fill()

    # ── concrete texture
    for _ in range(2400):
        x = rng.uniform(0, width); y = rng.uniform(0, height)
        a = rng.uniform(0.04, 0.16); v = rng.uniform(0.05, 0.20)
        cr.set_source_rgba(v, v, v, a)
        cr.arc(x, y, rng.uniform(0.3, 1.2), 0, math.pi * 2); cr.fill()

    NEON = [(1.0, 0.0, 1.0), (0.8, 0.0, 1.0), (0.0, 0.85, 1.0),
            (0.22, 1.0, 0.08), (1.0, 1.0, 0.0), (1.0, 0.33, 0.66),
            (0.55, 0.20, 1.0), (1.0, 0.50, 0.0)]

    # ── splatters
    for _ in range(38):
        x = rng.uniform(-30, width + 30); y = rng.uniform(-30, height + 30)
        r = rng.uniform(28, 90); col = rng.choice(NEON)
        a = rng.uniform(0.10, 0.32)
        gr = cairo.RadialGradient(x, y, 0, x, y, r)
        gr.add_color_stop_rgba(0.0, col[0], col[1], col[2], a)
        gr.add_color_stop_rgba(1.0, col[0], col[1], col[2], 0.0)
        cr.set_source(gr); cr.arc(x, y, r, 0, math.pi * 2); cr.fill()

    # ── small splat dots
    for _ in range(220):
        x = rng.uniform(0, width); y = rng.uniform(0, height)
        col = rng.choice(NEON); a = rng.uniform(0.30, 0.75)
        cr.set_source_rgba(col[0], col[1], col[2], a)
        cr.arc(x, y, rng.uniform(0.8, 3.4), 0, math.pi * 2); cr.fill()

    # ── spray streaks
    for _ in range(40):
        x = rng.uniform(0, width); y = rng.uniform(0, height)
        ex = x + rng.uniform(-80, 80); ey = y + rng.uniform(-12, 12)
        col = rng.choice(NEON)
        cr.set_source_rgba(col[0], col[1], col[2], rng.uniform(0.12, 0.32))
        cr.set_line_width(rng.uniform(0.6, 2.0))
        cr.move_to(x, y); cr.line_to(ex, ey); cr.stroke()

    # ── drips
    for _ in range(14):
        x = rng.uniform(0, width); y = rng.uniform(0, height * 0.7)
        col = rng.choice(NEON); h = rng.uniform(20, 80)
        cr.set_source_rgba(col[0], col[1], col[2], 0.50)
        cr.set_line_width(rng.uniform(1.4, 2.6))
        cr.move_to(x, y); cr.line_to(x + rng.uniform(-1.5, 1.5), y + h); cr.stroke()
        cr.set_source_rgba(col[0], col[1], col[2], 0.78)
        cr.arc(x, y + h, rng.uniform(2.2, 4.2), 0, math.pi * 2); cr.fill()

    # ── tagged words
    words = ["NYXUS", "LINUX", "ARCH", "KALI", "NVIDIA", "PYTHON",
             "GTK", "WAYLAND", "HYPR", "RTX", "CUDA", "BASH",
             "ROOT", "SUDO", "UNIX", "VIM", "SHELL", "OPEN", "JOEY"]
    cr.select_font_face("Caveat", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    for _ in range(36):
        word = rng.choice(words)
        size = rng.uniform(28, 84)
        cr.set_font_size(size)
        ext = cr.text_extents(word)
        x = rng.uniform(-20, width - 40)
        y = rng.uniform(40, height - 10)
        ang = rng.uniform(-0.42, 0.42)
        col = rng.choice(NEON); alpha = rng.uniform(0.18, 0.48)

        cr.save()
        cr.translate(x + ext.width / 2, y - ext.height / 2)
        cr.rotate(ang)
        cr.translate(-(x + ext.width / 2), -(y - ext.height / 2))
        for dx, dy in ((-2, -2), (2, -2), (-2, 2), (2, 2), (0, -3), (0, 3)):
            cr.set_source_rgba(col[0], col[1], col[2], alpha * 0.35)
            cr.move_to(x + dx, y + dy); cr.show_text(word)
        cr.set_source_rgba(col[0], col[1], col[2], alpha)
        cr.move_to(x, y); cr.show_text(word)
        cr.restore()

    # ── vignette
    vg = cairo.RadialGradient(width / 2, height / 2, height * 0.25,
                              width / 2, height / 2, height * 0.85)
    vg.add_color_stop_rgba(0.0, 0, 0, 0, 0.0)
    vg.add_color_stop_rgba(1.0, 0, 0, 0, 0.55)
    cr.set_source(vg); cr.rectangle(0, 0, width, height); cr.fill()

    surf.write_to_png(str(BG_PATH))
    return str(BG_PATH)


# ──────────────────────────────────────────────── owl mascot (Cairo, hand-drawn)
def _make_owl_image(size: int = 36) -> Gtk.Picture:
    """A tiny Cairo-rendered owl head as a Gtk.Picture (no PNG asset needed)."""
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size)
    cr   = cairo.Context(surf)

    # head
    cr.set_source_rgba(0.85, 0.0, 1.0, 0.90)   # neon purple
    cr.arc(size / 2, size / 2, size * 0.42, 0, math.pi * 2); cr.fill()

    # outer wobble outline
    cr.set_source_rgba(1.0, 0.0, 1.0, 0.95)
    cr.set_line_width(1.4)
    cr.arc(size / 2, size / 2, size * 0.42, 0, math.pi * 2); cr.stroke()

    # eyes (white sclera)
    eye_y = size * 0.45
    eye_dx = size * 0.16
    cr.set_source_rgba(1, 1, 1, 0.95)
    cr.arc(size / 2 - eye_dx, eye_y, size * 0.13, 0, math.pi * 2); cr.fill()
    cr.arc(size / 2 + eye_dx, eye_y, size * 0.13, 0, math.pi * 2); cr.fill()

    # pupils (cyan)
    cr.set_source_rgba(0.13, 0.83, 0.93, 1)
    cr.arc(size / 2 - eye_dx, eye_y, size * 0.06, 0, math.pi * 2); cr.fill()
    cr.arc(size / 2 + eye_dx, eye_y, size * 0.06, 0, math.pi * 2); cr.fill()

    # beak
    cr.set_source_rgba(1.0, 0.84, 0.0, 1)
    cr.move_to(size / 2 - 3, size * 0.62)
    cr.line_to(size / 2 + 3, size * 0.62)
    cr.line_to(size / 2,     size * 0.74)
    cr.close_path(); cr.fill()

    # ear tufts
    cr.set_source_rgba(1.0, 0.0, 1.0, 0.85)
    cr.move_to(size * 0.18, size * 0.18)
    cr.line_to(size * 0.30, size * 0.06)
    cr.line_to(size * 0.34, size * 0.20); cr.fill()
    cr.move_to(size * 0.82, size * 0.18)
    cr.line_to(size * 0.70, size * 0.06)
    cr.line_to(size * 0.66, size * 0.20); cr.fill()

    out = BG_DIR / f"owl-{size}.png"
    surf.write_to_png(str(out))
    img = Gtk.Picture.new_for_filename(str(out))
    img.set_size_request(size, size)
    img.set_can_shrink(False)
    return img


# ──────────────────────────────────────────────── CSS install
def _install_css(cfg: Dict[str, Any]) -> None:
    bg = _render_background()
    css = f"""
    * {{
        font-family: "Caveat", "Inter", "Cantarell", sans-serif;
        font-size:   14px;
        color:       {C_TEXT};
    }}

    .nyxus-start {{
        background-image:    url("file://{bg}");
        background-size:     cover;
        background-position: center;
    }}

    /* every floating section sits on a semi-transparent dark plate */
    .nyxus-section {{
        background-color: rgba(8, 4, 22, 0.78);
        border:           1.5px solid rgba(204, 68, 255, 0.40);
        border-radius:    10px;
        margin:           4px 8px;
        padding:          6px 8px;
    }}

    .nyxus-section-title {{
        font-family: "Caveat", sans-serif;
        font-size:   18px;
        font-weight: bold;
        color:       {C_PINK};
        text-shadow: 0 0 8px rgba(255, 0, 255, 0.55);
        margin:      0 4px 4px 4px;
    }}

    .nyxus-header {{
        background-color: rgba(8, 4, 22, 0.80);
        border-bottom:    2px solid rgba(255, 0, 255, 0.45);
        padding:          8px 10px;
    }}
    .nyxus-brand {{
        font-family: "Caveat", sans-serif;
        font-size:   24px;
        font-weight: bold;
        color:       {C_PINK};
        text-shadow: 0 0 10px rgba(255, 0, 255, 0.65);
    }}
    .nyxus-username {{
        font-family: "Caveat", sans-serif;
        font-size:   16px;
        color:       {C_GOLD};
        text-shadow: 0 0 8px rgba(255, 215, 0, 0.50);
    }}
    .nyxus-time {{
        font-family: "JetBrains Mono", monospace;
        font-size:   13px;
        color:       {C_CYAN};
        text-shadow: 0 0 8px rgba(34, 211, 238, 0.55);
    }}

    entry.nyxus-search {{
        background-color: rgba(0, 0, 0, 0.55);
        border:           1.5px solid rgba(204, 68, 255, 0.50);
        border-radius:    14px;
        color:            {C_TEXT};
        font-family:      "Caveat", sans-serif;
        font-size:        16px;
        padding:          4px 12px;
        min-height:       28px;
    }}
    entry.nyxus-search:focus {{
        border-color: {C_PINK};
        box-shadow:   0 0 12px rgba(255, 0, 255, 0.55);
    }}

    /* generic item row (recent / search results / all apps) */
    button.nyxus-row {{
        background:   transparent;
        border:       none;
        border-radius: 6px;
        padding:      4px 6px;
        color:        {C_TEXT};
    }}
    button.nyxus-row:hover {{
        background-color: rgba(255, 0, 255, 0.18);
        text-shadow:      0 0 6px rgba(255, 0, 255, 0.55);
    }}
    .nyxus-row-title {{ font-size: 14px; color: {C_TEXT}; }}
    .nyxus-row-sub   {{ font-size: 11px; color: {C_DIM}; font-family: "JetBrains Mono", monospace; }}

    /* pinned grid tiles */
    button.nyxus-tile {{
        background-color: rgba(12, 6, 28, 0.55);
        border:           1px solid rgba(204, 68, 255, 0.30);
        border-radius:    10px;
        padding:          8px 4px;
        margin:           3px;
        color:            {C_TEXT};
        min-width:        82px;
        min-height:       82px;
    }}
    button.nyxus-tile:hover {{
        border-color:     {C_PINK};
        background-color: rgba(255, 0, 255, 0.18);
        box-shadow:       0 0 12px rgba(255, 0, 255, 0.55);
        text-shadow:      0 0 8px rgba(255, 0, 255, 0.55);
    }}
    .nyxus-tile-name {{
        font-family: "Caveat", sans-serif;
        font-size:   13px;
        color:       {C_TEXT};
    }}

    /* status row */
    .nyxus-status     {{ font-family: "JetBrains Mono", monospace; font-size: 11px; color: {C_DIM}; }}
    .nyxus-status-ok  {{ color: {C_GREEN}; text-shadow: 0 0 6px rgba(57, 255, 20, 0.65); }}
    .nyxus-status-bad {{ color: {C_RED};   text-shadow: 0 0 6px rgba(255, 77, 109, 0.65); }}

    /* power buttons */
    button.nyxus-power {{
        font-family: "JetBrains Mono Nerd Font", monospace;
        font-size:   18px;
        background:  transparent;
        border:      1px solid rgba(204, 68, 255, 0.35);
        border-radius: 8px;
        color:       {C_TEXT};
        padding:     6px 10px;
        margin:      0 3px;
    }}
    button.nyxus-power:hover {{
        border-color: {C_GOLD};
        color:        {C_GOLD};
        text-shadow:  0 0 10px rgba(255, 215, 0, 0.65);
    }}
    button.nyxus-power-danger:hover {{
        border-color: {C_RED};
        color:        {C_RED};
        text-shadow:  0 0 10px rgba(255, 77, 109, 0.65);
    }}

    /* category chip dropdown */
    button.nyxus-chip {{
        background:   rgba(0, 0, 0, 0.45);
        border:       1px solid rgba(204, 68, 255, 0.50);
        border-radius: 12px;
        color:        {C_TEXT};
        font-family:  "Caveat", sans-serif;
        font-size:    13px;
        padding:      2px 10px;
        margin:       0 2px;
    }}
    button.nyxus-chip.active,
    button.nyxus-chip:hover {{
        border-color: {C_PINK};
        color:        {C_PINK};
        text-shadow:  0 0 6px rgba(255, 0, 255, 0.55);
    }}

    /* small ghost button */
    button.nyxus-ghost {{
        background: transparent;
        border:     none;
        color:      {C_DIM};
        font-family: "Caveat", sans-serif;
        font-size:  13px;
    }}
    button.nyxus-ghost:hover {{
        color:       {C_PINK};
        text-shadow: 0 0 6px rgba(255, 0, 255, 0.55);
    }}

    scrolledwindow undershoot.top, scrolledwindow undershoot.bottom {{ background: none; }}
    scrollbar slider {{
        background-color: rgba(204, 68, 255, 0.50);
        border-radius: 6px;
        min-width: 6px; min-height: 6px;
    }}
    scrollbar slider:hover {{ background-color: {C_PINK}; }}

    popover.menu {{
        background-color: rgba(8, 4, 22, 0.97);
        border: 1px solid {C_PINK};
        border-radius: 8px;
    }}
    popover.menu modelbutton {{
        font-family: "Caveat", sans-serif;
        font-size: 14px;
        color: {C_TEXT};
        padding: 6px 12px;
    }}
    popover.menu modelbutton:hover {{
        background-color: rgba(255, 0, 255, 0.25);
        color: {C_PINK};
    }}
    """
    provider = Gtk.CssProvider()
    provider.load_from_data(css.encode("utf-8"))
    display = Gdk.Display.get_default()
    if display is not None:
        Gtk.StyleContext.add_provider_for_display(
            display, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )


# ──────────────────────────────────────────────── helpers
def _detached(parts) -> None:
    try:
        if isinstance(parts, str):
            subprocess.Popen(parts, shell=True, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(parts, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def _has(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _launch_app(app: Dict[str, Any]) -> None:
    """Launch a discovered app dict, preferring Gio.AppInfo."""
    aid = app.get("id", "")
    name = app.get("name", aid)
    icon = app.get("icon", "")
    push_recent(aid, name, icon)

    desktop = app.get("desktop", "")
    if desktop:
        try:
            ai = Gio.DesktopAppInfo.new_from_filename(desktop)
            if ai is not None:
                ai.launch(None, None)
                return
        except Exception:
            pass

    if aid.endswith(".desktop"):
        try:
            ai = Gio.DesktopAppInfo.new(aid)
            if ai is not None:
                ai.launch(None, None)
                return
        except Exception:
            pass

    cmd = app.get("exec", "")
    if cmd:
        # strip Field codes (%U %F %u %f %i %c %k)
        clean = " ".join(p for p in cmd.split() if not (p.startswith("%") and len(p) == 2))
        _detached(clean)


def _launch_command(cmd: str) -> None:
    if cmd:
        _detached(cmd)


def _icon_widget(name: str, fallback_glyph: str = "\uf0c8",
                 fallback_color: str = C_PURPLE,
                 px: int = 36) -> Gtk.Widget:
    """Build a square icon widget — themed icon if available, else a glyph."""
    if name:
        try:
            display = Gdk.Display.get_default()
            theme = Gtk.IconTheme.get_for_display(display) if display else None
            if theme is not None:
                # Icon name OR direct file path
                if name.startswith("/") and Path(name).exists():
                    img = Gtk.Picture.new_for_filename(name)
                    img.set_size_request(px, px)
                    img.set_can_shrink(True)
                    img.set_content_fit(Gtk.ContentFit.CONTAIN)
                    return img
                if theme.has_icon(name):
                    img = Gtk.Image.new_from_icon_name(name)
                    img.set_pixel_size(px)
                    return img
        except Exception:
            pass

    lbl = Gtk.Label(label=fallback_glyph)
    lbl.add_css_class("nyxus-tile-glyph")
    lbl.set_attributes(_pango_glyph(px, fallback_color))
    return lbl


def _pango_glyph(px: int, color_hex: str) -> Pango.AttrList:
    al = Pango.AttrList()
    al.insert(Pango.attr_family_new("JetBrains Mono Nerd Font"))
    al.insert(Pango.attr_size_new_absolute(int(px * 0.85) * Pango.SCALE))
    rgba = Gdk.RGBA(); rgba.parse(color_hex)
    al.insert(Pango.attr_foreground_new(
        int(rgba.red * 65535), int(rgba.green * 65535), int(rgba.blue * 65535)))
    return al


# ──────────────────────────────────────────────── confirmation dialog
def _confirm(parent: Gtk.Window, title: str, body: str,
             on_yes: Callable[[], None]) -> None:
    dlg = Gtk.AlertDialog()
    dlg.set_modal(True)
    dlg.set_message(title)
    dlg.set_detail(body)
    dlg.set_buttons(["Cancel", "Confirm"])
    dlg.set_default_button(0)
    dlg.set_cancel_button(0)

    def _cb(d, res):
        try:
            idx = d.choose_finish(res)
            if idx == 1:
                on_yes()
        except Exception:
            pass
    dlg.choose(parent, None, _cb)


# ──────────────────────────────────────────────── start window
class StartWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application):
        super().__init__(application=app)
        self.set_title("NYXUS Start")
        self.set_default_size(PANEL_W, PANEL_H)
        self.set_resizable(False)
        self.set_decorated(False)
        self.add_css_class("nyxus-start")

        self._cfg     = load_config()
        self._pins    = load_pins()
        self._all_apps: List[Dict] = []
        self._cat     = "All"
        _install_css(self._cfg)

        # ── Layer-shell anchor: bottom-LEFT (above the Start button)
        if _HAS_LAYER_SHELL:
            try:
                LayerShell.init_for_window(self)
                LayerShell.set_layer(self, LayerShell.Layer.OVERLAY)
                LayerShell.set_keyboard_mode(self, LayerShell.KeyboardMode.ON_DEMAND)
                LayerShell.set_anchor(self, LayerShell.Edge.BOTTOM, True)
                LayerShell.set_anchor(self, LayerShell.Edge.LEFT,   True)
                LayerShell.set_margin(self, LayerShell.Edge.BOTTOM, 60)
                LayerShell.set_margin(self, LayerShell.Edge.LEFT,   10)
            except Exception:
                pass

        # ── Revealer (slide up animation)
        self._revealer = Gtk.Revealer()
        self._revealer.set_transition_type(Gtk.RevealerTransitionType.SLIDE_UP)
        self._revealer.set_transition_duration(
            0 if self._cfg.get("reduce_animations") else 220
        )
        self.set_child(self._revealer)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.set_size_request(PANEL_W, PANEL_H)
        self._revealer.set_child(outer)

        outer.append(self._build_header())

        # ── scrollable middle (pinned + recent + all)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_vexpand(True); scroller.set_hexpand(True)
        outer.append(scroller)

        middle = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        scroller.set_child(middle)

        self._search_results_section = self._build_section("Search Results")
        self._search_results_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self._search_results_section.append(self._search_results_box)
        self._search_results_section.set_visible(False)
        middle.append(self._search_results_section)

        self._pinned_section = self._build_section("Pinned",
            right_widget=self._mk_ghost_btn("\uf044  Edit", lambda *_: self._edit_pins()))
        self._pinned_grid = Gtk.FlowBox()
        self._pinned_grid.set_max_children_per_line(4)
        self._pinned_grid.set_min_children_per_line(4)
        self._pinned_grid.set_selection_mode(Gtk.SelectionMode.NONE)
        self._pinned_grid.set_homogeneous(True)
        self._pinned_section.append(self._pinned_grid)
        middle.append(self._pinned_section)

        self._recent_section = self._build_section("Recently Used",
            right_widget=self._mk_ghost_btn("\uf2ed  Clear",
                                            lambda *_: self._clear_recent()))
        self._recent_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self._recent_section.append(self._recent_box)
        middle.append(self._recent_section)

        self._all_section = self._build_section("All Apps")
        self._cats_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self._cats_row.set_margin_bottom(4)
        self._all_section.append(self._cats_row)
        self._all_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self._all_section.append(self._all_box)
        middle.append(self._all_section)

        # ── status row
        self._status_section = self._build_section("GowskiNet")
        self._status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                                    spacing=10, homogeneous=True)
        self._status_section.append(self._status_box)
        outer.append(self._status_section)

        # ── power footer
        outer.append(self._build_power_row())

        # close on Escape & focus-out
        kc = Gtk.EventControllerKey()
        kc.connect("key-pressed", self._on_key)
        self.add_controller(kc)
        focus = Gtk.EventControllerFocus()
        focus.connect("leave", lambda *_: self._dismiss())
        self.add_controller(focus)

        # build content
        self._refresh_pinned()
        self._refresh_recent()
        self._build_categories()

        # async-ish: fetch app list right away (it's quick) & status
        GLib.idle_add(self._load_all_apps)
        self._tick_clock()
        GLib.timeout_add_seconds(1, self._tick_clock)
        GLib.timeout_add_seconds(8, self._refresh_status_async)
        GLib.idle_add(self._refresh_status_async)

    # ─────────────────────────────── header
    def _build_header(self) -> Gtk.Widget:
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bar.add_css_class("nyxus-header")

        owl = _make_owl_image(36)
        bar.append(owl)

        brand = Gtk.Label(label="NYXUS"); brand.add_css_class("nyxus-brand")
        bar.append(brand)
        user_lbl = Gtk.Label(label=self._cfg.get("user_name", "Joey"))
        user_lbl.add_css_class("nyxus-username")
        bar.append(user_lbl)

        # search
        self._search = Gtk.Entry()
        self._search.add_css_class("nyxus-search")
        self._search.set_placeholder_text("Search apps…")
        self._search.set_hexpand(True)
        self._search.set_margin_start(8); self._search.set_margin_end(8)
        self._search.connect("changed", self._on_search_changed)
        self._search.connect("activate", self._on_search_activate)
        bar.append(self._search)

        # date / time
        self._time_lbl = Gtk.Label(label="")
        self._time_lbl.add_css_class("nyxus-time")
        bar.append(self._time_lbl)

        if self._cfg.get("search_focus_on_open", True):
            GLib.idle_add(self._search.grab_focus)
        return bar

    def _tick_clock(self) -> bool:
        now = datetime.now()
        self._time_lbl.set_text(now.strftime("%a · %H:%M"))
        return True

    # ─────────────────────────────── section helper
    def _build_section(self, title: str,
                       right_widget: Optional[Gtk.Widget] = None) -> Gtk.Box:
        sec = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        sec.add_css_class("nyxus-section")

        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        ttl = Gtk.Label(label=title); ttl.set_xalign(0); ttl.set_hexpand(True)
        ttl.add_css_class("nyxus-section-title")
        head.append(ttl)
        if right_widget is not None:
            head.append(right_widget)
        sec.append(head)
        return sec

    def _mk_ghost_btn(self, text: str, cb: Callable) -> Gtk.Button:
        b = Gtk.Button(label=text)
        b.add_css_class("nyxus-ghost")
        b.connect("clicked", cb)
        return b

    # ─────────────────────────────── pinned grid
    def _refresh_pinned(self) -> None:
        # clear
        child = self._pinned_grid.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self._pinned_grid.remove(child)
            child = nxt

        for pid in self._pins:
            app = find_app_by_id(pid)
            if app is None:
                # synth a stub app for bare command
                app = {
                    "id": pid, "name": pid.replace("-", " ").title(),
                    "exec": pid, "icon": pid, "comment": "",
                    "categories": ["Other"], "raw": "", "desktop": "",
                }
            tile = self._make_pin_tile(app, pid)
            self._pinned_grid.append(tile)

    def _make_pin_tile(self, app: Dict, pid: str) -> Gtk.Widget:
        btn = Gtk.Button()
        btn.add_css_class("nyxus-tile")

        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        col.set_halign(Gtk.Align.CENTER); col.set_valign(Gtk.Align.CENTER)
        col.append(_icon_widget(app.get("icon", ""), "\uf135", C_PURPLE, 38))
        name = Gtk.Label(label=app["name"])
        name.add_css_class("nyxus-tile-name")
        name.set_max_width_chars(10); name.set_ellipsize(Pango.EllipsizeMode.END)
        col.append(name)
        btn.set_child(col)
        btn.set_tooltip_text(app["name"])

        btn.connect("clicked", lambda *_: (_launch_app(app), self._dismiss()))

        # right-click menu
        gesture = Gtk.GestureClick.new()
        gesture.set_button(3)
        gesture.connect("pressed",
                        lambda g, n, x, y: self._show_pin_menu(btn, app, pid, x, y))
        btn.add_controller(gesture)
        return btn

    def _show_pin_menu(self, anchor: Gtk.Widget, app: Dict, pid: str,
                       x: float, y: float) -> None:
        menu = Gio.Menu()
        menu.append("Launch",            f"start.launch::{pid}")
        menu.append("Unpin from Start",  f"start.unpin::{pid}")
        menu.append("Open File Location", f"start.openloc::{pid}")
        pop = Gtk.PopoverMenu.new_from_model(menu)
        pop.set_parent(anchor)
        pop.set_pointing_to(Gdk.Rectangle(x=int(x), y=int(y), width=1, height=1))
        pop.popup()
        # actions are wired once in _wire_actions

    def _edit_pins(self) -> None:
        """Toggle a simple 'pin all installed apps' flow — opens picker dialog."""
        win = Gtk.Window(title="Edit Pinned Apps")
        win.set_default_size(360, 460); win.set_transient_for(self); win.set_modal(True)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        win.set_child(scroller)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.set_margin_top(8); box.set_margin_bottom(8)
        box.set_margin_start(8); box.set_margin_end(8)
        scroller.set_child(box)

        for app in self._all_apps:
            aid = app["id"]
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            row.append(_icon_widget(app.get("icon", ""), "\uf135", C_PURPLE, 22))
            lbl = Gtk.Label(label=app["name"]); lbl.set_xalign(0); lbl.set_hexpand(True)
            row.append(lbl)
            sw = Gtk.Switch(); sw.set_active(aid in self._pins or aid.replace(".desktop","") in self._pins)
            def _toggle(s, _ps, app_id=aid):
                if s.get_active():
                    if app_id not in self._pins:
                        self._pins.append(app_id)
                else:
                    self._pins = [p for p in self._pins
                                  if p != app_id and p != app_id.replace(".desktop", "")]
                save_pins(self._pins)
                self._refresh_pinned()
            sw.connect("notify::active", _toggle)
            row.append(sw)
            box.append(row)
        win.present()

    # ─────────────────────────────── recent
    def _refresh_recent(self) -> None:
        child = self._recent_box.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self._recent_box.remove(child)
            child = nxt

        items = list_recent(10)
        if not items:
            empty = Gtk.Label(label="(no recent activity yet)")
            empty.add_css_class("nyxus-row-sub")
            empty.set_xalign(0); empty.set_margin_start(6); empty.set_margin_top(2)
            self._recent_box.append(empty)
            return

        for it in items:
            self._recent_box.append(self._make_recent_row(it))

    def _make_recent_row(self, item: Dict) -> Gtk.Widget:
        btn = Gtk.Button(); btn.add_css_class("nyxus-row")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.append(_icon_widget(item.get("icon", ""), "\uf15b", C_CYAN, 22))
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        col.set_hexpand(True)
        n = Gtk.Label(label=item["name"]); n.set_xalign(0)
        n.add_css_class("nyxus-row-title")
        n.set_ellipsize(Pango.EllipsizeMode.END)
        col.append(n)
        s = Gtk.Label(label=humanize_ts(item.get("ts", 0))); s.set_xalign(0)
        s.add_css_class("nyxus-row-sub")
        col.append(s)
        row.append(col)
        btn.set_child(row)

        def _click(*_):
            if item["kind"] == "app":
                app = find_app_by_id(item["id"])
                if app is not None:
                    _launch_app(app)
            else:
                _detached(["xdg-open", item["uri"] or item["id"]])
                push_recent(item["id"], item["name"], item.get("icon", ""))
            self._dismiss()

        btn.connect("clicked", _click)

        gesture = Gtk.GestureClick.new()
        gesture.set_button(3)
        def _menu(g, n, x, y):
            menu = Gio.Menu()
            menu.append("Remove from Recent",
                        f"start.recentrm::{item['kind']}::{item['id']}")
            if item["kind"] == "app":
                menu.append("Pin to Start",
                            f"start.pin::{item['id']}")
            pop = Gtk.PopoverMenu.new_from_model(menu)
            pop.set_parent(btn)
            pop.set_pointing_to(Gdk.Rectangle(x=int(x), y=int(y), width=1, height=1))
            pop.popup()
        gesture.connect("pressed", _menu)
        btn.add_controller(gesture)
        return btn

    def _clear_recent(self) -> None:
        clear_recent()
        self._refresh_recent()

    # ─────────────────────────────── all apps
    def _load_all_apps(self) -> bool:
        self._all_apps = list_installed_apps(
            max_count=int(self._cfg.get("max_all_apps", 500))
        )
        self._refresh_all_apps()
        return False  # don't repeat

    def _build_categories(self) -> None:
        # clear
        child = self._cats_row.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self._cats_row.remove(child)
            child = nxt
        for cat in ["All"] + NYXUS_CATEGORIES:
            chip = Gtk.Button(label=cat); chip.add_css_class("nyxus-chip")
            if cat == self._cat:
                chip.add_css_class("active")
            chip.connect("clicked", lambda b, c=cat: self._set_category(c))
            self._cats_row.append(chip)

    def _set_category(self, cat: str) -> None:
        self._cat = cat
        self._build_categories()
        self._refresh_all_apps()

    def _refresh_all_apps(self) -> None:
        child = self._all_box.get_first_child()
        while child is not None:
            nxt = child.get_next_sibling()
            self._all_box.remove(child)
            child = nxt

        if self._cat == "All":
            apps = self._all_apps
        else:
            apps = [a for a in self._all_apps if self._cat in a.get("categories", [])]

        if not apps:
            empty = Gtk.Label(label="(no apps in this category)")
            empty.add_css_class("nyxus-row-sub"); empty.set_xalign(0); empty.set_margin_start(6)
            self._all_box.append(empty); return

        for app in apps:
            self._all_box.append(self._make_app_row(app))

    def _make_app_row(self, app: Dict) -> Gtk.Widget:
        btn = Gtk.Button(); btn.add_css_class("nyxus-row")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.append(_icon_widget(app.get("icon", ""), "\uf135", C_PURPLE, 22))
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        col.set_hexpand(True)
        n = Gtk.Label(label=app["name"]); n.set_xalign(0)
        n.add_css_class("nyxus-row-title")
        n.set_ellipsize(Pango.EllipsizeMode.END)
        col.append(n)
        if app.get("comment"):
            s = Gtk.Label(label=app["comment"]); s.set_xalign(0)
            s.add_css_class("nyxus-row-sub")
            s.set_ellipsize(Pango.EllipsizeMode.END)
            s.set_max_width_chars(46)
            col.append(s)
        row.append(col)
        btn.set_child(row)
        btn.connect("clicked", lambda *_: (_launch_app(app), self._dismiss()))

        gesture = Gtk.GestureClick.new()
        gesture.set_button(3)
        def _menu(g, n, x, y):
            menu = Gio.Menu()
            menu.append("Launch",             f"start.launch::{app['id']}")
            menu.append("Pin to Start",       f"start.pin::{app['id']}")
            menu.append("Open File Location", f"start.openloc::{app['id']}")
            pop = Gtk.PopoverMenu.new_from_model(menu)
            pop.set_parent(btn)
            pop.set_pointing_to(Gdk.Rectangle(x=int(x), y=int(y), width=1, height=1))
            pop.popup()
        gesture.connect("pressed", _menu)
        btn.add_controller(gesture)
        return btn

    # ─────────────────────────────── search
    def _on_search_changed(self, entry: Gtk.Entry) -> None:
        q = entry.get_text().strip()
        # clear results
        c = self._search_results_box.get_first_child()
        while c is not None:
            nxt = c.get_next_sibling()
            self._search_results_box.remove(c)
            c = nxt

        if not q:
            self._search_results_section.set_visible(False)
            return
        results = search_apps(q, self._all_apps, limit=20)
        for app in results:
            self._search_results_box.append(self._make_app_row(app))
        if not results:
            empty = Gtk.Label(label="(no matches)")
            empty.add_css_class("nyxus-row-sub")
            empty.set_xalign(0); empty.set_margin_start(6)
            self._search_results_box.append(empty)
        self._search_results_section.set_visible(True)

    def _on_search_activate(self, entry: Gtk.Entry) -> None:
        q = entry.get_text().strip()
        if not q: return
        results = search_apps(q, self._all_apps, limit=1)
        if results:
            _launch_app(results[0])
            self._dismiss()

    # ─────────────────────────────── status row
    def _refresh_status_async(self) -> bool:
        # synchronous (status probes are fast); kept on a timer for periodic refresh
        try:
            data = gather_status()
        except Exception:
            return True

        c = self._status_box.get_first_child()
        while c is not None:
            nxt = c.get_next_sibling()
            self._status_box.remove(c)
            c = nxt

        for key, info in data.items():
            self._status_box.append(self._make_status_pill(key, info))
        return True

    def _make_status_pill(self, key: str, info: Dict) -> Gtk.Widget:
        btn = Gtk.Button(); btn.add_css_class("nyxus-row")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        glyph = Gtk.Label(label=info["glyph"])
        glyph.set_attributes(_pango_glyph(20, C_GREEN if info["ok"] else C_RED))
        row.append(glyph)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        n = Gtk.Label(label=info["label"]); n.set_xalign(0)
        n.add_css_class("nyxus-row-title")
        col.append(n)
        v = Gtk.Label(label=info["value"]); v.set_xalign(0)
        v.add_css_class("nyxus-status-ok" if info["ok"] else "nyxus-status-bad")
        v.add_css_class("nyxus-status")
        col.append(v)
        row.append(col); btn.set_child(row)

        target = info.get("target", "")
        def _open(*_):
            app = find_app_by_id(target)
            if app is not None:
                _launch_app(app)
            else:
                _launch_command(target)
            self._dismiss()
        btn.connect("clicked", _open)
        return btn

    # ─────────────────────────────── power row
    def _build_power_row(self) -> Gtk.Widget:
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        bar.add_css_class("nyxus-section")
        bar.set_margin_top(2); bar.set_margin_bottom(6)

        user_btn = Gtk.Button(label=f"\uf007  {self._cfg.get('user_name','Joey')}")
        user_btn.add_css_class("nyxus-power")
        user_btn.set_hexpand(True); user_btn.set_halign(Gtk.Align.START)
        user_btn.connect("clicked",
                         lambda *_: (_launch_command("nyxus-settings"), self._dismiss()))
        bar.append(user_btn)

        for key, label, glyph, color, requires_confirm in POWER_ACTIONS:
            b = Gtk.Button()
            b.add_css_class("nyxus-power")
            if requires_confirm:
                b.add_css_class("nyxus-power-danger")
            b.set_tooltip_text(label)
            inner = Gtk.Label(label=glyph)
            inner.set_attributes(_pango_glyph(20, color))
            b.set_child(inner)
            def _click(_btn, k=key, lbl=label, conf=requires_confirm):
                if conf:
                    _confirm(self, f"Confirm {lbl}",
                             f"Are you sure you want to {lbl.lower()} the system?",
                             lambda: (perform_power(k), self._dismiss()))
                else:
                    perform_power(k); self._dismiss()
            b.connect("clicked", _click)
            bar.append(b)
        return bar

    # ─────────────────────────────── close behavior
    def _on_key(self, ctrl, keyval, keycode, state) -> bool:
        if keyval == Gdk.KEY_Escape:
            self._dismiss(); return True
        return False

    def _dismiss(self) -> None:
        try:
            if not self._cfg.get("reduce_animations", False):
                self._revealer.set_reveal_child(False)
                GLib.timeout_add(220, self._final_close)
                return
        except Exception:
            pass
        self._final_close()

    def _final_close(self) -> bool:
        _clear_pid()
        self.close()
        try:
            self.get_application().quit()
        except Exception:
            pass
        return False


# ──────────────────────────────────────────────── application
class NyxusStartApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.NON_UNIQUE)
        self._win: Optional[StartWindow] = None
        self._actions_wired = False

    def do_activate(self) -> None:
        if self._win is None:
            self._win = StartWindow(self)
            self._wire_actions()
        self._win.present()
        # start with revealer collapsed → animate open
        try:
            self._win._revealer.set_reveal_child(False)
            GLib.idle_add(lambda: self._win._revealer.set_reveal_child(True))
        except Exception:
            pass

    def _wire_actions(self) -> None:
        if self._actions_wired or self._win is None: return
        self._actions_wired = True

        def add(name: str, cb: Callable[[str], None]):
            act = Gio.SimpleAction.new(name, GLib.VariantType.new("s"))
            act.connect("activate", lambda a, p: cb(p.get_string()))
            self.add_action(act)

        def launch(pid: str):
            app = find_app_by_id(pid)
            if app is not None:
                _launch_app(app)
            else:
                _launch_command(pid)
            self._win._dismiss()

        def pin(pid: str):
            if pid not in self._win._pins:
                self._win._pins.insert(0, pid); save_pins(self._win._pins)
                self._win._refresh_pinned()

        def unpin(pid: str):
            self._win._pins = [p for p in self._win._pins if p != pid]
            save_pins(self._win._pins); self._win._refresh_pinned()

        def openloc(pid: str):
            app = find_app_by_id(pid)
            target = app.get("desktop", "") if app else ""
            if not target:
                target = os.path.expanduser("~/.local/share/applications")
            target_dir = target if os.path.isdir(target) else os.path.dirname(target)
            if target_dir:
                _detached(["xdg-open", target_dir])
            self._win._dismiss()

        def recentrm(payload: str):
            try:
                kind, item_id = payload.split("::", 1)
            except ValueError:
                return
            remove_from_recent(kind, item_id)
            self._win._refresh_recent()

        add("launch",   launch)
        add("pin",      pin)
        add("unpin",    unpin)
        add("openloc",  openloc)
        add("recentrm", recentrm)


# ──────────────────────────────────────────────── entry
def main() -> int:
    # PID toggle (only if --no-toggle absent)
    if "--no-toggle" not in sys.argv:
        existing = _running_pid()
        if existing is not None:
            try:
                os.kill(existing, signal.SIGTERM)
            except OSError:
                pass
            return 0
    _write_pid()

    def _cleanup(*_):
        _clear_pid()
        sys.exit(0)
    for s in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        try: signal.signal(s, _cleanup)
        except Exception: pass

    app = NyxusStartApp()
    rc = app.run(None)
    _clear_pid()
    return rc


if __name__ == "__main__":
    sys.exit(main())
