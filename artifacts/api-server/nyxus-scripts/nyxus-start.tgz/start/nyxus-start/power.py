"""
NYXUS Start — power options.

Tries multiple backends in order so it works on barebones systems too:
    lock      → hyprlock | swaylock | loginctl lock-session
    logout    → hyprctl dispatch exit | loginctl terminate-user
    suspend   → systemctl suspend | loginctl suspend
    restart   → systemctl reboot
    shutdown  → systemctl poweroff

All actions are detached so the Start panel can close cleanly.

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations
import os
import shutil
import subprocess
from typing import List, Tuple


def _has(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def _run_detached(parts: List[str]) -> bool:
    try:
        subprocess.Popen(parts, start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except (FileNotFoundError, OSError):
        return False


def lock_screen() -> bool:
    if _has("hyprlock") and _run_detached(["hyprlock"]):
        return True
    if _has("swaylock") and _run_detached(["swaylock", "-f"]):
        return True
    if _has("loginctl") and _run_detached(["loginctl", "lock-session"]):
        return True
    return False


def log_out() -> bool:
    if _has("hyprctl") and _run_detached(["hyprctl", "dispatch", "exit"]):
        return True
    if _has("loginctl") and os.environ.get("USER"):
        if _run_detached(["loginctl", "terminate-user", os.environ["USER"]]):
            return True
    return False


def suspend() -> bool:
    if _has("systemctl") and _run_detached(["systemctl", "suspend"]):
        return True
    if _has("loginctl") and _run_detached(["loginctl", "suspend"]):
        return True
    return False


def restart() -> bool:
    if _has("systemctl") and _run_detached(["systemctl", "reboot"]):
        return True
    return False


def shutdown() -> bool:
    if _has("systemctl") and _run_detached(["systemctl", "poweroff"]):
        return True
    return False


# ─────────────────────────────────── catalog for the UI to render
# Each entry: (key, label, glyph, color_hex, requires_confirmation)
POWER_ACTIONS: List[Tuple[str, str, str, str, bool]] = [
    ("lock",     "Lock",     "\uf023", "#a78bfa", False),  # nf-fa-lock
    ("logout",   "Log Out",  "\uf2f5", "#c8ccd6", False),  # nf-fa-sign_out
    ("suspend",  "Suspend",  "\uf186", "#c8ccd6", False),  # nf-fa-moon
    ("restart",  "Restart",  "\uf021", "#e8edf5", True),   # nf-fa-refresh
    ("shutdown", "Shutdown", "\uf011", "#ff3232", True),   # nf-fa-power_off
]


def perform(key: str) -> bool:
    return {
        "lock":     lock_screen,
        "logout":   log_out,
        "suspend":  suspend,
        "restart":  restart,
        "shutdown": shutdown,
    }.get(key, lambda: False)()
