"""
NYXUS Start — settings + config persistence.

Two JSON files in ~/.config/nyxus-start/:
    config.json   — user preferences
    pins.json     — list of pinned .desktop ids (and arbitrary-command pins)
    recent.json   — last 10 launched apps (rotating)

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List

CFG_DIR    = Path(os.path.expanduser("~/.config/nyxus-start"))
CFG_FILE   = CFG_DIR / "config.json"
PINS_FILE  = CFG_DIR / "pins.json"
RECENT_FILE = CFG_DIR / "recent.json"

CFG_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_PINS: List[str] = [
    "nyxus-terminal",
    "nyxus-settings",
    "nyxus-control",
    "nyxus-sysmon",
    "nyxus-security",
    "godsapp",
    "nyxus-sage",
    "nyxus-notepad",
    "nyxus-stickies",
    "nyxus-weather",
    "nyxus-panel",
    "thunar",
    "firefox",
    "chromium",
    "discord",
]

DEFAULT_CONFIG: Dict[str, Any] = {
    "user_name":        "Joey",
    "user_avatar":      "",
    "reduce_animations": False,
    "search_focus_on_open": True,
    "max_recent":       10,
    "max_all_apps":     500,
}


def load_config() -> Dict[str, Any]:
    if not CFG_FILE.exists():
        save_config(DEFAULT_CONFIG)
        return dict(DEFAULT_CONFIG)
    try:
        with CFG_FILE.open() as f:
            data = json.load(f)
        merged = dict(DEFAULT_CONFIG)
        merged.update({k: v for k, v in data.items() if k in DEFAULT_CONFIG})
        return merged
    except (OSError, ValueError):
        return dict(DEFAULT_CONFIG)


def save_config(cfg: Dict[str, Any]) -> None:
    try:
        with CFG_FILE.open("w") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass


def load_pins() -> List[str]:
    if not PINS_FILE.exists():
        save_pins(DEFAULT_PINS)
        return list(DEFAULT_PINS)
    try:
        with PINS_FILE.open() as f:
            data = json.load(f)
        if isinstance(data, list):
            return [str(x) for x in data]
    except (OSError, ValueError):
        pass
    return list(DEFAULT_PINS)


def save_pins(pins: List[str]) -> None:
    try:
        with PINS_FILE.open("w") as f:
            json.dump(pins, f, indent=2)
    except OSError:
        pass


def load_recent() -> List[Dict[str, Any]]:
    if not RECENT_FILE.exists():
        return []
    try:
        with RECENT_FILE.open() as f:
            data = json.load(f)
        if isinstance(data, list):
            return [d for d in data if isinstance(d, dict) and "id" in d]
    except (OSError, ValueError):
        pass
    return []


def push_recent(app_id: str, name: str, icon: str = "") -> None:
    """Add or move an app to the head of recent (capped at 10)."""
    items = load_recent()
    items = [r for r in items if r.get("id") != app_id]
    items.insert(0, {
        "id":   app_id,
        "name": name,
        "icon": icon,
        "ts":   int(time.time()),
    })
    items = items[:10]
    try:
        with RECENT_FILE.open("w") as f:
            json.dump(items, f, indent=2)
    except OSError:
        pass


def clear_recent() -> None:
    try:
        if RECENT_FILE.exists():
            RECENT_FILE.unlink()
    except OSError:
        pass
