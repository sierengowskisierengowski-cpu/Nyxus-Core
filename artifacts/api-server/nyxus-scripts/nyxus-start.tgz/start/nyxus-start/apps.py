"""
NYXUS Start — installed-app discovery via Gio.AppInfo.

Returns a normalized list of dicts:
    {
        "id":          "firefox.desktop",        # Gio app id (unique)
        "name":        "Firefox",
        "exec":        "firefox %u",
        "icon":        "firefox",                # gtk icon name (or empty)
        "comment":     "Web Browser",
        "categories":  ["Internet"],             # mapped NYXUS categories
        "raw":         "Application;Network;WebBrowser;",
        "desktop":     "/usr/share/applications/firefox.desktop"  # may be ""
    }

NYXUS categories (matches the UI filter):
    System, Security, Internet, Media, Development, Games, Settings, Other

© 2026 Joseph Sierengowski — NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations
import os
import shlex
from pathlib import Path
from typing import Dict, List, Optional

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gio  # noqa: E402


# ── XDG → NYXUS category mapping (first match wins; case-insensitive)
CATEGORY_MAP = [
    ("Security",    {"security", "nyxus-security", "phantom", "shield", "godsapp"}),
    ("Internet",    {"network", "webbrowser", "email", "chat", "instantmessaging",
                     "filetransfer", "p2p", "remoteaccess", "telephony", "internet"}),
    ("Media",       {"audiovideo", "audio", "video", "player", "tv", "graphics",
                     "photography", "music", "art"}),
    ("Development", {"development", "ide", "building", "debugger", "revisioncontrol",
                     "translation", "webdevelopment"}),
    ("Games",       {"game", "actiongame", "adventuregame", "arcadegame", "boardgame",
                     "kidsgame", "logicgame", "roleplaying", "shootergame", "simulation",
                     "sportsgame", "strategygame"}),
    ("Settings",    {"settings", "desktopsettings", "hardwaresettings", "preferences"}),
    ("System",      {"system", "monitor", "filemanager", "filetools", "terminalemulator",
                     "utility", "core", "accessibility"}),
]

NYXUS_CATEGORIES = ["System", "Security", "Internet", "Media",
                    "Development", "Games", "Settings", "Other"]


def _classify(raw_categories: str, app_id: str = "", name: str = "") -> List[str]:
    raw_lower = (raw_categories or "").lower()
    name_lower = (name or "").lower()
    id_lower = (app_id or "").lower()

    out: List[str] = []
    # Force NYXUS-branded apps into Security if they're security stack pieces
    if any(t in id_lower or t in name_lower for t in
           ("nyxus-phantom", "phantom", "shield", "godsapp", "nyxus-security")):
        out.append("Security")

    for cat, tokens in CATEGORY_MAP:
        for tok in tokens:
            if tok in raw_lower:
                if cat not in out:
                    out.append(cat)
                break

    if not out:
        out.append("Other")
    return out


def _icon_to_string(icon: Optional[Gio.Icon]) -> str:
    """Best effort to coerce a Gio.Icon → icon name string GTK can resolve."""
    if icon is None:
        return ""
    try:
        if isinstance(icon, Gio.ThemedIcon):
            names = icon.get_names()
            if names:
                return names[0]
        if isinstance(icon, Gio.FileIcon):
            f = icon.get_file()
            return f.get_path() or ""
        return icon.to_string() or ""
    except Exception:
        return ""


def list_installed_apps(max_count: int = 500) -> List[Dict]:
    """Return all visible Gio.AppInfo entries, sorted A→Z."""
    out: List[Dict] = []
    for ai in Gio.AppInfo.get_all():
        try:
            if not ai.should_show():
                continue
            name = (ai.get_display_name() or ai.get_name() or "").strip()
            if not name:
                continue
            app_id = ai.get_id() or ""
            exec_cmd = ai.get_commandline() or ""
            comment = ai.get_description() or ""
            icon = _icon_to_string(ai.get_icon())

            raw_cats = ""
            try:
                raw_cats = ai.get_categories() or ""
            except Exception:
                pass

            cats = _classify(raw_cats, app_id, name)

            desktop_path = ""
            try:
                if hasattr(ai, "get_filename"):
                    desktop_path = ai.get_filename() or ""
            except Exception:
                pass

            out.append({
                "id":         app_id,
                "name":       name,
                "exec":       exec_cmd,
                "icon":       icon,
                "comment":    comment,
                "categories": cats,
                "raw":        raw_cats,
                "desktop":    desktop_path,
            })
        except Exception:
            continue

    out.sort(key=lambda d: d["name"].lower())
    return out[:max_count]


def find_app_by_id(app_id: str) -> Optional[Dict]:
    """Find a single installed app by id (or partial id / launcher name)."""
    if not app_id:
        return None
    target = app_id.lower()
    target_no_ext = target.replace(".desktop", "")
    for app in list_installed_apps(max_count=2000):
        aid = (app["id"] or "").lower()
        if aid == target or aid.replace(".desktop", "") == target_no_ext:
            return app
    # Fall back: match by exec basename or display-name slug
    for app in list_installed_apps(max_count=2000):
        exec_first = ""
        try:
            exec_parts = shlex.split(app["exec"])
            if exec_parts:
                exec_first = os.path.basename(exec_parts[0]).lower()
        except Exception:
            pass
        if exec_first == target_no_ext:
            return app
    return None


def search_apps(query: str, apps: List[Dict], limit: int = 30) -> List[Dict]:
    """Score apps by how well they match a free-text query."""
    q = (query or "").strip().lower()
    if not q:
        return apps[:limit]
    scored = []
    for app in apps:
        name = app["name"].lower()
        desc = (app.get("comment") or "").lower()
        score = 0
        if name == q:
            score += 100
        if name.startswith(q):
            score += 60
        if q in name:
            score += 30
        for word in name.split():
            if word.startswith(q):
                score += 12
                break
        if q in desc:
            score += 6
        if score:
            scored.append((score, app))
    scored.sort(key=lambda t: (-t[0], t[1]["name"].lower()))
    return [a for _, a in scored[:limit]]
