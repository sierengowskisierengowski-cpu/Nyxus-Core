#!/usr/bin/env python3
"""
NYXUS Notifications — standalone real native GTK4 app.
Mirrors the matching card on the NYXUS Home dashboard EXACTLY (same
widget code) but wrapped in a normal-sized application window. Real
data, real APIs, real keyring. No mocks.
(c) 2026 Joseph Sierengowski - NYX-J5W-2026-SIERENGOWSKI-LOCKED
"""
from __future__ import annotations

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import gi
gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gio, GLib  # noqa: E402

from style import install_css            # noqa: E402
from widgets import NotificationsCard         # noqa: E402

APP_ID  = "io.nyxus.notifications"
TITLE   = "NYXUS Notifications"
WIN_W   = 520
WIN_H   = 600


class NyxusNotificationsApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID,
                         flags=Gio.ApplicationFlags.FLAGS_NONE)

    def do_activate(self):
        win = self.props.active_window
        if win is None:
            install_css()
            win = Gtk.ApplicationWindow(application=self)
            win.set_title(TITLE)
            win.set_default_size(WIN_W, WIN_H)
            # Normal window — NEVER fullscreen / maximized
            win.set_resizable(True)
            win.add_css_class("home-root")

            outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                            spacing=0, margin_top=10, margin_bottom=10,
                            margin_start=10, margin_end=10)
            card = NotificationsCard()
            outer.append(card.root)
            win.set_child(outer)
        win.present()


def main():
    app = NyxusNotificationsApp()
    return app.run(sys.argv)


if __name__ == "__main__":
    raise SystemExit(main())
